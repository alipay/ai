---
name: alipay-enterprise-bill
description: 支付宝企业码账单专用 Skill。当用户提到"企业码账单"、"账单查询"、"账单通知"、"alipay.commerce.ec.consume"、"alipay.ebpp.invoice.ecorder"、"企业码消费账单"等相关关键词时必须使用此 Skill。帮助企业快速接入支付宝企业码账单能力，支持推模式账单查询（主要推荐），可选接入订单同步和对账单下载。
---

# 支付宝企业码账单 Skill

## 重要提示

支持两种使用方式：由方案型 Skill 调用时沿用上游已确定的账单模式、模块和消息接入方式；独立使用时按本文档完成必要决策。

生成方案或代码时：

1. 先确定账单模式、模块、消息接入方式、接口清单和 SDK 版本来源。
2. 接入某个模块时，必须覆盖该模块下全部接口和必要通知。
3. 生成前读取流程文档、接口文档、[账单通用代码生成规则](references/codegen-general-rules.md) 和 [账单字段和接口规则](references/field-interface-rules.md)；Java/Maven 场景还需读取 [账单 Java/Maven 质量门禁](references/quality-gates/java-maven.md)，Node.js 场景还需读取 [账单 Node.js 质量门禁](references/quality-gates/nodejs.md)，Python/Go/.NET 场景还需读取 [账单 Python/Go/.NET 质量门禁](references/quality-gates/python-go-dotnet.md)。
4. 按当前模块分段读取、分段生成、分段校验；基础推模式不得读取或实现订单同步、对账单下载等未选择文档。
5. 生成接口调用代码前必须完成对应语言的 SDK 或接入方式预检；Java/Maven 场景执行 Java SDK/Maven 预检。
6. 文档中找不到的字段、接口、通知或 SDK 能力，必须说明未找到，不能猜测生成。
7. 已有项目只做增量改造：第一轮只输出现有 SDK、Central Portal 当前 SDK 版本、账单服务、通知入口、目录结构、已有订单/费用记录/报销/对账 Entity/Service/Repository/Controller、已实现账单接口、业务衔接点和拟新增/修改文件清单，并按 [已有项目衔接契约](references/integration-contract.md) 给出拟定契约；Java/Maven 项目必须把 `alipay-sdk-java` 升级到当前版本列入计划，用户确认后才能写入契约并修改代码。上下文可推断时，账单通知必须衔接已有订单、费用记录、报销或对账对象；无法推断时暂停确认，不得默认生成仅幂等记录的旁路通知。
8. 代码生成环境必须运行本域自检脚本；Java/Maven、Node.js、Python、Go 和 .NET 项目会执行对应技术栈门禁，其他技术栈应使用对应语言的构建、测试和 SDK 校验方式。

由主方案 Skill 调用时，必须遵守主方案阶段闸门；未进入账单阶段前，不得读取账单接口文档。

由多 Agent 主方案调用时：

1. 第一轮必须输出 `已加载 Skill: alipay-enterprise-bill (<SKILL.md 路径>)`，并列出沿用的上游账单模式、模块、消息接入方式和允许写入范围。
2. 只处理账单代码和账单文档，不读取其他子 Skill。
3. 只生成或修改账单写入范围，例如 `src/main/java/**/bill/**`。
4. 不修改公共构建文件、配置文件、`README.md`、启动入口、SDK 配置或跨域消息聚合配置；已有项目中如需这些改动，只在回执中提出需求。
5. 输出本域已读文档、生成文件、接口和通知覆盖、本域自检结果、未覆盖边界。
6. 本域自检失败时先修正账单代码，不要求其他 Agent 兜底。

---

## 步骤 1：确定模式

企业码账单集成支持以下模式：

| 模式 | 说明 | 约束 |
|------|------|------|
| **推模式** | 接收员工消费账单变动通知，查询账单详情 | **必须接入**，为核心能力 |

**决策规则**：
- 方案型 Skill 调用：如果上游方案已确定账单模式、接入模块或消息接入方式，直接沿用，不要重复询问用户。
- 独立使用：如果没有上下文，默认使用推模式。
- 独立使用：订单同步和对账单下载仅在用户主动提出或上下文推断需要时接入。
- 消息接入方式：方案型调用时沿用上游统一决策；独立使用时按流程文档中的消息接入章节选择。

---

## 步骤 2：接入流程

根据选择的模式，查阅对应的接入流程文档：

| 模式 | 文档 |
|------|------|
| **推模式** | [推模式账单流程](references/push-mode/push-mode-flow.md) |

接入流程文档包含：
- 流程图
- 接口文档（含关键步骤备注）
- 可选功能（订单同步、对账单下载）
- 参考文档索引

---

## 附录：参考文档

| 文档 | 内容 |
|------|------|
| [账单扩展字段说明](references/common/bill-ext-info.md) | 账单 ext_infos 扩展字段详细说明 |
| [订单内容字段说明](references/common/order-content.md) | 订单 order_content 字段详细说明（地铁、外卖、其他场景） |
| [凭证内容字段说明](references/common/voucher-content.md) | 凭证 voucher_content 字段说明（发票、图片、视频、合规信息） |
| [费用类型枚举](references/common/expense-type-enum.md) | 费用类型和费用类型子类枚举 |
| [账单通用代码生成规则](references/codegen-general-rules.md) | 所有技术栈通用的字段、SDK/HTTP、验签、stub 和自检原则 |
| [已有项目衔接契约](references/integration-contract.md) | 已有项目增量接入时的业务衔接契约 |
| [账单字段和接口规则](references/field-interface-rules.md) | 字段、接口、枚举和响应解析规则 |
| [账单 Java/Maven 质量门禁](references/quality-gates/java-maven.md) | Java/Maven SDK、WebSocket 和工程质量门禁规则 |
| [账单 Node.js 质量门禁](references/quality-gates/nodejs.md) | Node.js SDK、HTTP(S) 通知验签、幂等和工程质量门禁规则 |
| [账单 Python/Go/.NET 质量门禁](references/quality-gates/python-go-dotnet.md) | Python/Go/.NET HTTP(S) 或 SDK 接入门禁规则 |

生成账单详情解析代码时，必须读取以上 common 文档，完整处理账单扩展字段、订单内容、凭证内容和费用类型枚举。

代码生成时先读取推模式流程文档、账单通用代码生成规则和账单字段和接口规则；再按技术栈读取对应质量门禁。随后按当前模块逐个读取接口文档、生成该模块代码并运行对应技术栈自检；不要预读未生成模块的接口文档。只有生成账单详情解析代码时，才读取对应账单扩展字段、订单内容、凭证内容和费用类型文档。

## 生成后校验

本 Skill 自带本域自检脚本，由 Skill/生成环境执行：

```bash
node alipay-enterprise-bill/scripts/validate_codegen.js <生成项目目录>
```

脚本会识别 Java/Maven、Node.js、Python、Go 和 .NET 项目。Java/Maven 项目校验账单必选接口/通知覆盖、SDK Model 使用、请求 setter 来源、必填顶层字段、通知和费用类型枚举、Java package 路径、禁止本地支付宝 SDK stub，以及 WebSocket 官方接入模式；Node.js 项目校验 SDK 导入、`appAuthToken`、通知验签、账单接口覆盖、幂等重试语义、模块加载和 `npm test`；Python/Go/.NET 项目校验账单接口覆盖、费用子类字段、通知验签占位和幂等提示，并在运行时存在时执行 Python 语法检查、`go test ./...`、`dotnet build` 或 PHP 语法检查。

退出码 `0` 表示通过，`1` 表示生成代码不符合门禁，`2` 表示 validator 自身执行不可信。
