# 已有项目衔接契约

已有项目增量接入时，第一轮先输出盘点和拟定契约，不修改代码。用户确认后，在生成目录写入 `.alipay-skill/integration-contract.json`，再开始账单代码修改。

契约用于说明账单通知、查询或解析结果接到哪些既有订单、费用、报销或对账对象。它不是业务运行依赖，只是 Skill 生成和校验证据。

最小结构：

```json
{
  "schemaVersion": 1,
  "projectMode": "existing",
  "baseline": {
    "sdkVersion": "当前项目版本",
    "targetSdkVersion": "Central Portal 当前版本",
    "buildStatus": "passed | failed | not-run"
  },
  "domains": {
    "bill": {
      "status": "CONFIRMED",
      "joinPoints": [
        {
          "capability": "consume.change",
          "status": "CONFIRMED",
          "strategy": "service",
          "evidenceFiles": ["src/main/.../TravelOrderService.java"],
          "symbols": ["TravelOrderService"]
        }
      ],
      "changes": [
        { "path": "src/main/.../BillNotifyHandler.java", "action": "add" }
      ]
    }
  },
  "gaps": []
}
```

规则：

1. `gaps` 中不得保留 `NEEDS_USER_CONFIRM`。
2. `domains.bill.status` 必须是 `CONFIRMED` 或 `NOT_APPLICABLE`。
3. `joinPoints` 支持 service、repository、controller、event、gateway、other 等策略，不要求 handler 直接引用某个类型。
4. `evidenceFiles` 和 `changes.path` 必须指向项目内真实文件，不得逃出项目目录。
5. 如果无法确认账单通知如何衔接已有订单、费用、报销或对账对象，先在 `gaps` 说明并暂停，不生成只写幂等记录的成功路径。

校验已有项目时使用：

```bash
ALIPAY_PROJECT_MODE=existing node alipay-enterprise-bill/scripts/validate_codegen.js <项目目录>
```
