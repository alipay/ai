# 账单 Python/Go/.NET 质量门禁

本文件只约束 Python、Go、.NET 等非 Java/Node.js 生成代码。通用原则见 [账单通用代码生成规则](../codegen-general-rules.md)，字段和接口来源见 [账单字段和接口规则](../field-interface-rules.md)。

1. 生成前必须确认当前语言使用官方 SDK 还是 HTTP(S) 网关调用；没有真实 SDK 能力时使用文档字段手拼请求体，但字段名和嵌套路径必须完全来自接口文档。
2. 推模式账单必须覆盖 `alipay.commerce.ec.consume.change.notify`、`alipay.commerce.ec.consume.detail.query`、`alipay.commerce.ec.consume.detail.batchquery`。
3. 账单费用子类字段必须使用 `expense_type_sub_category`；不得生成 `expense_type_sub`、`expense_sub_type`、`expense_sub_category` 等近义字段。
4. 账单费用类型和费用子类必须按 [费用类型枚举](../common/expense-type-enum.md) 成对使用；不得把某个子类（如 `DEFAULT`）当作所有费用类型的通用默认子类。
5. HTTP(S) 通知必须验签并具备幂等/重试语义；不得生成验签直接 `return true`、本地 SDK stub 或 mock-success 逻辑。
6. 生成后必须运行本域 validator；validator 会做跨语言接口覆盖、费用字段、通知验签占位检查，并在运行时存在时执行 Python 语法检查、`go test ./...`、`dotnet build` 或 PHP 语法检查。
