# 账单 Java/Maven 质量门禁

本文件只用于账单 Skill 生成 Java/Maven 代码时的工程质量、SDK、消息接入和失败处理门禁。跨语言通用原则见 [账单通用代码生成规则](../codegen-general-rules.md)，字段、接口、枚举和响应解析规则见 [账单字段和接口规则](../field-interface-rules.md)。非 Java 技术栈不要把本文件作为硬门禁。

## 输出注释

1. 生成代码注释中不得手写“字段白名单”“白名单字段”或“白名单：...”这类自报来源；文档真实枚举、规则因子或业务名称中包含“白名单”时可以保留。
2. 需要说明字段来源时，只写“字段来源：接口文档业务请求参数表”。

## Java SDK 来源

1. 账单域 Java 调用必须使用官方 `Request + Model + request.setBizModel(model)`；禁止对账单域 Request 手拼 `biz_content`、调用 `setBizContent`、用 JSON 或 Map 请求体绕过 SDK Model。该限制只约束账单域拥有的接口，不得扫描并拒绝发票等其他子 Skill 按其质量门禁使用的 `setBizContent + AlipayClient.execute` SDK 托管路径。
2. 禁止生成本地支付宝 SDK stub、mock 或影子类；源码中不得创建 `com.alipay.api` 包。
3. 生成 Java 代码前必须完成 SDK 预检。新 Maven 项目和已有项目叠加接入都必须用以下单条命令读取 Central Portal 页面，并从页面中的 `pkg:maven/com.alipay.sdk/alipay-sdk-java@<version>` 或 Maven dependency snippet 提取 `alipay-sdk-java` 当前版本：

```bash
curl -sL "https://central.sonatype.com/artifact/com.alipay.sdk/alipay-sdk-java"
```

4. Java/Maven 接入目标版本一律使用 Central Portal 当前版本。已有项目如果已有旧版 `alipay-sdk-java`，增量改造计划中必须列出升级依赖和同步说明文档；用户确认计划后执行升级。
5. 如果 auto mode、沙箱、网络策略或命令审批禁止执行上述 `curl`，不得改用记忆中的版本，也不得使用 `search.maven.org/solrsearch` 兜底；必须停止 Java/Maven 代码生成，请求用户授权执行该 `curl`，或要求用户明确提供 Central Portal 当前版本。
6. 提取出的 `alipay-sdk-java` 版本必须匹配 `^[0-9]+\.[0-9]+\.[0-9]+\.ALL$`。不符合该格式时，视为抓到了页面资源版本或其他无关版本，必须重新从 `pkg:maven/...@<version>` 或 dependency snippet 提取。
7. 必须用 `jar tf` 验证计划使用的 `Request`、`Response`、`Model`、`AlipayMsgClient`、`MsgHandler` 类真实存在。
8. 找不到 SDK getter/setter 或源码包缺失时，使用 `jar tf`、`javap -classpath <sdk.jar> <class>` 或 IDE 反编译确认真实类和方法；不得用反射、`getMethod/invoke`、`BeanUtils`、Map 包装等方式绕过官方 SDK Request/Model/Response 的编译期类型。
9. Maven 依赖解析或真实 SDK 编译失败时，保留官方 SDK 调用代码并基于 SDK 类型、版本和引用文档修正；不得改写为 stub、非 SDK Model 调用或猜测类名。
10. 禁止导入 SDK 中不存在或未实际使用的类；编译失败时必须删除 unused import 或改用真实存在的 SDK 类，不能新增本地影子类。
11. 禁止安全和接口完整性 stub：HTTP 通知验签必须使用 SDK 验签方法或证书验签方法，验签方法不得 `return true`；SDK 接口方法不得 `return null` 充数，也不得抛 `UnsupportedOperationException` 代替实现。显式的未配置 fail-closed Adapter 可以抛清晰异常，优先使用自定义 NotConfigured 异常。

## Java/Maven 工程质量

1. 生成环境必须运行本域 validator；该 Node 脚本属于 Skill 生成质量门禁，不作为接入方 Java 工程依赖。
2. 有 Maven 工程时必须尝试编译；编译失败时，必须保留官方 SDK 代码并基于依赖、类型或文档修正。
3. 校验失败时必须优先修正 SDK 类型、字段路径、通知枚举和响应解析结构；不得删除已选择模块的接口能力、方法或业务分支来绕过校验。确需裁剪时，必须在交付说明中明确列为未覆盖边界。
4. 代码目录可以按接入方习惯组织；校验以接口、SDK 类和业务字段识别域归属，不要求固定存在 `bill` 包。
5. 正式 Repository/Store 不得直接用进程内 Map/Set 保存账单、订单或通知状态；内存实现必须限制在显式 `test` / `demo` profile，不得包含 `default` profile。生产默认启动必须使用真实持久化实现，或落到无条件 fail-closed 实现。
6. Spring 注入接口如果只有 profile 条件实现，默认配置必须明确激活对应 profile，或提供无条件的真实/fail-closed 实现。
7. fail-closed 实现不得只放在 `demo` profile；默认 profile 必须能装配真实实现或 fail-closed 实现。默认 fail-closed Bean 必须使用 `@ConditionalOnMissingBean(<接口>.class)` 或互斥 profile，让接入方真实 Store/Repository/Port 注册后自动让位；demo/test profile 只能承载示例内存实现。
8. `application-<profile>.yml` / `application-<profile>.properties` 中不得设置 `spring.profiles.active`，需要激活 profile 时只能在基础配置、启动参数或环境变量中设置。
9. 生成工程必须包含可执行测试。通知场景至少覆盖正常处理、失败重试、未知消息、幂等状态；Spring Boot 新工程还必须有上下文装配测试。`mvn test` 执行零个测试不算通过。
10. 账单详情查询测试必须覆盖已选择 `query_options` 的响应投影，证明关联订单、凭证、退款等数据经过响应转换后仍能到达业务 Port，而不是只验证接口被调用。
11. 方案型 Skill 提供 `billIdentifiers` 时，生成代码必须把已确认字段用于实际识别、路由、过滤或失败策略；只把 `scene_code`、`order_type`、费用类型或子类写成日志、warn 校验、常量或注释不算通过。

## Java 消息接入

独立使用账单 Skill 且选择 Java WebSocket 时：

1. 只允许官方 `AlipayMsgClient + MsgHandler`；不得引入 `Java-WebSocket`、`javax.websocket`、`jakarta.websocket`。
2. 不得手写连接协议层、鉴权消息、心跳、ack 或自定义验签流程；业务代码只处理 `MsgHandler.onMessage` 收到的消息内容。
3. 必须生成可执行接入代码：持有 `AlipayMsgClient` 实例，完成 `getInstance`、`setSecurityConfig(signType, privateKey, alipayPublicKey)`、`setMessageHandler`、`connect` 和关闭逻辑；`setSecurityConfig` 第一个参数是签名类型（通常 `RSA2`），不得传 `appId`。
4. `MsgHandler.onMessage` 分发到业务 handler 后必须处理失败结果；业务 handler 返回 `false`、`fail` 或抛异常时，路由层必须转换为异常或明确失败路径，不能只记录日志后吞掉失败。
5. 未知 `msgApi` / `msg_method` / `consume_type` 默认不得返回 success、`true` 或标记已处理；必须返回 fail、抛异常，或委托显式 unknown handler 并由该 handler 明确是否可确认消费。
6. 账单通知幂等获取必须区分首次获得、已完成和正在处理；正在处理必须进入可重试失败路径。生产默认幂等存储不得使用进程内 Map/Set，除非被明确限制在 demo/test profile。
7. 通知处理如果构造或修改了业务状态后又删除当前记录，必须持久化、归档或发布该状态迁移。

被方案型 Skill 调用并由主方案统一消息接入时，本域不得生成独立 `AlipayMsgClient.getInstance`、`setMessageHandler` 或 `connect`；只生成可被主路由器调用的账单业务 handler。

## HTTP 通知接入

1. HTTP 通知可以读取 `biz_content` 并解析业务内容，但必须完成真实验签。
2. HTTP 通知和 WebSocket 长连接是两种接入模式，不得把 WebSocket `MsgHandler` 收到的业务内容再按 HTTP 通知公共参数验签。
