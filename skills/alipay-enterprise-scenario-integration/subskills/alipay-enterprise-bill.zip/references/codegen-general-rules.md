# 账单通用代码生成规则

本文件适用于所有技术栈。具体技术栈门禁见 [账单 Java/Maven 质量门禁](quality-gates/java-maven.md)、[账单 Node.js 质量门禁](quality-gates/nodejs.md) 和 [账单 Python/Go/.NET 质量门禁](quality-gates/python-go-dotnet.md)。

1. 接口、字段、枚举、通知、账单类型和响应解析结构只来自已读取文档；文档未找到时说明缺失，不猜测补齐。
2. 请求字段、响应字段、通知字段分开使用，不得互相迁移。
3. 必须使用对应语言的官方 SDK，或文档支持的 HTTP(S) 接入方式。
4. 不得生成 stub、mock、空实现或固定成功返回来绕过编译、验签、接口缺失或能力缺失。
5. 通知接入必须实现真实验签、幂等、重复通知和失败处理。
6. 账单通知幂等必须使用通知文档中的唯一业务键，消费账单默认使用 `pay_no`；只有业务处理成功后才能标记为已处理，如果先占位锁定，失败路径必须释放或标记为可重试。获取处理权时必须区分“首次获得”“已完成”“正在处理”，正在处理不得按已完成确认成功。生产默认幂等存储必须支持多实例和进程重启，进程内 Map/Set 只能用于明确的 demo/test 配置；不得挂在 `default` profile 或默认生产路径。
7. 接入方业务逻辑可以通过 Port、Adapter、回调接口或等价扩展点交付；扩展点尚未绑定真实实现时必须失败关闭，例如抛出明确的未配置异常、返回文档允许的失败结果或阻止应用启动。需要服务商替换成 DB/Redis/业务系统实现的 Store、Repository、Callback、Port 必须先定义接口，核心 Service/Handler 只能依赖接口，不能依赖 demo/test 具体类。默认 fail-closed Bean 必须能被接入方真实实现无冲突覆盖，例如使用 `@ConditionalOnMissingBean` 或互斥 profile。显式 fail-closed Adapter 可以抛异常，优先使用自定义 NotConfigured 异常；`UnsupportedOperationException` 仅允许出现在边界清晰的 fail-closed 默认 Adapter 中，不得代替 SDK 调用、安全校验或已选择业务能力的实现。不得回显请求值来构造允许/成功结果，也不得只记录日志或只更新幂等状态后确认业务成功。
8. Spring profile 只用于 demo/test 存储、示例回调、mock Adapter 或样例配置；消息 Handler、Router、Controller、Service、AutoConfiguration、启动入口等核心运行组件不得被 `demo`/`test` profile 包住，否则生产环境会启动但链路缺失。
9. Spring 自动配置不得在 `@PostConstruct` 或构造过程中直接调用本类 `@Bean` 方法来获取对象或注册路由；应注入真实 Spring Bean、`ObjectProvider` 或监听应用事件，避免绕过 `@ConditionalOnBean`、`@Profile` 和真实实现优先级。
10. 账单详情查询失败是否允许忽略，必须按接入方业务语义明确：若详情是后续处理必需数据，应返回失败或抛异常等待重试；只有明确作为补充信息时才可降级记录。
11. 未知通知类型、未知 `msg_method` 或未知 `consume_type` 默认不得成功确认；除非显式 unknown handler 写清确认策略，否则必须返回失败或抛异常。
12. 已有项目增量接入时，第一轮只盘点现有 SDK、Central Portal 当前 SDK 版本、配置、账单服务、通知入口、目录结构、已有订单/费用记录/报销/对账 Entity/Service/Repository/Controller 和已实现账单接口，并输出业务衔接点、拟新增/修改文件清单和拟定 `.alipay-skill/integration-contract.json`；Java/Maven 项目必须把 `alipay-sdk-java` 升级到当前版本列入计划，用户确认前不得修改代码或写入契约。
13. 已有项目不得重写公共构建文件、配置体系、启动入口或现有通知网关；如需公共改动，先列为计划或回执中的待处理项。
14. 已有项目中，账单通知默认必须衔接已有订单、费用记录、报销或对账对象；只查询账单、只写幂等记录或不更新业务对象的旁路处理，必须先说明原因并等待用户确认。
15. 方案型 Skill 传入 `.alipay-skill/scenario.json` 时，`billIdentifiers` 中已确认的账单识别字段必须参与实际识别、路由、过滤或失败策略；不得只作为常量、注释、日志、warn 校验或交付说明。通知缺少场景识别字段时，不能直接按命中场景处理；应查询详情后再判断，或按明确失败/跳过策略处理并记录原因。
16. 已有项目生成后必须使用 `ALIPAY_PROJECT_MODE=existing` 运行本域 validator；契约中不得保留 `NEEDS_USER_CONFIRM`，声明的文件和符号必须真实存在。
17. 生成后必须运行对应语言的依赖解析、构建、测试或最接近的自检；无法运行时说明原因。已有项目全量测试原本失败时，记录 baseline 并运行本域/增量范围自检。
18. SDK 或文档不支持时，说明不支持，不猜类名、方法名、接口名、字段名或账单类型。
19. 本域 validator 运行时使用 `curl` 从 `interface-docs.json` 记录的官方 URL 获取当前 Markdown，并对临时网络失败自动重试。运行环境必须能访问 `opendocs.alipay.com`；重试后仍无法获取时按 validator 基础设施失败处理，不得使用历史字段或枚举继续校验。
