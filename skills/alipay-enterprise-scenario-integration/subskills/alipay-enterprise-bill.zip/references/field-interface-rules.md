# 账单字段和接口生成规则

本文件只约束账单字段来源、接口完整性、枚举来源和响应解析边界。跨语言生成原则见 [账单通用代码生成规则](codegen-general-rules.md)，各技术栈工程门禁见对应质量门禁文档。

## 通用规则

1. 接口、通知、请求字段、枚举和响应解析字段只来自当前模块已读取的流程文档、接口文档和 common 文档。
2. 请求字段必须保留文档路径；顶层字段如 `pay_no`，嵌套字段如 `order_info.pay_no`。
3. 通知字段、响应字段和请求字段分开使用，不能互相迁移。
4. 字段或枚举校验失败时，先修正文档路径或枚举来源；文档未找到时说明缺失。

## 模块完成标准

- 账单管理（推模式）：账单变动通知 `alipay.commerce.ec.consume.change.notify`、`alipay.commerce.ec.consume.detail.query`、`alipay.commerce.ec.consume.detail.batchquery`，并读取账单扩展字段、订单内容、凭证内容、费用类型枚举文档。
- 订单同步：一旦接入，必须覆盖订单同步流程文档中的订单同步、订单变更通知和订单查询接口。
- 对账单下载：一旦接入，必须覆盖对账单流程文档中的账期设置和下载地址查询接口。

## 接口隔离约束

- 账单通知字段、单笔查询字段、批量查询字段、订单同步字段、对账单字段必须分开处理，不能互相迁移。
- `consume.detail.query` 与 `consume.detail.batchquery` 是不同接口；批量查询不能自动继承单笔查询的 `pay_no`、`query_options` 等字段，除非批量查询文档明确列出。
- 单笔查询一旦通过 `query_options` 请求关联数据，就必须读取对应响应字段并传递到业务处理边界：`Order` 对应 `related_order_info`，`Ticket` / `Compliance` 对应 `related_voucher_list`，`Refund` 对应 `related_refund_list`。不能只设置查询选项，却在 DTO、转换层或业务 Port 前丢弃返回数据。
- 账单扩展字段、订单内容和凭证内容用于响应解析时，必须读取对应 common 文档；不得把响应字段写入请求参数。
- 通知 switch case 和账单类型判断只能使用文档枚举；不得按业务含义自造近义枚举。
- 费用类型和费用子类必须按 [费用类型枚举](common/expense-type-enum.md) 成对使用；不得把某个子类当作所有费用类型的通用默认子类。
