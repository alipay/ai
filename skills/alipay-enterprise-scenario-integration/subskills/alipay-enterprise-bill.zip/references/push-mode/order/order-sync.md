# alipay.commerce.ec.order.sync(订单信息同步)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
企业码业务场景订单同步
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.commerce.ec.order.sync|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://opendocs.alipay.com/isv/10467/xldcyq)||
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|out_biz_no|String|必须|128|商家侧自定义订单号，同一笔订单必须保证唯一|qym_order_001|
|order_create_time|Date|必须|32|商家侧订单实际创建时间|2025-05-01 00:00:01|
|order_pay_time|Date|特殊可选|32|商家侧订单实际支付时间**必选条件**订单状态已流转到“支付”或支付后时，需要将支付时间传入|2025-05-01 00:00:01|
|order_modified_time|Date|必须|32|订单修改时间较晚的信息会被最终存储|2025-05-01 00:00:01|
|buyer_id|String|特殊可选|32|商家订单实际的买家uid新商户建议使用buyer_open_id替代该字段。对于新商户，buyer_id字段未来计划逐步回收，存量商户可继续使用。如使用buyer_open_id，请确认 应用-开发配置-openid配置管理 已启用。无该配置项，可查看[openid配置申请](https://opendocs.alipay.com/mini/0ai9ok?pathHash=de631c06)。|2088000123456789|
|buyer_open_id|String|特殊可选|128|买家用户的支付宝openid&nbsp; 详情可查看[ openid简介](https://opendocs.alipay.com/mini/0ai2i6?pathHash=13dd5946)|074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5|
|amount|Price|特殊可选|14|商家侧订单实际金额，金额单位为元**必选条件**订单不涉及金额可不传入该字段，其他场景必传，金额单位为元|10.05|
|discount_amount|Price|必须|14|商家侧订单优惠金额，金额单位为元|1.00|
|pay_amount|Price|特殊可选|14|商家侧订单实际支付金额，金额单位为元**必选条件**订单不涉及金额可不传入该字段，其他场景必传|10.00|
|trade_no|String|特殊可选|64|商家侧订单使用支付宝支付时，对应的支付宝交易号**必选条件**涉及支付的交易场景必传|2025050122001433721435458112|
|source_app|String|必须|64|订单发生的平台，默认为Alipay|Alipay|
|goods_info|EcOrderGoodsInfo|必须||订单商品信息列表||
|goods_info.goods_name|String|必须|256|订单所包含的商品名称|xxx食堂，xxx档口，xxx套餐|
|goods_info.ext_info|EcOrderExtInfo|必须||商品扩展信息||
|goods_info.ext_info.ext_key|String|必须|64|键值|MY_KEY|
|goods_info.ext_info.ext_value|String|必须|1024|值|MY_VALUE|
|ext_info|EcOrderExtInfo|必须||订单扩展信息||
|ext_info.ext_key|String|必须|64|键值|MY_KEY|
|ext_info.ext_value|String|必须|1024|值|MY_VALUE|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.response.AlipayCommerceEcOrderSyncResponse;
import com.alipay.api.domain.EcOrderGoodsInfo;
import com.alipay.api.domain.EcOrderExtInfo;
import com.alipay.api.request.AlipayCommerceEcOrderSyncRequest;
import com.alipay.api.domain.AlipayCommerceEcOrderSyncModel;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class AlipayCommerceEcOrderSync {

    public static void main(String[] args) throws AlipayApiException, ParseException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT+8"));

        // 构造请求参数以调用接口
        AlipayCommerceEcOrderSyncRequest request = new AlipayCommerceEcOrderSyncRequest();
        AlipayCommerceEcOrderSyncModel model = new AlipayCommerceEcOrderSyncModel();
        
        // 设置外部订单号
        model.setOutBizNo("qym_order_001");
        
        // 设置订单创建时间
        model.setOrderCreateTime(sdf.parse("2025-05-01 00:00:01"));
        
        // 设置订单支付时间
        model.setOrderPayTime(sdf.parse("2025-05-01 00:00:01"));
        
        // 设置订单修改时间
        model.setOrderModifiedTime(sdf.parse("2025-05-01 00:00:01"));
        
        // uid参数未来计划废弃，存量商户可继续使用，新商户请使用openid。请根据应用-开发配置-openid配置选择支持的字段。
        // model.setBuyerId("2088000123456789");
        
        // 设置买家用户的支付宝openid
        model.setBuyerOpenId("074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5");
        
        // 设置订单金额
        model.setAmount("10.05");
        
        // 设置优惠金额
        model.setDiscountAmount("1.00");
        
        // 设置订单支付金额
        model.setPayAmount("10.00");
        
        // 设置支付宝交易号
        model.setTradeNo("2025050122001433721435458112");
        
        // 设置订单来源
        model.setSourceApp("Alipay");
        
        // 设置商品信息列表
        List<EcOrderGoodsInfo> goodsInfo = new ArrayList<EcOrderGoodsInfo>();
        EcOrderGoodsInfo goodsInfo0 = new EcOrderGoodsInfo();
        goodsInfo0.setGoodsName("xxx食堂，xxx档口，xxx套餐");
        List<EcOrderExtInfo> extInfodrSWc = new ArrayList<EcOrderExtInfo>();
        EcOrderExtInfo extInfodrSWc0 = new EcOrderExtInfo();
        extInfodrSWc0.setExtKey("MY_KEY");
        extInfodrSWc0.setExtValue("MY_VALUE");
        extInfodrSWc.add(extInfodrSWc0);
        goodsInfo0.setExtInfo(extInfodrSWc);
        goodsInfo.add(goodsInfo0);
        model.setGoodsInfo(goodsInfo);
        
        // 设置订单扩展信息
        List<EcOrderExtInfo> extInfoUHwew = new ArrayList<EcOrderExtInfo>();
        EcOrderExtInfo extInfoUHwew0 = new EcOrderExtInfo();
        extInfoUHwew0.setExtKey("MY_KEY");
        extInfoUHwew0.setExtValue("MY_VALUE");
        extInfoUHwew.add(extInfoUHwew0);
        model.setExtInfo(extInfoUHwew);
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayCommerceEcOrderSyncResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayCommerceEcOrderSyncRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayCommerceEcOrderSyncRequest();
$model = array();

// 设置外部订单号
$model['out_biz_no'] = "qym_order_001";

// 设置订单创建时间
$model['order_create_time'] = "2025-05-01 00:00:01";

// 设置订单支付时间
$model['order_pay_time'] = "2025-05-01 00:00:01";

// 设置订单修改时间
$model['order_modified_time'] = "2025-05-01 00:00:01";

// uid参数未来计划废弃，存量商户可继续使用，新商户请使用openid。请根据应用-开发配置-openid配置选择支持的字段。
// $model['buyer_id'] = "2088000123456789";

// 设置买家用户的支付宝openid
$model['buyer_open_id'] = "074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5";

// 设置订单金额
$model['amount'] = "10.05";

// 设置优惠金额
$model['discount_amount'] = "1.00";

// 设置订单支付金额
$model['pay_amount'] = "10.00";

// 设置支付宝交易号
$model['trade_no'] = "2025050122001433721435458112";

// 设置订单来源
$model['source_app'] = "Alipay";

// 设置商品信息列表
$goodsInfo = array();
$goodsInfo0 = array();
$goodsInfo0['goods_name'] = "xxx食堂，xxx档口，xxx套餐";
$extInfoHOqzj = array();
$extInfoHOqzj0 = array();
$extInfoHOqzj0['ext_key'] = "MY_KEY";
$extInfoHOqzj0['ext_value'] = "MY_VALUE";
$extInfoHOqzj[] = $extInfoHOqzj0;
$goodsInfo0['ext_info'] = $extInfoHOqzj;
$goodsInfo[] = $goodsInfo0;
$model['goods_info'] = $goodsInfo;

// 设置订单扩展信息
$extInfoVuVlL = array();
$extInfoVuVlL0 = array();
$extInfoVuVlL0['ext_key'] = "MY_KEY";
$extInfoVuVlL0['ext_value'] = "MY_VALUE";
$extInfoVuVlL[] = $extInfoVuVlL0;
$model['ext_info'] = $extInfoVuVlL;

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayCommerceEcOrderSync
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayCommerceEcOrderSyncRequest request = new AlipayCommerceEcOrderSyncRequest();
            AlipayCommerceEcOrderSyncModel model = new AlipayCommerceEcOrderSyncModel();
            
            // 设置外部订单号
            model.OutBizNo = "qym_order_001";
            
            // 设置订单创建时间
            model.OrderCreateTime = "2025-05-01 00:00:01";
            
            // 设置订单支付时间
            model.OrderPayTime = "2025-05-01 00:00:01";
            
            // 设置订单修改时间
            model.OrderModifiedTime = "2025-05-01 00:00:01";
            
            // uid参数未来计划废弃，存量商户可继续使用，新商户请使用openid。请根据应用-开发配置-openid配置选择支持的字段。
            // model.BuyerId = "2088000123456789";
            
            // 设置买家用户的支付宝openid
            model.BuyerOpenId = "074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5";
            
            // 设置订单金额
            model.Amount = "10.05";
            
            // 设置优惠金额
            model.DiscountAmount = "1.00";
            
            // 设置订单支付金额
            model.PayAmount = "10.00";
            
            // 设置支付宝交易号
            model.TradeNo = "2025050122001433721435458112";
            
            // 设置订单来源
            model.SourceApp = "Alipay";
            
            // 设置商品信息列表
            List<EcOrderGoodsInfo> goodsInfo = new List<EcOrderGoodsInfo>();
            EcOrderGoodsInfo goodsInfo0 = new EcOrderGoodsInfo();
            goodsInfo0.GoodsName = "xxx食堂，xxx档口，xxx套餐";
            List<EcOrderExtInfo> extInfoNAvJY = new List<EcOrderExtInfo>();
            EcOrderExtInfo extInfoNAvJY0 = new EcOrderExtInfo();
            extInfoNAvJY0.ExtKey = "MY_KEY";
            extInfoNAvJY0.ExtValue = "MY_VALUE";
            extInfoNAvJY.Add(extInfoNAvJY0);
            goodsInfo0.ExtInfo = extInfoNAvJY;
            goodsInfo.Add(goodsInfo0);
            model.GoodsInfo = goodsInfo;
            
            // 设置订单扩展信息
            List<EcOrderExtInfo> extInfoGjFwp = new List<EcOrderExtInfo>();
            EcOrderExtInfo extInfoGjFwp0 = new EcOrderExtInfo();
            extInfoGjFwp0.ExtKey = "MY_KEY";
            extInfoGjFwp0.ExtValue = "MY_VALUE";
            extInfoGjFwp.Add(extInfoGjFwp0);
            model.ExtInfo = extInfoGjFwp;
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayCommerceEcOrderSyncResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.commerce.ec.order.sync&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"out_biz_no":"qym_order_001",
	"order_create_time":"2025-05-01 00:00:01",
	"order_pay_time":"2025-05-01 00:00:01",
	"order_modified_time":"2025-05-01 00:00:01",
	"buyer_id":"2088000123456789",
	"buyer_open_id":"074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5",
	"amount":"10.05",
	"discount_amount":"1.00",
	"pay_amount":"10.00",
	"trade_no":"2025050122001433721435458112",
	"source_app":"Alipay",
	"goods_info":[
		{
			"goods_name":"xxx食堂，xxx档口，xxx套餐",
			"ext_info":[
				{
					"ext_key":"MY_KEY",
					"ext_value":"MY_VALUE"
				}
			]
		}
	],
	"ext_info":[
		{
			"ext_key":"MY_KEY",
			"ext_value":"MY_VALUE"
		}
	]
}' 
```
 

### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|order_sync_id|String|必须|34|订单同步成功后产生的支付宝订单号|2025050100502300190500000000102188|
### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_commerce_ec_order_sync_response":{
		"code":"10000",
		"msg":"Success",
		"order_sync_id":"2025050100502300190500000000102188"
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_commerce_ec_order_sync_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|PERMISSION_DENIED|调用方无权限调用改接口|请联系企业码客服或技术支持|