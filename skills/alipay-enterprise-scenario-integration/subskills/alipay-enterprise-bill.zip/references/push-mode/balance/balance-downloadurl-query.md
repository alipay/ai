# alipay.commerce.ec.balance.downloadurl.query(对账单文件下载接口)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
对账单文件下载接口
注意：【调用条件】：无【返回约束】：无【其他】：无
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.commerce.ec.balance.downloadurl.query|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://opendocs.alipay.com/isv/10467/xldcyq)||
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|特殊可选|32|企业ID**注意事项**通过企业码2.0签约接口签约，如填写企业id，accout_id和agreement_no可以不填写|2088123456789000|
|account_id|String|特殊可选|32|共同账户ID**注意事项**通过企业码1.0接口签约的共同账户，和agreement_no搭配使用。|2088000295356628|
|agreement_no|String|特殊可选|128|授权签约协议号**注意事项**可通过签约消息获取。配合共同账户id使用，当填写企业共同账户id时，此字段必填。|20205820659822371223|
|bill_type|String|必须|16|账单类型**注意事项**商户通过接口或商户经开放平台授权后其所属服务商通过接口可以获取以下账单类型，支持： enterprisetrade：商户基于企业码交易收单的业务账单;|enterprisetrade|
|bill_date|String|必须|16|账单时间**注意事项**日账单格式为yyyy-MM-dd，最早可下载2016年1月1日开始的日账单。不支持下载当日账单，只能下载前一日24点前的账单数据（T+1），当日数据一般于次日 9 点前生成，特殊情况可能延迟。 月账单格式为yyyy-MM，最早可下载2016年1月开始的月账单。不支持下载当月账单，只能下载上一月账单数据，当月账单一般在次月 3 日生成，特殊情况可能延迟。|yyyy-MM-dd|
### 请求示例
#### 默认示例
##### java
```
 AlipayClient alipayClient = new DefaultAlipayClient("https://openapi.alipay.com/gateway.do","app_id","your private_key","json","GBK","alipay_public_key","RSA2");
AlipayCommerceEcBalanceDownloadurlQueryRequest request = new AlipayCommerceEcBalanceDownloadurlQueryRequest();
request.setBizContent("{" +
"  \"enterprise_id\":\"2088123456789000\"," +
"  \"account_id\":\"2088000295356628\"," +
"  \"agreement_no\":\"20205820659822371223\"," +
"  \"bill_type\":\"enterprisetrade\"," +
"  \"bill_date\":\"yyyy-MM-dd\"" +
"}");
AlipayCommerceEcBalanceDownloadurlQueryResponse response = alipayClient.execute(request);
if(response.isSuccess()){
System.out.println("调用成功");
} else {
System.out.println("调用失败");
}
```
 

##### php
```
 $aop = new AopClient ();
$aop->gatewayUrl = 'https://openapi.alipay.com/gateway.do';
$aop->appId = 'your app_id';
$aop->rsaPrivateKey = '请填写开发者私钥去头去尾去回车，一行字符串';
$aop->alipayrsaPublicKey='请填写支付宝公钥，一行字符串';
$aop->apiVersion = '1.0';
$aop->signType = 'RSA2';
$aop->postCharset='GBK';
$aop->format='json';
$request = new AlipayCommerceEcBalanceDownloadurlQueryRequest ();
$request->setBizContent("{" .
"  \"enterprise_id\":\"2088123456789000\"," .
"  \"account_id\":\"2088000295356628\"," .
"  \"agreement_no\":\"20205820659822371223\"," .
"  \"bill_type\":\"enterprisetrade\"," .
"  \"bill_date\":\"yyyy-MM-dd\"" .
"}");
$result = $aop->execute ( $request); 

$responseNode = str_replace(".", "_", $request->getApiMethodName()) . "_response";
$resultCode = $result->$responseNode->code;
if(!empty($resultCode)&&$resultCode == 10000){
echo "成功";
} else {
echo "失败";
}
```
 

##### csharp
```
 IAopClient client = new DefaultAopClient("https://openapi.alipay.com/gateway.do", "app_id", "merchant_private_key", "json", "1.0", "RSA2", "alipay_public_key", "GBK", false);
AlipayCommerceEcBalanceDownloadurlQueryRequest  request= new AlipayCommerceEcBalanceDownloadurlQueryRequest() ;
request.BizContent="{" +
"  \"enterprise_id\":\"2088123456789000\"," +
"  \"account_id\":\"2088000295356628\"," +
"  \"agreement_no\":\"20205820659822371223\"," +
"  \"bill_type\":\"enterprisetrade\"," +
"  \"bill_date\":\"yyyy-MM-dd\"" +
"}";
AlipayCommerceEcBalanceDownloadurlQueryResponse response=client.Execute(request);
Console.WriteLine(response.Body);
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.commerce.ec.balance.downloadurl.query&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"enterprise_id":"2088123456789000",
	"account_id":"2088000295356628",
	"agreement_no":"20205820659822371223",
	"bill_type":"enterprisetrade",
	"bill_date":"yyyy-MM-dd"
}' 
```
 

### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|bill_download_url|String|必须|256|对账单下载地址链接**注意事项**获取连接后3分钟后未下载，链接地址失效|https://mdgwdev.alipay.net/induspt_invoice/afts/file/A*hmt6Trd6OpUAAAAAAAAAAAAAAUYnAA?t=GWVhXq9S4K55nzCCaDB_fgAAAABkJ0ZiucEy&af_fileName=%E6%9C%88%E5%AF%B9%E8%B4%A6%E5%8D%95_2022-05-15.xlsx|
### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_commerce_ec_balance_downloadurl_query_response":{
		"code":"10000",
		"msg":"Success",
		"bill_download_url":"https://mdgwdev.alipay.net/induspt_invoice/afts/file/A*hmt6Trd6OpUAAAAAAAAAAAAAAUYnAA?t=GWVhXq9S4K55nzCCaDB_fgAAAABkJ0ZiucEy&af_fileName=%E6%9C%88%E5%AF%B9%E8%B4%A6%E5%8D%95_2022-05-15.xlsx"
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_commerce_ec_balance_downloadurl_query_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|BALANCE_HAS_NO_CONSUME|无交易记录|当前账期无交易记录，未生成对账单|
|DAILY_BALANCE_RECORD_NOT_EXIST|日对账单未生成|日对账单生成延迟，请稍后重试|
|MONTH_BALANCE_RECORD_NOT_EXIST|月对账单未生成|月对账单生成延迟，请稍后重试|
|PARAMETER_ILLEGAL|参数有误参数不合法|可以通过修改返回错误的参数来解决，如按照文档中参数格式要求重试后未能解决，请联系企业码客服或技术支持|
|PERMISSION_DENIED|权限不足|可以通过检查入参的企业ID来解决，如确认企业ID无误后未能解决，请联系企业码客服或技术支持|