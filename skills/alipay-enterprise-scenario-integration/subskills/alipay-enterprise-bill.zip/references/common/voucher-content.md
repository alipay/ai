# 凭证 voucher_content 字段说明

本文档详细说明账单详情查询接口返回的凭证信息字段结构，包括发票、图片、视频、合规信息等。

---

## Invoice（发票）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| total_amount | String | 消费总金额 | |
| file_infos | List | 文件信息 | 见 EcFileInfo 定义 |
| invoice_code | String | 发票代码 | |
| invoice_no | String | 发票号码 | |
| sum_amount | String | 价税合计，票面上的总开票金额，保留两位小数，单位：元 | sum_amount = without_tax_amount + tax_amount |
| without_tax_amount | String | 不含税金额，票面上的不含税金额，保留两位小数，单位：元 | |
| tax_amount | String | 合计税额，票面上的合计税额，保留两位小数，单位：元 | |
| invoice_kind | String | 票种 | 增值税普通电子发票：E_PLAN<br>增值税普通发票：PLAN<br>增值税专用发票：SPECIALTY<br>增值税专用电子发票：E_SPECIALTY<br>电子发票（普通发票）：ALL_ELECTRONIC_GENERAL<br>电子发票（增值税专用发票）：ALL_ELECTRONIC_SPECIAL |
| check_code | String | 校验码 | |
| ant_fake_code | String | 发票防伪码 | |
| invoice_payee_info | EcInvoicePayeeInfo | 销方信息 | 见下方定义 |
| invoice_payer_info | EcInvoicePayerInfo | 购方信息 | 见下方定义 |
| invoice_items | List | 发票明细 | 见 EcInvoiceItem 定义 |
| invoice_extend_info | EcInvoiceExtendInfo | 发票扩展信息 | 见下方定义 |

### EcInvoicePayeeInfo（销方信息）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| payee_register_no | String | 销方税号 | |
| payee_name | String | 销方企业名称 | |
| payee_phone | String | 销方联系电话 | |
| payee_address | String | 销方地址（可能拼接输出，地址+电话） | |
| payee_bank_name | String | 销方银行（可能拼接输出，银行+银行账户） | |
| payee_bank_account_id | String | 销方银行账户（可能拼接输出，银行+银行账户） | |

### EcInvoicePayerInfo（购方信息）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| payer_register_no | String | 购方税号 | |
| business_type | String | 购方抬头类型 | 个人：0<br>企业：1 |
| payer_name | String | 购方企业名称 | |
| payer_phone | String | 购方联系电话 | |
| payer_address | String | 购方地址（可能拼接输出，地址+电话） | |
| payer_bank_name | String | 购方银行（可能拼接输出，银行+银行账户） | |
| payer_bank_account_id | String | 购方银行账户（可能拼接输出，银行+银行账户） | |

### EcInvoiceItem（发票明细）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| row_type | String | 发票行性质 | 正常行：0<br>折扣行：1<br>被折扣行：2 |
| amount | String | 价税合计 | 单位：元，格式为2位小数；amount = sum_price + tax |
| sum_price | String | 总价(不含税) | 单位：元 |
| tax | String | 税额 | 单位：元，格式为2位小数 |
| price | String | 单价(不含税) | 格式为2位小数，最大支持6位小数；正常行与被折扣行（row_type=0或2）可缺省 |
| unit | String | 单位 | |
| quantity | String | 数量 | 最多6位小数；正常行与被折扣行（row_type=0或2）可缺省 |
| specification | String | 规格型号 | |
| tax_rate | String | 税率 | 格式为2位小数 |
| item_name | String | 发票项目名称/货物名称 | |
| item_no | String | 税收分类编码 | |
| zero_rate_flag | String | 零税率标识 | 出口零税率：0<br>免税：1<br>不征收：2<br>普通零税率：3<br>（只有税率为零的情况才有值） |

### EcInvoiceExtendInfo（发票扩展信息）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| invoice_type | String | 发票类型 | 蓝票：blue<br>红票：red |
| invoice_status | String | 发票状态 | 正常：0<br>失效：1 |
| invoice_memo | String | 发票备注 | |
| payee_operator | String | 操作人 | |
| payee_receiver | String | 收款人 | |
| payee_checker | String | 复核人 | |

### EcFileInfo（文件信息）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| file_url | String | 文件下载地址 | 示例：https://gw.alipayobjects.com/... |
| file_type | String | 文件类型 | PDF文件：PDF<br>OFD文件：OFD<br>视频：VIDEO<br>图片：PIC |

---

## Picture（图片）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| file_info | EcFileInfo | 文件信息 | 见上方 EcFileInfo 定义 |

---

## Video（视频）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| file_info | EcFileInfo | 文件信息 | 见上方 EcFileInfo 定义 |
| snapshot_info | EcFileInfo | 首帧图片信息 | 见上方 EcFileInfo 定义 |

---

## Compliance（合规信息）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| compliance_risk_result | Boolean | 交易合规风险判定结果 | 交易存在风险时，该项结果为：true<br>未识别到风险时（包含无风险，无法判断及风险检测还未运行三种场景），该项结果为：false |
| compliance_risk_detail_info_list | List | 合规风险详情 | 完成检测的风险项，该值必选；未检测的风险项不会列出 |

### ComplianceRiskDetailInfo（合规风险详情）

| 字段名 | 字段类型 | 字段含义 | 备注 |
|--------|----------|----------|------|
| compliance_label | String | 合规标签 | 风险名称，见下方枚举定义 |
| result | String | 判定结果 | 该项存在风险，该项结果为：RISKY<br>该项风险未知，该项结果为：PASSED |
| remark | String | 备注 | 风险备注信息 |

### 合规标签（compliance_label）定义

| 标签名称 | 含义 |
|----------|------|
| NEW_STORE_TRANS_RISK | 新店交易风险 |
| EMPLOYEE_RECEIPT_RISK | 员工收款风险 |
| ENTERPRISE_HIGH_FREQ_TRANS_RISK | 企业高频交易风险 |
| EMPLOYEE_HIGH_FREQ_TRANS_RISK | 员工高频交易风险 |
| ABNORMAL_LARGE_TRANS_RISK | 异常大额交易风险 |
| NO_SHOW_TRANS_RISK | 可疑远程交易风险 |
| BILL_INVOICE_LICENSE_MATCH_RISK | 账票营业执照匹配风险 |
| INVOICE_NO_SEQ_RISK | 发票连号风险 |
| INVOICE_TRADE_DATE_RISK | 发票日期早于交易日期风险 |
| TRAIN_TRADE_PASSENGER_RISK | 乘车人与购票人不符风险 |
| TRADE_TIME_RISK | 交易时间不允许风险 |
| MERCHANT_BLACKLIST_RISK | 商家黑名单风险 |
| INVOICE_TRADE_CITY_RISK | 交易城市与商家经营城市不符风险 |
| STORE_NAME_CHANGE_RISK | 商家名称变更风险 |
| STORE_LOW_FREQ_TRANS_RISK | 商户交易低频风险 |
| SUSPICIOUS_TRADE_RISK | 可疑交易风险 |
| BUSINESS_SCOPE_BALCKLIST_RISK | 商家经营范围黑名单风险 |

---

## 参考

- [ext_infos 扩展字段说明](bill-ext-info.md) - 账单扩展信息字段
- [consume-detail-query.md](../push-mode/consume-detail-query.md) - 账单详情查询接口文档
