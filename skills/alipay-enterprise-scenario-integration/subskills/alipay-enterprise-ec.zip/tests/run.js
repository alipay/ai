#!/usr/bin/env node
"use strict";

const assert = require("assert");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawnSync } = require("child_process");

const skillDir = path.resolve(__dirname, "..");
const scriptsDir = path.join(skillDir, "scripts");
const validator = path.join(scriptsDir, "validate_codegen.js");
const runtime = path.join(scriptsDir, "lib", "validator-runtime.js");
const resolver = require(path.join(scriptsDir, "lib", "value-resolver.js"));
const javaProjectGates = require(path.join(scriptsDir, "lib", "java-project-gates.js"));

testRuntime();
testMissingSupportIsBroken();
testValueResolver();
require("./java-project-gates.test").run(javaProjectGates);
testFixtures();
testEmployeeIdentityPreflight();
testFailClosedNotificationBehavior();
testFailClosedUnsupportedOperationBoundary();
testNotificationIdempotencyStates();
testMessageClientStartupFailurePolicy();
testIntegrationContract();
console.log("[alipay-enterprise-ec tests] OK");

function testRuntime() {
  const ok = runNode(["-e", `require(${JSON.stringify(runtime)}).runGuarded("test", () => {})`]);
  assert.strictEqual(ok.status, 0, output(ok));

  const broken = runNode(["-e", `require(${JSON.stringify(runtime)}).runGuarded("test", () => { throw new Error("boom"); })`]);
  assert.strictEqual(broken.status, 2, output(broken));
  assert.match(output(broken), /\[test\] BROKEN/);
}

function testMissingSupportIsBroken() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-broken-"));
  const isolatedValidator = path.join(dir, "validate_codegen.js");
  fs.copyFileSync(validator, isolatedValidator);
  const result = runNode([isolatedValidator, path.join(__dirname, "fixtures", "valid")]);
  assert.strictEqual(result.status, 2, output(result));
  assert.match(output(result), /BROKEN failed to load validator support/);
}

function testValueResolver() {
  const text = [
    "const EMPLOYEE_ACTION = \"EMPLOYEE_ADD\";",
    "const PAYLOAD = \"{\\\"identity_type\\\":\\\"ALIPAY_LOGON_ID\\\"}\";",
  ].join("\n");
  const constants = resolver.extractStringConstants(text);
  assert.strictEqual(resolver.resolveStringArg("NotifyConstants.EMPLOYEE_ACTION", constants), "EMPLOYEE_ADD");
  assert.deepStrictEqual(resolver.valueTokens(text, "identity_type"), ["identity_type", "PAYLOAD"]);
}

function testFixtures() {
  assertExit(path.join(__dirname, "fixtures", "valid"), 0);
  assertExit(path.join(__dirname, "fixtures", "invalid"), 1);
}

function testEmployeeIdentityPreflight() {
  const invalidDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-employee-identity-"));
  fs.writeFileSync(path.join(invalidDir, "EmployeeService.java"), [
    "class EmployeeService {",
    "  public void add(EmployeeCommand command) {",
    "    AlipayCommerceEcEmployeeAddModel model = new AlipayCommerceEcEmployeeAddModel();",
    "    model.setEnterpriseId(command.getEnterpriseId());",
    "    model.setEmployeeName(command.getEmployeeName());",
    "    model.setIdentity(command.getIdentity());",
    "    model.setEmployeeMobile(command.getEmployeeMobile());",
    "  }",
    "}",
  ].join("\n"));
  assert.match(output(runNode([validator, invalidDir])), /does not validate the documented alternative identity group/);

  const validDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-employee-identity-"));
  fs.writeFileSync(path.join(validDir, "EmployeeService.java"), [
    "class EmployeeService {",
    "  public void add(EmployeeCommand command) {",
    "    validateEmployeeIdentity(command);",
    "    AlipayCommerceEcEmployeeAddModel model = new AlipayCommerceEcEmployeeAddModel();",
    "    model.setEnterpriseId(command.getEnterpriseId());",
    "    model.setEmployeeName(command.getEmployeeName());",
    "    model.setIdentity(command.getIdentity());",
    "  }",
    "  private void validateEmployeeIdentity(EmployeeCommand command) {",
    "    boolean identity = command.getIdentityType() != null && command.getIdentity() != null;",
    "    boolean certificate = command.getEmployeeCertType() != null && command.getEmployeeCertNo() != null;",
    "    boolean contact = command.getEmployeeMobile() != null || command.getEmployeeEmail() != null;",
    "    if (!identity && !certificate && !contact) { throw new IllegalArgumentException(); }",
    "  }",
    "}",
  ].join("\n"));
  assert.doesNotMatch(output(runNode([validator, validDir])), /does not validate the documented alternative identity group/);

  const inlineBooleanDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-employee-identity-"));
  fs.writeFileSync(path.join(inlineBooleanDir, "EmployeeService.java"), [
    "class EmployeeService {",
    "  public void add(EmployeeCommand command) {",
    "    boolean hasIdentity = command.getIdentityType() != null",
    "        && (command.getIdentity() != null || command.getIdentityOpenId() != null);",
    "    boolean hasCert = command.getEmployeeCertType() != null && command.getEmployeeCertNo() != null;",
    "    boolean hasMobile = command.getEmployeeMobile() != null;",
    "    boolean hasEmail = command.getEmployeeEmail() != null;",
    "    if (!hasIdentity && !hasCert && !hasMobile && !hasEmail) {",
    "      throw new IllegalArgumentException();",
    "    }",
    "    AlipayCommerceEcEmployeeAddModel model = new AlipayCommerceEcEmployeeAddModel();",
    "    model.setEnterpriseId(command.getEnterpriseId());",
    "    model.setEmployeeName(command.getEmployeeName());",
    "  }",
    "}",
  ].join("\n"));
  assert.doesNotMatch(output(runNode([validator, inlineBooleanDir])), /does not validate the documented alternative identity group/);

  const openIdRejectedDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-employee-identity-"));
  fs.writeFileSync(path.join(openIdRejectedDir, "EmployeeService.java"), [
    "class EmployeeService {",
    "  public void add(EmployeeCommand command) {",
    "    validateEmployeeIdentity(command);",
    "    AlipayCommerceEcEmployeeAddModel model = new AlipayCommerceEcEmployeeAddModel();",
    "    model.setEnterpriseId(command.getEnterpriseId());",
    "    model.setEmployeeName(command.getEmployeeName());",
    "    model.setIdentityOpenId(command.getIdentityOpenId());",
    "  }",
    "  private void validateEmployeeIdentity(EmployeeCommand command) {",
    "    boolean identity = command.getIdentityType() != null && command.getIdentity() != null;",
    "    boolean certificate = command.getEmployeeCertType() != null && command.getEmployeeCertNo() != null;",
    "    boolean contact = command.getEmployeeMobile() != null || command.getEmployeeEmail() != null;",
    "    if (!identity && !certificate && !contact) { throw new IllegalArgumentException(); }",
    "  }",
    "}",
  ].join("\n"));
  assert.match(output(runNode([validator, openIdRejectedDir])), /sets identity_open_id but the preflight identity guard does not allow/);

  const openIdAllowedDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-employee-identity-"));
  fs.writeFileSync(path.join(openIdAllowedDir, "EmployeeService.java"), [
    "class EmployeeService {",
    "  public void add(EmployeeCommand command) {",
    "    validateEmployeeIdentity(command);",
    "    AlipayCommerceEcEmployeeAddModel model = new AlipayCommerceEcEmployeeAddModel();",
    "    model.setEnterpriseId(command.getEnterpriseId());",
    "    model.setEmployeeName(command.getEmployeeName());",
    "    model.setIdentityOpenId(command.getIdentityOpenId());",
    "  }",
    "  private void validateEmployeeIdentity(EmployeeCommand command) {",
    "    boolean identity = command.getIdentityType() != null",
    "        && (command.getIdentity() != null || command.getIdentityOpenId() != null);",
    "    boolean certificate = command.getEmployeeCertType() != null && command.getEmployeeCertNo() != null;",
    "    boolean contact = command.getEmployeeMobile() != null || command.getEmployeeEmail() != null;",
    "    if (!identity && !certificate && !contact) { throw new IllegalArgumentException(); }",
    "  }",
    "}",
  ].join("\n"));
  assert.doesNotMatch(output(runNode([validator, openIdAllowedDir])), /sets identity_open_id but the preflight identity guard does not allow/);
}

function testFailClosedNotificationBehavior() {
  const failOpenDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-fail-open-"));
  fs.writeFileSync(path.join(failOpenDir, "EnterpriseChangeProcessor.java"), [
    "class EnterpriseChangeProcessor {",
    "  static final String METHOD = \"alipay.commerce.ec.enterprise.change.notify\";",
    "  public boolean process(String action) {",
    "    System.out.println(action);",
    "    return true;",
    "  }",
    "}",
  ].join("\n"));
  const failOpen = runNode([validator, failOpenDir]);
  assert.strictEqual(failOpen.status, 1, output(failOpen));
  assert.match(output(failOpen), /confirms notification success without calling a business service/);

  const failClosedDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-fail-closed-"));
  fs.writeFileSync(path.join(failClosedDir, "EnterpriseChangeProcessor.java"), [
    "class EnterpriseChangeProcessor {",
    "  static final String METHOD = \"alipay.commerce.ec.enterprise.change.notify\";",
    "  public boolean process(String action) {",
    "    throw new IllegalStateException(\"enterprise sync port is not configured\");",
    "  }",
    "}",
  ].join("\n"));
  const failClosed = runNode([validator, failClosedDir]);
  assert.doesNotMatch(output(failClosed), /confirms notification success without calling a business service/);
}

function testFailClosedUnsupportedOperationBoundary() {
  const allowedDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-fail-closed-uoe-"));
  fs.writeFileSync(path.join(allowedDir, "FailClosedEnterpriseEventPort.java"), [
    "class FailClosedEnterpriseEventPort {",
    "  public void recordEnterpriseCreated() {",
    "    throw new UnsupportedOperationException(\"EnterpriseEventPort not configured; fail-closed\");",
    "  }",
    "}",
  ].join("\n"));
  assert.doesNotMatch(output(runNode([validator, allowedDir])), /stub implementation in recordEnterpriseCreated/);

  const stubDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-uoe-stub-"));
  fs.writeFileSync(path.join(stubDir, "EnterpriseService.java"), [
    "class EnterpriseService {",
    "  public void invokeApi() {",
    "    throw new UnsupportedOperationException(\"later\");",
    "  }",
    "}",
  ].join("\n"));
  assert.match(output(runNode([validator, stubDir])), /stub implementation in invokeApi/);
}

function testNotificationIdempotencyStates() {
  const unsafeDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-idempotency-unsafe-"));
  const unsafeFile = path.join(unsafeDir, "src", "main", "java", "com", "example", "app", "ec", "notify", "EcNotifyIdempotentStore.java");
  fs.mkdirSync(path.dirname(unsafeFile), { recursive: true });
  fs.writeFileSync(unsafeFile, [
    "@Component",
    "class EcNotifyIdempotentStore {",
    "  enum State { PROCESSING, DONE }",
    "  private final Map<String, State> states = new ConcurrentHashMap<>();",
    "  public boolean tryAcquire(String notifyId) {",
    "    return states.putIfAbsent(notifyId, State.PROCESSING) == null;",
    "  }",
    "}",
  ].join("\n"));
  const unsafe = output(runNode([validator, unsafeDir]));
  assert.match(unsafe, /collapses in-progress and completed idempotency states/);
  assert.match(unsafe, /production notification idempotency uses a process-local Map\/Set/);

  const safeDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-idempotency-safe-"));
  fs.writeFileSync(path.join(safeDir, "EnterpriseNotifyStore.java"), [
    "@Profile(\"test\")",
    "@Component",
    "class EnterpriseNotifyStore {",
    "  enum State { PROCESSING, DONE }",
    "  private final Map<String, State> states = new ConcurrentHashMap<>();",
    "  public boolean tryAcquire(String notifyId) {",
    "    State previous = states.putIfAbsent(notifyId, State.PROCESSING);",
    "    if (previous == null) return true;",
    "    if (previous == State.DONE) return false;",
    "    throw new IllegalStateException(\"notification is processing; retry\");",
    "  }",
    "}",
  ].join("\n"));
  const safe = output(runNode([validator, safeDir]));
  assert.doesNotMatch(safe, /collapses in-progress and completed idempotency states/);
  assert.doesNotMatch(safe, /production notification idempotency uses a process-local Map\/Set/);

  const routerDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-router-registry-"));
  const routerFile = path.join(routerDir, "MessageRouterHandler.java");
  fs.writeFileSync(routerFile, [
    "class MessageRouterHandler {",
    "  private final Map<String, DomainMessageHandler> handlers = new ConcurrentHashMap<>();",
    "  public void register(String msgMethod, DomainMessageHandler handler) {",
    "    handlers.put(msgMethod, handler);",
    "  }",
    "}",
    "interface DomainMessageHandler {}",
  ].join("\n"));
  const router = output(runNode([validator, routerDir]));
  assert.doesNotMatch(router, /production notification idempotency uses a process-local Map\/Set/);
}

function testMessageClientStartupFailurePolicy() {
  const unsafeDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-connect-unsafe-"));
  fs.writeFileSync(path.join(unsafeDir, "EnterpriseMsgClient.java"), [
    "class EnterpriseMsgClient {",
    "  public void start() {",
    "    AlipayMsgClient client = AlipayMsgClient.getInstance(\"app\");",
    "    try { client.connect(); } catch (Exception e) { logger.error(\"connect failed\", e); }",
    "  }",
    "}",
  ].join("\n"));
  assert.match(output(runNode([validator, unsafeDir])), /catches initial AlipayMsgClient\.connect failure/);

  const safeDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-connect-safe-"));
  fs.writeFileSync(path.join(safeDir, "EnterpriseMsgClient.java"), [
    "class EnterpriseMsgClient {",
    "  public void start() {",
    "    AlipayMsgClient client = AlipayMsgClient.getInstance(\"app\");",
    "    try { client.connect(); } catch (Exception e) { throw new IllegalStateException(\"connect failed\", e); }",
    "  }",
    "}",
  ].join("\n"));
  assert.doesNotMatch(output(runNode([validator, safeDir])), /catches initial AlipayMsgClient\.connect failure/);
}

function testIntegrationContract() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-ec-contract-"));
  copyDir(path.join(__dirname, "fixtures", "valid"), dir);
  const meta = path.join(dir, ".alipay-skill");
  fs.mkdirSync(meta, { recursive: true });
  const contract = {
    schemaVersion: 1,
    projectMode: "existing",
    domains: {
      ec: {
        status: "CONFIRMED",
        joinPoints: [{
          capability: "enterprise.change",
          status: "CONFIRMED",
          strategy: "service",
          evidenceFiles: ["enterprise_directory.py"],
          symbols: ["EnterpriseDirectory"],
        }],
        changes: [{ path: "enterprise_directory.py", action: "reuse" }],
      },
    },
    gaps: [],
  };
  fs.writeFileSync(path.join(meta, "integration-contract.json"), JSON.stringify(contract, null, 2));
  assertExit(dir, 0, { ALIPAY_PROJECT_MODE: "existing" });
  contract.projectMode = "greenfield";
  fs.writeFileSync(path.join(meta, "integration-contract.json"), JSON.stringify(contract, null, 2));
  assertExit(dir, 1, { ALIPAY_PROJECT_MODE: "existing" });
  contract.projectMode = "existing";
  contract.gaps.push({ domain: "ec", issue: "unknown mapping", status: "NEEDS_USER_CONFIRM" });
  fs.writeFileSync(path.join(meta, "integration-contract.json"), JSON.stringify(contract, null, 2));
  assertExit(dir, 1, { ALIPAY_PROJECT_MODE: "existing" });
}

function assertExit(target, expected, extraEnv = {}) {
  const result = runNode([validator, target], extraEnv);
  assert.strictEqual(result.status, expected, output(result));
}

function runNode(args, extraEnv = {}) {
  return spawnSync(process.execPath, args, {
    encoding: "utf8",
    env: Object.assign({}, process.env, extraEnv),
  });
}

function output(result) {
  return `${result.stdout || ""}\n${result.stderr || ""}`.trim();
}

function copyDir(from, to) {
  for (const entry of fs.readdirSync(from, { withFileTypes: true })) {
    const source = path.join(from, entry.name);
    const target = path.join(to, entry.name);
    if (entry.isDirectory()) {
      fs.mkdirSync(target, { recursive: true });
      copyDir(source, target);
    } else {
      fs.copyFileSync(source, target);
    }
  }
}
