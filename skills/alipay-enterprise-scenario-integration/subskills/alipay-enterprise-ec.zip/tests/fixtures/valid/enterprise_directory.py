class EnterpriseDirectory:
    pass
