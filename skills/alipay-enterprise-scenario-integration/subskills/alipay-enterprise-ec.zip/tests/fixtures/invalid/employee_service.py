METHOD = "alipay.commerce.ec.employee.add"


def build_employee():
    return {"name": "Alice"}
