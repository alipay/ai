#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const os = require("os");
const { spawnSync } = require("child_process");

let runGuarded;
let extractStringConstants;
let resolveStringArg;
let validateIntegrationContract;
let javaProjectGates;
try {
  ({ runGuarded } = require("./lib/validator-runtime"));
  ({ extractStringConstants, resolveStringArg } = require("./lib/value-resolver"));
  ({ validateIntegrationContract } = require("./lib/integration-contract"));
  javaProjectGates = require("./lib/java-project-gates");
} catch (err) {
  console.error(`[alipay-enterprise-ec] BROKEN failed to load validator support: ${err && err.stack ? err.stack : err}`);
  process.exit(2);
}

const skillDir = path.resolve(__dirname, "..");
const targetDir = path.resolve(process.argv[2] || ".");

/**
 * 员企代码生成校验器。
 *
 * 阅读顺序：
 * 1. main() 判断项目语言并选择对应校验链路。
 * 2. Node.js / 跨语言分支检查接口覆盖、字段结构、通知处理和构建结果。
 * 3. Java 分支从接口 Markdown 参数表推导允许的 Model setter，再检查 SDK、通知和工程结构。
 *
 * Markdown 接口文档是字段与必填性的事实来源，脚本不维护另一份手写字段白名单。
 */

// 顶层 SDK Model 与嵌套 DTO 分开映射。嵌套 DTO 需要先按文档路径定位字段，
// 再把 snake_case 字段名转换成 Java setter。
const modelDocs = {
  AlipayCommerceEcEnterpriseRegisterinviteCreateModel: "references/enterprise-register-invite/alipay.commerce.ec.enterprise.registerinvite.create.md",
  AlipayCommerceEcEnterpriseInfoQueryModel: "references/enterprise-mgmt/alipay.commerce.ec.enterprise.info.query.md",
  AlipayCommerceEcEnterpriseInfoModifyModel: "references/enterprise-mgmt/alipay.commerce.ec.enterprise.info.modify.md",
  AlipayCommerceEcEnterpriseDeleteModel: "references/enterprise-mgmt/alipay.commerce.ec.enterprise.delete.md",
  AlipayCommerceEcEmployeeAddModel: "references/employee-sign-invite/alipay.commerce.ec.employee.add.md",
  AlipayCommerceEcEmployeeInviteQueryModel: "references/employee-sign-invite/alipay.commerce.ec.employee.invite.query.md",
  AlipayCommerceEcEmployeeInfoQueryModel: "references/employee-mgmt/alipay.commerce.ec.employee.info.query.md",
  AlipayCommerceEcEmployeeInfoModifyModel: "references/employee-mgmt/alipay.commerce.ec.employee.info.modify.md",
  AlipayCommerceEcEmployeeDeleteModel: "references/employee-mgmt/alipay.commerce.ec.employee.delete.md",
  AlipayCommerceEcEmployeeIdlistQueryModel: "references/employee-mgmt/alipay.commerce.ec.employee.idlist.query.md",
};

const nestedDocs = {
  EnterpriseBaseInfoDTO: ["references/enterprise-register-invite/alipay.commerce.ec.enterprise.registerinvite.create.md", "base_info"],
  EnterpriseProfilesDTO: ["references/enterprise-register-invite/alipay.commerce.ec.enterprise.registerinvite.create.md", "profiles"],
  ReliableEnterpriseProfilesDTO: ["references/enterprise-mgmt/alipay.commerce.ec.enterprise.info.modify.md", "reliable_profiles"],
};

const requiredTokens = [
  "AlipayCommerceEcEnterpriseRegisterinviteCreateRequest",
  "alipay.commerce.ec.enterprise.change.notify",
  "AlipayCommerceEcEnterpriseInfoQueryRequest",
  "AlipayCommerceEcEnterpriseInfoModifyRequest",
  "AlipayCommerceEcEnterpriseDeleteRequest",
  "AlipayCommerceEcEmployeeAddRequest",
  "AlipayCommerceEcEmployeeInviteQueryRequest",
  "alipay.commerce.ec.employee.change.notify",
  "AlipayCommerceEcEmployeeInfoQueryRequest",
  "AlipayCommerceEcEmployeeInfoModifyRequest",
  "AlipayCommerceEcEmployeeDeleteRequest",
  "AlipayCommerceEcEmployeeIdlistQueryRequest",
];

const enumDocs = [
  "references/enterprise-register-invite/enterprise-change-notify.md",
  "references/employee-sign-invite/employee-change-notify.md",
];

const nodeRequiredTokens = [
  "alipay.commerce.ec.enterprise.registerinvite.create",
  "alipay.commerce.ec.enterprise.info.query",
  "alipay.commerce.ec.enterprise.info.modify",
  "alipay.commerce.ec.enterprise.delete",
  "alipay.commerce.ec.employee.add",
  "alipay.commerce.ec.employee.invite.query",
  "alipay.commerce.ec.employee.info.query",
  "alipay.commerce.ec.employee.info.modify",
  "alipay.commerce.ec.employee.delete",
  "alipay.commerce.ec.employee.idlist.query",
];

const nodeMethodDocs = {
  "alipay.commerce.ec.enterprise.registerinvite.create": "references/enterprise-register-invite/alipay.commerce.ec.enterprise.registerinvite.create.md",
  "alipay.commerce.ec.enterprise.info.query": "references/enterprise-mgmt/alipay.commerce.ec.enterprise.info.query.md",
  "alipay.commerce.ec.enterprise.info.modify": "references/enterprise-mgmt/alipay.commerce.ec.enterprise.info.modify.md",
  "alipay.commerce.ec.enterprise.delete": "references/enterprise-mgmt/alipay.commerce.ec.enterprise.delete.md",
  "alipay.commerce.ec.employee.add": "references/employee-sign-invite/alipay.commerce.ec.employee.add.md",
  "alipay.commerce.ec.employee.invite.query": "references/employee-sign-invite/alipay.commerce.ec.employee.invite.query.md",
  "alipay.commerce.ec.employee.info.query": "references/employee-mgmt/alipay.commerce.ec.employee.info.query.md",
  "alipay.commerce.ec.employee.info.modify": "references/employee-mgmt/alipay.commerce.ec.employee.info.modify.md",
  "alipay.commerce.ec.employee.delete": "references/employee-mgmt/alipay.commerce.ec.employee.delete.md",
  "alipay.commerce.ec.employee.idlist.query": "references/employee-mgmt/alipay.commerce.ec.employee.idlist.query.md",
};

runGuarded("alipay-enterprise-ec", main);

function main() {
  const errors = [];
  const warnings = [];
  if (!fs.existsSync(targetDir)) fail(`target directory not found: ${targetDir}`);
  validateIntegrationContract(targetDir, ["ec"], errors);

  const javaFiles = walk(targetDir).filter((f) => f.endsWith(".java"));
  const nodeProject = isNodeProject(targetDir);

  // 每次只走一条语言链路，避免把 Java SDK 类名规则误施加到其他语言。
  if (javaFiles.length === 0 && nodeProject) {
    checkNodeProject("alipay-enterprise-ec", nodeRequiredTokens, errors, warnings);
    report("alipay-enterprise-ec", errors, warnings);
    return;
  }
  if (javaFiles.length === 0) {
    checkCrossLanguageEcProject(errors, warnings);
    report("alipay-enterprise-ec", errors, warnings);
    return;
  }

  const domainFiles = javaFiles.filter(isEcFile);
  const allText = domainFiles.map((f) => fs.readFileSync(f, "utf8")).join("\n");
  const allCode = stripJavaComments(allText);
  const projectText = javaFiles.map((f) => fs.readFileSync(f, "utf8")).join("\n");

  checkJavaMavenSdkLatest(errors);
  checkSdkStubs(javaFiles, errors);
  checkUnsafeStubs(domainFiles, errors);
  checkSdkModelUsage(allText, modelDocs, errors);
  checkRawBizContent(allText, errors);
  checkCoverage(allCode, requiredTokens, errors);
  checkPackagePaths(javaFiles, errors);
  checkSetters(domainFiles, errors);
  checkJavaEmployeeIdentityPreflight(domainFiles, errors);
  checkEnums(allText, projectText, enumDocs, errors);
  checkWebSocket(allText, projectText, errors);
  javaProjectGates.checkJavaTransportContracts(javaFiles, errors, rel, domainFiles);
  javaProjectGates.checkJavaProductionStateStores(domainFiles, errors, rel);
  javaProjectGates.checkJavaStateTransitionPersistence(domainFiles, errors, rel);
  if (process.env.ALIPAY_VALIDATE_AGGREGATE !== "1") {
    checkJavaMessageClientStartupFailure(javaFiles, errors);
    javaProjectGates.checkSpringProfileWiring(targetDir, javaFiles, errors, rel);
    javaProjectGates.checkJavaTestEvidence(targetDir, javaFiles, errors);
  }
  checkJavaUnknownNotifySuccess(domainFiles, errors);
  checkJavaFailOpenNotificationHandlers(domainFiles, errors);
  checkJavaNotificationIdempotency(domainFiles, errors);
  checkJavaProductionMemoryIdempotency(domainFiles, errors);
  checkForbiddenComments(allText, errors);

  report("alipay-enterprise-ec", errors, warnings);
}

// -----------------------------------------------------------------------------
// Node.js：SDK 调用、bizContent 字段、接口覆盖、通知语义和工程可运行性。
// -----------------------------------------------------------------------------

function isNodeProject(dir) {
  const files = walk(dir);
  return files.some((f) => path.basename(f) === "package.json")
    && files.some((f) => /\.(?:js|cjs|mjs|ts)$/i.test(f));
}

function checkNodeProject(name, requiredTokens, errors, warnings) {
  const packageFile = findFile(targetDir, "package.json");
  if (!packageFile) {
    errors.push("Node.js project must contain package.json");
    return;
  }

  let pkg = {};
  try {
    pkg = JSON.parse(fs.readFileSync(packageFile, "utf8"));
  } catch (err) {
    errors.push(`package.json is not valid JSON: ${err.message}`);
    return;
  }

  const jsFiles = walk(targetDir).filter((f) => /\.(?:js|cjs|mjs)$/i.test(f) && isNodeEcFile(f));
  const sourceText = jsFiles.map((f) => fs.readFileSync(f, "utf8")).join("\n");
  const sourceCode = stripJsComments(sourceText);

  checkNodeAlipaySdkUsage(pkg, packageFile, sourceCode, errors);
  checkNodeExecAppAuthTokenPlacement(sourceCode, errors);
  checkNodeNotifyVerification(sourceCode, errors);
  checkNodeBizContentFields(jsFiles, nodeMethodDocs, errors);
  checkNodeCoverage(sourceCode, requiredTokens, errors);
  checkNodeEcNotifyHandlers(sourceCode, errors);
  checkNodeFailOpenNotificationHandlers(sourceCode, errors);
  checkNodeUnsafeStubs(sourceCode, errors);
  checkNodeSyntax(jsFiles, errors);
  checkNodeModuleLoading(jsFiles, errors);
  checkNodeTests(pkg, path.dirname(packageFile), errors, warnings, name);
}

function checkNodeAlipaySdkUsage(pkg, packageFile, text, errors) {
  if (!/alipay-sdk/.test(text)) return;
  const deps = Object.assign({}, pkg.dependencies || {}, pkg.devDependencies || {});
  if (!deps["alipay-sdk"]) errors.push("Node.js code uses alipay-sdk but package.json does not declare alipay-sdk");
  if (/require\s*\(\s*["']alipay-sdk["']\s*\)\s*\.default\b/.test(text)) {
    errors.push("Node.js CommonJS code imports alipay-sdk via .default; use `const { AlipaySdk } = require(\"alipay-sdk\")` after verifying the installed SDK export");
  }
  try {
    const sdkPath = require.resolve("alipay-sdk", { paths: [path.dirname(packageFile)] });
    const sdk = require(sdkPath);
    if (typeof sdk.AlipaySdk !== "function") errors.push("installed alipay-sdk does not export AlipaySdk as a constructor");
  } catch (err) {
    if (fs.existsSync(path.join(path.dirname(packageFile), "node_modules"))) {
      errors.push(`failed to load installed alipay-sdk: ${err.message}`);
    }
  }
}

function checkNodeExecAppAuthTokenPlacement(text, errors) {
  if (/\.exec\s*\(\s*[^,]+,\s*\{\s*bizContent[\s\S]{0,300}?\}\s*,\s*\{[\s\S]{0,160}?appAuthToken\s*:/g.test(text)) {
    errors.push("Node.js alipay-sdk exec(...) passes appAuthToken in the third options argument; for OpenAPI 2.0 put it in the second argument with bizContent");
  }
}

function checkNodeNotifyVerification(text, errors) {
  if (/crypto\s*\.\s*createVerify\s*\(/.test(text) && !/\.checkNotifySign(?:V2)?\s*\(/.test(text)) {
    errors.push("Node.js notification verification hand-rolls crypto.createVerify; use alipay-sdk checkNotifySign/checkNotifySignV2");
  }
  if (/\basync\s+function\s+verify[A-Za-z0-9_]*(?:Sign|Notify)[A-Za-z0-9_]*\s*\(/.test(text)
      && /(?:const|let|var)\s+[A-Za-z0-9_]+\s*=\s*verify[A-Za-z0-9_]*(?:Sign|Notify)[A-Za-z0-9_]*\s*\(/.test(text)
      && !/(?:const|let|var)\s+[A-Za-z0-9_]+\s*=\s*await\s+verify[A-Za-z0-9_]*(?:Sign|Notify)[A-Za-z0-9_]*\s*\(/.test(text)) {
    errors.push("Node.js notification verification helper is async but callers do not await it; failed signatures may be treated as valid");
  }
}

function checkNodeBizContentFields(jsFiles, methodDocs, errors) {
  const docCache = new Map();
  for (const file of jsFiles) {
    const text = stripJsComments(fs.readFileSync(file, "utf8"));
    const functions = extractJsFunctions(text);
    for (const [method, docRel] of Object.entries(methodDocs)) {
      const callPattern = new RegExp(`\\.exec\\s*\\(\\s*["']${escapeRegExp(method)}["']`, "g");
      for (const match of text.matchAll(callPattern)) {
        const fn = functions.find((item) => match.index >= item.start && match.index <= item.end);
        const scope = fn ? fn.body : text;
        const fields = extractNodeBizContentFields(scope);
        if (!fields.found) continue;
        if (!docCache.has(docRel)) docCache.set(docRel, documentedNodeFields(docRel));
        const documented = docCache.get(docRel);

        for (const field of fields.names()) {
          if (!documented.allowed.has(field)) {
            errors.push(`${rel(file)}: ${method} bizContent field ${field} is not in documented business request parameters`);
          }
        }
        for (const field of documented.required) {
          const state = fields.get(field);
          if (!state) {
            errors.push(`${rel(file)}: ${method} bizContent is missing required documented field ${field}`);
          } else if (!state.unconditional && !hasRequiredFieldPreflight(scope, field)) {
            errors.push(`${rel(file)}: ${method} required field ${field} is only conditionally assigned without a documented preflight validation`);
          }
        }
        checkNodeEcSpecialFieldRules(file, method, fields, scope, errors);
      }
    }
  }
}

function checkNodeEcSpecialFieldRules(file, method, fields, scope, errors) {
  if (method === "alipay.commerce.ec.enterprise.registerinvite.create") {
    if (!fields.has("identity") && !fields.has("identity_open_id")) {
      errors.push(`${rel(file)}: enterprise.registerinvite.create must pass identity or identity_open_id with identity_type; do not replace it with contact fields`);
    }
  }

  if (method === "alipay.commerce.ec.employee.add") {
    const hasIdentity = fields.has("identity_type") && (fields.has("identity") || fields.has("identity_open_id"));
    const hasCert = fields.has("employee_cert_type") && fields.has("employee_cert_no");
    const hasContact = fields.has("employee_mobile") || fields.has("employee_email") || fields.has("encrypt_mobile");
    if (!hasIdentity && !hasCert && !hasContact) {
      errors.push(`${rel(file)}: employee.add must implement one documented identity condition: identity pair, certificate pair, mobile, email, or encrypt_mobile`);
    }
    for (const guard of scope.matchAll(/\bif\s*\(([^)]*)\)\s*\{[\s\S]{0,160}?throw\s+new\s+Error/g)) {
      const condition = guard[1];
      if (/\|\|/.test(condition) && /!\s*employee_no\b/.test(condition)) {
        errors.push(`${rel(file)}: employee.add must not make employee_no mandatory; it is optional in the documented business request parameters`);
      }
      if (/\|\|/.test(condition) && /!\s*employee_mobile\b/.test(condition)) {
        errors.push(`${rel(file)}: employee.add must not force employee_mobile when the docs allow identity pair, certificate pair, mobile, email, or encrypt_mobile alternatives`);
      }
    }
  }
}

function documentedNodeFields(docRel) {
  const rows = extractRequestRows(path.join(skillDir, docRel));
  const allowed = new Set();
  const required = new Set();
  for (const row of rows) {
    if (row.field.includes(".")) continue;
    allowed.add(row.field);
    if (isRequired(row.required)) required.add(row.field);
  }
  return { allowed, required };
}

function extractNodeBizContentFields(scope) {
  const states = new Map();
  const ifRanges = conditionalRanges(scope);
  let found = false;

  function add(field, unconditional) {
    if (!/^[a-z][a-z0-9_]*$/.test(field)) return;
    const state = states.get(field) || { unconditional: false, conditional: false };
    if (unconditional) state.unconditional = true;
    else state.conditional = true;
    states.set(field, state);
  }

  const literalPattern = /\b(?:const|let|var)\s+bizContent\s*=\s*\{/g;
  for (const match of scope.matchAll(literalPattern)) {
    const open = match.index + match[0].lastIndexOf("{");
    const close = findMatchingBrace(scope, open);
    if (close < 0) continue;
    found = true;
    const unconditional = !isInsideRanges(match.index, ifRanges);
    for (const key of topLevelObjectKeys(scope.slice(open + 1, close))) add(key, unconditional);
  }

  const assignPattern = /\bbizContent\s*(?:\.\s*([A-Za-z_$][\w$]*)|\[\s*["']([^"']+)["']\s*\])\s*=/g;
  for (const match of scope.matchAll(assignPattern)) {
    found = true;
    add(match[1] || match[2], !isInsideRanges(match.index, ifRanges));
  }

  return {
    found,
    get: (field) => states.get(field),
    has: (field) => states.has(field),
    names: () => Array.from(states.keys()),
  };
}

function conditionalRanges(text) {
  const ranges = [];
  for (const match of text.matchAll(/\bif\s*\([^)]*\)\s*\{/g)) {
    const open = match.index + match[0].lastIndexOf("{");
    const close = findMatchingBrace(text, open);
    if (close > open) ranges.push([match.index, close]);
  }
  return ranges;
}

function hasRequiredFieldPreflight(scope, field) {
  const escaped = escapeRegExp(field);
  return new RegExp(`\\b(?:validate|assert|ensure|require)[A-Za-z0-9_]*\\s*\\([^)]*["']${escaped}["']`, "i").test(scope)
    || new RegExp(`\\bif\\s*\\([^)]*(?:!\\s*)?(?:bizContent\\s*\\.\\s*)?${escaped}[^)]*\\)[\\s\\S]{0,240}\\b(?:throw\\b|return\\s+(?:false|fail))`, "i").test(scope)
    || new RegExp(`\\bif\\s*\\([^)]*(?:!\\s*)?(?:params|request|input)\\s*\\.\\s*${escaped}[^)]*\\)[\\s\\S]{0,240}\\b(?:throw\\b|return\\s+(?:false|fail))`, "i").test(scope);
}

function isInsideRanges(index, ranges) {
  return ranges.some(([start, end]) => index >= start && index <= end);
}

function extractJsFunctions(text) {
  const functions = [];
  const seen = new Set();
  const patterns = [
    /\b(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{/g,
    /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>\s*\{/g,
    /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s+)?function\s*\([^)]*\)\s*\{/g,
    /\b(?:async\s+)?([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{/g,
  ];
  for (const pattern of patterns) {
    for (const match of text.matchAll(pattern)) {
      const open = match.index + match[0].lastIndexOf("{");
      if (seen.has(open)) continue;
      const close = findMatchingBrace(text, open);
      if (close > open) {
        seen.add(open);
        functions.push({ name: match[1], start: match.index, end: close, body: text.slice(open + 1, close) });
      }
    }
  }
  return functions;
}

function topLevelObjectKeys(body) {
  const keys = [];
  for (const entry of splitTopLevel(body, ",")) {
    const trimmed = entry.trim();
    if (!trimmed || trimmed.startsWith("...")) continue;
    const colon = topLevelColon(trimmed);
    const keyPart = (colon >= 0 ? trimmed.slice(0, colon) : trimmed).trim();
    const literal = keyPart.match(/^["']([^"']+)["']$/);
    if (literal) {
      keys.push(literal[1]);
      continue;
    }
    const ident = keyPart.match(/^([A-Za-z_$][\w$]*)$/);
    if (ident) keys.push(ident[1]);
  }
  return keys;
}

function splitTopLevel(text, delimiter) {
  const parts = [];
  let start = 0;
  let depth = 0;
  let quote = null;
  let escaped = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === quote) quote = null;
      continue;
    }
    if (ch === "\"" || ch === "'" || ch === "`") {
      quote = ch;
      continue;
    }
    if (ch === "{" || ch === "[" || ch === "(") depth++;
    else if (ch === "}" || ch === "]" || ch === ")") depth--;
    else if (ch === delimiter && depth === 0) {
      parts.push(text.slice(start, i));
      start = i + 1;
    }
  }
  parts.push(text.slice(start));
  return parts;
}

function topLevelColon(text) {
  let depth = 0;
  let quote = null;
  let escaped = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === quote) quote = null;
      continue;
    }
    if (ch === "\"" || ch === "'" || ch === "`") quote = ch;
    else if (ch === "{" || ch === "[" || ch === "(") depth++;
    else if (ch === "}" || ch === "]" || ch === ")") depth--;
    else if (ch === ":" && depth === 0) return i;
  }
  return -1;
}

function checkNodeCoverage(text, tokens, errors) {
  for (const token of tokens) {
    if (!text.includes(token)) errors.push(`missing required Node.js interface token: ${token}`);
  }
}

function checkNodeEcNotifyHandlers(text, errors) {
  if (!/handleEnterprise[A-Za-z0-9_]*Notify|handleEnterpriseChangeNotify/.test(text)) {
    errors.push("missing executable enterprise change notification handler");
  }
  if (!/handleEmployee[A-Za-z0-9_]*Notify|handleEmployeeChangeNotify/.test(text)) {
    errors.push("missing executable employee change notification handler");
  }
  if (/\bdefault\s*:[\s\S]{0,420}\breturn\s+true\s*;/.test(text)) {
    errors.push("Node.js EC notification handler must not default unknown msg_method/action to success; return fail or delegate to an explicit unknown handler result so retry semantics are preserved");
  }
}

function checkNodeFailOpenNotificationHandlers(text, errors) {
  for (const fn of extractJsFunctions(text)) {
    if (!/^(?:process|handle|onNotify|apply|sync).*(?:Enterprise|Employee|Notify|Change)/i.test(fn.name || "")) continue;
    if (!/\breturn\s+(?:true|["']success["'])\s*;?/.test(fn.body)) continue;
    if (hasBusinessSideEffectCall(fn.body)) continue;
    errors.push(`Node.js EC notification function ${fn.name}(...) confirms success without calling a business service, port, repository, gateway, or equivalent side effect; wire a real extension point or fail closed`);
  }
}

function checkNodeUnsafeStubs(text, errors) {
  if (/\b(?:verifySign|checkSign|validateSign)\s*\([^)]*\)\s*\{[\s\S]{0,120}?return\s+true\s*;/.test(text)) {
    errors.push("Node.js signature verification contains a return-true stub");
  }
  if (/TODO_STUB|stub implementation|mock success|return\s+["']success["']\s*;[\s\S]{0,160}\/\/\s*TODO/i.test(text)) {
    errors.push("Node.js code contains stub/mock success logic");
  }
}

function checkNodeSyntax(jsFiles, errors) {
  for (const file of jsFiles) {
    const result = spawnSync(process.execPath, ["--check", file], { cwd: targetDir, encoding: "utf8", maxBuffer: 1024 * 1024 });
    if (result.status !== 0) errors.push(`node --check failed for ${rel(file)}:\n${lastLines(result.stderr || result.stdout)}`);
  }
}

function checkNodeModuleLoading(jsFiles, errors) {
  for (const file of jsFiles) {
    if (!isGeneratedSourceFile(file)) continue;
    if (path.basename(file) === "index.js" && /app\.listen\s*\(/.test(fs.readFileSync(file, "utf8"))) continue;
    const result = spawnSync(process.execPath, ["-e", "require(process.argv[1])", file], { cwd: targetDir, encoding: "utf8", maxBuffer: 1024 * 1024 });
    if (result.status !== 0) errors.push(`Node.js module load failed for ${rel(file)}:\n${lastLines(result.stderr || result.stdout)}`);
  }
}

function checkNodeTests(pkg, cwd, errors, warnings, name) {
  if (process.env.ALIPAY_VALIDATE_SKIP_NODE_TEST === "1") return;
  if (!pkg.scripts || !pkg.scripts.test) {
    warnings.push("package.json has no test script; skipped npm test");
    return;
  }
  const result = spawnSync("npm", ["test"], { cwd, encoding: "utf8", maxBuffer: 1024 * 1024 * 4 });
  if (result.status !== 0) errors.push(`npm test failed for generated Node.js project:\n${lastLines(`${result.stdout || ""}\n${result.stderr || ""}`, 40)}`);
}

function isGeneratedSourceFile(file) {
  const relPath = rel(file).split(path.sep).join("/");
  return /^(src|lib|app)\//.test(relPath);
}

function isNodeEcFile(file) {
  const relPath = rel(file).split(path.sep).join("/");
  if (/^(config)\//.test(relPath) || /^(src|lib|app)\/common\//.test(relPath)) return true;
  if (/^(src|lib|app)\/ec\//.test(relPath)) return true;
  if (/^(src|lib|app)\/notify\//.test(relPath) && /ec|enterprise|employee/i.test(relPath)) return true;
  const text = fs.readFileSync(file, "utf8");
  return /alipay\.commerce\.ec\.(enterprise|employee)/.test(text);
}

function findFile(dir, name) {
  return walk(dir).find((f) => path.basename(f) === name);
}

function checkJavaMavenSdkLatest(errors) {
  const pom = findFile(targetDir, "pom.xml");
  if (!pom) return;
  const sdkVersion = extractPomSdkVersion(fs.readFileSync(pom, "utf8"));
  if (!sdkVersion) {
    errors.push("pom.xml must declare com.alipay.sdk:alipay-sdk-java with an explicit version, alipay-sdk.version property, or alipay.sdk.version property");
    return;
  }
  const latest = fetchLatestAlipaySdkVersion();
  if (!latest) {
    errors.push("unable to verify latest alipay-sdk-java version from Central Portal; run `curl -sL \"https://central.sonatype.com/artifact/com.alipay.sdk/alipay-sdk-java\"` with approval or provide the Central Portal current version before generating Java/Maven code");
    return;
  }
  if (sdkVersion !== latest) {
    errors.push(`pom.xml uses alipay-sdk-java ${sdkVersion}, but Central Portal current version is ${latest}; upgrade existing and new Java/Maven projects to the current version`);
  }
}

function fetchLatestAlipaySdkVersion() {
  const result = spawnSync("curl", ["-fsSL", "https://central.sonatype.com/artifact/com.alipay.sdk/alipay-sdk-java"], {
    encoding: "utf8",
    maxBuffer: 1024 * 1024 * 2,
  });
  if (result.status !== 0 || !result.stdout) return null;
  const pkg = result.stdout.match(/pkg:maven\/com\.alipay\.sdk\/alipay-sdk-java@([0-9][0-9A-Za-z._-]*\.ALL)/);
  if (pkg) return pkg[1];
  const dep = result.stdout.match(/<artifactId>\s*alipay-sdk-java\s*<\/artifactId>[\s\S]*?<version>\s*([0-9][0-9A-Za-z._-]*\.ALL)\s*<\/version>/);
  return dep ? dep[1] : null;
}

function extractPomSdkVersion(pomText) {
  const properties = extractPomProperties(pomText);
  const dep = pomText.match(/<groupId>\s*com\.alipay\.sdk\s*<\/groupId>[\s\S]*?<artifactId>\s*alipay-sdk-java\s*<\/artifactId>[\s\S]*?<version>\s*([^<\s]+)\s*<\/version>/);
  if (!dep) return properties.get("alipay-sdk.version") || properties.get("alipay.sdk.version") || null;
  const version = dep[1];
  const propertyRef = version.match(/^\$\{([^}]+)\}$/);
  if (propertyRef) return properties.get(propertyRef[1]) || null;
  return version;
}

function extractPomProperties(pomText) {
  const properties = new Map();
  const block = pomText.match(/<properties>([\s\S]*?)<\/properties>/);
  if (!block) return properties;
  for (const m of block[1].matchAll(/<([A-Za-z0-9_.-]+)>\s*([^<\s]+)\s*<\/\1>/g)) {
    properties.set(m[1], m[2]);
  }
  return properties;
}

function lastLines(text, count = 20) {
  return String(text || "").trim().split(/\r?\n/).slice(-count).join("\n");
}

// -----------------------------------------------------------------------------
// Java/Maven：以接口文档为准校验 SDK Model、setter、枚举、通知和工程结构。
// -----------------------------------------------------------------------------

function checkSetters(javaFiles, errors) {
  const allowed = {};
  for (const [type, doc] of Object.entries(modelDocs)) {
    allowed[type] = allowedSetters(doc, null, true);
  }
  for (const [type, [doc, prefix]] of Object.entries(nestedDocs)) {
    allowed[type] = allowedSetters(doc, prefix, false);
  }

  for (const file of javaFiles) {
    const text = fs.readFileSync(file, "utf8");
    scanSetterBlocks(text, allowed, file, errors);
  }
}

function scanSetterBlocks(text, allowed, file, errors) {
  const vars = {};
  const pattern = /\b([A-Za-z0-9_]+)\s+([A-Za-z0-9_]+)\s*=\s*new\s+\1\s*\(|\b([A-Za-z0-9_]+)\.set([A-Za-z0-9_]+)\s*\(/g;

  function finalize(varName) {
    const state = vars[varName];
    if (!state || !allowed[state.type] || !allowed[state.type].required.size) return;
    for (const setter of allowed[state.type].required) {
      if (!state.called.has(setter)) {
        errors.push(`${rel(file)}: ${state.type} variable ${varName} is missing required documented setter ${setter}`);
      }
    }
  }

  for (const m of text.matchAll(pattern)) {
    if (m[1]) {
      const type = m[1];
      const varName = m[2];
      finalize(varName);
      vars[varName] = { type, called: new Set() };
      continue;
    }

    const varName = m[3];
    const setter = `set${m[4]}`;
    const state = vars[varName];
    if (!state || !allowed[state.type]) continue;
    state.called.add(setter);
    if (!allowed[state.type].all.has(setter)) {
      errors.push(`${rel(file)}: setter ${state.type}.${setter} is not in documentation whitelist`);
    }
  }

  for (const varName of Object.keys(vars)) finalize(varName);
}

// "特殊可选" fields often form a required alternative group. For employee.add,
// accepting a DTO that can leave every identity branch empty only defers a
// deterministic client error to the gateway, so require a preflight guard.
function checkJavaEmployeeIdentityPreflight(files, errors) {
  for (const file of files) {
    const text = stripJavaComments(fs.readFileSync(file, "utf8"));
    const methods = extractMethods(text);
    for (const method of methods) {
      if (!/AlipayCommerceEcEmployeeAddModel\s+[A-Za-z0-9_]+\s*=\s*new\s+AlipayCommerceEcEmployeeAddModel/.test(method.body)) continue;

      const setsIdentityOpenId = /\bsetIdentityOpenId\s*\(/.test(method.body);
      const inlineGuard = hasEmployeeIdentityAlternativeGuard(method.body, true);
      const inlineOpenIdGuard = guardMentionsEmployeeIdentityOpenId(method.body, true);
      const helperNames = Array.from(method.body.matchAll(/\b((?:validate|check|require|ensure|preflight)[A-Za-z0-9_]*(?:Identity|Credential|Employee)[A-Za-z0-9_]*)\s*\(/gi))
        .map((match) => match[1]);
      const helperCandidates = helperNames
        .map((name) => methods.find((candidate) => candidate.name === name))
        .filter(Boolean);
      const helperGuard = helperCandidates.some((candidate) => hasEmployeeIdentityAlternativeGuard(candidate.body, false));
      const helperOpenIdGuard = helperCandidates.some((candidate) => guardMentionsEmployeeIdentityOpenId(candidate.body, false));

      if (!helperGuard && !inlineGuard) {
        errors.push(`${rel(file)}: employee.add does not validate the documented alternative identity group before invoking the SDK; require an identity pair, certificate pair, mobile/email, or documented encrypted identity branch`);
      }
      if ((helperGuard || inlineGuard) && setsIdentityOpenId && !helperOpenIdGuard && !inlineOpenIdGuard) {
        errors.push(`${rel(file)}: employee.add sets identity_open_id but the preflight identity guard does not allow identity_type + identity_open_id as a documented identity branch`);
      }
    }
  }
}

function hasEmployeeIdentityAlternativeGuard(body, isolateThrowingGuards) {
  let guardText = isolateThrowingGuards
    ? Array.from(body.matchAll(/\bif\s*\(([\s\S]{0,700}?)\)\s*\{?[\s\S]{0,180}?\bthrow\s+new\b/g)).map((match) => match[0]).join("\n")
    : body;
  guardText = expandBooleanGuardDependencies(body, guardText);
  if (!/\bif\b/.test(guardText) || !/\bthrow\s+new\b/.test(guardText)) return false;
  const identityBranch = /identity(?:Type|OpenId)?|getIdentity/i.test(guardText);
  const certificateBranch = /employeeCert|cert(?:Type|No)|getEmployeeCert/i.test(guardText);
  const contactBranch = /employeeMobile|employeeEmail|encryptMobile|encryptCert|getEmployee(?:Mobile|Email)/i.test(guardText);
  return identityBranch && certificateBranch && contactBranch;
}

function guardMentionsEmployeeIdentityOpenId(body, isolateThrowingGuards) {
  let guardText = isolateThrowingGuards
    ? Array.from(body.matchAll(/\bif\s*\(([\s\S]{0,700}?)\)\s*\{?[\s\S]{0,180}?\bthrow\s+new\b/g)).map((match) => match[0]).join("\n")
    : body;
  guardText = expandBooleanGuardDependencies(body, guardText);
  return /identityOpenId|IdentityOpenId|getIdentityOpenId|identity_open_id/i.test(guardText);
}

// Generated services often name each legal branch first and combine those
// booleans in one throwing guard. Expand the referenced initializers so the
// validator checks the actual fields instead of depending on variable names.
function expandBooleanGuardDependencies(body, guardText) {
  const initializers = new Map();
  for (const match of body.matchAll(/\bboolean\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([^;]+);/g)) {
    initializers.set(match[1], match[2]);
  }

  let expanded = guardText;
  const visited = new Set();
  for (let pass = 0; pass < initializers.size; pass++) {
    let changed = false;
    for (const [name, expression] of initializers) {
      if (visited.has(name) || !new RegExp(`\\b${escapeRegExp(name)}\\b`).test(expanded)) continue;
      expanded += `\n${expression}`;
      visited.add(name);
      changed = true;
    }
    if (!changed) break;
  }
  return expanded;
}

function allowedSetters(docRel, prefix, enforceRequired) {
  // required 只对顶层 Model 强制执行。嵌套 DTO 是否出现取决于业务分支，
  // 因此嵌套对象只校验“用了哪些 setter”，不要求对象一定存在。
  const rows = extractRequestRows(path.join(skillDir, docRel));
  const all = new Set();
  const required = new Set();
  for (const row of rows) {
    const field = row.field;
    let setter = null;
    if (prefix) {
      if (field.startsWith(`${prefix}.`)) setter = toSetter(field.slice(prefix.length + 1));
    } else if (!field.includes(".")) {
      setter = toSetter(field);
    }
    if (!setter) continue;
    all.add(setter);
    if (enforceRequired && isRequired(row.required)) required.add(setter);
  }
  return { all, required };
}

function extractRequestRows(file) {
  const text = fs.readFileSync(file, "utf8");
  const rows = [];
  let inRequestParams = false;
  for (const line of text.split(/\r?\n/)) {
    if (/^###\s+业务请求参数/.test(line)) {
      inRequestParams = true;
      continue;
    }
    if (inRequestParams && /^###\s+/.test(line)) break;
    if (!inRequestParams) continue;
    if (!line.startsWith("|") || line.includes("---") || line.includes("参数英文名")) continue;
    const cells = line.split("|").map((s) => s.trim());
    const field = cells[1];
    if (/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)*$/.test(field)) rows.push({ field, required: cells[3] || "" });
  }
  return rows;
}

function checkCoverage(text, tokens, errors) {
  for (const token of tokens) {
    if (!text.includes(token)) errors.push(`missing required interface/notification: ${token}`);
  }
}

function checkSdkModelUsage(text, docs, errors) {
  for (const type of Object.keys(docs)) {
    const declaration = new RegExp(`\\b${escapeRegExp(type)}\\s+([A-Za-z0-9_]+)\\s*=\\s*new\\s+${escapeRegExp(type)}\\s*\\(`);
    const m = text.match(declaration);
    if (!m) {
      errors.push(`missing required SDK model construction: ${type}; generated Java must use official Request + Model classes`);
      continue;
    }
    const varName = m[1];
    const setBizModel = new RegExp(`\\.setBizModel\\s*\\(\\s*${escapeRegExp(varName)}\\s*\\)`);
    if (!setBizModel.test(text)) {
      errors.push(`SDK model ${type} variable ${varName} is not passed to request.setBizModel(...)`);
    }
  }
}

function checkRawBizContent(text, errors) {
  if (usesSdkRequestSetBizContent(text) || /putOtherTextParam\s*\(\s*["']biz_content["']/.test(text)) {
    errors.push("generated Java must not hand-build biz_content with JSON/Map/setBizContent; use official SDK Model setters and request.setBizModel(model)");
  }
}

function checkUnsafeStubs(files, errors) {
  for (const file of files) {
    const text = fs.readFileSync(file, "utf8");
    for (const method of extractMethods(text)) {
      if (/verifySign|checkSign|validateSign/.test(method.name) && /\breturn\s+true\s*;/.test(method.body)) {
        errors.push(`${rel(file)}: ${method.name}(...) is a security stub returning true; implement SDK signature verification or use the documented SDK message client`);
      }
      if (/Stub implementation for compilation purposes/.test(method.body)
          || /UnsupportedOperationException/.test(method.body) && !isExplicitFailClosedAdapter(text, method)) {
        errors.push(`${rel(file)}: generated code contains a stub implementation in ${method.name}(...)`);
      }
    }
  }
}

function isExplicitFailClosedAdapter(fileText, method) {
  if (!/UnsupportedOperationException/.test(method.body)) return false;
  const body = stripJavaComments(method.body).trim();
  const throwsOnly = /^\{\s*throw\s+new\s+UnsupportedOperationException\s*\([\s\S]*\)\s*;\s*\}$/.test(body);
  const boundary = /fail[- ]closed|not configured|未配置|@ConditionalOnMissingBean|\b(?:Port|Adapter|Gateway)\b/i.test(fileText);
  const sdkOrSecurity = /Alipay[A-Za-z0-9_]*Request|alipayClient\s*\.\s*execute|verifySign|checkSign|validateSign/.test(`${method.name}\n${method.body}`);
  return throwsOnly && boundary && !sdkOrSecurity;
}

function checkSdkStubs(files, errors) {
  const sdkPath = `${path.sep}src${path.sep}main${path.sep}java${path.sep}com${path.sep}alipay${path.sep}api${path.sep}`;
  const offenders = [];
  for (const file of files) {
    const text = fs.readFileSync(file, "utf8");
    if (file.includes(sdkPath) || /^\s*package\s+com\.alipay\.api(\.|;)/m.test(text) || /Stub implementation for compilation purposes/.test(text)) {
      offenders.push(rel(file));
    }
  }
  if (offenders.length) {
    const sample = offenders.slice(0, 8).join(", ");
    const suffix = offenders.length > 8 ? `, ... ${offenders.length - 8} more` : "";
    errors.push(`generated code must not define local Alipay SDK stubs or shadow com.alipay.api classes; remove ${offenders.length} offending files and use the official alipay-sdk-java dependency: ${sample}${suffix}`);
  }
}

function checkEnums(text, projectText, docs, errors) {
  const allowed = new Set();
  for (const doc of docs) {
    const s = fs.readFileSync(path.join(skillDir, doc), "utf8");
    for (const m of s.matchAll(/\b[A-Z][A-Z0-9_]{2,}\b/g)) allowed.add(m[0]);
  }
  const constants = extractStringConstants(`${projectText}\n${text}`);
  for (const m of text.matchAll(/case\s+([^:\n]+)\s*:/g)) {
    const value = resolveStringArg(m[1], constants);
    if (value && /^[A-Z][A-Z0-9_]+$/.test(value) && !allowed.has(value)) {
      errors.push(`enum case not found in notification docs: ${value}`);
    }
  }
}

function checkWebSocket(text, projectText, errors) {
  const uncommented = stripJavaComments(text);
  if (uncommented.includes("@ClientEndpoint") || /msg_type["']?\s*[:,]\s*["'](?:auth|heartbeat|ack)["']/.test(uncommented)) {
    errors.push("WebSocket implementation appears to hand-roll protocol; use official AlipayMsgClient + MsgHandler");
  }
  if (/WebSocket|AlipayMsgClient|MsgHandler/.test(text) && /AlipayMsgClient|MsgHandler/.test(uncommented)) {
    const hasExecutableClient = /AlipayMsgClient\s+[A-Za-z0-9_]+|AlipayMsgClient\.getInstance\s*\(/.test(uncommented)
      && /setMessageHandler\s*\(/.test(uncommented)
      && /\.connect\s*\(/.test(uncommented);
    if (!hasExecutableClient && !hasSharedEcMessageRouter(projectText)) {
      errors.push("Java WebSocket code mentions AlipayMsgClient/MsgHandler but does not contain executable getInstance + setMessageHandler + connect logic; do not leave official SDK access as comments/logs");
    }
  }
}

function hasSharedEcMessageRouter(text) {
  const uncommented = stripJavaComments(text);
  const hasExecutableClient = /AlipayMsgClient\s+[A-Za-z0-9_]+|AlipayMsgClient\.getInstance\s*\(/.test(uncommented)
    && /setMessageHandler\s*\(/.test(uncommented)
    && /\.connect\s*\(/.test(uncommented);
  if (!hasExecutableClient) return false;

  const hasEnterpriseRoute = /alipay\.commerce\.ec\.enterprise\.change\.notify/.test(uncommented)
    && /\.\s*[A-Za-z0-9_]*Enterprise[A-Za-z0-9_]*\s*\(/.test(uncommented);
  const hasEmployeeRoute = /alipay\.commerce\.ec\.employee\.change\.notify/.test(uncommented)
    && /\.\s*[A-Za-z0-9_]*Employee[A-Za-z0-9_]*\s*\(/.test(uncommented);
  return hasEnterpriseRoute && hasEmployeeRoute;
}

function checkJavaUnknownNotifySuccess(files, errors) {
  for (const file of files) {
    const text = stripJavaComments(fs.readFileSync(file, "utf8"));
    if (!/alipay\.commerce\.ec\.(?:enterprise|employee)\.change\.notify|EcNotifyResult|ChangeNotifyHandler/.test(text)) continue;

    if (/if\s*\(\s*!\s*handled\s*\)[\s\S]{0,260}\breturn\s+EcNotifyResult\.success\s*\(/.test(text)
        || /if\s*\(\s*handled\s*\)[\s\S]{0,260}\breturn\s+EcNotifyResult\.success\s*\([\s\S]{0,260}\bmarkProcessed\s*\([\s\S]{0,160}\breturn\s+EcNotifyResult\.success\s*\(/.test(text)) {
      errors.push(`${rel(file)}: Java EC notification must not mark unknown action as processed/success by default; return fail/throw or delegate to an explicit unknown handler with documented acknowledgement policy`);
    }

    for (const body of switchDefaultBodies(text)) {
      const hasExplicitUnknownHandler = /\b(?:handleUnknown|unknownHandler|onUnknown|unknown[A-Za-z0-9_]*Handler)\s*\(/i.test(body);
      const successDefault = /\breturn\s+(?:true|EcNotifyResult\.success\s*\()/m.test(body);
      if (successDefault && !hasExplicitUnknownHandler) {
        errors.push(`${rel(file)}: Java EC notification default branch returns success for unknown action/msg_method; use fail/throw or an explicit unknown handler`);
      }
    }
  }
}

function checkJavaFailOpenNotificationHandlers(files, errors) {
  for (const file of files) {
    const raw = fs.readFileSync(file, "utf8");
    if (!/enterprise|employee|notify|change/i.test(`${path.basename(file)}\n${raw}`)) continue;

    for (const method of extractMethods(raw)) {
      if (!/^(?:process|handle|onNotify|apply|sync)/i.test(method.name)) continue;
      if (!/\breturn\s+true\s*;/.test(method.body)) continue;
      if (hasBusinessSideEffectCall(method.body)) continue;
      errors.push(`${rel(file)}: ${method.name}(...) confirms notification success without calling a business service, port, repository, gateway, or equivalent side effect; wire a real extension point or fail closed`);
    }
  }
}

function checkJavaNotificationIdempotency(files, errors) {
  for (const file of files) {
    const raw = fs.readFileSync(file, "utf8");
    if (!/notify|notification|enterprise|employee|幂等/i.test(`${path.basename(file)}\n${raw}`)) continue;
    if (!/\b(?:PROCESSING|IN_PROGRESS)\b/.test(raw) || !/\b(?:DONE|COMPLETED|PROCESSED)\b/.test(raw)) continue;

    for (const method of extractMethods(raw)) {
      if (!/(?:tryAcquire|acquire|claim|reserve|lock)/i.test(method.name)) continue;
      if (!/putIfAbsent\s*\(/.test(method.body)) continue;
      if (collapsesInFlightAndCompleted(method.body)) {
        errors.push(`${rel(file)}: ${method.name}(...) collapses in-progress and completed idempotency states into the same boolean result; return distinct states or throw/retry for in-progress so a concurrent notification is not acknowledged as completed`);
      }
    }
  }
}

function collapsesInFlightAndCompleted(body) {
  if (/return\s+[^;]*putIfAbsent\s*\([^;]+(?:==|!=)\s*null\s*;/.test(body)) return true;
  const assigned = body.match(/\b([A-Za-z_][A-Za-z0-9_]*)\s*=\s*[^;]*putIfAbsent\s*\([^;]+;/);
  if (!assigned || !/\breturn\s+(?:true|false)\s*;/.test(body)) return false;
  const previous = escapeRegExp(assigned[1]);
  const distinguishesCompleted = new RegExp(`\\b${previous}\\b\\s*==\\s*(?:[A-Za-z0-9_]+\\.)?(?:DONE|COMPLETED|PROCESSED)\\b`).test(body);
  const rejectsInFlight = /\bthrow\s+new\b/.test(body)
    || /\b(?:PROCESSING|IN_PROGRESS)\b[\s\S]{0,180}\breturn\s+(?:RETRY|FAIL|ERROR)\b/.test(body);
  return !distinguishesCompleted || !rejectsInFlight;
}

function checkJavaProductionMemoryIdempotency(files, errors) {
  for (const file of files) {
    const raw = fs.readFileSync(file, "utf8");
    if (isDemoOrTestSource(file, raw)) continue;
    // 注意：不要求是 Spring Bean。裸 new 的内存幂等存储（例如 handler 内 new XxxStore()
    // 持有 ConcurrentHashMap）同样不可跨实例/重启，必须被拦截。
    if (!/notify|notification|幂等|idempot/i.test(`${path.basename(file)}\n${raw}`)) continue;
    if (!hasMutableInMemoryStateField(raw)) continue;
    errors.push(`${rel(file)}: production notification idempotency uses a process-local Map/Set; use a shared durable store for multi-instance and restart safety, or restrict the in-memory implementation to an explicit demo/test profile`);
  }
}

function hasMutableInMemoryStateField(text) {
  return /\b(?:Map|ConcurrentMap|ConcurrentHashMap|Set|HashSet)\s*<[^;\n=]+>\s+[A-Za-z_][A-Za-z0-9_]*\s*=\s*new\s+(?:ConcurrentHashMap|HashMap|ConcurrentSkipListMap|HashSet|LinkedHashSet)\b/.test(text);
}

function isDemoOrTestSource(file, text) {
  const relPath = rel(file).split(path.sep).join("/");
  return /(^|\/)(?:test|tests|demo|demos|examples)(\/|$)/i.test(relPath)
    || hasExplicitDemoOrTestAnnotation(text);
}

function hasExplicitDemoOrTestAnnotation(text) {
  const annotations = text.match(/@(?:Profile|ConditionalOnProperty)\s*\([^)]*\)/g) || [];
  return annotations.some((annotation) =>
    Array.from(annotation.matchAll(/["']([^"']+)["']/g))
      .some((match) => /(^|[-_.])(?:test|demo)(?:[-_.]|$)/i.test(match[1])));
}

function checkJavaMessageClientStartupFailure(files, errors) {
  for (const file of files) {
    const raw = stripJavaComments(fs.readFileSync(file, "utf8"));
    if (!/AlipayMsgClient/.test(raw) || !/\.connect\s*\(/.test(raw)) continue;
    for (const method of extractMethods(raw)) {
      if (!/\.connect\s*\(/.test(method.body)) continue;
      const catches = catchBodies(method.body);
      if (catches.length && catches.some((body) => !hasSafeConnectFailurePolicy(body))) {
        errors.push(`${rel(file)}: ${method.name}(...) catches initial AlipayMsgClient.connect failure without fail-fast or both retry and health/readiness signaling; do not leave the application running while message intake is unavailable`);
      }
    }
  }
}

function catchBodies(body) {
  const result = [];
  for (const match of body.matchAll(/\bcatch\s*\([^)]*\)\s*\{/g)) {
    const open = match.index + match[0].length - 1;
    const close = findMatchingBrace(body, open);
    if (close > open) result.push(body.slice(open + 1, close));
  }
  return result;
}

function hasSafeConnectFailurePolicy(body) {
  const failsFast = /\bthrow\b|System\s*\.\s*exit\s*\(|SpringApplication\s*\.\s*exit\s*\(|Runtime\s*\.\s*getRuntime\s*\(\s*\)\s*\.\s*halt\s*\(/.test(body);
  const retries = /\b(?:retry|reconnect|backoff|reschedule|schedule|connectAsync)\b|\.connect\s*\(/i.test(body);
  const signalsHealth = /\b(?:health|readiness|availability|liveness)\b|REFUSING_TRAFFIC|\bDOWN\b|setConnected\s*\(\s*false\s*\)|mark[A-Za-z0-9_]*(?:Unavailable|Down)/i.test(body);
  return failsFast || retries && signalsHealth;
}

function hasBusinessSideEffectCall(body) {
  const call = /\b([A-Za-z_][A-Za-z0-9_]*)\s*\.\s*([A-Za-z_][A-Za-z0-9_]*)\s*\(/g;
  const meaningfulVerb = /^(?:save|insert|update|upsert|delete|persist|store|write|publish|dispatch|execute|apply|sync|process|handle|record|send|emit)/i;
  for (const match of body.matchAll(call)) {
    const owner = match[1];
    const method = match[2];
    if (/^(?:log|logger|response|res|reply|ctx|context)$/i.test(owner)) continue;
    if (meaningfulVerb.test(method)) return true;
  }
  return false;
}

function switchDefaultBodies(text) {
  const bodies = [];
  for (const match of text.matchAll(/default\s*:/g)) {
    const start = match.index + match[0].length;
    const tail = text.slice(start, start + 700);
    const nextCase = tail.search(/\bcase\s+/);
    const switchEnd = tail.search(/\n\s*}\s*(?:\n|$)/);
    const ends = [nextCase, switchEnd].filter((i) => i >= 0);
    const end = ends.length ? Math.min(...ends) : tail.length;
    bodies.push(tail.slice(0, end));
  }
  return bodies;
}

function usesSdkRequestSetBizContent(text) {
  for (const m of text.matchAll(/\b(Alipay[A-Za-z0-9_]*Request)\s+([A-Za-z0-9_]+)\s*=/g)) {
    const varName = m[2];
    const pattern = new RegExp(`\\b${escapeRegExp(varName)}\\s*\\.\\s*setBizContent\\s*\\(`);
    if (pattern.test(text)) return true;
  }
  return false;
}

function stripJavaComments(text) {
  return text.replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");
}

function stripJsComments(text) {
  return text.replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");
}

function checkPackagePaths(files, errors) {
  const src = `${path.sep}src${path.sep}main${path.sep}java${path.sep}`;
  for (const file of files) {
    const text = fs.readFileSync(file, "utf8");
    const m = text.match(/^\s*package\s+([a-zA-Z0-9_.]+)\s*;/m);
    if (!m || !file.includes(src)) continue;
    const expected = path.dirname(file).slice(file.indexOf(src) + src.length).split(path.sep).join(".");
    if (m[1] !== expected) errors.push(`${rel(file)}: package ${m[1]} does not match path ${expected}`);
  }
}

function checkForbiddenComments(text, errors) {
  if (hasManualWhitelistComment(text)) errors.push("code comments must not hand-write field whitelist notes; use 字段来源：接口文档业务请求参数表");
}

function hasManualWhitelistComment(text) {
  const comments = [];
  for (const m of text.matchAll(/\/\*[\s\S]*?\*\/|^\s*\/\/.*$/gm)) comments.push(m[0]);
  return comments.some((comment) => /字段白名单|白名单字段|白名单\s*[:：]/.test(comment));
}

// -----------------------------------------------------------------------------
// Python / Go / .NET / PHP：执行不依赖 Java SDK 的通用员企门禁。
// -----------------------------------------------------------------------------

function checkCrossLanguageEcProject(errors, warnings) {
  const files = walk(targetDir).filter((f) => /\.(?:py|go|cs|php)$/i.test(f) && isCrossLanguageEcFile(f));
  if (files.length === 0) {
    warnings.push("no Java/Node.js EC source files found; skipped EC language-specific gates");
    return;
  }

  const rawText = files.map((f) => fs.readFileSync(f, "utf8")).join("\n");
  const sourceText = files.map((f) => stripCrossLanguageComments(fs.readFileSync(f, "utf8"), f)).join("\n");

  checkCrossLanguageEnterpriseInvite(files, errors);
  checkCrossLanguageEmployeeFields(sourceText, errors);
  checkCrossLanguageIdListQuery(sourceText, errors);
  checkCrossLanguageNotifyAndSignature(files, sourceText, errors, warnings);
  checkCrossLanguageBuild(files, warnings, errors);

  if (/字段白名单|白名单字段|白名单\s*[:：]/.test(rawText)) {
    errors.push("code comments must not hand-write field whitelist notes; use 字段来源：接口文档业务请求参数表");
  }
}

function isCrossLanguageEcFile(file) {
  const relPath = rel(file).split(path.sep).join("/");
  if (/\/(?:node_modules|vendor|target|dist|build|bin|obj|coverage|__pycache__)\//.test(`/${relPath}/`)) return false;
  if (/\/(?:bill|expense)\//i.test(`/${relPath}/`)) return false;
  const text = fs.readFileSync(file, "utf8");
  return /alipay\.commerce\.ec\.(?:enterprise|employee|department|accountingentity)|Enterprise|Employee|Department|AccountingEntity|registerinvite|employee\.idlist\.query/.test(text);
}

function checkCrossLanguageEnterpriseInvite(files, errors) {
  for (const file of files) {
    const text = stripCrossLanguageComments(fs.readFileSync(file, "utf8"), file);
    if (!/alipay\.commerce\.ec\.enterprise\.registerinvite\.create|AlipayCommerceEcEnterpriseRegisterinviteCreateRequest|type\s+CreateRegisterInviteReq\s+struct/i.test(text)) continue;

    for (const field of ["out_biz_no", "identity_type"]) {
      if (!fieldNamePattern(field).test(text)) {
        errors.push(`${rel(file)}: non-Java enterprise.registerinvite.create is missing required documented field: ${field}`);
      }
    }
    if (!fieldNamePattern("identity").test(text) && !fieldNamePattern("identity_open_id").test(text)) {
      errors.push(`${rel(file)}: non-Java enterprise.registerinvite.create must pass identity or identity_open_id with identity_type`);
    }

    if ((fieldNamePattern("enterprise_name").test(text) || /\bEnterpriseName\b/.test(text)) && !fieldNamePattern("base_info").test(text)) {
      errors.push(`${rel(file)}: non-Java enterprise_name must be nested under base_info.enterprise_name for enterprise.registerinvite.create; do not put enterprise_name at top level`);
    }

    const forbiddenTopLevel = [
      "enterprise_email",
      "contact_mobile",
      "contact_name",
      "contact_phone",
      "contactPhone",
      "contact_email",
      "contactEmail",
      "employee_sign_mode",
      "invite_type",
      "logo",
    ];
    for (const field of forbiddenTopLevel) {
      if (fieldNamePattern(field).test(text)) {
        errors.push(`${rel(file)}: non-Java enterprise.registerinvite.create uses unsupported guessed top-level field: ${field}`);
      }
    }
  }
}

function checkCrossLanguageEmployeeFields(text, errors) {
  if (!/alipay\.commerce\.ec\.employee\.(?:add|info\.modify)|employee\.add|EmployeeAdd|EmployeeInfoModify/i.test(text)) return;
  const guessed = [
    ["name", "employee_name"],
    ["phone", "employee_mobile"],
    ["role", "documented employee fields"],
    ["departmentIdList", "department_ids"],
    ["department_id_list", "department_ids"],
  ];
  for (const [field, expected] of guessed) {
    const pattern = /^[a-z]+$/.test(field) ? fieldKeyPattern(field) : fieldAssignmentPattern(field);
    if (pattern.test(text)) {
      errors.push(`non-Java employee code uses guessed field ${field}; use ${expected} from employee docs`);
    }
  }
}

function checkCrossLanguageIdListQuery(text, errors) {
  if (!/alipay\.commerce\.ec\.employee\.idlist\.query|employee\.idlist\.query|EmployeeIdlistQuery/i.test(text)) return;
  if (!fieldNamePattern("department_id").test(text)) {
    errors.push("non-Java employee.idlist.query must include required documented field department_id");
  }
}

function checkCrossLanguageNotifyAndSignature(files, text, errors, warnings) {
  checkCrossLanguageSignatureStubs(text, errors);
  const hasNotifyFile = files.some((file) => /notify|handler|callback/i.test(path.basename(file)) || /\/notify\//i.test(rel(file)));
  const hasNotifyMethod = /alipay\.commerce\.ec\.(?:enterprise|employee)\.change\.notify/.test(text);
  if ((hasNotifyFile || hasNotifyMethod) && !/checkNotifySign|verifyNotify|verifySign|validateSign|rsaCheck|signature/i.test(text)) {
    warnings.push("EC notification code found but no signature verification token detected; ensure HTTP(S) notifications are verified before business handling");
  }
}

function checkCrossLanguageSignatureStubs(text, errors) {
  if (/\b(?:verify|check|validate)[A-Za-z0-9_]*(?:Sign|Signature|Notify)[A-Za-z0-9_]*\s*\([^)]*\)\s*\{[\s\S]{0,180}?\breturn\s+true\b/i.test(text)) {
    errors.push("non-Java signature verification contains a return-true stub");
  }
}

function checkCrossLanguageBuild(files, warnings, errors) {
  const exts = new Set(files.map((f) => path.extname(f).toLowerCase()));
  if (exts.has(".py")) checkPythonSyntax(files.filter((f) => f.endsWith(".py")), warnings, errors);
  if (exts.has(".go")) checkGoBuild(warnings, errors);
  if (exts.has(".cs")) checkDotnetBuild(warnings, errors);
  if (exts.has(".php")) checkPhpSyntax(files.filter((f) => f.endsWith(".php")), warnings, errors);
}

function checkPythonSyntax(files, warnings, errors) {
  if (!commandExists("python3")) {
    warnings.push("python3 not found; skipped Python syntax validation");
    return;
  }
  const script = [
    "import ast, pathlib, sys",
    "for name in sys.argv[1:]:",
    "    path = pathlib.Path(name)",
    "    ast.parse(path.read_text(encoding='utf-8'), filename=str(path))",
  ].join("\n");
  const result = spawnSync("python3", ["-c", script, ...files], {
    cwd: targetDir,
    encoding: "utf8",
    env: Object.assign({}, process.env, { PYTHONDONTWRITEBYTECODE: "1" }),
    maxBuffer: 1024 * 1024,
  });
  if (result.status !== 0) errors.push(`Python syntax validation failed:\n${lastLines(result.stderr || result.stdout)}`);
}

function checkGoBuild(warnings, errors) {
  const goMod = findFile(targetDir, "go.mod");
  if (!goMod) {
    warnings.push("Go source detected but go.mod not found; skipped go test");
    return;
  }
  if (!commandExists("go")) {
    warnings.push("go command not found; skipped go test");
    return;
  }
  const result = spawnSync("go", ["test", "./..."], {
    cwd: path.dirname(goMod),
    encoding: "utf8",
    env: Object.assign({}, process.env, { GOCACHE: path.join(os.tmpdir(), "alipay-skill-go-cache") }),
    maxBuffer: 1024 * 1024 * 4,
  });
  if (result.status !== 0) errors.push(`go test ./... failed:\n${lastLines(`${result.stdout || ""}\n${result.stderr || ""}`, 40)}`);
}

function checkDotnetBuild(warnings, errors) {
  const project = walk(targetDir).find((f) => /\.csproj$/i.test(f));
  if (!project) {
    warnings.push(".NET source detected but no .csproj found; skipped dotnet build");
    return;
  }
  if (!commandExists("dotnet")) {
    warnings.push("dotnet command not found; skipped dotnet build");
    return;
  }
  const result = spawnSync("dotnet", ["build", "--nologo"], {
    cwd: path.dirname(project),
    encoding: "utf8",
    maxBuffer: 1024 * 1024 * 8,
  });
  if (result.status !== 0) errors.push(`dotnet build failed:\n${lastLines(`${result.stdout || ""}\n${result.stderr || ""}`, 40)}`);
}

function checkPhpSyntax(files, warnings, errors) {
  if (!commandExists("php")) {
    warnings.push("php command not found; skipped PHP syntax validation");
    return;
  }
  for (const file of files) {
    const result = spawnSync("php", ["-l", file], { cwd: targetDir, encoding: "utf8", maxBuffer: 1024 * 256 });
    if (result.status !== 0) errors.push(`php -l failed for ${rel(file)}:\n${lastLines(result.stderr || result.stdout)}`);
  }
}

function commandExists(command) {
  const result = spawnSync(command, ["--version"], { encoding: "utf8", maxBuffer: 1024 * 32 });
  return result.status === 0;
}

function fieldNamePattern(field) {
  return new RegExp(`(^|[^A-Za-z0-9_])${escapeRegExp(field)}([^A-Za-z0-9_]|$)`);
}

function fieldAssignmentPattern(field) {
  return new RegExp(`["']${escapeRegExp(field)}["']\\s*(?:=>|:|=)|\\b${escapeRegExp(field)}\\b\\s*(?:=>|:|=)`);
}

function fieldKeyPattern(field) {
  return new RegExp(`["']${escapeRegExp(field)}["']\\s*(?:=>|:|=)`);
}

function stripCrossLanguageComments(text, file) {
  if (file.endsWith(".py")) return text.replace(/^\s*#.*$/gm, "");
  return text
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/^\s*\/\/.*$/gm, "")
    .replace(/^\s*#.*$/gm, "");
}

function isEcFile(file) {
  const relPath = rel(file).split(path.sep).join("/");
  if (/\/(bill|expense)\//.test(`/${relPath}`)) return false;
  if (/\/ec\//.test(`/${relPath}`)) return true;
  const text = fs.readFileSync(file, "utf8");
  return /AlipayCommerceEc|alipay\.commerce\.ec\.(enterprise|employee)|Enterprise|Employee/.test(text);
}

function extractMethods(text) {
  const methods = [];
  const pattern = /\b(?:public|private|protected)\s+(?:static\s+)?[A-Za-z0-9_<>, ?\[\]]+\s+([A-Za-z0-9_]+)\s*\(([^)]*)\)\s*(?:throws\s+[^{]+)?\{/g;
  for (const m of text.matchAll(pattern)) {
    const open = m.index + m[0].length - 1;
    const close = findMatchingBrace(text, open);
    if (close < 0) continue;
    methods.push({ name: m[1], body: text.slice(open, close + 1) });
  }
  return methods;
}

function findMatchingBrace(text, open) {
  // 轻量词法扫描：字符串和注释中的大括号不参与代码块配对，
  // 避免 bizContent JSON 或日志模板截断方法体。
  let depth = 0;
  let quote = null;
  let escaped = false;
  let lineComment = false;
  let blockComment = false;
  for (let i = open; i < text.length; i++) {
    const ch = text[i];
    const next = text[i + 1];

    if (lineComment) {
      if (ch === "\n") lineComment = false;
      continue;
    }
    if (blockComment) {
      if (ch === "*" && next === "/") {
        blockComment = false;
        i++;
      }
      continue;
    }
    if (quote) {
      if (escaped) {
        escaped = false;
      } else if (ch === "\\") {
        escaped = true;
      } else if (ch === quote) {
        quote = null;
      }
      continue;
    }

    if (ch === "/" && next === "/") {
      lineComment = true;
      i++;
      continue;
    }
    if (ch === "/" && next === "*") {
      blockComment = true;
      i++;
      continue;
    }
    if (ch === "\"" || ch === "'" || ch === "`") {
      quote = ch;
      continue;
    }

    if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}

function walk(dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory() && shouldSkipDir(entry.name)) return [];
    return entry.isDirectory() ? walk(full) : [full];
  });
}

function shouldSkipDir(name) {
  return new Set([".git", ".idea", ".codefuse", "node_modules", "target", "dist", "build", "coverage", "vendor", "bin", "obj", "__pycache__", ".venv", "venv"]).has(name);
}

function toSetter(field) {
  return `set${field.split("_").map((p) => p ? p[0].toUpperCase() + p.slice(1) : "").join("")}`;
}

function isRequired(value) {
  return /^(必须|必选)$/.test(value);
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function rel(file) {
  return path.relative(targetDir, file);
}

function report(name, errors, warnings) {
  for (const w of warnings) console.warn(`[${name}] WARN ${w}`);
  if (errors.length) {
    for (const e of errors) console.error(`[${name}] ERROR ${e}`);
    process.exit(1);
  }
  console.log(`[${name}] OK`);
}

function fail(msg) {
  console.error(`[alipay-enterprise-ec] ERROR ${msg}`);
  process.exit(1);
}
