# 员企 Node.js 质量门禁

本文件只约束 Node.js 生成代码。通用原则见 [员企通用代码生成规则](../codegen-general-rules.md)，字段和接口来源见 [员企字段和接口规则](../field-interface-rules.md)。

1. 必须读取真实安装的 `alipay-sdk` 导出形态。CommonJS 使用 `const { AlipaySdk } = require("alipay-sdk")`；不得写 `require("alipay-sdk").default`。
2. OpenAPI 2.0 `alipaySdk.exec(method, params, options)` 中，`appAuthToken` 必须作为第二个参数里的网关通参参与签名，例如 `exec(method, { bizContent, appAuthToken })`。
3. HTTP(S) 通知验签必须使用 SDK `checkNotifySign` / `checkNotifySignV2`，不得手写 `crypto.createVerify` 拼接验签串。
4. HTTP(S) 通知验签 helper 如果是 `async`，调用方必须 `await`；否则会把 Promise 当成验签通过。
5. `bizContent` 字段必须来自对应接口 Markdown 的“业务请求参数”表；发送请求前必须保证无条件必填字段已校验并赋值，条件必填字段按文档“必选条件”或身份组合规则校验。
6. 企业邀请注册必须使用 `out_biz_no`、`identity_type` 和 `identity` / `identity_open_id` 中的一个身份标识；企业名称只能放在 `base_info.enterprise_name`，不得把文档嵌套字段或不存在字段扁平化到顶层。
7. 员工添加必须支持文档里的身份条件组合；不得把可选字段或某个身份分支误写成唯一必填；部门字段使用 `department_ids`，不是近义或跨接口字段。
8. 员企通知遇到未知 `msg_method` 或未知 action 时，默认必须返回 `fail` 或由显式 unknown handler 返回处理结果；不得无处理地返回 `success`。
9. 员企接口必须覆盖所选企业入驻、员工签约、企业管理、员工管理模块的完整接口；不得只生成路由、注释或 TODO。
10. 生成后必须通过 `node --check`、模块加载和 `npm test`；测试脚本存在但失败时不得宣布生成完成。
11. 不得生成 SDK stub、固定成功返回、空验签或本地模拟接口来绕过 SDK 能力缺失。
