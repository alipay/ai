# alipay.commerce.ec.department.change.notify(部门变更通知)

部门变更通知，包括：部门创建、修改和删除

## 公共请求参数

| 参数 | 类型 | 是否必选 | 最大长度 | 描述 | 示例值 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| notify_id | String | 必选 | 50 | 通知ID | 5608cccc09ddb39d41c2e3c06e3d9fejh2 |
| utc_timestamp | String | 必选 | 13 | 消息发送时的服务端时间 | 1514210452731 |
| msg_method | String | 必选 | 100 | 消息接口名称 | alipay.commerce.ec.department.change.notify |
| app_id | String | 必选 | 20 | 消息接受方的应用id | 2014060600164699 |
| msg_type | String | 可选 | 5 | 消息类型。目前支持类型：sys：系统消息；usr，用户消息；app，应用消息 | sys |
| msg_app_id | String | 可选 | 20 | 消息归属方的应用id。应用消息时非空 | 2016032301002387 |
| version | String | 必选 | 5 | 版本号(1.1版本为标准消息) | 1.0或者1.1 |
| biz_content | String | 必选 | | 消息报文 | 参见消息属性 |
| sign | String | 必选 | | 签名 | WcO+t3D8Kg71dTlKwN7r9PzUOXeaBJwp8/FOuSxcuSkXsoVYxBpsAidprySCjHCjmaglNcjoKJQLJ28/Asl93joTW39FX6i07lXhnbPknezAlwmvPdnQuI01HZsZF9V1i6ggZjBiAd5lG8bZtTxZOJ87ub2i9GuJ3Nr/NUc9VeY= |
| sign_type | String | 必选 | 10 | 签名类型 | RSA2 |
| encrypt_type | String | 可选 | 10 | 加密算法 | AES |
| charset | String | 必选 | 10 | 编码集，该字符集为验签和解密所需要的字符集 | UTF-8 |
| notify_type | String | 可选 | 20 | [1.0版本老协议参数]通知类型，1.1接口没有该参数 | trade_status |
| notify_time | String | 可选 | 19 | [1.0版本老协议参数]通知时间，北京时区，时间格式为：yyyy-MM-dd HH:mm:ss | 1970-01-01 00:00:00 |
| auth_app_id | String | 可选 | 20 | [1.0版本老协议参数]授权方的应用id | 2016032301002387 |

## 消息属性

| 参数英文名 | 类型 | 是否必选 | 长度/取值 | 描述 | 示例值 |
|---|---|---|---|---|---|
| department_id | String | 必选 | 32 | 部门id | 1001094000039142 |
| enterprise_id | String | 必选 | 32 | 企业id | 2088441399627416 |
| action | String | 必选 | 32 | 变更动作，可选值：DEPARTMENT_CREATE：创建部门；DEPARTMENT_MODIFY：修改部门；DEPARTMENT_REMOVE：删除部门 | DEPARTMENT_CREATE |
| change_time | String | 必选 | 32 | 变更时间 | 2022-05-23 14:38:09 |
| department_name | String | 特殊可选 | 80 | 部门名称，当action为DEPARTMENT_CREATE时为空 | 产品部 |
| department_code | String | 特殊可选 | 64 | 部门编码，当action为DEPARTMENT_CREATE时为空 | D02415 |
| parent_department_id | String | 特殊可选 | 32 | 上级部门id，特殊值-1表示根部门，当action为DEPARTMENT_CREATE时为空 | 1001194000010003 |
| sub_department_id_list | String[] | 特殊可选 | 100000 | 删除的子部门id列表 | ["1001094000052875","1001094000052876"] |
| gmt_create | String | 特殊可选 | 32 | 创建时间，当action为DEPARTMENT_CREATE时为空 | 2022-04-20 17:13:51 |
| gmt_modified | String | 特殊可选 | 32 | 修改时间，当action为DEPARTMENT_CREATE时为空 | 2022-04-25 17:13:51 |
| ext_info | String | 可选 | 10000 | 扩展信息，JSON格式 | {"key": "value"} |

## 响应值

| 响应值 | 描述 | 是否重试 |
| :--- | :--- | :--- |
| fail | 消息获取失败 | 是 |
| success | 消息获取成功 | 否 |

## 消息示例

```http
ISV_GATEWAY_URL?charset=GBK&biz_content=
{
"department_id":"1001094000039142",
"enterprise_id":"2088441399627416",
"action":"DEPARTMENT_CREATE",
"change_time":"2022-05-23 14:38:09",
"department_name":"产品部",
"department_code":"D02415",
"parent_department_id":"1001194000010003",
      "sub_department_id_list":[
        "1001094000052875","1001094000052876"
      ],
"gmt_create":"2022-04-20 17:13:51",
"ext_info":"{\"key\": \"value\"}",
"gmt_modified":"2022-04-25 17:13:51"
}
&msg_method=alipay.commerce.ec.department.change.notify&utc_timestamp=1516797622752&version=1.1&sign_type=RSA2&notify_id=d275fec564e62af6bedbcee73f3f05fi5x&app_id=2013121700999429&sign=I+Y/lvqYUEEc10EPdpntRhFIQ==
```
