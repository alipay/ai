# 消息接口集成

## 简介

蚂蚁集团向外推送官方消息。推送内容包括（蚂蚁集团交易、签约、商品等信息），基于该推送服务，应用获取蚂蚁集团数据不需再不停轮询 API，仅需在接收到蚂蚁集团推送的消息时调用 API 获取即可，大幅提高 API 调用效率。

## 使用流程

![](https://cdn.nlark.com/yuque/0/2023/png/179989/1679643587372-1c64313f-7b56-4fbd-9d6d-598a810ffb52.png)

## 开通服务

### 订阅消息

#### 订阅消息接口

在应用页面点击左侧的 **开发设置** 进入消息服务的订阅管理页面，在 **From 平台** 标签页即可订阅所需监听的消息接口（以下以网页移动&应用为例进行说明）。

![](https://cdn.nlark.com/yuque/0/2022/png/179989/1661246237293-627d6416-5c6d-4663-a59a-d9e2fe16f9d6.png)

## 接入实现

目前开放平台消息服务支持商家两种通讯协议来接收消息，分为长连接 SDK 以及 http(s)，后续根据需要支付宝还可能会提供更丰富的支持，商家可以根据自己的需要自行选择接入方式。

针对不同的消息接口开发者可以在订阅消息接口时选择接入方式，原有已经订阅过的消息接口默认使用 http 来投递消息，不会影响到现有业务。

### websocket 长连接

如果开发者在订阅消息接口时，选择了 websocket 长连接接入，则可以忽略后续关于 http(s) 接入的相关说明，专注于实现接收消息后的业务处理逻辑即可。

与 http(s) 相比，该方式接入性能更优，通道安全，减少成本，接入快速等优势，**推荐使用 websocket 长连接 SDK 来接收 From 蚂蚁消息：**

- 官方 SDK，处理消息无需关心验签，协议报文组装等业务逻辑，提升消费成功率，专注消息内容处理业务即可。
- 无需开启 httpserver，通过长连接可以提供更高效的通讯能力，特别是对于量大的场景效果更明显。
- 针对非 https 的商家提供安全的通讯渠道，减少申请 https 服务端证书的成本，也能具备一定的安全能力。
- 商家可以接收来自于蚂蚁的消息，后续还可以发送 To 蚂蚁消息，消息通讯协议统一，可以有效降低接入成本。

#### 公钥设置

为了在接收消息时能正常的验签，开发者需要在开放平台门户的 **开发信息** 页面的 **接口加签方式** 中设置 **应用公钥**，如果该应用已经设置过则可以忽略该步骤。

![](https://cdn.nlark.com/yuque/0/2022/png/179989/1661246419341-2248155c-d6b0-4cd9-a1e2-0cc5e5ef9a6d.png)

#### 处理 From 蚂蚁消息

长连接 SDK 的接入说明以及代码 demo 可查看 [WebSocket长连接接入](../common/websocket-integration.md)。

### http(s)接入

#### 网关设置

登录开放平台控制台，在应用 **首页/开发设置** 下设置应用网关。

![](https://cdn.nlark.com/yuque/0/2022/png/179989/1661246532928-ee6b2dd3-cf17-4ae8-8ab3-2a18fce5ae4d.png)

##### 应用网关地址

默认情况下，支付宝主动以 POST 方式发送通知消息给配置的应用网关地址。

**注意**：产品地址优先。即：若具体对接的产品额外说明了消息投递的地址，则请优先使用产品指定的地址，例如 [App支付](https://opendocs.alipay.com/open/204/105297) 产品的 notify_url 参数。

##### 加签方式

默认情况下，支付宝投递的消息会使用此签名方法对消息进行签名。

**注意**：产品签名算法优先。即：若具体对接的产品额外说明了消息的加签方式，则请优先使用产品指定的加签方式，例如 [App支付](https://opendocs.alipay.com/open/204/105297) 产品的 sign_type 参数。

#### 处理 From 蚂蚁消息

![](https://gw.alipayobjects.com/zos/skylark/c32deb9c-0cfc-427c-896c-77c129f6964d/2018/png/41957286-9f9f-47e0-be6f-484020fafc73.png)

##### 验签

- 获取验签基本要素。
- 生成待验签字符串。

```javascript
charset=GBK
biz_content={"app_auth_token":"197002BB1bcb984cc0ab4c5ebed9c592df6acX80","auth_app_id":"2016062401550921","user_id":"2088102285927804","app_id":"1970121701099429"}
utc_timestamp=1518170340170
sign=ABC
app_id=1970121701099429
version=1.1
sign_type=RSA2
notify_id=2798c9cf5f88f24bb7ab6a94733cab1m3l
msg_method=alipay.open.auth.appauth.cancelled
```

则待验签字符串为：

```javascript
app_id=1970121701099429&biz_content={"app_auth_token":"197002BB1bcb984cc0ab4c5ebed9c592df6acX80","auth_app_id":"2016062401550921","user_id":"2088102285927804","app_id":"1970121701099429"}&charset=GBK&msg_method=alipay.open.auth.appauth.cancelled&notify_id=2798c9cf5f88f24bb7ab6a94733cab1m3l&utc_timestamp=1518170340170&version=1.1
```

- 调用验签函数。

使用各自语言对应的 SHA256WithRSA（对应 sign_type 为 RSA2）或 SHA1WithRSA（对应 sign_type 为 RSA）签名函数利用支付宝公钥对待验签字符串进行验签。 若使用开放平台服务端 SDK，可以使用以下方法处理`com.alipay.api.internal.util.AlipaySignature#rsaCheck`处理，对应不同的算法传递对应的签名算法和支付宝公钥即可。

```javascript
/**
 * 对报文进行验签
 * @param content 验签内容
 * @param sign 签名值
 * @param publicKey 支付宝公钥
 * @param charset 验签字符集
 * @param signType 签名算法
 * @return 验签结果。true: 验签通过； false: 验签失败
 * @throws AlipayApiException
 */
public static boolean rsaCheck(String content, String sign,
                               String publicKey, String charset,
                               String signType)
```

##### 幂等处理

由于消息存在重试机制（见投递重试策略），同一笔消息（相同 notify_id）可能多次发送（网络原因、商家服务器原因、或者商家接收处理成功但并未按要求返回 success 字符串等），消息接收方需要对同一个 notifyId 的多次消息投递实现幂等处理。若之前相同的 notify_id 已处理成功直接返回 success 字符串即可。

##### 业务处理

- 获取消息接口。  
From 蚂蚁消息接口名用于表示一个或一类业务变更消息。由于历史原因，存在两个消息接口标识：msg_method 和 notify_type。优先从 msg_method 获取消息接口标识，若不存在则用 notify_type 作为接口标识。
- 获取业务参数。  
标准的 From 蚂蚁消息接口的业务参数统一从 biz_content 中获取。历史原因一部分接口的业务报文的内容是平铺在一级参数（例如[ App支付的异步通知](https://opendocs.alipay.com/open/204/105301)），根据消息报文中的 msg_method，实际的业务处理，具体的业务报文以及处理逻辑请参考对应的 From 蚂蚁消息接口。
- 处理业务逻辑。  
请依据对接的具体业务自行处理。消息正确处理后，http 同步响应报文需要返回 success 字符串，消息服务则认为开发者已经处理成功，停止投递，否则会按照重投策略多次投递。

##### 反馈消息接收结果

消息正确处理后，http 同步响应报文需要返回 success 字符串，消息服务则认为开发者已经处理成功，停止投递，如果返回 `fail` 或其它值，表示消息获取失败，支付宝会根据 [投递重试策略](https://opendocs.alipay.com/common/02km9j#投递重试策略)（见投递重试策略） 重新发送消息到应用网关地址。

##### 样例代码

在 Github 上有不同开发者为支付宝开放平台做了一些非官方的 SDK，其中处理 From 蚂蚁消息的 SDK 中处理逻辑比较规范的可查看 [ant-open-sdk](https://github.com/telmochan/ant-open-sdk)，注意此项目为非官方的，相关代码仅供逻辑参考。

## FAQ

### 什么是消息签名？

支付宝投递给开发者应用的消息会对报文进行签名，更多签名相关的通用问题请移步 [签名专区](https://opendocs.alipay.com/common/02kf5p)。

### 为什么无法使用 RSA 签名算法？

为了提供更强级别的安全通信能力，新增应用强制要求使用 RSA2 签名算法，详情可查看 [支付宝开放平台接口签名方式升级公告](https://open.alipay.com/platform/announcement.htm?id=2)。

### 验签相关问题

验签失败的可能情况主要包括以下几类，请按顺序依次排查。

- 支付宝公钥错误。详情可查看 [生成并配置密钥](https://opendocs.alipay.com/common/02kdnc#%E7%AC%AC%E4%B8%89%E6%AD%A5%EF%BC%9A%E8%8E%B7%E5%8F%96%E6%94%AF%E4%BB%98%E5%AE%9D%E5%85%AC%E9%92%A5%2F%E8%AF%81%E4%B9%A6)。
- 字符集错误。使用报文中的 charset 参数作为验签字符集）。
- 签名原文错误。可查看 [异步通知验签](https://opendocs.alipay.com/common/02mse7#%E5%BC%82%E6%AD%A5%E9%80%9A%E7%9F%A5%E9%AA%8C%E7%AD%BE_3) 的待签名字符串说明。
- sign_type 是否参与签名。标准的 **From 蚂蚁** 消息在验签环节均需要把 sign 和 sign_type 两个参数去除（这种情况可以使用 [开放平台服务端SDK](https://opendocs.alipay.com/common/02kkv2) 里的`com.alipay.api.internal.util.AlipaySignature#getSignCheckContentV1`方法拼接）；有少部分历史消息接口验签时仅需要把 sign 移除（这部分消息接口会在产品文档中作特殊说明，这种情况可以使用 [开放平台服务端SDK](https://opendocs.alipay.com/common/02kkv2) 里的`com.alipay.api.internal.util.AlipaySignature#getSignCheckContentV2`方法拼接）。具体方法如下：

```javascript
/**
 * 获取待验证签名的内容
 * 该方法会去除请求参数中的sign和sign_type,然后对报文进行字母序排序拼接
 * @param params
 * @return
 */
public static String getSignCheckContentV1(Map<String, String> params)
/**
 * 获取待验证签名的内容
 * 该方法会去除请求参数中的sign,然后对报文进行字母序排序拼接
 * @param params
 * @return
 */
public static String getSignCheckContentV2(Map<String, String> params)
```

- 暂无 sign_type 参与验签的 From 蚂蚁消息接口。

### 如何提高 From 蚂蚁消息的消费能力？

以下仅作为建议的做法，请开发者根据自己的技术架构和业务场景做决策。

- [负载均衡](https://www.aliyun.com/product/slb?spm=5176.10695662.1112700.1.63f8544aTT1497)。
- 阿里云推荐使用 [云解析DNS](https://wanwang.aliyun.com/domain/dns/)。
- 异步化处理。即将消息可靠接收和业务处理做到异步，例如可以在做 **业务处理** 时将支付宝的消息投递到可靠的分布式消息队列，投递成功后即可以直接返回 success，然后再异步处理即可。

### 是否支持加密？

目前 From 蚂蚁消息的加密功能处于内测阶段。

### 为什么收不到 From 蚂蚁消息？

这种情况一般是开发者的配置的应用网关地址出现了问题，可能情况包括：

- 网关地址域名解析错误：可用`dig ${host} +short`查看。
- 服务有效性校验：一般是服务宕机，可通过`curl -vk https://${host}`或者`curl -vk http://${host}`验证链接有效性。
- 被防火墙白名单拦截：请联系技术支持获取蚂蚁集团的出口 IP 列表。
- **单 IP 多域名** 情况下，SNI 功能未开启：详情可查看 [SNI说明和开启说明](https://help.aliyun.com/knowledge_detail/40519.html)。
- https 情况下证书不被信任：不支持自签名证书，请保证证书由权威机构签发并且证书未失效。
- 投递到了其它地址：前面提到过，默认情况下所有蚂蚁集团的消息会投递到应用配置的 **应用网关** 地址，但是由于有些支付宝开放平台的功能会提供 **动态地址** 功能（例如 [App支付产品](https://gw.alipayobjects.com/os/skylark-tools/public/files/87688b4ca815619ff3c1fe5cdf8bb73c)），这种类型的产品会要求在请求 OpenAPI 的时候传递一个 notify_url 参数，在实际投递消息的时候会将消息投递到 notify_url 指定的地址。

**注意**：这种 **动态地址** 情况仅限于部分已有的开放平台产品（默认均不支持，支持的产品会在其产品文档中特殊说明），同时现有产品会继续支持此特性，后续新增的产品不会支持。一种简单的排查方式是：如果收到的消息接口标识为 msg_method 的情况是不支持 notify_url 这样的动态地址的，如果收到的消息接口标识为 notify_type 的情况则需要查看对应的产品文档。

### 投递重试策略

一般情况下，25 小时以内完成 8 次通知，除了第一次是实时投递外，后续的每次重试都会间隔一段时间，间隔频率一般是：2m、10m、10m、1h、2h、6h、15h（第二次消息投递是在第一次投递失败后的 2 分钟；第三次投递是在第二次投递失败后的 10 分钟，以此类推）。

**特别注意**：该策略仅供参考，重试策略仅适用于目前的大部分消息场景，蚂蚁集团会根据负载以及业务规则动态调整策略，请勿依赖此策略做任何业务强依赖。
