# alipay.commerce.ec.enterprise.reliable.create(可信渠道创建企业)
## 通用场景
可信渠道专用，创建企业并开通因公户账户，同时信任渠道认证等级自动完成企业认证
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.commerce.ec.enterprise.reliable.create|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|out_biz_no|String|必须|64|服务商生成的请求唯一流水号/业务幂等号； 字段作用： 1. 作为邀请注册的幂等标识，使用相同的out_biz_no 会得到相同的注册链接（若链接未使用过期，会重新生成） 2. 使用相同的身份标识（identity）传入不同的out_biz_no 可生成不同的链接，适用于一个用户注册多个企业 3. 若调用失败或超时，可以使用相同的 out_biz_no 进行幂等重试 4. 并发使用相同 out_biz_no 调用，会报错：邀请链接生成中 5. 当企业注册/认证/签约成功后，企业码系统发送的「企业状态变更通知」中，会携带out_biz_no，服务商可用于关联企业ID**注意事项**仅支持英文字母、数字、下划线组成|2024051000000001|
|identity_type|String|必须|64|企业管理员身份类型**枚举值**企业邮箱::ENTERPRISE_EMAIL支付宝会员uid:ALIPAY_USER_ID支付宝登录号:ALIPAY_LOGON_ID|ENTERPRISE_EMAIL|
|identity|String|特殊可选|64|企业管理员身份唯一标识，搭配 identity_type 传参： 1. 当identity_type=ENTERPRISE_EMAIL时，identity传企业邮箱；  2. identity_type=ALIPAY_USER_ID时，identity传支付宝会员uid（此时可与identity_open_id二选一）；  3. 当identity_type=ALIPAY_LOGON_ID时，identity传已注册支付宝且可以登录支付宝的手机号或邮箱|ym@alipay.com|
|identity_open_id|String|特殊可选|128|企业管理员身份标识openId**注意事项**服务商使用openId方式对接时，且当identity_type=ALIPAY_USER_ID，此字段传入对应的open_id|051PZjio8MFya3OHw9tl41J7Sy6m-z150mJTSHM3N3Es4sb|
|base_info|ReliableEnterpriseBaseInfoDTO|必须||企业基本信息||
|base_info.enterprise_name|String|必须|48|企业名称|支付宝测试有限公司|
|base_info.enterprise_code|String|特殊可选|18|企业营业执照中的统一社会信用代码，只能是数字和字母组成**必选条件**1. 当用户使用企业支付宝创建企业时，不依赖此参数，会以企支认证信息为准； 2. 当其他身份类型（如个人支付宝、企业邮箱）创建企业且企业为已认证时，该参数必填；|918805156111TT11TT|
|base_info.auth_status|String|必须|8|企业认证状态**枚举值**已认证:HAS_AUTH未认证:NO_AUTH|HAS_AUTH|
|base_info.industry|String|可选|128|企业所属行业**枚举值**零售:RETAIL餐饮:CATERING医疗健康:HEALTHCARE制造业:MANUFACTURING金融:FINANCE保险:INSURANCE互联网:INTERNET政务与公共服务:GOVERNMENT_SERVICES教育:EDUCATION运营商:TELECOMMUNICATIONS集团生态:GROUP_ECOSYSTEM大交通:BIG_TRANSPORT物流:LOGISTICS地产物业:REAL_ESTATE旅行社:TRAVEL_AGENCY票务代理:TICKET_AGENCY批发:WHOLESALETMC:TMC|RETAIL|
|profiles|ReliableEnterpriseProfilesDTO|必须||企业个性化信息，适用于特殊场景，请按需使用||
|profiles.access_channel|String|必须|16|企业注册来源渠道**枚举值**钉钉企业卡:DING_EC_CARD网商-生意卡:ANTBANK_CARD爱心码:LOVE_CODE网商-西进户:ANTBANK|DING_EC_CARD|
|profiles.count_employee|String|可选|16|企业当前的员工数规模区间**注意事项**可选值： (1,10] (11,50] (51,100] (101,200] (201,500] (501,1000] (1001,2000] (2001,10000] (10001,无穷)|(1,10]|
|profiles.legal_person_cert_no|String|可选|18|企业法人的身份证号码|110101199001011237|
|profiles.platform_gmt_create|String|可选|19|企业在来源渠道（如钉钉）的注册时间**注意事项**格式：yyyy-MM-dd HH:mm:ss|2025-01-01 10:00:00|
|profiles.auth_type|String|可选|2|企业在来源渠道（如钉钉）的认证类型**注意事项**钉钉平台传值规范：1-高级认证；2-改名；3-扩容；4-中级认证；5-中级资料修改；6-高级资料修改；7-初级认证；8-初级认证资料修改；9-高级总机认证；10-中级总机认证；11-年检认证；12-年检认证修改|1|
|profiles.activity_level|String|可选|8|企业在来源渠道（如钉钉）的活跃度|L1|
|profiles.tax_no|String|可选|20|企业纳税人识别号，适用于未三证合一的企业|91310230MA1K051234|
|profiles.biz_license_no|String|可选|20|企业营业执照编码，适用于未三证合一的企业|91310230MA1K054321|
|profiles.biz_license_url|String|可选|128|企业在来源渠道（如钉钉）的营业执照照片URL|https://xxxx|
|profiles.utm_source|String|可选|30|渠道侧流量来源，由渠道侧自定义|isv|
|profiles.utm_content|String|可选|30|具体流量内容区分，如推荐码、推荐人、推荐服务商名称等。由渠道侧自定义|杭州测试推广有限公司|
|profiles.utm_chain|String|可选|30|用于标识企业入驻链路**枚举值**C2B链路创建的企业:C2B其他链路创建的企业，不传默认为B2C:B2C|C2B|
|profiles.sign_fund_inst_id|String|可选|128|机构id|ANTBANK|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.domain.AlipayCommerceEcEnterpriseReliableCreateModel;
import com.alipay.api.domain.ReliableEnterpriseBaseInfoDTO;
import com.alipay.api.response.AlipayCommerceEcEnterpriseReliableCreateResponse;
import com.alipay.api.request.AlipayCommerceEcEnterpriseReliableCreateRequest;
import com.alipay.api.domain.ReliableEnterpriseProfilesDTO;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayCommerceEcEnterpriseReliableCreate {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayCommerceEcEnterpriseReliableCreateRequest request = new AlipayCommerceEcEnterpriseReliableCreateRequest();
        AlipayCommerceEcEnterpriseReliableCreateModel model = new AlipayCommerceEcEnterpriseReliableCreateModel();
        
        // 设置外部业务号
        model.setOutBizNo("2024051000000001");
        
        // 设置企业创建人身份类型
        model.setIdentityType("ENTERPRISE_EMAIL");
        
        // 设置企业创建人身份标识
        model.setIdentity("ym@alipay.com");
        
        // 设置企业管理员身份标识openId
        model.setIdentityOpenId("051PZjio8MFya3OHw9tl41J7Sy6m-z150mJTSHM3N3Es4sb");
        
        // 设置企业基本信息
        ReliableEnterpriseBaseInfoDTO baseInfo = new ReliableEnterpriseBaseInfoDTO();
        baseInfo.setIndustry("RETAIL");
        baseInfo.setEnterpriseCode("918805156111TT11TT");
        baseInfo.setAuthStatus("HAS_AUTH");
        baseInfo.setEnterpriseName("支付宝测试有限公司");
        model.setBaseInfo(baseInfo);
        
        // 设置企业个性化信息
        ReliableEnterpriseProfilesDTO profiles = new ReliableEnterpriseProfilesDTO();
        profiles.setAuthType("1");
        profiles.setBizLicenseUrl("https://xxxx");
        profiles.setUtmChain("C2B");
        profiles.setCountEmployee("(1,10]");
        profiles.setBizLicenseNo("91310230MA1K054321");
        profiles.setAccessChannel("DING_EC_CARD");
        profiles.setActivityLevel("L1");
        profiles.setPlatformGmtCreate("2025-01-01 10:00:00");
        profiles.setTaxNo("91310230MA1K051234");
        profiles.setSignFundInstId("ANTBANK");
        profiles.setLegalPersonCertNo("110101199001011237");
        profiles.setUtmSource("isv");
        profiles.setUtmContent("杭州测试推广有限公司");
        model.setProfiles(profiles);
        
        request.setBizModel(model);
        AlipayCommerceEcEnterpriseReliableCreateResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayCommerceEcEnterpriseReliableCreateRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayCommerceEcEnterpriseReliableCreateRequest();
$model = array();

// 设置外部业务号
$model['out_biz_no'] = "2024051000000001";

// 设置企业创建人身份类型
$model['identity_type'] = "ENTERPRISE_EMAIL";

// 设置企业创建人身份标识
$model['identity'] = "ym@alipay.com";

// 设置企业管理员身份标识openId
$model['identity_open_id'] = "051PZjio8MFya3OHw9tl41J7Sy6m-z150mJTSHM3N3Es4sb";

// 设置企业基本信息
$baseInfo = array();
$baseInfo['industry'] = "RETAIL";
$baseInfo['enterprise_code'] = "918805156111TT11TT";
$baseInfo['auth_status'] = "HAS_AUTH";
$baseInfo['enterprise_name'] = "支付宝测试有限公司";
$model['base_info'] = $baseInfo;

// 设置企业个性化信息
$profiles = array();
$profiles['auth_type'] = "1";
$profiles['biz_license_url'] = "https://xxxx";
$profiles['utm_chain'] = "C2B";
$profiles['count_employee'] = "(1,10]";
$profiles['biz_license_no'] = "91310230MA1K054321";
$profiles['access_channel'] = "DING_EC_CARD";
$profiles['activity_level'] = "L1";
$profiles['platform_gmt_create'] = "2025-01-01 10:00:00";
$profiles['tax_no'] = "91310230MA1K051234";
$profiles['sign_fund_inst_id'] = "ANTBANK";
$profiles['legal_person_cert_no'] = "110101199001011237";
$profiles['utm_source'] = "isv";
$profiles['utm_content'] = "杭州测试推广有限公司";
$model['profiles'] = $profiles;

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
$responseResult = $alipayClient->execute($request);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayCommerceEcEnterpriseReliableCreate
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayCommerceEcEnterpriseReliableCreateRequest request = new AlipayCommerceEcEnterpriseReliableCreateRequest();
            AlipayCommerceEcEnterpriseReliableCreateModel model = new AlipayCommerceEcEnterpriseReliableCreateModel();
            
            // 设置外部业务号
            model.OutBizNo = "2024051000000001";
            
            // 设置企业创建人身份类型
            model.IdentityType = "ENTERPRISE_EMAIL";
            
            // 设置企业创建人身份标识
            model.Identity = "ym@alipay.com";
            
            // 设置企业管理员身份标识openId
            model.IdentityOpenId = "051PZjio8MFya3OHw9tl41J7Sy6m-z150mJTSHM3N3Es4sb";
            
            // 设置企业基本信息
            ReliableEnterpriseBaseInfoDTO baseInfo = new ReliableEnterpriseBaseInfoDTO();
            baseInfo.Industry = "RETAIL";
            baseInfo.EnterpriseCode = "918805156111TT11TT";
            baseInfo.AuthStatus = "HAS_AUTH";
            baseInfo.EnterpriseName = "支付宝测试有限公司";
            model.BaseInfo = baseInfo;
            
            // 设置企业个性化信息
            ReliableEnterpriseProfilesDTO profiles = new ReliableEnterpriseProfilesDTO();
            profiles.AuthType = "1";
            profiles.BizLicenseUrl = "https://xxxx";
            profiles.UtmChain = "C2B";
            profiles.CountEmployee = "(1,10]";
            profiles.BizLicenseNo = "91310230MA1K054321";
            profiles.AccessChannel = "DING_EC_CARD";
            profiles.ActivityLevel = "L1";
            profiles.PlatformGmtCreate = "2025-01-01 10:00:00";
            profiles.TaxNo = "91310230MA1K051234";
            profiles.SignFundInstId = "ANTBANK";
            profiles.LegalPersonCertNo = "110101199001011237";
            profiles.UtmSource = "isv";
            profiles.UtmContent = "杭州测试推广有限公司";
            model.Profiles = profiles;
            
            request.SetBizModel(model);
            AlipayCommerceEcEnterpriseReliableCreateResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.commerce.ec.enterprise.reliable.create&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'biz_content={
	"out_biz_no":"2024051000000001",
	"identity_type":"ENTERPRISE_EMAIL",
	"identity":"ym@alipay.com",
	"identity_open_id":"051PZjio8MFya3OHw9tl41J7Sy6m-z150mJTSHM3N3Es4sb",
	"base_info":{
		"industry":"RETAIL",
		"enterprise_code":"918805156111TT11TT",
		"auth_status":"HAS_AUTH",
		"enterprise_name":"支付宝测试有限公司"
	},
	"profiles":{
		"auth_type":"1",
		"biz_license_url":"https://xxxx",
		"utm_chain":"C2B",
		"count_employee":"(1,10]",
		"biz_license_no":"91310230MA1K054321",
		"access_channel":"DING_EC_CARD",
		"activity_level":"L1",
		"platform_gmt_create":"2025-01-01 10:00:00",
		"tax_no":"91310230MA1K051234",
		"sign_fund_inst_id":"ANTBANK",
		"legal_person_cert_no":"110101199001011237",
		"utm_source":"isv",
		"utm_content":"杭州测试推广有限公司"
	}
}' 
```
 

### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|必须|32|企业码企业ID|2088770030000000|
|account_id|String|必须|32|因公付共同账户ID|2088770030000000|
### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_commerce_ec_enterprise_reliable_create_response":{
		"code":"10000",
		"msg":"Success",
		"enterprise_id":"2088770030000000",
		"account_id":"2088770030000000"
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_commerce_ec_enterprise_reliable_create_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|ECEIF_ENTERPRISE_ALIAS_EXIST|当前账号已存在相同企业名称，请修改|企业简称和已有企业重复，请更换企业名称|
|ENTERPRISE_CREATE_ING|企业创建中，请稍后|企业正在创建中，通常由于并发创建企业导致，请稍后重试|
|ENTERPRISE_EMAIL_ALREADY_EXIST|企业邮箱已注册企业|该企业邮箱已注册企业，可直接登录，登陆密码已发送至该企业邮箱中|
|ENTERPRISE_MAIL_INVALID_CHARACTERS|邮箱不能包含特殊关键字词|邮箱包含非法关键词（如前缀包含aliapy, alibaba, aliyun等），请更换邮箱重试|
|EXIST_SAME_NAME_VERIFIED_ENTERPRISE|当前账号存在同名已认证企业，请修改|当前支付宝账号存在同名已认证企业，请更换企业名称重试|
|IDENTITY_INFO_INCOMPLETE|本次操作已受限，如需继续使用服务，请您完善身份信息|本次操作已受限，如需继续使用服务，请您完善身份信息|
|NO_PERMISSION_NOT_CERTIFIED|支付宝账号未实名认证，请实名认证后重试|用户未实名，无法使用该功能，请先进行支付宝实名认证。|
|OPERATION_LIMITED|本次操作已受限，如需帮助请致电95188|本次操作已受限，如需帮助请致电95188|
|PERMISSION_DENIED|接口无权限|接口仅特定渠道可用，请先联系客服小二|
|SECURITY_CHECK_FAILED|安全检查失败。安全风控校验不通，存在安全风险|安全风控校验不通，存在安全风险|
|SENSITIVE_WORDS_EXIST|存在敏感词，请修改后重新提交|输入信息（如服务商邀请码）中包含敏感词，请检查并移除可能涉及广告违禁、政治、违法等关键词后重试|
|USER_NOT_EXIST|支付宝用户不存在，请修改后重试|支付宝用户不存在，请检查入参 identity 的正确性，更换支付宝账号重试|
|USER_STATUS_ERROR|支付宝账号状态异常，请拨打95188进行咨询|支付宝账号状态异常，请拨打95188进行咨询|