# 可信渠道注册模式流程

## 概述

> **【注意】** 可信渠道注册模式面向可信渠道（钉钉、网商、爱心码等）提供的专用接口，企业码会完全信任渠道侧的企业认证状态。
> 
> 此模式<u>不对生态服务商开放</u>，如有可信渠道需求，请先**<u>联系企业码员企产品（忞雯）+ 职能同学（星航、甘茂、沐笙）严格准入评估</u>**，然后由员企产品提交需求至技术侧（颁发可信渠道码、分配接口权限），否则概不受理。

## 前置依赖

- 颁发可信渠道码
- 分配接口权限

## 流程图

```
┌─────────────────────────────────────────────────────────────────────────┐
│                       可信渠道注册模式流程                                 │
└─────────────────────────────────────────────────────────────────────────┘

【模式1：企业先认证后开通企业码】

┌─────────────┐     ┌─────────────────────────────────────┐     ┌─────────────┐
│   渠道侧    │ ──► │  企业完成认证                        │ ──► │  认证成功    │
│             │     │                                     │     │             │
└─────────────┘     └─────────────────────────────────────┘     └─────────────┘
                                                                         │
                                                                         ▼
┌─────────────┐     ┌─────────────────────────────────────┐     ┌─────────────┐
│  开通结果    │ ◄── │  调用可信渠道企业注册接口              │ ◄── │  开通企业码   │
│             │     │  alipay.commerce.ec.enterprise.     │     │             │
│             │     │         reliable.create               │     │             │
│             │     │  auth_status=已认证                   │     │             │
└─────────────┘     └─────────────────────────────────────┘     └─────────────┘


【模式2：企业先开通企业码后认证】

┌─────────────┐     ┌─────────────────────────────────────┐     ┌─────────────┐
│   渠道侧    │ ──► │  调用可信渠道企业注册接口              │ ──► │  开通成功    │
│             │     │  alipay.commerce.ec.enterprise.       │     │             │
│             │     │         reliable.create               │     │             │
│             │     │  auth_status=未认证                   │     │             │
└─────────────┘     └─────────────────────────────────────┘     └─────────────┘
                                                                         │
                                                                         ▼
┌─────────────┐     ┌─────────────────────────────────────┐     ┌─────────────┐
│  认证结果    │ ◄── │  调用可信企业认证信息同步接口          │ ◄── │  渠道侧完成   │
│             │     │  alipay.commerce.ec.enterprise.       │     │  企业认证     │
│             │     │         reliableauth.sync             │     │             │
└─────────────┘     └─────────────────────────────────────┘     └─────────────┘
```

## 接口文档

| 阶段 | 接口说明 | 接口文档 | 备注 |
|------|----------|----------|------|
| **企业注册** | 可信渠道企业注册 | [alipay.commerce.ec.enterprise.reliable.create.md](alipay.commerce.ec.enterprise.reliable.create.md) | 创建企业并开通因公户账户，信任渠道侧认证状态 |
| **认证同步** | 可信企业认证信息同步 | [alipay.commerce.ec.enterprise.reliableauth.sync.md](alipay.commerce.ec.enterprise.reliableauth.sync.md) | 先开通后认证模式下，同步渠道企业认证信息 |
| **消息接收** | 企业变更通知 | [../enterprise-register-invite/enterprise-change-notify.md](../enterprise-register-invite/enterprise-change-notify.md) | 接收企业入驻、认证、激活等状态变更 |

## 必须接入模块

完成企业入驻后，必须接入以下模块：

### 1. 企业管理

| 接口说明 | 接口文档 | 用途 |
|----------|----------|------|
| 查询企业详情 | [../enterprise-mgmt/alipay.commerce.ec.enterprise.info.query.md](../enterprise-mgmt/alipay.commerce.ec.enterprise.info.query.md) | 查询企业详细信息 |
| 修改企业信息 | [../enterprise-mgmt/alipay.commerce.ec.enterprise.info.modify.md](../enterprise-mgmt/alipay.commerce.ec.enterprise.info.modify.md) | 修改企业基本信息 |
| 注销企业 | [../enterprise-mgmt/alipay.commerce.ec.enterprise.delete.md](../enterprise-mgmt/alipay.commerce.ec.enterprise.delete.md) | 企业注销、解约 |

### 2. 员工签约

> 完成企业入驻后，需进入员工签约阶段。若由方案型 Skill 调用，沿用上游确定的员工签约模式；独立使用时按 SKILL.md「步骤 1：确定模式」选择员工签约模式（默认邀请员工签约，按需切换授权签约模式）。

### 3. 员工管理

| 接口说明 | 接口文档 | 用途 |
|----------|----------|------|
| 查询员工详情 | [../employee-mgmt/alipay.commerce.ec.employee.info.query.md](../employee-mgmt/alipay.commerce.ec.employee.info.query.md) | 查询员工详细信息 |
| 修改员工信息 | [../employee-mgmt/alipay.commerce.ec.employee.info.modify.md](../employee-mgmt/alipay.commerce.ec.employee.info.modify.md) | 修改员工基本信息、部门、核算主体等 |
| 删除员工 | [../employee-mgmt/alipay.commerce.ec.employee.delete.md](../employee-mgmt/alipay.commerce.ec.employee.delete.md) | 员工离职删除 |
| 查询部门下员工ID列表 | [../employee-mgmt/alipay.commerce.ec.employee.idlist.query.md](../employee-mgmt/alipay.commerce.ec.employee.idlist.query.md) | 分页查询部门下员工 |
| 查询标签下员工ID列表 | [../employee-mgmt/alipay.commerce.ec.label.employeeidlist.query.md](../employee-mgmt/alipay.commerce.ec.label.employeeidlist.query.md) | 根据标签查询员工 |
| 员工变更通知 | [../employee-sign-invite/employee-change-notify.md](../employee-sign-invite/employee-change-notify.md) | 接收员工新增、激活、修改、删除通知 |

## 按需接入模块（可选）

根据业务需求选择性接入：

| 模块 | 流程文档 | 说明 |
|------|----------|------|
| **部门管理** | [../department/department-flow.md](../department/department-flow.md) | 部门树管理、员工所属部门管理 |
| **核算主体管理** | [../accounting-entity/accounting-entity-flow.md](../accounting-entity/accounting-entity-flow.md) | 核算主体管理、员工所属核算主体管理 |
| **企业地址管理** | [../enterprise-address/enterprise-address-flow.md](../enterprise-address/enterprise-address-flow.md) | 企业办公地址管理 |
| **企业消息推送任务** | [../msg-task/msg-task-flow.md](../msg-task/msg-task-flow.md) | 消息盒子、Push消息推送 |

## 消息接入方式选择

若由方案型 Skill 调用且上游已统一消息接入方式，直接沿用上游决策；独立使用时按本节选择，默认推荐 WebSocket 长连接。

企业变更通知支持两种接入方式：

| 接入方式 | 适用场景 | 特点 |
|----------|----------|------|
| **WebSocket 长连接**（推荐） | 消息量大、实时性要求高 | 性能优、通道安全、无需 HTTPS 证书、SDK 自动验签 |
| **HTTP(S) 接入** | 消息量小、已有 HTTP 服务 | 需配置应用网关、需自行实现验签、需处理幂等 |

**详细接入文档**：
- [消息接口集成说明](../common/message-integration.md) - HTTP(S) 消息接入
- [WebSocket 长连接接入](../common/websocket-integration.md) - WebSocket 接入

## 参考文档

- [消息接口集成说明](../common/message-integration.md) - HTTP(S) 消息接入详细说明
- [WebSocket 长连接接入](../common/websocket-integration.md) - WebSocket 接入详细说明
