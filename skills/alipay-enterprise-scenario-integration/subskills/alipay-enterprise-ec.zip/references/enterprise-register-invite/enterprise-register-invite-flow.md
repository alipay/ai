# 邀请企业注册模式流程

## 概述

邀请企业注册模式是服务商邀请企业自助完成注册、认证、签约三合一流程的通用模式。

## 前置配置

+ 企业管理员身份类型，默认开放「支付宝用户UID」或「支付宝登录号」，如遇特殊场景：
    - 若必须使用<u>企业邮箱 (ENTERPRISE_EMAIL)</u>，请联系BD同学，按技术配置需求SOP提交申请
    - 若必须使用<u>服务商用户ID (ISV_USER_ID)</u>，由于此方案下企业码系统无法核验用户身份，存在较高安全风险，因此需BD同学<u>先联系职能同学（星航、甘茂）+中台同学审批</u>，再按技术配置SOP提交申请

## 流程图

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        邀请企业注册模式流程                                │
└─────────────────────────────────────────────────────────────────────────┘

【企业入驻流程】

┌─────────────┐     ┌─────────────────────────────────────┐     ┌─────────────┐
│   服务商     │ ──► │  调用邀请企业注册接口                  │ ──► │  获取注册链接  │
│             │     │  alipay.commerce.ec.enterprise.     │     │             │
│             │     │         registerinvite.create         │     │             │
└─────────────┘     └─────────────────────────────────────┘     └─────────────┘
                                                                         │
                                                                         ▼
┌─────────────┐     ┌─────────────────────────────────────┐     ┌─────────────┐
│  企业管理员  │ ◄── │  跳转/内嵌企业码企业注册页面          │ ◄── │  邀请企业     │
│             │     │                                     │     │  完成注册     │
└─────────────┘     └─────────────────────────────────────┘     └─────────────┘
       │
       ▼
┌─────────────┐
│ 企业完成     │
│ 注册/认证/   │
│ 资金签约     │
└─────────────┘
       │
       ▼
┌─────────────────────────────────────┐
│  接收企业变更通知                     │
│  alipay.commerce.ec.enterprise.    │
│         change.notify                │
│  action=ENTERPRISE_CREATE            │
│  action=ENTERPRISE_ACTIVATED         │
│  action=ENTERPRISE_AUTH              │
└─────────────────────────────────────┘
```

## 接口文档

| 阶段 | 接口说明 | 接口文档 | 备注 |
|------|----------|----------|------|
| **企业入驻** | 邀请企业注册 | [alipay.commerce.ec.enterprise.registerinvite.create](https://opendocs.alipay.com/pre-open/59de3d66_alipay.commerce.ec.enterprise.registerinvite.create.md) | 获取企业注册链接 |
| **消息接收** | 企业变更通知 | [enterprise-change-notify](https://opendocs.alipay.com/pre-open/e34175b7_alipay.commerce.ec.enterprise.change.notify.md) | 接收企业入驻、认证、激活等状态变更 |

## 必须接入模块

完成企业入驻后，必须接入以下模块：

### 1. 企业管理

| 接口说明 | 接口文档 | 用途 |
|----------|----------|------|
| 查询企业详情 | [alipay.commerce.ec.enterprise.info.query](https://opendocs.alipay.com/pre-open/8bf9819f_alipay.commerce.ec.enterprise.info.query.md) | 查询企业详细信息 |
| 修改企业信息 | [alipay.commerce.ec.enterprise.info.modify](https://opendocs.alipay.com/pre-open/852ff146_alipay.commerce.ec.enterprise.info.modify.md) | 修改企业基本信息 |
| 注销企业 | [alipay.commerce.ec.enterprise.delete](https://opendocs.alipay.com/pre-open/ca08a920_alipay.commerce.ec.enterprise.delete.md) | 企业注销、解约 |

### 2. 员工签约

> 完成企业入驻后，需进入员工签约阶段。若由方案型 Skill 调用，沿用上游确定的员工签约模式；独立使用时按 SKILL.md「步骤 1：确定模式」选择员工签约模式（默认邀请员工签约，按需切换授权签约模式）。

### 3. 员工管理

| 接口说明 | 接口文档 | 用途 |
|----------|----------|------|
| 查询员工详情 | [alipay.commerce.ec.employee.info.query](https://opendocs.alipay.com/pre-open/4d2bd8f0_alipay.commerce.ec.employee.info.query.md) | 查询员工详细信息 |
| 修改员工信息 | [alipay.commerce.ec.employee.info.modify](https://opendocs.alipay.com/pre-open/0ac4f5fb_alipay.commerce.ec.employee.info.modify.md) | 修改员工基本信息、部门、核算主体等 |
| 删除员工 | [alipay.commerce.ec.employee.delete](https://opendocs.alipay.com/pre-open/aa3f1b52_alipay.commerce.ec.employee.delete.md) | 员工离职删除 |
| 查询部门下员工ID列表 | [alipay.commerce.ec.employee.idlist.query](https://opendocs.alipay.com/pre-open/091b8f5c_alipay.commerce.ec.employee.idlist.query.md) | 分页查询部门下员工 |
| 查询标签下员工ID列表 | [alipay.commerce.ec.label.employeeidlist.query](https://opendocs.alipay.com/pre-open/fad25fa8_alipay.commerce.ec.label.employeeidlist.query.md) | 根据标签查询员工 |
| 员工变更通知 | [employee-change-notify](https://opendocs.alipay.com/pre-open/afb27d88_alipay.commerce.ec.employee.change.notify.md) | 接收员工新增、激活、修改、删除通知 |

## 按需接入模块（可选）

根据业务需求选择性接入：

| 模块 | 流程文档 | 说明 |
|------|----------|------|
| **部门管理** | [../department/department-flow.md](../department/department-flow.md) | 部门树管理、员工所属部门管理 |
| **核算主体管理** | [../accounting-entity/accounting-entity-flow.md](../accounting-entity/accounting-entity-flow.md) | 核算主体管理、员工所属核算主体管理 |
| **企业地址管理** | [../enterprise-address/enterprise-address-flow.md](../enterprise-address/enterprise-address-flow.md) | 企业办公地址管理 |
| **企业消息推送任务** | [../msg-task/msg-task-flow.md](../msg-task/msg-task-flow.md) | 消息盒子、Push消息推送 |

## 消息接入方式选择

若由方案型 Skill 调用且上游已统一消息接入方式，直接沿用上游决策；独立使用时按本节选择，默认推荐 WebSocket 长连接。

企业变更通知支持两种接入方式：

| 接入方式 | 适用场景 | 特点 |
|----------|----------|------|
| **WebSocket 长连接**（推荐） | 消息量大、实时性要求高 | 性能优、通道安全、无需 HTTPS 证书、SDK 自动验签 |
| **HTTP(S) 接入** | 消息量小、已有 HTTP 服务 | 需配置应用网关、需自行实现验签、需处理幂等 |

**详细接入文档**：
- [消息接口集成说明](https://opendocs.alipay.com/common/02km9j.md) - HTTP(S) 消息接入
- [WebSocket 长连接接入](https://opendocs.alipay.com/common/02kiq1.md) - WebSocket 接入

## 参考文档

- [消息接口集成说明](https://opendocs.alipay.com/common/02km9j.md) - HTTP(S) 消息接入详细说明
- [WebSocket 长连接接入](https://opendocs.alipay.com/common/02kiq1.md) - WebSocket 接入详细说明
