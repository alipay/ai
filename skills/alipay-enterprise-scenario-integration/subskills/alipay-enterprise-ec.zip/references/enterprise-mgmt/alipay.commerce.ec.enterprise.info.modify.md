# alipay.commerce.ec.enterprise.info.modify(修改企业基础信息)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
修改企业基础信息
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.commerce.ec.enterprise.info.modify|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://opendocs.alipay.com/isv/10467/xldcyq)||
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|必须|32|企业id|2088501412314698|
|enterprise_name|String|可选|48|企业名称**注意事项**已认证的企业不支持随意更换企业名称，需走企业认证流程|企业码测试有限公司|
|enterprise_alias|String|可选|14|企业简称**注意事项**简称将用于员工支付时收银台展示，变更简称需要审核通过后才会真正生效|企业码测试|
|reliable_profiles|ReliableEnterpriseProfilesDTO|可选||企业个性化信息，仅适用于可信渠道（如钉钉），普通场景请勿传此参数||
|reliable_profiles.access_channel|String|必须|16|企业注册来源渠道**枚举值**钉钉企业卡:DING_EC_CARD网商-生意卡:ANTBANK_CARD爱心码:LOVE_CODE网商-西进户:ANTBANK|DING_EC_CARD|
|reliable_profiles.count_employee|String|可选|16|企业当前的员工数规模区间**注意事项**可选值： (1,10] (11,50] (51,100] (101,200] (201,500] (501,1000] (1001,2000] (2001,10000] (10001,无穷)|(1,10]|
|reliable_profiles.legal_person_cert_no|String|可选|18|企业法人的身份证号码|110101199001011237|
|reliable_profiles.platform_gmt_create|String|可选|19|企业在来源渠道（如钉钉）的注册时间**注意事项**格式：yyyy-MM-dd HH:mm:ss|2025-01-01 10:00:00|
|reliable_profiles.auth_type|String|可选|2|企业在来源渠道（如钉钉）的认证类型**注意事项**钉钉平台传值规范：1-高级认证；2-改名；3-扩容；4-中级认证；5-中级资料修改；6-高级资料修改；7-初级认证；8-初级认证资料修改；9-高级总机认证；10-中级总机认证；11-年检认证；12-年检认证修改|1|
|reliable_profiles.activity_level|String|可选|8|企业在来源渠道（如钉钉）的活跃度|L1|
|reliable_profiles.tax_no|String|可选|20|企业纳税人识别号，适用于未三证合一的企业|91310230MA1K051234|
|reliable_profiles.biz_license_no|String|可选|20|企业营业执照编码，适用于未三证合一的企业|91310230MA1K054321|
|reliable_profiles.biz_license_url|String|可选|128|企业在来源渠道（如钉钉）的营业执照照片URL|https://xxxx|
|reliable_profiles.utm_source|String|可选|30|渠道侧流量来源，由渠道侧自定义|isv|
|reliable_profiles.utm_content|String|可选|30|具体流量内容区分，如推荐码、推荐人、推荐服务商名称等。由渠道侧自定义|杭州测试推广有限公司|
|reliable_profiles.utm_chain|String|可选|30|用于标识企业入驻链路**枚举值**C2B链路创建的企业:C2B其他链路创建的企业，不传默认为B2C:B2C|C2B|
|reliable_profiles.sign_fund_inst_id|String|可选|128|机构id|ANTBANK|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.domain.AlipayCommerceEcEnterpriseInfoModifyModel;
import com.alipay.api.response.AlipayCommerceEcEnterpriseInfoModifyResponse;
import com.alipay.api.request.AlipayCommerceEcEnterpriseInfoModifyRequest;
import com.alipay.api.domain.ReliableEnterpriseProfilesDTO;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayCommerceEcEnterpriseInfoModify {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayCommerceEcEnterpriseInfoModifyRequest request = new AlipayCommerceEcEnterpriseInfoModifyRequest();
        AlipayCommerceEcEnterpriseInfoModifyModel model = new AlipayCommerceEcEnterpriseInfoModifyModel();
        
        // 设置企业ID
        model.setEnterpriseId("2088501412314698");
        
        // 设置企业名称
        model.setEnterpriseName("企业码测试有限公司");
        
        // 设置企业简称
        model.setEnterpriseAlias("企业码测试");
        
        // 设置可信渠道企业个性化信息
        ReliableEnterpriseProfilesDTO reliableProfiles = new ReliableEnterpriseProfilesDTO();
        reliableProfiles.setAuthType("1");
        reliableProfiles.setBizLicenseUrl("https://xxxx");
        reliableProfiles.setUtmChain("C2B");
        reliableProfiles.setCountEmployee("(1,10]");
        reliableProfiles.setBizLicenseNo("91310230MA1K054321");
        reliableProfiles.setAccessChannel("DING_EC_CARD");
        reliableProfiles.setActivityLevel("L1");
        reliableProfiles.setPlatformGmtCreate("2025-01-01 10:00:00");
        reliableProfiles.setTaxNo("91310230MA1K051234");
        reliableProfiles.setSignFundInstId("ANTBANK");
        reliableProfiles.setLegalPersonCertNo("110101199001011237");
        reliableProfiles.setUtmSource("isv");
        reliableProfiles.setUtmContent("杭州测试推广有限公司");
        model.setReliableProfiles(reliableProfiles);
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayCommerceEcEnterpriseInfoModifyResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayCommerceEcEnterpriseInfoModifyRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayCommerceEcEnterpriseInfoModifyRequest();
$model = array();

// 设置企业ID
$model['enterprise_id'] = "2088501412314698";

// 设置企业名称
$model['enterprise_name'] = "企业码测试有限公司";

// 设置企业简称
$model['enterprise_alias'] = "企业码测试";

// 设置可信渠道企业个性化信息
$reliableProfiles = array();
$reliableProfiles['auth_type'] = "1";
$reliableProfiles['biz_license_url'] = "https://xxxx";
$reliableProfiles['utm_chain'] = "C2B";
$reliableProfiles['count_employee'] = "(1,10]";
$reliableProfiles['biz_license_no'] = "91310230MA1K054321";
$reliableProfiles['access_channel'] = "DING_EC_CARD";
$reliableProfiles['activity_level'] = "L1";
$reliableProfiles['platform_gmt_create'] = "2025-01-01 10:00:00";
$reliableProfiles['tax_no'] = "91310230MA1K051234";
$reliableProfiles['sign_fund_inst_id'] = "ANTBANK";
$reliableProfiles['legal_person_cert_no'] = "110101199001011237";
$reliableProfiles['utm_source'] = "isv";
$reliableProfiles['utm_content'] = "杭州测试推广有限公司";
$model['reliable_profiles'] = $reliableProfiles;

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayCommerceEcEnterpriseInfoModify
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayCommerceEcEnterpriseInfoModifyRequest request = new AlipayCommerceEcEnterpriseInfoModifyRequest();
            AlipayCommerceEcEnterpriseInfoModifyModel model = new AlipayCommerceEcEnterpriseInfoModifyModel();
            
            // 设置企业ID
            model.EnterpriseId = "2088501412314698";
            
            // 设置企业名称
            model.EnterpriseName = "企业码测试有限公司";
            
            // 设置企业简称
            model.EnterpriseAlias = "企业码测试";
            
            // 设置可信渠道企业个性化信息
            ReliableEnterpriseProfilesDTO reliableProfiles = new ReliableEnterpriseProfilesDTO();
            reliableProfiles.AuthType = "1";
            reliableProfiles.BizLicenseUrl = "https://xxxx";
            reliableProfiles.UtmChain = "C2B";
            reliableProfiles.CountEmployee = "(1,10]";
            reliableProfiles.BizLicenseNo = "91310230MA1K054321";
            reliableProfiles.AccessChannel = "DING_EC_CARD";
            reliableProfiles.ActivityLevel = "L1";
            reliableProfiles.PlatformGmtCreate = "2025-01-01 10:00:00";
            reliableProfiles.TaxNo = "91310230MA1K051234";
            reliableProfiles.SignFundInstId = "ANTBANK";
            reliableProfiles.LegalPersonCertNo = "110101199001011237";
            reliableProfiles.UtmSource = "isv";
            reliableProfiles.UtmContent = "杭州测试推广有限公司";
            model.ReliableProfiles = reliableProfiles;
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayCommerceEcEnterpriseInfoModifyResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.commerce.ec.enterprise.info.modify&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"enterprise_id":"2088501412314698",
	"enterprise_name":"企业码测试有限公司",
	"enterprise_alias":"企业码测试",
	"reliable_profiles":{
		"auth_type":"1",
		"biz_license_url":"https://xxxx",
		"utm_chain":"C2B",
		"count_employee":"(1,10]",
		"biz_license_no":"91310230MA1K054321",
		"access_channel":"DING_EC_CARD",
		"activity_level":"L1",
		"platform_gmt_create":"2025-01-01 10:00:00",
		"tax_no":"91310230MA1K051234",
		"sign_fund_inst_id":"ANTBANK",
		"legal_person_cert_no":"110101199001011237",
		"utm_source":"isv",
		"utm_content":"杭州测试推广有限公司"
	}
}' 
```
 

### 响应示例
#### 正常响应示例
```
 {
	"alipay_commerce_ec_enterprise_info_modify_response":{
		"code":"10000",
		"msg":"Success"
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_commerce_ec_enterprise_info_modify_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|ENTERPRISE_NOT_EXIST|企业不存在|【错误原因】企业不存在。 【排查步骤】请检查企业id是否正确。|
|NO_AGREEMENT|产品未签约或合约状态异常|【错误原因】产品未签约或合约状态异常。 【排查步骤】请检查入参或企业是否已解约。|
|ONLY_NOAUTH_CAN_MODIFY_NAME|只有未认证的企业才可以修改企业名称|【错误原因】只有未认证的企业才可以修改企业名称。 【排查步骤】无。|
|SENSITIVE_WORDS_EXIST|企业名称存在敏感词|【错误原因】企业名称存在敏感词。 【排查步骤】修改企业名称后重试。|