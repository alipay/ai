# alipay.commerce.ec.employee.invite.query(获取员工签约激活链接)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
获取员工签约激活链接
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.commerce.ec.employee.invite.query|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://opendocs.alipay.com/isv/10467/xldcyq)||
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|必须|32|企业id|2088985758939|
|employee_id|String|可选|32|企业码员工ID，签约适用对象为指定员工时填写**注意事项**若不传则返回的邀请链接对企业所有员工均有效； 若传员工ID则链接只对传入的员工ID有效|2288099887700000|
|page_content_code|String|可选|12|用于展示不同的页面文案，使用标准页面文案是无需传值**枚举值**企业码标准文案:PCC_STANDARD青岛码文案:PCC_QINGDAO钉钉企业文案:PCC_DINGDING**注意事项**青岛码场景时，需传PCC_QINGDAO。|PCC_STANDARD|
|withholding_sign_str|String|可选|2048|代扣签约串。需要签约代扣协议时，必传，返回的签约链接会拼接上代扣签约串。**注意事项**代扣签约串的获取参考 [alipay.user.agreement.page.sign](https://opendocs.alipay.com/open/8bccfa0b_alipay.user.agreement.page.sign)|biz_content=%7B%22access_params%22%3A%7B%22personal_product_code%22%3A%22GENERAL_WITHHOLDING_P%22%2C%22sign_scene%22%3A%22INDUSTRY%7CMULTI_MEDIA%22%7D&sign=111&app_id=2017090501336035&method=alipay.user.agreement.page.sign&version=1.0|
|create_share_code|String|可选|8|是否生成签约吱口令，不传默认为N**枚举值**是:Y否:N|Y|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.domain.AlipayCommerceEcEmployeeInviteQueryModel;
import com.alipay.api.response.AlipayCommerceEcEmployeeInviteQueryResponse;
import com.alipay.api.request.AlipayCommerceEcEmployeeInviteQueryRequest;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayCommerceEcEmployeeInviteQuery {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayCommerceEcEmployeeInviteQueryRequest request = new AlipayCommerceEcEmployeeInviteQueryRequest();
        AlipayCommerceEcEmployeeInviteQueryModel model = new AlipayCommerceEcEmployeeInviteQueryModel();
        
        // 设置企业id
        model.setEnterpriseId("2088985758939");
        
        // 设置员工ID
        model.setEmployeeId("2288099887700000");
        
        // 设置页面内容code
        model.setPageContentCode("PCC_STANDARD");
        
        // 设置代扣签约串
        model.setWithholdingSignStr("biz_content=%7B%22access_params%22%3A%7B%22personal_product_code%22%3A%22GENERAL_WITHHOLDING_P%22%2C%22sign_scene%22%3A%22INDUSTRY%7CMULTI_MEDIA%22%7D&sign=111&app_id=2017090501336035&method=alipay.user.agreement.page.sign&version=1.0");
        
        // 设置是否生成签约吱口令
        model.setCreateShareCode("Y");
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayCommerceEcEmployeeInviteQueryResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayCommerceEcEmployeeInviteQueryRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayCommerceEcEmployeeInviteQueryRequest();
$model = array();

// 设置企业id
$model['enterprise_id'] = "2088985758939";

// 设置员工ID
$model['employee_id'] = "2288099887700000";

// 设置页面内容code
$model['page_content_code'] = "PCC_STANDARD";

// 设置代扣签约串
$model['withholding_sign_str'] = "biz_content=%7B%22access_params%22%3A%7B%22personal_product_code%22%3A%22GENERAL_WITHHOLDING_P%22%2C%22sign_scene%22%3A%22INDUSTRY%7CMULTI_MEDIA%22%7D&sign=111&app_id=2017090501336035&method=alipay.user.agreement.page.sign&version=1.0";

// 设置是否生成签约吱口令
$model['create_share_code'] = "Y";

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayCommerceEcEmployeeInviteQuery
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayCommerceEcEmployeeInviteQueryRequest request = new AlipayCommerceEcEmployeeInviteQueryRequest();
            AlipayCommerceEcEmployeeInviteQueryModel model = new AlipayCommerceEcEmployeeInviteQueryModel();
            
            // 设置企业id
            model.EnterpriseId = "2088985758939";
            
            // 设置员工ID
            model.EmployeeId = "2288099887700000";
            
            // 设置页面内容code
            model.PageContentCode = "PCC_STANDARD";
            
            // 设置代扣签约串
            model.WithholdingSignStr = "biz_content=%7B%22access_params%22%3A%7B%22personal_product_code%22%3A%22GENERAL_WITHHOLDING_P%22%2C%22sign_scene%22%3A%22INDUSTRY%7CMULTI_MEDIA%22%7D&sign=111&app_id=2017090501336035&method=alipay.user.agreement.page.sign&version=1.0";
            
            // 设置是否生成签约吱口令
            model.CreateShareCode = "Y";
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayCommerceEcEmployeeInviteQueryResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.commerce.ec.employee.invite.query&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"enterprise_id":"2088985758939",
	"employee_id":"2288099887700000",
	"page_content_code":"PCC_STANDARD",
	"withholding_sign_str":"biz_content=%7B%22access_params%22%3A%7B%22personal_product_code%22%3A%22GENERAL_WITHHOLDING_P%22%2C%22sign_scene%22%3A%22INDUSTRY%7CMULTI_MEDIA%22%7D&sign=111&app_id=2017090501336035&method=alipay.user.agreement.page.sign&version=1.0",
	"create_share_code":"Y"
}' 
```
 

### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|必须|32|企业id|208847489339|
|sign_url|String|必须|1024|邀请链接|http://sjddkk.com|
|mini_app_sign_url|String|必须|2048|支付宝服务商小程序跳入企业码小程序签约链接|/pages/open/authorize/individual-auth/index?token=xxxxea2ac30656af68522fa596335a3642364d9994270ba&scene=PCC_STANDARD|
|share_code|String|可选|256|签约吱口令|d:/qO2jW35792K 或复制此消息打开支付宝，企业码 $203 j@i.Dany e:/R|
### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_commerce_ec_employee_invite_query_response":{
		"code":"10000",
		"msg":"Success",
		"enterprise_id":"208847489339",
		"sign_url":"http://sjddkk.com",
		"mini_app_sign_url":"/pages/open/authorize/individual-auth/index?token=xxxxea2ac30656af68522fa596335a3642364d9994270ba&scene=PCC_STANDARD",
		"share_code":"d:/qO2jW35792K 或复制此消息打开支付宝，企业码  $203 j@i.Dany e:/R"
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_commerce_ec_employee_invite_query_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|EMPLOYEE_NOT_EXIST|员工不存在|【错误原因】员工不存在。 【排查步骤】请检查员工id是否正确。|
|ENTERPRISE_NOT_EXIST|企业不存在|【错误原因】企业不存在。 【排查步骤】请检查企业id是否正确。|
|ENTERPRISE_NOT_SIGNED|企业未签约因公付|【错误原因】企业未签约因公付。 【排查步骤】请企业先签约因公付。|
|NO_AGREEMENT|产品未签约或合约状态异常|【错误原因】产品未签约或合约状态异常。 【排查步骤】请检查入参或企业是否已解约。|