# alipay.commerce.ec.employee.change.notify(员工变更通知)

员工变更通知，包括：员工新增、激活、信息修改、部门修改、角色修改和删除

## 公共请求参数

| 参数 | 类型 | 是否必选 | 最大长度 | 描述 | 示例值 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| notify_id | String | 必选 | 50 | 通知ID | 5608cccc09ddb39d41c2e3c06e3d9fejh2 |
| utc_timestamp | String | 必选 | 13 | 消息发送时的服务端时间 | 1514210452731 |
| msg_method | String | 必选 | 100 | 消息接口名称 | alipay.commerce.ec.employee.change.notify |
| app_id | String | 必选 | 20 | 消息接受方的应用id | 2014060600164699 |
| version | String | 必选 | 5 | 版本号(1.1版本为标准消息) | 1.0或者1.1 |
| biz_content | String | 必选 | | 消息报文 | 参见消息属性 |
| sign | String | 必选 | | 签名 | WcO+t3D8Kg71dTlKwN7r9PzUOXeaBJwp8/FOuSxcuSkXsoVYxBpsAidprySCjHCjmaglNcjoKJQLJ28/Asl93joTW39FX6i07lXhnbPknezAlwmvPdnQuI01HZsZF9V1i6ggZjBiAd5lG8bZtTxZOJ87ub2i9GuJ3Nr/NUc9VeY= |
| sign_type | String | 必选 | 10 | 签名类型 | RSA2 |
| charset | String | 必选 | 10 | 编码集，该字符集为验签和解密所需要的字符集 | UTF-8 |

## 消息属性

| 参数英文名 | 类型 | 是否必选 | 长度/取值 | 描述 | 示例值 |
|---|---|---|---|---|---|
| employee_id | String | 必选 | 32 | 员工id | 228420000000057942506 |
| enterprise_id | String | 必选 | 32 | 企业id | 2088441363102941 |
| action | String | 必选 | 32 | 变更动作<br>**枚举值**：<br>企业增加员工: EMPLOYEE_ADD<br>企业激活员工: EMPLOYEE_ACTIVATED<br>企业修改员工信息: EMPLOYEE_MODIFY<br>企业删除员工: EMPLOYEE_LEAVE<br>企业修改员工部门: EMPLOYEE_DEPARTMENT_CHANGE<br>企业修改员工角色: EMPLOYEE_ROLE_CHANGE<br>人脸库入库: EMPLOYEE_IOT_USER_CREATE<br>人脸库出库: EMPLOYEE_IOT_USER_DELETE<br>员工支付宝解绑: EMPLOYEE_UNBIND_ALIPAY | EMPLOYEE_ADD |
| change_time | String | 必选 | 32 | 变更时间 | 2022-05-23 14:38:09 |
| employee_name | String | 必选 | 80 | 员工姓名 | 张三 |
| department_list | EmployeeDepartmentDTO[] | 必选 | | 员工所属部门列表 | |
| - department_id | String | 必选 | 32 | 部门id | 1001094000039142 |
| - department_name | String | 必选 | 80 | 部门名称 | 产品部 |
| activate | String | 条件必选 | 16 | 是否激活<br>**枚举值**：已激活: ACTIVATED<br>未激活: UNACTIVATED<br>激活中: ACTIVATING<br>**注意事项**：当action为EMPLOYEE_LEAVE时为空 | ACTIVATED |
| role_list | string[] | 条件必选 | 1024 | 角色列表<br>**枚举值**：用户: USER<br>管理员: ADMIN<br>超级管理员: SUPER_ADMIN<br>**注意事项**：当action为EMPLOYEE_LEAVE时为空 | ["ADMIN", "USER"] |
| gmt_create | String | 条件必选 | 32 | 加入时间<br>**注意事项**：当action为EMPLOYEE_LEAVE时为空 | 2022-04-20 17:13:51 |
| gmt_modified | String | 条件必选 | 32 | 变更时间<br>**注意事项**：当action为EMPLOYEE_LEAVE时为空 | 2022-04-25 17:13:51 |
| user_id | String | 可选 | 32 | 用户ID, 员工绑定的支付宝账号UID<br>新商户建议使用open_id替代该字段 | 2088501304519332 |
| open_id | String | 可选 | 128 | 用户ID, 员工绑定的支付宝账号UID | 074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5 |
| employee_no | String | 可选 | 64 | 员工工号/编号<br>**注意事项**：当action为EMPLOYEE_LEAVE时为空 | 200818255 |
| mobile | String | 可选 | 11 | 手机号码 | 13456782345 |
| email | String | 可选 | 64 | 邮箱<br>**注意事项**：当action为EMPLOYEE_LEAVE时为空 | 123456@qq.com |
| ext_info | String | 可选 | 2048 | 扩展信息，JSON格式 | {"key":"value"} |
| iot_vid | String | 可选 | 32 | 员工在企业人脸库的人脸唯一标识 | 2109b5e671aa3ff2eb4851816c65828f |
| iot_unique_id | String | 可选 | 64 | IOT开通刷脸支持唯一操作流水号 | 3444950005320032 |
| profiles | String | 可选 | 500 | 个性化信息<br>支持的key：<br>consume_remark: 员工账单备注 | {"consume_remark":"员工账单备注内容示例"} |

**注意**：user_id 和 open_id 二选一传入

### 消息示例

```bash
curl -X POST 'NOTIFY_URL' \
--header 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8' \
--data-urlencode 'charset=UTF-8' \
--data-urlencode 'biz_content={
	"employee_id":"228420000000057942506",
	"enterprise_id":"2088441363102941",
	"action":"EMPLOYEE_ADD",
	"change_time":"2022-05-23 14:38:09",
	"employee_name":"张三",
	"employee_no":"200818255",
	"mobile":"13456782345",
	"email":"123456@qq.com",
	"activate":"ACTIVATED",
	"role_list":[
		"ADMIN",
		"USER"
	],
	"department_list":[
		{
			"department_id":"1001094000039142",
			"department_name":"产品部"
		}
	],
	"gmt_create":"2022-04-20 17:13:51",
	"gmt_modified":"2022-04-25 17:13:51",
	"ext_info":"{\"key\":\"value\"}",
	"iot_vid":"2109b5e671aa3ff2eb4851816c65828f",
	"user_id":"2088501304519332",
	"open_id":"074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5",
	"iot_unique_id":"3444950005320032",
	"profiles":"{\"consume_remark\":\"员工账单备注内容示例\"}"
}' \
--data-urlencode 'utc_timestamp=${now}' \
--data-urlencode 'sign=${sign}' \
--data-urlencode 'app_id=${appid}' \
--data-urlencode 'version=1.1' \
--data-urlencode 'sign_type=RSA2' \
--data-urlencode 'notify_id=${notify_id}' \
--data-urlencode 'msg_method=alipay.commerce.ec.employee.change.notify'
```

**说明：** NOTIFY_URL是开发者在开放平台控制台上设置的应用网关地址

## 通知应答

| 响应报文 | 描述 | 是否重试 | 是否区分大小写 |
| :--- | :--- | :--- | :--- |
| success | 消息处理成功 | 否 | 否 |
| fail | 消息处理失败 | 是 | 否 |

说明：消息服务会根据响应报文判断商户系统是否已经成功处理消息。如果HTTP同步响应报文返回 success 字符串，消息服务则认为消息已经处理成功，停止投递，如果返回 fail ，表示消息获取失败，支付宝会根据投递重试策略重新发送消息到应用网关地址；

投递重试策略：一般情况下，25 小时以内完成 8 次通知，除了第一次是实时投递外，后续的每次重试都会间隔一段时间，间隔频率一般是：2m、10m、10m、1h、2h、6h、15h（第二次消息投递是在第一次投递失败后的 2 分钟；第三次投递是在第二次投递失败后的 10 分钟，以此类推）
