# alipay.commerce.ec.employee.add(添加员工)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
企业添加员工，并返回员工签约激活链接和吱口令
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.commerce.ec.employee.add|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://opendocs.alipay.com/isv/10467/xldcyq)||
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|必须|32|员工所属企业ID|20887448493929|
|employee_name|String|必须|32|员工姓名|张三|
|employee_no|String|可选|64|员工编号/工号**注意事项**工号不可重复|D28339|
|identity_type|String|特殊可选|32|员工身份类型**枚举值**支付宝登录账号:ALIPAY_LOGON_ID支付宝用户id:ALIPAY_USER_ID服务商用户id:ISV_USER_ID**注意事项**与身份标识(identity)搭配使用**必选条件**身份标识(identity_type+identity)、身份证(employee_cert_type+employee_cert_no)、手机号、邮箱四者必选其一； 当传入多个时，优先级为：身份标识>身份证>手机号>邮箱|ALIPAY_USER_ID|
|identity|String|特殊可选|64|员工身份唯一标识**注意事项**根据身份类型(identity_type)进行传参： 1. 当identity_type=ALIPAY_USER_ID时，identity传支付宝用户uid（此时可与identity_open_id二选一） 2. 当identity_type=ALIPAY_LOGON_ID时，identity传已注册支付宝且可以登录支付宝的手机号或邮箱 ； 3. 当identity_type=ISV_USER_ID时，identity传服务商生成的用户唯一标识；**必选条件**身份标识(identity_type+identity)、身份证(employee_cert_type+employee_cert_no)、手机号、邮箱四者必选其一； 当传入多个时，优先级为：身份标识>身份证>手机号>邮箱|20889939994000|
|employee_mobile|String|特殊可选|11|员工手机号**必选条件**身份标识(identity_type+identity)、身份证(employee_cert_type+employee_cert_no)、手机号、邮箱四者必选其一； 当传入多个时，优先级为：身份标识>身份证>手机号>邮箱|13388888888|
|employee_email|String|特殊可选|64|员工邮箱**必选条件**身份标识(identity_type+identity)、身份证(employee_cert_type+employee_cert_no)、手机号、邮箱四者必选其一； 当传入多个时，优先级为：身份标识>身份证>手机号>邮箱|test123@email.com|
|employee_cert_type|String|特殊可选|32|员工证件类型**枚举值**身份证:IDENTITY_CARD**注意事项**与证件号(employee_cert_no)搭配使用**必选条件**身份标识(identity_type+identity)、身份证(employee_cert_type+employee_cert_no)、手机号、邮箱四者必选其一； 当传入多个时，优先级为：身份标识>身份证>手机号>邮箱|IDENTITY_CARD|
|employee_cert_no|String|特殊可选|32|员工证件号码**注意事项**与证件类型(employee_cert_type)搭配使用，传入对应的证件号码**必选条件**身份标识(identity_type+identity)、身份证(employee_cert_type+employee_cert_no)、手机号、邮箱四者必选其一； 当传入多个时，优先级为：身份标识>身份证>手机号>邮箱|260101202310011234|
|iot_check_type|String|特殊可选|32|员工签约开通企业刷脸付时，刷脸核身的核验方式**枚举值**无核验:business_facepay无核验-企业刷脸付单独开通:business_facepay_nores无核验-企业刷脸付_企业码开通2合1开通组件:facepay_epc_nores无核验-企业刷脸付_企业码_代扣开通3合1开通组件:facepay_epc_agree_nores核验姓名:business_facepay_checkname核验姓名-企业刷脸付单独开通:business_facepay_checkname_nores核验姓名-企业刷脸付_企业码开通2合1开通组件:facepay_epc_check_nores核验姓名-企业刷脸付_企业码_代扣开通3合1开通组件:facepay_epc_agree_check_nores核验三要素:business_facepay_checkall核验三要素-无结果页:business_facepay_checkall_nores**注意事项**1. 当传入人脸核验方式时，身份标识(identity_type+identity)不能为空，并且identity_type只能为ALIPAY_LOGON_ID或ALIPAY_USER_ID  2. 若需核验三要素(business_facepay_checkall_nores)，则要传入员工姓名(employee_name)、证件类型(employee_cert_type)、证件号码(employee_cert_no)，未传则不校验相应字段；**必选条件**员工需开通企业刷脸付时必传，否则请勿传|facepay_epc_agree_check_nores|
|department_ids|String|可选|32|员工所属部门，支持多个部门，不传默认为根部门|["1001069000162569"]|
|accounting_entity_ids|String|可选|32|员工所属核算主体，核算主体可用于管控不同员工的出资方式，建议和不同出资账户关联**注意事项**目前一个员工仅支持有一个核算主体|["1007000041812522"]|
|label_names|String|可选|15|员工标签，用于员工的打标分类，后续费控管理可使用标签进行控制，支持输入多个标签，如“差旅员工，用餐员工”等；若企业需要将离职员工统一管理且不变更员工状态，可打标“离职员工”**注意事项**1. 请严格对标签分类，不要滥用员工标签，否则影响员工和费控管理； 2. 一个员工最多10个标签，如无必要请勿使用；3. 标签名只能包含字母（大小写）、数字或中文字符|["差旅员工"]|
|sign_return_url|String|可选|1024|员工签约后回跳地址；支持 alipay scheme 协议地址，不传默认跳转企业码小程序首页**注意事项**请务必验证回跳是否符合预期，如回跳受限请联系企业码BD|alipays://platformapi/startapp?appId=xxx&page=xxx|
|create_share_code|Boolean|可选|10|是否需要生成吱口令，默认不生成|true|
|sign_url_carry_info|Boolean|可选|10|签约链接页面是否需要自动回显员工的身份信息（手机或邮箱），默认不显示|true|
|identity_open_id|String|可选|128|当身份类型为支付宝用户ID(identity_type=ALIPAY_USER_ID)时，传入user_id对应的open_id**注意事项**仅适用于以open_id方式对接的调用方|074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5|
|encrypt_mobile|String|可选|128|加密手机号，可替代手机号(employee_mobile)字段**注意事项**默认使用SHA256加密，不可与手机号同时存在|B0160ABEE2099421C8B30EF3D9ED4E13C6C5708D6BB71441C7858B0C3AF89274|
|encrypt_cert_no|String|可选|128|加密证件号，需与证件类型搭配使用，可替代证件号码(employee_cert_no)字段**注意事项**默认转大写后用SHA256加密，不可与证件号同时存在|B0160ABEE2099421C8B30EF3D9ED4E13C6C5708D6BB71441C7858B0C3AF89274|
|profiles|String|可选|512|个性化信息 详见文档|{"consume_remark":"员工账单备注内容示例"}|
|withholding_sign_str|String|可选|2048|代扣签约字符串，员工需签约开通代扣时必传，否则无需传值**注意事项**需调支付宝个人协议页面签约接口，并按规则生成，见 参考文档 3.1.3 生成签约字符串示例|app_id%3D2015052600090779%26biz_content%3D%257B%2522access_params%2522%253A%257B%2522channel%2522%253A%2522ALIPAYAPP%2522%257D%252C%2522external_agreement_no%2522%253A%25222019_06_0910%2522%252C%2522personal_product_code%2522%253A%2522...|
|free_sign_token|String|可选|256|员工签约授权密钥； 该密钥需联系企业码业务小二申请，当传入密钥有效，则员工添加时会默认签约企业因公付，并激活员工。**注意事项**当传入授权签约密钥，员工身份仅支持以下二选一： 1、通过身份标识(identity_type+identity)，并且identity_type只能为ALIPAY_LOGON_ID或ALIPAY_USER_ID； 2、通过员工身份证(employee_cert_no+employee_cert_type)|66WertX2ZyMqHDqEmnfe8I00xxu1AK30qIRx12mr9uhJB6oVuyjZcb32QBLWBU+2|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.response.AlipayCommerceEcEmployeeAddResponse;
import com.alipay.api.request.AlipayCommerceEcEmployeeAddRequest;
import com.alipay.api.domain.AlipayCommerceEcEmployeeAddModel;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayCommerceEcEmployeeAdd {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayCommerceEcEmployeeAddRequest request = new AlipayCommerceEcEmployeeAddRequest();
        AlipayCommerceEcEmployeeAddModel model = new AlipayCommerceEcEmployeeAddModel();
        
        // 设置企业ID
        model.setEnterpriseId("20887448493929");
        
        // 设置员工姓名
        model.setEmployeeName("张三");
        
        // 设置员工工号
        model.setEmployeeNo("D28339");
        
        // 设置身份类型
        model.setIdentityType("ALIPAY_USER_ID");
        
        // 设置身份标识
        model.setIdentity("20889939994000");
        
        // 设置员工手机号
        model.setEmployeeMobile("13388888888");
        
        // 设置员工邮箱
        model.setEmployeeEmail("test123@email.com");
        
        // 设置证件类型
        model.setEmployeeCertType("IDENTITY_CARD");
        
        // 设置证件号码
        model.setEmployeeCertNo("260101202310011234");
        
        // 设置刷脸付核验方式
        model.setIotCheckType("facepay_epc_agree_check_nores");
        
        // 设置员工所属部门
        List<String> departmentIds = new ArrayList<String>();
        departmentIds.add("1001069000162569");
        model.setDepartmentIds(departmentIds);
        
        // 设置员工所属核算主体
        List<String> accountingEntityIds = new ArrayList<String>();
        accountingEntityIds.add("1007000041812522");
        model.setAccountingEntityIds(accountingEntityIds);
        
        // 设置员工标签
        List<String> labelNames = new ArrayList<String>();
        labelNames.add("差旅员工");
        model.setLabelNames(labelNames);
        
        // 设置员工签约后回跳地址
        model.setSignReturnUrl("alipays://platformapi/startapp?appId=xxx&page=xxx");
        
        // 设置是否生成吱口令
        model.setCreateShareCode(true);
        
        // 设置签约页面是否回显员工身份信息
        model.setSignUrlCarryInfo(true);
        
        // 设置身份标识openId
        model.setIdentityOpenId("074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5");
        
        // 设置加密手机号
        model.setEncryptMobile("B0160ABEE2099421C8B30EF3D9ED4E13C6C5708D6BB71441C7858B0C3AF89274");
        
        // 设置加密证件号
        model.setEncryptCertNo("B0160ABEE2099421C8B30EF3D9ED4E13C6C5708D6BB71441C7858B0C3AF89274");
        
        // 设置个性化信息
        model.setProfiles("{\"consume_remark\":\"员工账单备注内容示例\"}");
        
        // 设置代扣签约字符串
        model.setWithholdingSignStr("app_id%3D2015052600090779%26biz_content%3D%257B%2522access_params%2522%253A%257B%2522channel%2522%253A%2522ALIPAYAPP%2522%257D%252C%2522external_agreement_no%2522%253A%25222019_06_0910%2522%252C%2522personal_product_code%2522%253A%2522...");
        
        // 设置员工授权签约密钥
        model.setFreeSignToken("66WertX2ZyMqHDqEmnfe8I00xxu1AK30qIRx12mr9uhJB6oVuyjZcb32QBLWBU+2");
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayCommerceEcEmployeeAddResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayCommerceEcEmployeeAddRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayCommerceEcEmployeeAddRequest();
$model = array();

// 设置企业ID
$model['enterprise_id'] = "20887448493929";

// 设置员工姓名
$model['employee_name'] = "张三";

// 设置员工工号
$model['employee_no'] = "D28339";

// 设置身份类型
$model['identity_type'] = "ALIPAY_USER_ID";

// 设置身份标识
$model['identity'] = "20889939994000";

// 设置员工手机号
$model['employee_mobile'] = "13388888888";

// 设置员工邮箱
$model['employee_email'] = "test123@email.com";

// 设置证件类型
$model['employee_cert_type'] = "IDENTITY_CARD";

// 设置证件号码
$model['employee_cert_no'] = "260101202310011234";

// 设置刷脸付核验方式
$model['iot_check_type'] = "facepay_epc_agree_check_nores";

// 设置员工所属部门
$departmentIds = array();
$departmentIds[] = "1001069000162569";
$model['department_ids'] = $departmentIds;

// 设置员工所属核算主体
$accountingEntityIds = array();
$accountingEntityIds[] = "1007000041812522";
$model['accounting_entity_ids'] = $accountingEntityIds;

// 设置员工标签
$labelNames = array();
$labelNames[] = "差旅员工";
$model['label_names'] = $labelNames;

// 设置员工签约后回跳地址
$model['sign_return_url'] = "alipays://platformapi/startapp?appId=xxx&page=xxx";

// 设置是否生成吱口令
$model['create_share_code'] = true;

// 设置签约页面是否回显员工身份信息
$model['sign_url_carry_info'] = true;

// 设置身份标识openId
$model['identity_open_id'] = "074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5";

// 设置加密手机号
$model['encrypt_mobile'] = "B0160ABEE2099421C8B30EF3D9ED4E13C6C5708D6BB71441C7858B0C3AF89274";

// 设置加密证件号
$model['encrypt_cert_no'] = "B0160ABEE2099421C8B30EF3D9ED4E13C6C5708D6BB71441C7858B0C3AF89274";

// 设置个性化信息
$model['profiles'] = "{\"consume_remark\":\"员工账单备注内容示例\"}";

// 设置代扣签约字符串
$model['withholding_sign_str'] = "app_id%3D2015052600090779%26biz_content%3D%257B%2522access_params%2522%253A%257B%2522channel%2522%253A%2522ALIPAYAPP%2522%257D%252C%2522external_agreement_no%2522%253A%25222019_06_0910%2522%252C%2522personal_product_code%2522%253A%2522...";

// 设置员工授权签约密钥
$model['free_sign_token'] = "66WertX2ZyMqHDqEmnfe8I00xxu1AK30qIRx12mr9uhJB6oVuyjZcb32QBLWBU+2";

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayCommerceEcEmployeeAdd
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayCommerceEcEmployeeAddRequest request = new AlipayCommerceEcEmployeeAddRequest();
            AlipayCommerceEcEmployeeAddModel model = new AlipayCommerceEcEmployeeAddModel();
            
            // 设置企业ID
            model.EnterpriseId = "20887448493929";
            
            // 设置员工姓名
            model.EmployeeName = "张三";
            
            // 设置员工工号
            model.EmployeeNo = "D28339";
            
            // 设置身份类型
            model.IdentityType = "ALIPAY_USER_ID";
            
            // 设置身份标识
            model.Identity = "20889939994000";
            
            // 设置员工手机号
            model.EmployeeMobile = "13388888888";
            
            // 设置员工邮箱
            model.EmployeeEmail = "test123@email.com";
            
            // 设置证件类型
            model.EmployeeCertType = "IDENTITY_CARD";
            
            // 设置证件号码
            model.EmployeeCertNo = "260101202310011234";
            
            // 设置刷脸付核验方式
            model.IotCheckType = "facepay_epc_agree_check_nores";
            
            // 设置员工所属部门
            List<String> departmentIds = new List<String>();
            departmentIds.Add("1001069000162569");
            model.DepartmentIds = departmentIds;
            
            // 设置员工所属核算主体
            List<String> accountingEntityIds = new List<String>();
            accountingEntityIds.Add("1007000041812522");
            model.AccountingEntityIds = accountingEntityIds;
            
            // 设置员工标签
            List<String> labelNames = new List<String>();
            labelNames.Add("差旅员工");
            model.LabelNames = labelNames;
            
            // 设置员工签约后回跳地址
            model.SignReturnUrl = "alipays://platformapi/startapp?appId=xxx&page=xxx";
            
            // 设置是否生成吱口令
            model.CreateShareCode = true;
            
            // 设置签约页面是否回显员工身份信息
            model.SignUrlCarryInfo = true;
            
            // 设置身份标识openId
            model.IdentityOpenId = "074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5";
            
            // 设置加密手机号
            model.EncryptMobile = "B0160ABEE2099421C8B30EF3D9ED4E13C6C5708D6BB71441C7858B0C3AF89274";
            
            // 设置加密证件号
            model.EncryptCertNo = "B0160ABEE2099421C8B30EF3D9ED4E13C6C5708D6BB71441C7858B0C3AF89274";
            
            // 设置个性化信息
            model.Profiles = "{\"consume_remark\":\"员工账单备注内容示例\"}";
            
            // 设置代扣签约字符串
            model.WithholdingSignStr = "app_id%3D2015052600090779%26biz_content%3D%257B%2522access_params%2522%253A%257B%2522channel%2522%253A%2522ALIPAYAPP%2522%257D%252C%2522external_agreement_no%2522%253A%25222019_06_0910%2522%252C%2522personal_product_code%2522%253A%2522...";
            
            // 设置员工授权签约密钥
            model.FreeSignToken = "66WertX2ZyMqHDqEmnfe8I00xxu1AK30qIRx12mr9uhJB6oVuyjZcb32QBLWBU+2";
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayCommerceEcEmployeeAddResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.commerce.ec.employee.add&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"enterprise_id":"20887448493929",
	"employee_name":"张三",
	"employee_no":"D28339",
	"identity_type":"ALIPAY_USER_ID",
	"identity":"20889939994000",
	"employee_mobile":"13388888888",
	"employee_email":"test123@email.com",
	"employee_cert_type":"IDENTITY_CARD",
	"employee_cert_no":"260101202310011234",
	"iot_check_type":"facepay_epc_agree_check_nores",
	"department_ids":[
		"1001069000162569"
	],
	"accounting_entity_ids":[
		"1007000041812522"
	],
	"label_names":[
		"差旅员工"
	],
	"sign_return_url":"alipays://platformapi/startapp?appId=xxx&page=xxx",
	"create_share_code":true,
	"sign_url_carry_info":true,
	"identity_open_id":"074a1CcTG1LelxKe4xQC0zgNdId0nxi95b5lsNpazWYoCo5",
	"encrypt_mobile":"B0160ABEE2099421C8B30EF3D9ED4E13C6C5708D6BB71441C7858B0C3AF89274",
	"encrypt_cert_no":"B0160ABEE2099421C8B30EF3D9ED4E13C6C5708D6BB71441C7858B0C3AF89274",
	"profiles":"{\"consume_remark\":\"员工账单备注内容示例\"}",
	"withholding_sign_str":"app_id%3D2015052600090779%26biz_content%3D%257B%2522access_params%2522%253A%257B%2522channel%2522%253A%2522ALIPAYAPP%2522%257D%252C%2522external_agreement_no%2522%253A%25222019_06_0910%2522%252C%2522personal_product_code%2522%253A%2522...",
	"free_sign_token":"66WertX2ZyMqHDqEmnfe8I00xxu1AK30qIRx12mr9uhJB6oVuyjZcb32QBLWBU+2"
}' 
```
 

### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|employee_id|String|必须|32|企业码生成的员工ID|2288033000090876|
|sign_url|String|特殊可选|1024|员工签约激活页面链接**必选条件**非员工授权签约(free_sign_token为空)时返回|https://ur.alipay.com/3I2tPbLkAiktIoqe2dseZUzT|
|share_code|String|可选|256|员工签约激活吱口令**注意事项**仅需要生成吱口令(create_share_code=true)时返回|https://xxxxx，或复制此消息打开吱搜索，加入企业码，使用企业应公付|
|iot_unique_id|String|可选|64|员工开通IoT企业刷脸付的唯一流水号**注意事项**仅员工开通企业刷脸付时才会返回，可通过iot_unique_id调用IoT刷脸相关接口|3444950005320032|
### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_commerce_ec_employee_add_response":{
		"code":"10000",
		"msg":"Success",
		"employee_id":"2288033000090876",
		"sign_url":"https://ur.alipay.com/3I2tPbLkAiktIoqe2dseZUzT",
		"share_code":"https://xxxxx，或复制此消息打开吱搜索，加入企业码，使用企业应公付",
		"iot_unique_id":"3444950005320032"
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_commerce_ec_employee_add_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|ACCOUNTING_ENTITY_NOT_EXIST|核算主体不存在，请修改后重试|【错误原因】核算主体不存在。 【排查步骤】请修改核算主体id后重试。|
|ACCOUNT_NOT_PERSONAL|仅支持个人支付宝账户，请修改后重试|【错误原因】员工绑定的支付宝账号为非个人支付宝账号。 【排查步骤】请修改支付宝账号并重试。|
|DEPT_UPGRADING|部门升级中不支持添加员工，请稍后|【错误原因】员工绑定的部门正在升级中，暂不支持添加员工。【排查步骤】待部门升级完成后，重新添加员工即可。|
|EMPLOYEE_ALIPAY_OCCUPIED|当前支付宝账号已被绑定，请更换|【错误原因】支付宝账号已被绑定。 【排查步骤】请更换支付宝账号后重试。|
|EMPLOYEE_CERT_EXIST|证件号与已有员工重复，请修改后重试|【错误原因】证件号已存在。【排查步骤】请更换证件号或证件类型并重试|
|EMPLOYEE_CID_REPEATED|本人其他账号已经加入企业，请切换该支付宝账号|【错误原因】本人其他账号已经加入企业，无法使用该功能。 【排查步骤】请切换该支付宝账号。|
|EMPLOYEE_CREATE_ING|当前员工创建中，请稍后|【错误原因】存在并发请求，员工正在创建中 【排查步骤】请稍后重试。|
|EMPLOYEE_EMAIL_EXIST|邮箱与已有员工重复，请修改后重试|【错误原因】邮箱已存在。 【排查步骤】请更换邮箱并重试。|
|EMPLOYEE_EXIST|当前员工已存在|【错误原因】使用服务商用户ID(identity_type=ISV_USER_ID)添加员工且此员工已存在时。 【排查步骤】无需操作，可作为幂等条件。|
|EMPLOYEE_FREQUENCY_OVER_LIMIT|初级认证企业操作频率达上限，请完成企业认证后重试|【错误原因】初级认证企业添加员工操作频率超出上限。 【排查步骤】请等待24小时后重试。|
|EMPLOYEE_HAS_ACTIVATED|当前员工已激活|【错误原因】员工已成功添加，并且员工状态为已激活。 【排查步骤】无需操作，可作为业务幂等条件。|
|EMPLOYEE_IS_SUPER_ADMIN|当前员工为超级管理员，暂不支持该操作|【错误原因】员工为超管不允许该操作。 【排查步骤】超管不允许操作。|
|EMPLOYEE_MOBILE_EXIST|手机号与已有员工重复，请修改后重试|【错误原因】手机号与已有员工重复。 【排查步骤】请更换手机号后重试|
|EMPLOYEE_NO_EXIST|员工工号已存在，请修改后重试|【错误原因】员工工号已存在。 【排查步骤】请修改员工工号后重试。|
|EMPLOYEE_OVER_LIMIT|初级认证企业添加员工数量达上限，请完成企业认证后重试|【错误原因】初级认证企业添加员工个数超出上限。 【排查步骤】删除其他员工再加入新员工或联系客服进行认证升级。|
|EMP_MULTI_ACCOUNT_NOT_SUPPORT|该员工有多账号，暂时无法使用授权签约能力，请员工手动签约|【错误原因】该员工有多账号，暂时无法使用授权授权签约能力【排查步骤】检查员工账号信息或请员工手动签约|
|EMP_NAME_VERIFY_FAIL|员工姓名与支付宝账号实名不一致，请修改|【错误原因】员工姓名不一致，暂时无法添加员工 【排查步骤】请保持员工姓名与支付宝实名一致|
|ENTERPRISE_MEMBER_NUM_EXCEED_MAX|企业人数已达上限|【错误原因】企业人数已达上限。 【排查步骤】请清理无效员工或联系支付宝小二。|
|ENTERPRISE_NOT_EXIST|企业不存在，请修改后重试|【错误原因】企业不存在。 【排查步骤】请检查企业id是否正确。|
|ENTERPRISE_NOT_SIGNED|企业未签约因公付，请签约后重试|【错误原因】企业未签约因公付。 【排查步骤】企业进行因公付签约后重试。|
|ENT_LABEL_COUNT_EXCEED_MAX|企业标签数量已达上限，请使用已有标签|【错误原因】企业标签数量已达上限。 【排查步骤】更换使用现有标签并重试。|
|FREE_SIGN_EMPLOYEE_EXISTED|授权签约员工已存在|【错误原因】授权签约员工已存在【排查步骤】请删除员工后重新添加；|
|FREE_SIGN_TOKEN_INVALID|员工授权签约密钥错误或已过期，请重新申请|【错误原因】授权签约密钥输入错误或已过期 【排查步骤】请联系企业码业务人员重新获取新密钥；|
|FUND_ACCOUNT_WHITE_NOT_EXIST|企业资金账户白名单不存在，请联系支付宝业务小二|【错误原因】企业资金账户白名单不存在 【排查步骤】请联系企业码业务人员检查企业的资金账户白名单是否配置成功|
|FUND_DAILY_JOINENT_REACHED_LIMIT|员工当日加入企业数量超过上限|【错误原因】员工当日加入企业数量超过上限 【排查步骤】请明日重试。|
|FUND_INVITE_REPLYING|员工签约因公付处理中，请稍后|【错误原因】邀请员工签约，资金处理中 【排查步骤】请刷新重试。|
|FUND_SECURITY_CHECK_FAILED|员工支付宝账号异常，暂时无法加入企业|【错误原因】员工账号异常，暂时无法加入企业 【排查步骤】请联系支付宝技术。|
|FUND_SYSTEM_ERROR|员工签约因公付失败，请稍后重试|【错误原因】员工签约资金失败 【排查步骤】请联系支付宝技术。|
|IOT_APP_UNSIGN|应用未签约IoT刷脸组件，请先签约|【错误原因】当前应用(appId)未签约IoT人脸库组件 【排查步骤】签约IoT组件后重试。|
|IOT_ENTERPRISE_UNSIGN|企业未创建人脸库，员工不支持开通刷脸付|【错误原因】企业未创建IoT人脸库 【排查步骤】调邀请企业注册接口，创建企业人脸库后重试|
|IOT_SYSTEM_ERROR|员工开通刷脸付失败，请稍后重试|【错误原因】用户信息录入企业人脸库失败 【排查步骤】请联系支付宝技术。|
|IOT_USER_FACEPAY_OPEN_FAIL|员工无刷脸记录，请在支付宝-设置-开通到店刷脸支付|【错误原因】员工无刷脸记录 【排查步骤】请在支付宝-设置-开通到店刷脸支付。|
|IOT_USER_FACE_NOT_EXIST|员工无刷脸记录，请在支付宝-设置-体验手机刷脸后重试|【错误原因】员工无刷脸记录 【排查步骤】请在支付宝-设置-体验手机刷脸后重试。|
|ISV_USER_ID_NOT_SUPPORT|权限不足-不支持的身份类型(ISV_USER_ID)|【错误原因】身份类型 ISV_USER_ID 为定向开放能力。 【排查步骤】修改身份类型传参或联系客服处理。|
|JOINED_ENTERPRISE_NUM_EXCEED_MAX|当前用户加入的企业已超过上限|【错误原因】用户加入的企业已经超过上限 【排查步骤】请用户退出不常用的企业，重新加入。|
|LABEL_NAME_ILLEGAL|标签名称非法，请修改后重试|【错误原因】标签名称非法。【排查步骤】请检查标签名是否仅包含字母（大小写）、数字或中文字符。|
|MODIFY_AGENCY_OPERATION_FAIL|已绑定支付宝的员工不支持修改成代运营角色|【错误原因】已绑定支付宝的员工不允许修改角色为代运营。 【排查步骤】请检查员工信息|
|NEED_TO_SET_PPW|支付宝账号未设置支付密码，不支持此操作|【错误原因】员工的支付宝账号未设置支付密码，不支持开通因公付 【排查步骤】请用户设置支付密码后重试|
|NODE_NOT_EXIST|部门不存在，请修改后重试|【错误原因】部门不存在。 【排查步骤】请修改部门id后重试。|
|NO_AGREEMENT|权限不足-产品未签约或合约状态异常|【错误原因】无权限操作当前企业，请检查产品签约与合约状态异常。 【排查步骤】请检查入参或企业是否已解约。|
|USER_NOT_AUTHENTICATED|支付宝账号未实名认证，请实名认证后重试|【错误原因】用户未实名，无法使用该功能。 【排查步骤】用户先进行支付宝实名认证。|
|USER_NOT_EXIST|支付宝用户不存在，请修改后重试|【错误原因】支付宝用户信息不存在。 【排查步骤】请检查用户身份标识(identity)是否正确。|
|USER_STATUS_ERROR|支付宝账号状态异常，请拨打95188进行咨询|【错误原因】支付宝账号状态异常。 【排查步骤】请拨打95188进行咨询。|