# 员企字段和接口生成规则

本文件只约束员企字段来源、接口完整性和本域易错结构。跨语言生成原则见 [员企通用代码生成规则](codegen-general-rules.md)，各技术栈工程门禁见对应质量门禁文档。

## 通用规则

1. 接口、通知、请求字段和枚举只来自当前阶段已读取的流程文档、接口文档和通知文档。
2. 请求字段必须保留文档路径；顶层字段如 `enterprise_id`，嵌套字段如 `base_info.enterprise_name`。
3. 通知字段、响应字段和请求字段分开使用，不能互相迁移。
4. 字段或枚举校验失败时，先修正文档路径或枚举来源；文档未找到时说明缺失。

## 模块完成标准

- 企业入驻（邀请企业注册）：`alipay.commerce.ec.enterprise.registerinvite.create`、企业变更通知 `alipay.commerce.ec.enterprise.change.notify`。
- 企业入驻（可信渠道注册）：读取可信渠道流程文档，以其中接口和通知表为准。
- 员工签约（邀请员工签约）：`alipay.commerce.ec.employee.add`、`alipay.commerce.ec.employee.invite.query`、员工变更通知 `alipay.commerce.ec.employee.change.notify`。
- 员工签约（授权签约模式）：读取授权签约流程文档，以其中接口和通知表为准。
- 企业管理：`alipay.commerce.ec.enterprise.info.query`、`alipay.commerce.ec.enterprise.info.modify`、`alipay.commerce.ec.enterprise.delete`。
- 员工管理：`alipay.commerce.ec.employee.info.query`、`alipay.commerce.ec.employee.info.modify`、`alipay.commerce.ec.employee.delete`、`alipay.commerce.ec.employee.idlist.query`。
- 按需模块（部门、核算主体、企业地址、消息推送任务）：一旦接入，必须覆盖对应流程文档表格中的全部接口和通知。

## 结构和接口约束

- 企业邀请注册、可信渠道注册、员工签约、企业管理、员工管理等接口字段不能互相借用。
- 企业基础信息如果在文档中位于 `base_info` 等嵌套对象下，代码必须保留该结构，不能扁平化为顶层字段。
- 文档标注“特殊可选”“必选条件”“至少一个”或成对出现的字段，必须在调用接口前执行组合校验。员工新增至少满足身份标识对、证件对、手机号、邮箱或文档允许的加密身份分支之一；如果实现暴露了 `identity_open_id`，组合校验也必须把 `identity_type + identity_open_id` 作为文档允许的身份标识分支，不能只设置字段却在本地校验中拒绝；不能只把规则写在注释里并交给上游调用方保证。
- 员工身份、手机号、邮箱、部门、核算主体、角色、标签等字段必须使用接口文档中的英文名和路径，不能按本地 DTO 属性名或业务中文名反推。
- 员工列表、企业注销、部门查询等能力只能使用流程文档列出的接口；文档未列出的接口不得按命名规律自造。
- 通知 switch case 只能使用通知文档枚举。例如企业解约/注销使用 `ENTERPRISE_UNSIGN`、`ENTERPRISE_WITHDRAW`；员工删除使用 `EMPLOYEE_LEAVE`，不得改写为近义枚举。
