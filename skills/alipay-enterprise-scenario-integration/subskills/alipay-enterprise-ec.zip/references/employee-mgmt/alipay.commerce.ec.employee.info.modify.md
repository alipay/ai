# alipay.commerce.ec.employee.info.modify(修改员工基础信息)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
修改员工基础信息
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.commerce.ec.employee.info.modify|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://opendocs.alipay.com/common/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://opendocs.alipay.com/isv/10467/xldcyq)||
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档||
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|必须|32|企业id|2088474883838|
|employee_id|String|必须|32|员工id|22887387848484|
|employee_name|String|必须|64|员工姓名|张三|
|employee_no|String|可选|64|员工工号。如果不传值，则不更新工号。|D83030|
|employee_email|String|可选|64|员工邮箱。如果不传值，则不更新邮箱。|aajka@email.com|
|employee_mobile|String|可选|11|员工手机号。如果不传值，则不更新手机号。|158****4364|
|role_list|String|可选|20|角色列表，目前只支持填一种角色。如果不传值，则不更新角色。**枚举值**普通员工:USER管理员:ADMIN超级管理员:SUPER_ADMIN代运营:AGENCY_OPERATION|["USER"]|
|label_names|String|可选|15|员工标签，用于员工的打标分类，后续费控管理可使用标签进行控制，支持输入多个标签，如“差旅员工，用餐员工”等； 使用场景：1. 请严格对标签分类，不要滥用员工标签，否则影响员工和费控管理； 2. 一个员工最多10个标签，如无必要请勿使用；3. 标签名只能包含字母（大小写）、数字或中文字符**注意事项**字段更新规则：若传值则修改员工对应的标签，不传则不更新。若想移除员工所有标签，请传入空数组[]|["标签"]|
|department_ids|String|可选|381|员工所属部门。如果不传值，则不更新所属部门|["1001107000098337"]|
|accounting_entity_ids|String|可选|16|员工所属核算主体，核算主体可用于管控不同员工的出资方式，建议和不同出资账户关联，一个员工只能有一个核算主体。**注意事项**字段更新规则：若传值则修改员工对应的核算主体，不传则不更新。若想移除员工核算主体，请传入空数组[]|["1007000041812522"]|
|profiles|String|可选|500|个性化信息。如果不传值，则不更新个性化信息。 详见文档|{"consume_remark":"员工账单备注内容示例","inst_id":"CMBC",card_type:"CC","check_bind_card":"Y"}|
### 请求示例
#### 默认示例
##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.response.AlipayCommerceEcEmployeeInfoModifyResponse;
import com.alipay.api.request.AlipayCommerceEcEmployeeInfoModifyRequest;
import com.alipay.api.domain.AlipayCommerceEcEmployeeInfoModifyModel;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayCommerceEcEmployeeInfoModify {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayCommerceEcEmployeeInfoModifyRequest request = new AlipayCommerceEcEmployeeInfoModifyRequest();
        AlipayCommerceEcEmployeeInfoModifyModel model = new AlipayCommerceEcEmployeeInfoModifyModel();
        
        // 设置企业id
        model.setEnterpriseId("2088474883838");
        
        // 设置员工id
        model.setEmployeeId("22887387848484");
        
        // 设置员工姓名
        model.setEmployeeName("张三");
        
        // 设置员工工号
        model.setEmployeeNo("D83030");
        
        // 设置员工邮箱
        model.setEmployeeEmail("aajka@email.com");
        
        // 设置员工手机号
        model.setEmployeeMobile("158****4364");
        
        // 设置角色列表
        List<String> roleList = new ArrayList<String>();
        roleList.add("USER");
        model.setRoleList(roleList);
        
        // 设置员工标签
        List<String> labelNames = new ArrayList<String>();
        labelNames.add("标签");
        model.setLabelNames(labelNames);
        
        // 设置部门id列表
        List<String> departmentIds = new ArrayList<String>();
        departmentIds.add("1001107000098337");
        model.setDepartmentIds(departmentIds);
        
        // 设置员工所属核算主体
        List<String> accountingEntityIds = new ArrayList<String>();
        accountingEntityIds.add("1007000041812522");
        model.setAccountingEntityIds(accountingEntityIds);
        
        // 设置个性化信息
        model.setProfiles("{\"consume_remark\":\"员工账单备注内容示例\",\"inst_id\":\"CMBC\",card_type:\"CC\",\"check_bind_card\":\"Y\"}");
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayCommerceEcEmployeeInfoModifyResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayCommerceEcEmployeeInfoModifyRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayCommerceEcEmployeeInfoModifyRequest();
$model = array();

// 设置企业id
$model['enterprise_id'] = "2088474883838";

// 设置员工id
$model['employee_id'] = "22887387848484";

// 设置员工姓名
$model['employee_name'] = "张三";

// 设置员工工号
$model['employee_no'] = "D83030";

// 设置员工邮箱
$model['employee_email'] = "aajka@email.com";

// 设置员工手机号
$model['employee_mobile'] = "158****4364";

// 设置角色列表
$roleList = array();
$roleList[] = "USER";
$model['role_list'] = $roleList;

// 设置员工标签
$labelNames = array();
$labelNames[] = "标签";
$model['label_names'] = $labelNames;

// 设置部门id列表
$departmentIds = array();
$departmentIds[] = "1001107000098337";
$model['department_ids'] = $departmentIds;

// 设置员工所属核算主体
$accountingEntityIds = array();
$accountingEntityIds[] = "1007000041812522";
$model['accounting_entity_ids'] = $accountingEntityIds;

// 设置个性化信息
$model['profiles'] = "{\"consume_remark\":\"员工账单备注内容示例\",\"inst_id\":\"CMBC\",card_type:\"CC\",\"check_bind_card\":\"Y\"}";

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayCommerceEcEmployeeInfoModify
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayCommerceEcEmployeeInfoModifyRequest request = new AlipayCommerceEcEmployeeInfoModifyRequest();
            AlipayCommerceEcEmployeeInfoModifyModel model = new AlipayCommerceEcEmployeeInfoModifyModel();
            
            // 设置企业id
            model.EnterpriseId = "2088474883838";
            
            // 设置员工id
            model.EmployeeId = "22887387848484";
            
            // 设置员工姓名
            model.EmployeeName = "张三";
            
            // 设置员工工号
            model.EmployeeNo = "D83030";
            
            // 设置员工邮箱
            model.EmployeeEmail = "aajka@email.com";
            
            // 设置员工手机号
            model.EmployeeMobile = "158****4364";
            
            // 设置角色列表
            List<String> roleList = new List<String>();
            roleList.Add("USER");
            model.RoleList = roleList;
            
            // 设置员工标签
            List<String> labelNames = new List<String>();
            labelNames.Add("标签");
            model.LabelNames = labelNames;
            
            // 设置部门id列表
            List<String> departmentIds = new List<String>();
            departmentIds.Add("1001107000098337");
            model.DepartmentIds = departmentIds;
            
            // 设置员工所属核算主体
            List<String> accountingEntityIds = new List<String>();
            accountingEntityIds.Add("1007000041812522");
            model.AccountingEntityIds = accountingEntityIds;
            
            // 设置个性化信息
            model.Profiles = "{\"consume_remark\":\"员工账单备注内容示例\",\"inst_id\":\"CMBC\",card_type:\"CC\",\"check_bind_card\":\"Y\"}";
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayCommerceEcEmployeeInfoModifyResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.commerce.ec.employee.info.modify&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"enterprise_id":"2088474883838",
	"employee_id":"22887387848484",
	"employee_name":"张三",
	"employee_no":"D83030",
	"employee_email":"aajka@email.com",
	"employee_mobile":"158****4364",
	"role_list":[
		"USER"
	],
	"label_names":[
		"标签"
	],
	"department_ids":[
		"1001107000098337"
	],
	"accounting_entity_ids":[
		"1007000041812522"
	],
	"profiles":"{\"consume_remark\":\"员工账单备注内容示例\",\"inst_id\":\"CMBC\",card_type:\"CC\",\"check_bind_card\":\"Y\"}"
}' 
```
 

### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|employee_id|String|必须|32|员工id|2288738383939|
### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_commerce_ec_employee_info_modify_response":{
		"code":"10000",
		"msg":"Success",
		"employee_id":"2288738383939"
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_commerce_ec_employee_info_modify_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|DEPT_NOT_EXIST|部门不存在|【错误原因】部门不存在。 【排查步骤】请检查部门id是否正确。|
|DEPT_UPGRADING|部门升级中|【错误原因】部门升级中，当前操作暂不支持。【排查步骤】待部门升级完成后重试。|
|EMPLOYEE_BIND_NOT_MODIFY_ROLE|员工已绑定支付宝不允许修改成代运营|【错误原因】员工已绑定支付宝不允许修改成代运营。 【排查步骤】修改参数后重试。|
|EMPLOYEE_EMAIL_EXIST|邮箱与已有员工重复|【错误原因】邮箱与已有员工重复。 【排查步骤】请修改邮箱并重试。|
|EMPLOYEE_MOBILE_EXIST|手机号与已有员工重复|【错误原因】手机号与已有员工重复。 【排查步骤】请修改手机号并重试。|
|EMPLOYEE_NOT_EXIST|员工不存在|【错误原因】员工不存在。 【排查步骤】请检查员工id是否正确。|
|ENTERPRISE_NOT_EXIST|企业不存在|【错误原因】企业不存在。 【排查步骤】请检查企业id是否正确。|
|ENT_LABEL_COUNT_EXCEED_MAX|企业标签数量已达上限|【错误原因】企业标签数量已达上限。【排查步骤】更换使用现有标签并重试。|
|LABEL_NAME_ILLEGAL|标签名称非法|【错误原因】标签名称非法。【排查步骤】请检查标签名是否仅包含字母（大小写）、数字或中文字符。|
|NO_AGREEMENT|产品未签约或合约状态异常|【错误原因】产品未签约或合约状态异常。 【排查步骤】请检查入参或企业是否已解约。|
|ORG_USER_NOT_EXIST|企业人脸库用户信息未找到|【错误原因】企业人脸库用户信息未找到 【排查步骤】请稍后重试或联系技术支持。|