# 已有项目衔接契约

已有项目增量接入时，第一轮不要直接改代码。先输出并等待用户确认以下契约。

## 需要识别的现状

- 现有支付宝 SDK 或 HTTP MAPI 接入方式。
- MAPI 签名和验签工具位置。
- MAPI 签名/验签工具是否按 `_input_charset` 转字节。
- MAPI HTTP 客户端位置、非 2xx 处理方式、同步响应字符集来源。
- 支付宝配置来源：PID、私钥、公钥、字符集、网关地址。
- 页面返回入口：签约/解约的 `return_url` 承接方式。代扣结果通知面向商户侧，接入方不新增代扣通知入口；若项目已有代扣通知入口，需要先确认是否属于其他产品或商户侧系统，不纳入本 Skill 的接入方改造。
- 协议查询确认入口：需要确认如何传入本地 `external_user_id`、支付宝 `alipay_user_id` 和已有 `agreement_no`，以及 MAPI 同步响应验签工具；如果查询使用员工 openid + `app_id`，还要确认可信响应 `principal_id` 落入本地协议 `alipay_user_id` 的位置。
- 签约页面启动方式：ALIPAYAPP/支付宝钱包 H5 schema，还是 PC/浏览器直跳 MAPI。
- 签约渠道 `channel` 的入口来源和可选值，是否需要兼容大小写或前后空格。
- 现有用户、员工、企业、协议、订单、支付流水模型。
- 协议是否已有 `external_sign_no` 体系；若无，后续不得为了查询/解约随机生成。
- 现有 12306 支付 URL 获取位置，以及上游提供的是完整 URL、`?` 后原始 Query String，还是已按当前产品契约去除非支付噪音参数后的 Query String。
- 现有因公付账户 ID 获取位置。
- 客票平台资金账号 `trans_account_out` 和实际付款员工 `payer_user_id` 获取位置；本地协议记录或协议查询结果中的 `alipay_user_id` 如何与本次 `payer_user_id` 绑定；同一 `submit_param`、`ord_id_ext` 或 `out_order_no` 与 `payer_user_id` 的绑定和重复单处理方式；已有订单幂等重试是否优先于协议/支付串时效门禁，以及通过 `ord_id_ext` 命中时如何处理不同 `out_order_no`。
- 代扣查询订单号 `out_order_no` 的来源：代扣同步返回、上游业务订单、已有支付流水字段或其他明确映射。
- `submit_param` 解码诊断规则：已确认样例字段清单、必填字段集合、允许空值字段集合，以及非 `key=value` 片段、空 key、重复 key、连续/结尾 `&`、错误分隔符、关键字段空值、当前产品契约外异常字段、`ord_pmt_timeout` 过期或不足 60 秒时的拒绝/提示策略。
- 代扣查询状态机：哪些本地状态是最终成功终态，主动查询失败或处理中响应不得覆盖这些状态；主动查询响应字段写回必须受订单身份和金额/资金账号对账校验保护；响应中可比对字段出现冲突时不得用另一个字段匹配来放行。
- 协议查询失败语义：解析失败、验签失败、调用失败、`is_success` 非 T 时如何记录查询失败，并确认不会覆盖已有可信协议状态。
- 已有测试框架和构建命令。

## 拟定契约格式

输出时使用以下结构：

```text
已识别现状：
- 技术栈：
- 支付宝/MAPI 接入：
- 签名工具：
- 回调入口：
- 协议对象：
- 代扣订单对象：
- 12306 支付串来源：
- 因公付账户来源：

拟新增/修改文件：
- ...

业务衔接契约：
- external_user_id 从 ... 获取/生成
- ALIPAYAPP 签约返回 ... 字段，格式为 alipays://platformapi/startapp?appId=20000067&url=<encoded_mapi_sign_url>
- channel 从 ... 获取，先 trim/uppercase，再按 ALIPAYAPP/PC 白名单处理
- 协议签约/解约不传 notify_url；页面 return_url 后通过协议查询确认状态
- 协议查询确认先验签并检查 is_success，再比对 alipay_user_id；已有 agreement_no 时比对一致，首次确认时持久化返回 agreement_no；不可确认失败只记录查询失败，不覆盖已有可信协议状态
- MAPI 签名/验签按 _input_charset=... 转字节
- MAPI HTTP 非 2xx 按 ... 失败处理；响应字符集从 ... 获取
- agreement_no 写入 ...
- alipay_user_id 写入 ...；openid 查询路径下取可信响应 principal_id，供协议解约、代扣执行和主动查询复用
- external_sign_no 是否使用：签约传入则写入 ... 并在查询/解约复用；未使用则不生成、不强制要求
- submit_param 从 ... 构造，按输入原文 base64，保留编码、普通空值字段和内层 sign；不自行删除字段、重拼或重签；白名单不校验字段顺序
- submit_param 字段清单：已确认样例字段共 ... 个；必填字段为 ...；允许空值字段为 ...
- submit_param 诊断：非 key=value 片段、空 key、重复 key、连续/结尾 &、错误分隔符、关键字段空值、产品契约外异常字段写入 ... 错误/告警；ord_pmt_timeout 过期或不足 60 秒时 ...
- submit_param.partner 写入 ... 并作为 trade_partner
- submit_param.ord_id_ext 写入 ...
- out_biz_no 写入 ...
- out_order_no 从 ... 获取，写入 ...，用于 dut.agent.query.third
- assignJointAccountId 从 ... 获取，非空校验后写入 business_info
- trans_account_out 从 ... 获取，非空校验后写入代扣请求和本地订单
- payer_user_id 从 ... 获取，非空校验后写入代扣请求和本地订单，并在 dut.agent.query.third 主动查询请求中复用；新代扣发起前校验协议 alipay_user_id 与 payer_user_id 一致；同一 submit_param/ord_id_ext/out_order_no 不允许切换 payer_user_id 重试，重复外部单号按 ... 幂等/重新取支付串处理；同付款人已有订单重试优先返回已有结果，不受协议状态变化、ord_pmt_timeout 过期或本次支付串结构异常影响；幂等查询先按 out_order_no 查已有订单，未命中才轻量提取 ord_id_ext；通过 ord_id_ext 命中但 out_order_no 不同时按 ... 返回已有 out_order_no/拒绝
- 不新增接入方代扣 `notify_url`、`notify_id`、`notify_verify`、通知验签或通知状态流转；代扣最终结果由 `dut.agent.query.third` 主动查询确认
- 主动查询不会覆盖 ... 这些最终成功状态；查询失败写入 ... 错误字段，交易最终失败且响应身份/金额/资金账号匹配且无冲突才写入 ... 状态；`trade_no/out_order_no` 等响应字段也只有校验通过后才写回；未更新时返回 ... 而不是 `updated`

待确认问题：
- ...
```

## 允许继续写代码的条件

- 用户确认拟新增/修改文件。
- 协议状态和代扣订单状态衔接到已有业务对象。
- 签约启动方式明确；如果是 ALIPAYAPP/H5，必须返回支付宝钱包 schema 且 schema 的 url 参数为完整 MAPI 签约 URL 的 URL encode。
- 协议签约/解约不会新增 `notify_url`；协议状态确认方式明确为页面返回后的协议查询、支付前协议查询或解约后的查询/本地状态流转。
- 签名/验签工具明确。
- 签名/验签使用的字符集与 `_input_charset` 一致。
- HTTP 客户端非 2xx 处理和响应字符集策略明确。
- 代扣主动查询查单字段和金额/交易参与方比对字段明确。
- 主动查询状态机明确，特别是最终成功态保护规则。
- 协议查询失败不会覆盖已有可信协议状态；代扣查询响应关键字段缺失时状态和字段都不写回的规则明确。
- 12306 `submit_param` 的原始 Query String 来源明确，并明确是否由上游按当前产品契约去除非支付噪音参数；已确认样例字段清单、必填字段集合和允许空值字段集合明确，生成代码只能据此做显式白名单诊断，不能维护隐藏白名单或用白名单重拼 `submit_param`。
- `submit_param.partner`、`submit_param.ord_id_ext`，以及主动查询所需订单号、商户 PID、付款人 UID、资金账号等字段的来源和持久化位置明确。
- `submit_param` 异常诊断（示例字段以外参数、重复 key、空 key、非 `key=value`、连续/结尾 `&`、错误分隔符、必填字段缺失或空值）、`ord_pmt_timeout` 60 秒保护、协议 `alipay_user_id` 与代扣 `payer_user_id` 一致性、重复外部单号、幂等重试优先级、幂等返回 canonical `out_order_no` 以及 `payer_user_id` 绑定规则明确。
- `external_sign_no` 是否使用明确；未使用时不得作为必填定位条件。

无法确认以上内容时，只输出计划和待确认问题，不生成孤立旁路实现。
