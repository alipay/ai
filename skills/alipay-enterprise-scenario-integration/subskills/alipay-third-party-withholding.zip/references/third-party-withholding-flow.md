# 支付宝三方免密代扣 - 免密代扣模式

## 概述

三方免密代扣只有一个模式：免密代扣。该模式下先完成用户协议授权，再基于 12306 原始支付串发起代扣。

| 链路 | 接口 | 说明 |
| --- | --- | --- |
| 签约 | `alipay.dut.customer.agreement.page.sign`、`alipay.dut.customer.agreement.query`、`alipay.dut.customer.agreement.unsign` | 用户授权、协议状态查询和协议解约 |
| 代扣 | `dut.agent.third`、`dut.agent.query.third` | 基于 12306 原始支付串执行扣款并查询结果 |

## 流程图

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         三方免密代扣模式流程                             │
└─────────────────────────────────────────────────────────────────────────┘

【签约链路】
用户/前端 → 接入方系统 → 支付宝 MAPI
   │              │              │
   ├─发起页面签约─┤→ alipay.dut.customer.agreement.page.sign
   │              │      【关键步骤】
   │              │      1. 确认 product_code=DUT_AGENT_THIRD_P、scene、channel
   │              │      2. ALIPAYAPP 返回钱包 schema，PC 返回 MAPI 签约 URL
   │              │      3. 签约请求不传 notify_url；return_url 只做页面承接
   │              │
   ├─页面返回─────┤
   │              │      return_url 不作为最终协议状态依据
   │              │
   ├─主动确认协议─┤→ alipay.dut.customer.agreement.query
   │              │      【关键步骤】
   │              │      1. 验 MAPI 响应签名，检查 is_success=T
   │              │      2. 比对 alipay_user_id、agreement_no、product_code、scene
   │              │      3. 可信确认后落库为 NORMAL
   │              │
   └─协议解约─────┤→ alipay.dut.customer.agreement.unsign
                  │      【关键步骤】
                  │      1. 解约请求不传 notify_url
                  │      2. HTTP/网络异常不得污染原可信协议状态

【代扣链路】
12306/上游支付串 → 接入方系统 → 支付宝 MAPI
      │               │              │
      ├─提供支付URL───┤
      │               │      截取 ? 后 Query String，原样 base64 得到 submit_param
      │               │
      ├─发起代扣──────┤→ dut.agent.third
      │               │      【关键步骤】
      │               │      1. 新代扣前确认协议 NORMAL 且主体等于 payer_user_id
      │               │      2. 校验 submit_param 内层字段、白名单和 ord_pmt_timeout
      │               │      3. 先按 out_order_no/ord_id_ext 做幂等命中，再发新代扣
      │               │      4. 同步 XML 先验签，再写回可信结果
      │               │
      └─主动查询结果──┤→ dut.agent.query.third
                      │      【关键步骤】
                      │      1. 使用明确 out_order_no 或 trade_no 查询
                      │      2. payer_user_id 取本地代扣订单保存的付款人 UID
                      │      3. trade_partner 来自 submit_param.partner
                      │      4. 验签、身份比对和对账通过后才更新订单
```

## 推荐读取和生成顺序

三方免密代扣不提供“只签约/只代扣”拆分选择。接入时按完整链路生成，但可以按阶段分段实现和校验。

1. 读取 `api-contract.md` 确认接口文档索引和链路边界。
2. 读取 `codegen-general-rules.md` 和 `field-interface-rules.md`。
3. 按技术栈读取质量门禁。
4. 按链路分段生成：
   - 签约阶段：依次读取 [协议页面签约](agreement/alipay.dut.customer.agreement.page.sign.md)、[协议查询](agreement/alipay.dut.customer.agreement.query.md)、[协议解约](agreement/alipay.dut.customer.agreement.unsign.md)。
   - 代扣阶段：依次读取 [第三方代扣执行](withholding/dut.agent.third.md)、[代扣结果查询](withholding/dut.agent.query.third.md)。
5. 运行本域自检脚本和技术栈构建/测试。

## 接口文档

| 链路 | 接口 | 文档 | 读取时机 |
| --- | --- | --- | --- |
| 签约 | `alipay.dut.customer.agreement.page.sign` | [协议页面签约](agreement/alipay.dut.customer.agreement.page.sign.md) | 生成完整链路时读取 |
| 签约 | `alipay.dut.customer.agreement.query` | [协议查询](agreement/alipay.dut.customer.agreement.query.md) | 生成完整链路时读取 |
| 签约 | `alipay.dut.customer.agreement.unsign` | [协议解约](agreement/alipay.dut.customer.agreement.unsign.md) | 生成完整链路时读取 |
| 代扣 | `dut.agent.third` | [第三方代扣执行](withholding/dut.agent.third.md) | 生成完整链路时读取 |
| 代扣 | `dut.agent.query.third` | [代扣结果查询](withholding/dut.agent.query.third.md) | 生成完整链路时读取 |

## 状态流转建议

协议状态：

- `INIT`：本地发起签约。
- `SIGNING`：已跳转支付宝签约页。
- `NORMAL`：签约成功，已获得 `agreement_no`。
- `UNSIGNING`：已发起解约。
- `UNSIGN`：解约完成。
- `FAILED`：签约或解约失败。

代扣订单状态：

- `CREATED`：本地订单已创建，尚未发起代扣。
- `WITHHOLDING`：已调用 `dut.agent.third`。
- `SYNC_SUCCESS`：同步 XML 返回已验签且身份可信。
- `QUERY_SUCCESS`：主动查询已验签、身份和对账通过。
- `FINAL_SUCCESS` / `FINAL_FAILED`：本地最终态。

同步响应验签失败、解析失败、HTTP 失败、查询业务失败或身份/对账不通过时，应记录不可确认诊断并保持原可信状态，不要直接落 `SYNC_FAILED`、`QUERY_FAILED` 或交易失败态。

代扣订单至少保存 `out_biz_no`、查询用 `out_order_no` 或 `trade_no`、12306 `ord_id_ext`、12306 `trade_partner`、`trans_account_out`、`payer_user_id`、`assignJointAccountId` 和 `submit_param`。其中 `out_order_no` 不能由查询方法临时生成，必须来自代扣执行上下文、同步返回或上游业务映射。

`return_url` 只影响用户页面体验，不应直接推动最终状态。协议产品码为 `DUT_AGENT_THIRD_P` 时，签约/解约没有服务端 `notify_url`，协议最终状态应通过协议查询或清晰的本地状态流转确认。
