# 通用代码生成规则

## MAPI 请求模型

三方免密代扣使用 MAPI 模型：

- 网关：`https://mapi.alipay.com/gateway.do`
- 接口参数：`service`
- 商户标识：`partner`
- 业务参数：Query String
- 签名参数：`sign`、`sign_type`

禁止按 OpenAPI 方式生成 `method/app_id/biz_content` 请求。

火车票接通样例的共同形态：

- 历史样例网关为 `http://mapi.alipay.com/gateway.do`；新接入按当前网关配置选择 HTTP 或 HTTPS，不要把样例网关硬编码。
- 外层请求都通过 Query String 传参，包括 `sign` 和 `sign_type`。
- 样例使用 `_input_charset=utf-8`、`sign_type=RSA`。
- 协议类接口传 `format=JSON`；代扣执行和代扣查询样例未传 `format`，同步返回按 XML 解析。
- 当协议产品码为 `DUT_AGENT_THIRD_P` 时，签约和解约接口不支持服务端 `notify_url`；不要给 `alipay.dut.customer.agreement.page.sign` 或 `alipay.dut.customer.agreement.unsign` 传 `notify_url`，也不要生成签约/解约通知处理器。
- 代扣结果通知面向商户侧，不是接入方服务端能力；`dut.agent.third` 不为接入方新增外层 `notify_url`，也不生成接入方通知入口。

## 生产扩展点和 Spring 装配

- 协议、订单、幂等、业务回调等可替换扩展点必须先定义 Port/Store/Repository/Callback 接口；Service、Handler、Controller、AutoConfiguration 等核心组件依赖接口，不得直接依赖 demo/test 具体实现。
- 进程内 Map/Set 只能作为明确 demo/test profile 下的示例实现；生产默认路径必须使用真实持久化实现，或 fail-closed 阻止继续执行。
- 默认 fail-closed Bean 必须能被接入方真实实现无冲突覆盖，例如使用 `@ConditionalOnMissingBean` 或互斥 profile；不得用 `@Primary` 抢占真实实现。
- Spring profile 只能限制 demo/test 存储、回调、适配器或示例配置；核心 Handler、Router、Controller、Service、AutoConfiguration、启动监听器必须默认可装配。
- Spring 自动配置、初始化或 `@PostConstruct` 不得直接调用同类中的 `@Bean` 方法来获取依赖；必须注入真实 Bean、`ObjectProvider` 或事件监听，避免绕过 `@ConditionalOnBean` 和 profile 条件。

## 签名和编码

生成代码时必须分清三层数据：

1. **原始参数 Map**：业务值保持未 URL 编码形态。
2. **待签名串**：过滤空值、`sign` 和 `sign_type`，按 MAPI 规则排序拼接。
3. **最终请求 URL**：签名完成后再对 Query 参数做 URL 编码。

编码敏感字段：

- `scene=INDUSTRY|B2B_TICKET_AGENT`
- `access_info={"channel":"ALIPAYAPP"}`
- `business_info={"assignJointAccountId":"..."}`
- 协议 `return_url`、`submit_param` base64 中的商户侧原始字段
- `submit_param` base64 中的 `=`、`+`、`/`
- `create_time`、`query_time` 中的空格和冒号

不要对同一个值双重编码；不要签名最终编码后的整条 URL。

MAPI 签名细节：

- 请求参数签名：请求参数里除 `sign`、`sign_type` 和空值外，其余参与签名。`_input_charset` 如果传入，也参与待签名串。
- XML 同步响应验签：把响应 XML 中业务节点的直接子节点按“节点名=节点值”抽成参数；正常响应读取业务响应节点下的子节点，错误响应通常读取 `error` 节点。节点文本如果包含 XML/HTML 转义字符，先还原为正常字符后再参与验签。代扣执行和代扣查询的 XML 同步响应在验签通过前只能作为不可确认响应处理，不能用其中的 `is_success`、`trade_status`、`trade_no`、`out_order_no`、金额或资金账号更新本地订单。
- 排序和拼接：按参数名从小到大排序，使用 `key=value` 片段并以 `&` 连接；排序依据是参数名，不是 URL 编码后的整段字符串。
- 签名算法：按商户 MAPI 配置选择 `RSA`、`DSA` 或 `MD5`。新代码优先使用既有 RSA/DSA 签名服务；如果历史接入仍使用 MD5，MD5 key 只能来自安全配置，不得写入代码或文档示例。配置项和实现必须一致：代码如果只实现 `RSA`，就要在启动或构造签名器时限制 `sign_type=RSA`；如果允许配置 `MD5`、`DSA` 等值，就必须真正按该配置分派签名和验签算法，不能请求里发 `sign_type=MD5/DSA` 但实际仍用 RSA。
- 验签公钥、商户私钥、MD5 key 和 PID 必须从配置或密钥管理系统读取，不要硬编码。

签名和验签的字节编码必须与 `_input_charset` 一致。新接入通常是 `utf-8`，但历史 MAPI 文档和存量接入可能使用 `gbk`；如果代码固定 `UTF-8` 做签名字节，而请求参数声明 `_input_charset=gbk`，支付宝验签会失败。生成代码应从配置读取 `_input_charset`，用于待签名串转字节和最终 URL 编码。Java 实现使用 `Charset.forName(inputCharset)`；不要在 `Signature.update(...)` 前硬编码 `StandardCharsets.UTF_8`。

## MAPI HTTP 同步响应

MAPI 同步调用要把传输结果和业务结果分开处理：

- HTTP 状态码非 2xx 时，直接按传输失败抛异常或返回明确失败结果；可以记录 error body 便于排查，但不能把 `errorStream`、HTML 错误页或网关错误文本当成正常 XML/JSON 交给业务解析器。
- HTTP 2xx 后才进入 MAPI 业务响应解析。协议类接口按 JSON 处理，代扣执行/查询按 XML 处理。
- 响应读取字符集按 `Content-Type charset -> XML declaration encoding -> _input_charset -> UTF-8` 顺序确定；不能只看响应头，也不能固定 UTF-8。
- 实现时推荐先把 HTTP 2xx 响应体读成 `byte[]`，再从响应头和 XML declaration 的 ASCII 兼容前缀中嗅探字符集，最后用确定出的 `Charset` 解码整段响应。不要先用 fallback charset 解完整响应再尝试从乱码里恢复 XML declaration。
- 读取 2xx response body 时，IO 异常必须向上传播或包装为 MAPI HTTP/传输异常；不能 catch 后返回 `""`、`new byte[0]`、空 Buffer 或空对象，否则会把网络读失败伪装成业务空响应。
- 读取 `errorStream` 只用于诊断；即使读取失败，也必须返回明确的 HTTP 非 2xx 传输失败，不能进入正常 XML/JSON 解析。错误流读取失败时可以把 error body 标为不可读。
- 响应 `InputStream`/body reader 必须用 try-with-resources、`defer close`、`using` 或等价机制关闭；不要只关闭连接而遗漏 body stream。
- Java 代码不要在 MAPI HTTP 客户端里固定 `new InputStreamReader(is, StandardCharsets.UTF_8)`；应使用配置字符集或响应声明解析出的 `Charset`。如果 `Content-Type` 是 `text/xml` 但不带 `charset`，必须能识别 `<?xml version="1.0" encoding="GBK"?>`。
- 测试要覆盖 `Content-Type: text/xml` 不带 `charset`、XML declaration 声明 `encoding="GBK"` 且响应包含中文字段的场景，证明 HTTP 层返回的字符串不乱码。
- 测试要覆盖 body 读取异常：模拟响应流读取抛异常时，HTTP 客户端应抛出明确传输异常，不能返回空字符串再让 XML parser 报“XML 返回内容为空”。

## XML 同步响应解析

如果 HTTP 层已经按响应声明或 `_input_charset` 把 MAPI XML 响应解码成语言内字符串，后续 XML parser 应继续按字符流解析这段字符串，不要再把字符串按固定 UTF-8 转回字节流。

Java 示例：

- 推荐：`DocumentBuilder.parse(new InputSource(new StringReader(xml)))`。
- 避免：`DocumentBuilder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)))`。

原因是 XML declaration 可能保留 `encoding="GBK"`。当 HTTP 客户端已经正确解码成 Java `String` 后，如果再把该字符串转成 UTF-8 字节流，DOM/SAX 解析器可能根据 XML declaration 按 GBK 解释这批 UTF-8 字节，导致中文字段乱码。生成代码应补充 `encoding="GBK"` + 中文字段的解析测试，证明解析结果不是乱码。

解析器要区分“业务字段读取”和“验签参数抽取”。用于业务读取的扁平化 Map 可以保留易用字段，但不能直接拿“所有叶子节点”去做 XML 响应验签，因为 `<request><param name="...">...</param></request>` 这类节点会出现重复节点名或非业务节点。应提供专门的 XML 响应验签抽取方法：

- 业务读取可以递归扁平化，方便服务层读取 `agreement_no`、`trade_no`、`out_order_no` 等字段；验签抽取必须走独立方法，协议查询、代扣执行、代扣查询都不能把 `xmlParser.parse(xml)` 这类“所有叶子节点 Map”直接传给 `verify`。
- 正常响应：忽略 `request` 节点，定位 `response` 下的业务响应节点或其直接业务子节点，只抽取业务节点的直接子节点名和值。
- 错误响应：按接口文档读取 `error` 等错误节点参与验签。
- 抽取后过滤空值、`sign`、`sign_type`，还原 XML/HTML 转义，再按 MAPI 规则排序验签。
- 验签失败、缺少 `sign`、XML 解析失败或无法定位签名节点时，业务层不得更新订单/协议状态；代扣执行不得置为 `SYNC_FAILED`，代扣查询不得置为 `QUERY_FAILED`，也不得写回响应字段或把未验签的业务响应字段返回给调用方。
- 测试必须分别覆盖协议查询、代扣执行和代扣查询的接近 MAPI XML 结构，至少包含 `<request><param name="...">...</param></request>` 和 `<response>...业务节点...</response>`，证明验签不会被 `request/param` 节点污染；不能只用 `<alipay><is_success>...` 这类扁平 XML，也不能只靠代扣测试间接覆盖协议查询。

## 支付宝钱包 H5 签约 schema

协议页面签约如果走支付宝钱包 H5（`access_info.channel=ALIPAYAPP`），前端启动地址必须是：

```text
alipays://platformapi/startapp?appId=20000067&url=<encoded_mapi_sign_url>
```

生成代码按下面顺序处理：

1. 先用 MAPI 请求构造器生成完整签约 URL；这一步仍遵循“原始参数 Map -> 待签名串 -> MAPI Query 参数 URL 编码”。
2. 再把第 1 步得到的整条 MAPI URL 作为钱包 schema 的 `url` 参数值整体 URL encode。
3. 返回 schema 给前端，例如字段名可用 `sign_url`、`wallet_sign_url` 或同时返回 `mapi_sign_url` 便于排查。

这不是对 MAPI 参数值重复编码，而是把已经完整的 MAPI URL 作为另一个 URL 参数传入钱包 schema。PC 签约场景可以继续返回裸 MAPI URL。

签约渠道入参必须先归一化再使用：

- 对外部传入的 `channel` 做 trim 和大小写归一，建议规范成大写。
- Java 代码若使用 `toUpperCase` 做归一，必须传 `Locale.ROOT`，避免服务器默认 Locale 影响 `ALIPAYAPP` / `PC` 判断。
- 只允许 `ALIPAYAPP` 和 `PC` 两个值；非法值直接拒绝，不要静默降级。
- `access_info` 里的 `channel` 和返回链接分支必须使用归一化后的值，避免 `alipayapp`、`ALIPAYAPP ` 等输入误返回裸 MAPI URL。

## `submit_param` 规则

`submit_param` 必须来自 12306 原始支付 URL 中 `?` 后面的 Query String：

```text
12306 支付 URL
  -> substringAfter("?")
  -> 原样保留 Query String
  -> base64
  -> 外层 submit_param
```

不要把完整 URL 做 base64；不要把解析后的 JSON 做 base64；不要重排 12306 内层参数。用于生成 `submit_param` 的源 Query String 应来自上游支付 URL 中的支付参数部分；若上游按当前产品契约去除了非支付噪音参数，生成代码应接收处理后的 Query String，但不要在没有明确契约的情况下自行删除字段。选定 Query String 后按输入原文做 base64，保留原始编码、空值字段和内层 `sign`；字段顺序只随输入原文保留，不作为白名单校验条件。

可以解码 `submit_param` 做只读校验和映射：

- 校验内层 `service=alipay.acquire.mr.ord.createandpay`。
- 提取内层 `partner` 作为代扣查询的 `trade_partner`。
- 提取内层 `ord_id_ext` 作为 12306 原始订单号。
- 按已确认的 12306 支付串样例字段清单做白名单校验。当前接通样例为 15 个子参数；生成代码要集中维护允许字段集合、必填字段集合和允许空值字段集合。白名单只校验字段集合、必填/可空、重复 key 和拼接格式，不校验字段顺序。示例字段以外的参数、重复 key、空 key、非 `key=value` 片段、连续/结尾 `&` 造成的空片段、必填字段空值或错误分隔符要返回明确诊断（例如 `SUBMIT_PARAM_SIGN_ERROR` 风险），不要继续发起代扣。普通允许空值字段不得擅自删除、补值、重排或重签。
- 如果内层 `ord_pmt_timeout` 存在，先按真实上游支付串样例、产品契约或配置化解析策略确定格式，再按内层编码/URL decode 后解析；当前底层文档没有明确格式时，不要臆测为固定 epoch 秒/毫秒或固定日期格式。格式策略必须能通过运行时配置、构造参数或明确产品常量进入解析代码；只有类内 setter、默认枚举值或注释说明，不算配置化落地。无法识别格式时应返回明确诊断并暂停发起；解析后已过期或距离当前不足 60 秒时拒绝发起新代扣，并返回 `PAYMENT_TIMEOUT` 风险诊断。已有订单幂等重试不应被时效校验拦截；如果要用 `ord_id_ext` 定位已有订单，先做不触发时效判断的只读提取，再在确认没有已有订单后做 `ord_pmt_timeout` 校验。
- 内层 `notify_url`、`return_url` 属于 12306/商户侧原始参数，只能随 `submit_param` 原样保留；不要解析成接入方回调、页面跳转、验签入口或状态更新逻辑。`ord_amt`、`ord_cur`、`ord_time_ext` 等对账字段如当前业务需要，可只读解析并随本地订单保存。

这些解析结果只能用于校验、持久化和查询映射，不能用于重新拼接 `submit_param` 或重算内层签名。同一个 `submit_param`、`ord_id_ext` 或 `out_order_no` 要与同一个 `payer_user_id` 绑定；不能把同一笔外部交易换付款人重试，否则容易出现买家不匹配或重复外部单号问题。若上游返回的支付串/外部单号已重复，应作为幂等重试处理，或重新获取新的上游支付串再发起新支付。幂等重试应在调用 MAPI 前命中已有订单/已有结果并返回，不得生成新的 `out_biz_no` 或再次调用 `dut.agent.third`。必须先用 `out_order_no` 查询已有订单，且这一步要早于 `submit_param` 构造、base64、解码、白名单/必填校验、`ord_pmt_timeout` 校验和 `ord_id_ext` 提取；只有 `out_order_no` 未命中时，才用不会触发完整结构诊断和时效门禁的轻量方式提取 `ord_id_ext` 做第二路径幂等查询。对已存在订单且 `payer_user_id` 一致的重试，优先返回已有结果；新代扣发起前才进入协议有效性门禁和 `ord_pmt_timeout` 时效门禁。同 `out_order_no` 已命中时，本次支付串即使缺少 `partner`、包含示例外字段、重复 key、错误分隔符或其他结构异常，也不能挡住幂等返回。幂等命中返回的 `out_order_no` 必须来自已有订单保存值；如果通过 `ord_id_ext` 命中已有订单但本次 `out_order_no` 与保存值不同，返回保存值或拒绝/诊断，不要返回本次入参。

代扣执行发起前必须对外层必填业务字段做 fail fast 校验：

- `business_info.assignJointAccountId`：因公付账户 ID，不允许为空或空白字符串。
- `trans_account_out`：客票平台付款方支付宝人民币资金账号，不允许为空或空白字符串。
- `payer_user_id`：实际付款员工支付宝 UID，不允许为空或空白字符串。

校验应发生在落库和调用 `dut.agent.third` 之前；不要把空值写进订单、`business_info` 或 MAPI Query。新代扣发起前必须确认协议主体与付款人一致：本地可信协议记录或可信协议查询响应中的 `alipay_user_id` 必须等于本次 `payer_user_id`，否则按身份不匹配拒绝，不落新单、不调用 MAPI。

代扣结果通知和代扣内层页面返回都面向商户侧，不是接入方服务端或前端能力；不要给 `dut.agent.third` 新增接入方外层 `notify_url`、`withholdNotifyUrl` 配置、公网回调地址校验、代扣 `return_url` 配置或页面跳转承接。

## `out_order_no` 映射

`dut.agent.query.third.out_order_no` 是查询路由使用的订单号。火车票接通样例中它和 `submit_param.ord_id_ext` 不同，因此生成代码必须明确来源：

- 优先取代扣执行同步返回里的 `out_order_no` 或支付宝交易号 `trade_no`。
- 如果上游业务已生成查询订单号，把它作为代扣执行上下文的一部分传入并持久化。
- 如果只能拿到 12306 `ord_id_ext`，不要假设它就是 `out_order_no`；需要在回执中标明缺少查询订单号来源。

不要用时间戳、UUID 或另一个本地流水号临时生成 `out_order_no` 后直接用于查询。代扣执行返回给调用方时，应包含 `out_biz_no` 以及可用于后续查询的 `out_order_no` 或 `trade_no`。

## 状态确认和回调处理

协议类 `DUT_AGENT_THIRD_P` 不支持签约/解约服务端通知：

- 签约请求不要传 `notify_url`，只传页面流程需要的 `return_url`。
- 解约请求不要传 `notify_url`。
- 不要生成 `AgreementNotifyHandler`、`handleSignNotify`、`handleUnsignNotify`、`/notify/sign`、`/notify/unsign` 或等价协议通知入口。
- `return_url` 只用于页面体验承接，不作为最终状态依据；页面返回后应触发协议查询或提示前端/后端主动查询。
- 发起新代扣前必须可通过本地协议状态和/或 `alipay.dut.customer.agreement.query` 确认协议有效。代扣执行方法或入口必须能关联协议定位字段（例如 `external_user_id`、`alipay_user_id`、`agreement_no` 或业务订单到协议记录的映射），在落代扣新单和调用 `dut.agent.third` 前检查本地可信协议为 `NORMAL`，或调用协议查询确认 `status=NORMAL`、`product_code`、`scene` 和身份字段匹配；同时必须确认协议主体就是本次付款人，即协议记录或可信查询响应中的 `alipay_user_id` 等于本次 `payer_user_id`。如果服务商只掌握签约员工 openid，协议查询可使用 openid + `app_id` 定位，但验签通过后必须读取响应 `principal_id` 并保存为协议 `alipay_user_id`，后续 `payer_user_id` 取该支付宝 UID，不能直接使用 openid。无协议、`SIGNING`、`UNSIGNING`、`FAILED`、查询不可确认、协议主体与付款人不一致或其他身份不匹配时要 fail fast，不得发起新代扣。
- 对外协议查询入口不能只返回原始 `queryAgreement(alipay_user_id)` 响应；如果生成 Controller/API，应提供会调用 `confirmAgreementByQuery(external_user_id, alipay_user_id)` 或等价确认落库逻辑的入口，用于签约返回、支付前和解约后的状态闭环。
- `external_sign_no` 是可选协议定位字段。签约时传入才需要进入签约请求、持久化到本地协议对象，并在后续查询/解约按同一口径从本地协议记录复用进 MAPI 请求；签约未传入时，不要后续臆造、强制要求或用随机值填充。生成代码要有真实入参/实体字段/查询请求组装/解约请求组装/测试覆盖，不能只在注释或测试名称里提到它。
- 协议查询用 `alipay_user_id` 定位支付宝协议，本地协议记录通常用 `external_user_id` 建索引；确认查询结果落库时必须显式区分两者，不能把 `alipay_user_id` 当成 `external_user_id` 去查或新建本地协议。如果 `alipay_user_id` 入参实际是员工 openid，必须同时传 `app_id`，并把可信响应里的 `principal_id` 作为支付宝 UID 写回本地协议记录；请求 openid 只能作为定位字段保存，不能作为协议主体 UID 或代扣付款人。
- 协议查询确认落库必须兼容 JSON/XML 同步响应，先验 MAPI 响应签名并检查 `is_success=T`，再比对返回的 `alipay_user_id` 与请求/本地记录一致；已有 `agreement_no` 时必须比对一致，首次确认时才持久化返回的 `agreement_no`。JSON 响应不能只读取顶层字段，必须兼容业务响应节点嵌套形态，例如 `response`、`alipay_dut_customer_agreement_query_response`、`customer_agreement_query_response` 等节点下的字段；即使请求带了 `format=JSON`，真实网关返回 XML 时也要能走 XML 解析/验签路径，不能只用 JSON parser 导致协议永远无法确认。
- 协议查询的解析失败、HTTP/传输失败、验签失败或 `is_success` 非 T 只能表示本次查询无法确认，不能覆盖已有本地可信协议状态为 `FAILED` 或未签约；应记录查询失败原因并保持原状态。只有已验签的可信响应明确证明协议不可用、且身份字段匹配时，才允许进入协议失效/失败状态。
- 不要生成只有 `alipay_user_id` 一个参数的 `confirmAgreementByQuery` 之类快捷方法；确认协议至少要显式携带本地 `external_user_id` 和支付宝 `alipay_user_id`，避免把支付宝 UID 当成本地用户号。
- 协议签约发起前必须 fail fast 校验 `external_user_id`、`return_url`；协议查询确认前必须校验 `alipay_user_id`；协议解约前必须校验 `agreement_no` 和 `alipay_user_id`。
- 协议解约状态流转要避免传输失败污染本地可信状态：不要在 MAPI HTTP 调用尚未成功发出前永久写入 `UNSIGNING`；如果实现需要先写中间态，必须在 HTTP/网络/读取异常分支回滚到原状态并记录失败原因。测试要覆盖 HTTP 调用抛异常时协议仍保持原可信状态。

代扣结果通知边界：

- 代扣结果通知面向商户侧，不是接入方服务端能力；本 Skill 生成接入方代码时不生成代扣通知 handler/controller、通知验签、`notify_id` 幂等、`notify_verify` 或通知状态流转。
- `dut.agent.third` 不要求接入方传外层 `notify_url`；不要为接入方新增 `withholdNotifyUrl` 配置或公网回调校验。
- 12306 原始支付串里已有的内层 `notify_url`、`return_url` 属于商户侧原始参数，只能随 `submit_param` 原样保留；不能改写成接入方回调或页面跳转地址，也不能生成代扣 `return_url` 验签、跳转承接或状态逻辑。


协议 `return_url` 只用于页面跳转。即使消费协议 `return_url` 参数，也必须验签；不得只靠协议 `return_url` 更新最终业务状态。

代扣主动查询只能作为结果补偿手段：

- 查询调用失败、MAPI 业务失败和交易最终失败要分开表达；不要把所有非 `TRADE_SUCCESS` 响应统一写成 `QUERY_FAILED`。`is_success=F`、错误码、缺少 `trade_status` 或查询业务失败应保持本地原状态并返回查询失败诊断，不能写成交易最终失败。
- 主动查询更新本地订单前必须先检查当前订单是否已经处于已确认的最终成功态；已成功的终态不能被一次查询失败或处理中状态覆盖。
- 主动查询更新本地订单状态或写回 `trade_no/out_order_no/金额/资金账号` 等响应字段前，必须比对响应里的 `out_order_no/trade_no`、金额、资金账号等与本地订单一致；响应里出现且本地可比对的身份字段不能有任何冲突，例如 `out_order_no` 不匹配时，即使 `trade_no` 匹配也不能更新；响应里出现且本地可比对的对账字段也不能有任何冲突，例如金额匹配但资金账号不匹配时不能更新。响应缺失关键身份/对账字段、身份冲突或对账冲突时不得更新终态，不得写回响应字段污染本地订单，也不得把这些响应业务字段原样返回给调用方。
- 代扣主动查询必须有独立测试，覆盖终态保护、响应身份不匹配/缺失、身份字段混合冲突、金额或资金账号不匹配/缺失、对账字段混合冲突，以及未通过校验时 `trade_no/out_order_no` 等字段不写回。
- 查询结果返回值必须反映实际动作；身份/对账未通过而没有更新本地订单时，应返回 `mismatch_not_updated`、`not_updated` 或等价结果，不能统一返回 `updated`，也不能携带未归属当前订单的 `trade_no/out_order_no/金额/资金账号` 等业务响应字段。
- 只有支付宝明确返回最终失败/关闭状态，并且订单身份、金额、交易参与方与本地订单一致时，才允许把订单转为最终失败。

## 代码组织

推荐拆分：

- `MApiSigner` / `MApiSignatureService`
- `MApiRequestBuilder`
- `AgreementSignService`
- `AgreementQueryService`
- `AgreementUnsignService`
- `TrainTicketWithholdingService`
- `TrainTicketWithholdingQueryService`

固定常量集中定义，不要散落在多个方法里。
