# 核心领域约束

本文档只做红线索引，避免遗漏本域最容易出错的约束；字段明细、请求/响应构造和测试要求以接口文档、[通用代码生成规则](codegen-general-rules.md) 与 [字段与接口规则](field-interface-rules.md) 为准。

## 全局红线

- 本域是旧版 MAPI 网关接入：使用 `service`、`partner`、Query String 和 MAPI `sign`；不得按 OpenAPI `method/app_id/biz_content` 生成。
- 文档没有的字段、接口、通知、SDK 能力或参数来源必须说明缺口，不能猜测补齐。
- 签名/验签必须使用未 URL 编码的原始参数和 `_input_charset` 对应字节编码；`sign_type` 配置要与真实算法实现一致。
- MAPI HTTP 非 2xx、响应体读取失败、响应验签失败或解析失败，都只能进入不可确认/传输失败路径，不能直接污染本地协议或订单状态。

## 签约链路红线

- `ALIPAYAPP` 签约必须返回钱包 schema：`alipays://platformapi/startapp?appId=20000067&url=<encoded_mapi_sign_url>`；`url` 是整条 MAPI 签约 URL 的整体 URL encode。
- `channel` 先 trim 和大小写归一，只允许 `ALIPAYAPP`、`PC`；非法值拒绝。
- `product_code=DUT_AGENT_THIRD_P` 时，签约和解约不支持服务端 `notify_url`，不得传参或生成签约/解约通知入口。
- 协议状态以协议查询确认或解约调用后的可信状态流转为准；页面 `return_url` 只做体验承接，不能直接落最终状态。
- `external_sign_no` 是可选协议定位字段：签约时传入才持久化并在查询/解约复用，未传不得臆造或强制要求。
- 协议查询确认必须验签、检查 `is_success=T`，并比对 `alipay_user_id`、`agreement_no`、`product_code`、`scene` 等身份字段；失败或不可确认时保持已有可信状态。
- 如果服务商只掌握员工 openid，协议查询可用 openid + `app_id` 定位，但必须把可信响应 `principal_id` 保存为协议支付宝 UID；后续代扣 `payer_user_id` 不能直接使用 openid。
- 解约不得在 MAPI HTTP 调用尚未成功发出前永久写入 `UNSIGNING`；传输异常要保持原状态或回滚。

## 代扣链路红线

- 新发起 `dut.agent.third` 前必须确认协议可代扣：本地可信 `NORMAL` 或协议查询可信确认通过，并且协议主体 `alipay_user_id` 等于本次 `payer_user_id`。
- `assignJointAccountId`、`trans_account_out`、`payer_user_id` 在落库和发 MAPI 前必须非空。
- `submit_param` 来自 12306 原始支付 URL 的 Query String base64；只能做只读校验、映射和持久化，不能重排、改写、删除普通空值字段或重签内层参数。
- `submit_param` 白名单以已确认样例字段集合为准，只校验字段集合、必填/可空、重复 key 和拼接格式，不校验字段顺序。
- `ord_pmt_timeout` 格式必须来自真实样例、产品契约或可配置解析策略；时效门禁只用于新代扣，不拦截已有订单幂等重试。
- `out_order_no` 必须来自明确业务映射、代扣同步返回或上游入参，不能用时间戳、UUID 或 `ord_id_ext` 直接冒充。
- 幂等优先：先按 `out_order_no` 查已有订单，再轻量提取 `ord_id_ext` 做第二路径；命中同付款人订单时返回已有 canonical 结果，不再发起新 MAPI。
- 同一个 `submit_param`、`ord_id_ext` 或 `out_order_no` 不得切换 `payer_user_id` 重试。
- 代扣结果通知和代扣内层 `notify_url`/`return_url` 面向商户侧，不是接入方能力；不得生成接入方代扣通知、外层代扣 `notify_url` 或代扣 `return_url` 承接。

## 响应可信度红线

- 协议查询要兼容 JSON/XML 同步响应；JSON 不能只读顶层字段，XML 验签不能把递归扁平化结果直接传给 `verify`。
- 代扣执行和代扣查询同步 XML 必须先按 MAPI XML 响应规则验签；验签前不得用响应里的 `trade_no/out_order_no/trade_status/金额/资金账号` 更新或返回可信业务结果。
- 代扣主动查询更新前必须保护已成功终态，并在同一分支内完成验签、订单身份比对和金额/资金账号对账；任一冲突或缺失都不得写回响应字段。
- `is_success=F`、错误码、查询业务失败或缺少 `trade_status` 不等同交易最终失败；只有明确终态且身份/对账通过才允许转失败态。

## 完成条件

- 接入三方免密代扣时必须覆盖签约 + 代扣完整五个接口和状态确认方式，不生成孤立请求方法，也不生成“只签约/只代扣”半链路。
- 已有项目只做增量改造；无法推断协议或订单与已有业务对象的衔接时先暂停确认。
- 生成后必须执行本域官方 `scripts/validate_codegen.js`，退出码为 `0` 才能声明完成。
