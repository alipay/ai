# Python/Go/.NET 质量门禁

Python、Go、.NET 项目生成后必须检查：

- MAPI 参数 Map、签名串、最终 URL 分层清楚。
- MAPI 待签名串测试覆盖过滤空值、`sign` 和 `sign_type`，并证明签名前使用原始值而不是 URL 编码后的值。
- MAPI 签名和验签使用 `_input_charset` 对应字符集，不要固定 UTF-8 后又声明其他字符集。
- MAPI `sign_type` 与签名实现一致：如果只实现 RSA，测试或启动校验覆盖非 RSA 配置会失败；如果支持 MD5/DSA，测试覆盖按配置分派算法。
- MAPI HTTP 客户端测试覆盖非 2xx 返回会明确失败，不会把错误响应当正常 XML/JSON 解析。
- MAPI HTTP 客户端测试覆盖响应字符集处理，例如 GBK XML/JSON 能按响应声明或 `_input_charset` 正确读取。
- MAPI HTTP 客户端测试必须覆盖 `Content-Type: text/xml` 不带 `charset`、XML declaration 声明 `encoding="GBK"` 且中文字段不乱码的场景。
- MAPI HTTP 客户端测试必须覆盖响应体读取异常会抛出明确传输异常；读取辅助方法不能 catch 后返回空内容，响应流必须关闭。
- XML 同步响应解析不要在 HTTP 层已解码为字符串后再按固定 UTF-8 重新转字节；测试覆盖 XML 声明 `encoding="GBK"` 且包含中文字段时解析结果不乱码。
- XML 同步响应验签测试覆盖：代扣执行和代扣查询在验签失败/缺少签名/无法抽取签名参数时，不更新订单状态，也不写回 `trade_no/out_order_no` 等响应字段。
- 固定常量集中定义。
- 协议页面签约 ALIPAYAPP/H5 场景返回支付宝钱包 schema，schema 的 `url` 参数是完整 MAPI 签约 URL 的 URL encode。
- 协议签约/解约测试或自检覆盖 `product_code=DUT_AGENT_THIRD_P` 时不传 `notify_url`，且不生成签约/解约通知 handler、controller 入口或相关测试。
- 协议页面签约 `channel` 做 trim、大小写归一和白名单校验，非法值拒绝。
- 协议查询确认测试覆盖 JSON 和 XML 同步响应都可解析验签；JSON 至少覆盖业务字段嵌套在 `response` 或协议业务响应节点下的形态，不能只测顶层扁平 JSON；解析失败、验签失败、HTTP 查询失败、`is_success=F` 均只记录查询失败，不把已有 `NORMAL/SIGNING/UNSIGNING` 等可信协议状态覆盖成 `FAILED`；返回 `alipay_user_id` 不匹配、已有 `agreement_no` 不匹配均不落库为可代扣状态。
- 如果支持员工 openid 查询协议，测试必须覆盖请求携带 openid + `app_id`，可信响应 `principal_id` 被保存为本地协议 `alipay_user_id`，后续代扣执行和主动查询的 `payer_user_id` 都使用该 UID；响应缺少 `principal_id` 时不得确认协议为 `NORMAL`。
- 协议签约/查询/解约测试覆盖 `external_user_id`、`return_url`、`alipay_user_id`、`agreement_no` 空值/空白拒绝；同时覆盖 `external_sign_no` 可省略。`external_sign_no` 的覆盖必须是实际代码路径：签约请求传入时 MAPI 请求包含 `external_sign_no` 且本地协议实体持久化，查询和解约请求必须从本地协议记录复用并通过捕获实际请求断言包含该字段；未传时请求不包含该字段且不拦截。协议解约还必须覆盖 HTTP/网络异常时本地协议保持原可信状态，不提前停留在 `UNSIGNING`。
- `submit_param` 构造保留 12306 原始 Query String。
- `submit_param` 解码校验覆盖 `service`、`partner`、`ord_id_ext`；`partner` 映射到 `trade_partner`。
- `submit_param` 诊断测试覆盖非 `key=value` 片段、空 key、关键字段空值或当前产品契约外异常字段会返回 `SUBMIT_PARAM_SIGN_ERROR` 风险诊断；普通空值字段不被擅自删除、补值、重排或重签。
- `submit_param` 字段白名单测试覆盖：示例字段以外的参数拒绝或暂停确认；必填字段缺失、必填字段值为空/空白拒绝；允许空值字段原样保留；重复 key、连续/结尾 `&`、非 `key=value` 片段和 `;`/换行/空白等错误分隔方式拒绝；测试还要证明白名单校验不用于重拼 `submit_param`，且不因为字段顺序与样例不同而拒绝。
- `submit_param.ord_pmt_timeout` 测试覆盖字段格式来源：真实样例/产品契约/配置化解析策略至少其一明确；不得只写死 epoch 秒，也不得只有类内 setter/默认枚举值而没有运行时配置入口。测试覆盖配置入口或构造参数能切换策略、无法识别格式时拒绝或暂停、已过期和距当前不足 60 秒时拒绝发起新代扣；同时覆盖已有订单幂等重试不被过期/不足 60 秒的 `ord_pmt_timeout` 拦截。
- 代扣查询的 `out_order_no` 或 `trade_no` 来源明确，来自同步返回、上游入参或持久化映射，不由随机值临时生成。
- 代扣执行测试覆盖支付前协议门禁：无协议、`SIGNING`、`UNSIGNING`、`FAILED`、协议查询不可确认、协议 `alipay_user_id` 与本次 `payer_user_id` 不一致或其他身份不匹配时拒绝且不调用 `dut.agent.third`，本地可信 `NORMAL` 且协议主体等于付款人，或查询可信确认通过且主体匹配时才允许新发起代扣。
- 代扣执行对 `assignJointAccountId`、`transAccountOut`、`payerUserId` 做空值/空白拒绝。
- 代扣执行测试覆盖同一 `submit_param`、`ord_id_ext` 或 `out_order_no` 不能切换 `payer_user_id` 重试；同一 `payer_user_id` 的重复外部单号/支付串必须证明是真幂等：不再次调用 `dut.agent.third`、不生成新 `out_biz_no`，返回已有订单/已有同步结果/明确幂等结果。测试还要覆盖已有订单幂等重试优先于新单协议门禁和 `ord_pmt_timeout` 时效门禁：即使当前协议状态变为 `UNSIGNING/FAILED`，或原支付串已过期/不足 60 秒，同付款人的重复请求也应返回已有结果，不落新单、不调 MAPI。还必须覆盖同 `out_order_no` 已命中时，本次传入的支付串缺少 `partner`、含示例外字段、重复 key、连续/结尾 `&` 或错误分隔符等结构异常，也不会在幂等返回前触发 `submit_param` 结构诊断。
- 代扣执行测试覆盖通过 `ord_id_ext` 命中已有订单但本次 `out_order_no` 不同的场景：返回已有订单 canonical `out_order_no`，或明确拒绝/诊断；不能把已有 `out_biz_no/trade_no` 和本次未落库的 `out_order_no` 混合返回。
- 代扣链路测试或自检覆盖：不生成接入方代扣通知 handler/controller，不给 `dut.agent.third` 传接入方外层 `notify_url`，也不生成代扣 `return_url` 页面承接；`submit_param` 内层 `notify_url`、`return_url` 只作为商户侧原始参数保留。
- 协议状态写正常态的测试应覆盖通过协议查询确认 `status/product_code/scene`，不能通过签约通知或 `return_url` 直接写 `NORMAL`。
- 代扣主动查询必须有独立测试文件；测试覆盖请求包含本地订单保存的 `payer_user_id`，该值与执行代扣保存的付款人 UID 一致，缺失/空白时 fail fast，且不会用员工 openid 替代；覆盖 XML 验签失败/缺少签名时不更新不写回，已成功终态不被查询失败/处理中/未知响应覆盖，并区分查询失败、交易处理中和最终失败；状态更新和 `trade_no/out_order_no/金额/资金账号` 字段写回前必须覆盖查询响应 `out_order_no/trade_no`、金额、资金账号与本地订单不一致或缺失时不更新、不写回、不在返回值中透出响应业务字段；同时覆盖身份字段混合冲突、对账字段混合冲突不更新，且未更新时 `query_result` 不能返回 `updated`；覆盖 `is_success=F`/MAPI 业务失败时保持原状态、不置 `QUERY_FAILED`。
- XML/JSON 响应解析有错误分支。
- 运行对应语言检查：
  - Python：`python -m py_compile` 或项目测试命令。
  - Go：`go test ./...`。
  - .NET：`dotnet build` 或项目测试命令。
- 运行本域自检脚本：

```bash
node alipay-third-party-withholding/scripts/validate_codegen.js <生成项目目录>
```

最终回复必须给出自检脚本和项目构建/测试命令的退出码。
