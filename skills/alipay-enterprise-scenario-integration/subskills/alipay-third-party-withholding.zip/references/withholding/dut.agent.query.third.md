# dut.agent.query.third（代扣结果查询）

## 接口定位

| 项 | 值 |
| --- | --- |
| 模块 | 代扣 |
| 网关 | `https://mapi.alipay.com/gateway.do` |
| `service` | `dut.agent.query.third` |
| 接入模型 | 旧版 MAPI Query String + MAPI 签名 |
| 返回形态 | XML 同步返回 |

该接口用于查询三方代扣交易结果。代扣链路生成时必须与 `dut.agent.third` 的订单号、交易号和 12306 商户 PID 映射衔接。

## 固定值

| 参数 | 值 | 规则 |
| --- | --- | --- |
| `protocol_code` | `mr_dut_third` | 火车票/12306 场景固定值 |
| `item_code` | `DEFAULT` | 固定值 |

不要使用历史航空票样例中的 `air_dut_third`。

## 请求参数

| 参数 | 含义 | 规则 |
| --- | --- | --- |
| `service` | 接口名称 | 固定为 `dut.agent.query.third` |
| `partner` | ISV/商户 PID | 外层服务商 PID，从配置读取，不得硬编码 |
| `_input_charset` | 请求字符集 | 签名、URL 编码和响应兜底解码必须一致 |
| `sign_type` | 签名类型 | 按商户 MAPI 配置，常见为 `RSA` |
| `sign` | MAPI 签名 | 排除 `sign`、`sign_type`、空值和文件类参数后生成 |
| `protocol_code` | 代扣协议码 | 固定 `mr_dut_third` |
| `item_code` | 代扣项目码 | 固定 `DEFAULT` |
| `out_order_no` | 查询订单号 | 使用当前路由要求的订单标识，必须来自明确业务映射、代扣执行返回或上游入参 |
| `trade_partner` | 原交易商户 PID | 12306 场景取 decoded `submit_param.partner` |
| `trans_account_out` | 客票平台付款方支付宝人民币资金账号 | 必须与代扣执行请求一致 |
| `query_time` | 查询时间 | 格式如 `YYYY-MM-DD HH:mm:ss` |
| `trade_no` | 支付宝交易号 | 可选；有值时优先按它查询 |
| `payer_user_id` | 实际付款人 | 原接通样例未传；只有当前规范或运行时校验要求时才补传 |
| `dut_security_code_sign` | 旧代扣安全码摘要 | 历史 MAPI 字段；除非当前产品路由要求，否则不要臆造 |

历史 MAPI 文档还可能出现 `operator_id`、`operator_name` 等多操作员字段。只有商户账号启用多操作员且当前产品路由要求时才传，不要为了字段齐全而默认生成。

通用规则是使用 `trade_no` 或 `out_order_no + trade_partner` 定位交易；两者都有时 `trade_no` 优先。

## 订单号和商户 PID 映射

`out_order_no` 不一定等于 12306 `submit_param.ord_id_ext`。生成代码必须保存并区分：

| 字段 | 来源 | 用途 |
| --- | --- | --- |
| `ord_id_ext` | decoded `submit_param.ord_id_ext` | 12306 原始订单号，对账和内层参数校验 |
| `trade_partner` | decoded `submit_param.partner` | 代扣查询的原交易商户 PID |
| `out_order_no` | 代扣执行返回、上游业务入参或明确持久化映射 | `dut.agent.query.third` 查询定位 |
| `trade_no` | 代扣执行同步返回或本地持久化映射 | 有值时可优先查询 |
| `out_biz_no` | ISV 本地业务流水 | 本地幂等、对账和调用方追踪 |

如果项目无法确定 `out_order_no` 来源，应把它作为代扣执行返回解析结果、上游业务入参或持久化订单字段补齐；不要用时间戳、UUID 或另一个本地流水号冒充查询订单号。

## 同步 XML 返回

接口返回 XML 同步响应，常见字段包括 `is_success`、`request`、`response`、`trade`、`out_order_no`、`trade_no`、`trade_status`、`protocol_code`、`item_code`、`pay_account_no`、`pay_logon_id`、`receive_account_no`、`receive_logon_id`、`total_fee` 等。

处理建议：

- 先判断 HTTP 状态；非 2xx 按传输失败处理。
- 根据 `Content-Type charset`、XML declaration、`_input_charset` 顺序决定响应字符集。
- 已按响应 charset 解码为字符串后，用字符流解析 XML。
- 先按 MAPI XML 同步响应规则验签；验签失败、缺少 `sign`、XML 解析失败或无法抽取签名参数时，不得更新订单状态（不得置为 `QUERY_FAILED` 或其他失败态），也不得写回 `trade_no/out_order_no` 等响应字段；返回给调用方时也不得把未验签响应里的业务字段原样返回，只能返回失败诊断和本地已可信定位字段。
- 验签通过后，才可按支付宝交易状态更新本地代扣订单状态；更新前还必须比对响应中的订单身份字段（例如 `out_order_no` 或 `trade_no`）、金额、`trans_account_out` 等与本地订单一致，避免串单查询结果覆盖订单。响应里出现且本地可比对的身份字段不能有任何冲突，例如 `out_order_no` 不匹配时不能因为 `trade_no` 匹配就更新；响应里出现且本地可比对的对账字段也不能有任何冲突，例如金额匹配但 `trans_account_out` 不匹配时不能更新。响应缺失关键身份/对账字段、身份冲突或对账冲突时不得更新终态，也不得写回 `trade_no/out_order_no` 等响应字段；返回给调用方时也不得把已验签但未归属当前订单的业务字段原样返回，只能返回不更新诊断和本地已可信定位字段。
- 查询失败时保留错误码和错误文案，不要覆盖已确认的最终成功状态。
- 查询调用失败、MAPI 业务失败、交易处理中和交易最终失败要分开表达；不要把所有非 `TRADE_SUCCESS` 都写成 `QUERY_FAILED`。`is_success=F`、错误码、缺少 `trade_status` 或查询业务失败只说明本次查询没有得到可用于更新交易终态的可信结果，应保持本地原状态并返回 `business_failed`/错误码等诊断；只有 `is_success=T` 且 `trade_status` 明确为 `TRADE_CLOSED`、`TRADE_FAILED`、`PAY_FAILED` 等最终失败/关闭状态，并且身份和对账字段通过校验，才允许置为查询失败态。
- 已确认成功的终态订单，主动查询只能在身份和对账字段匹配后补充对账信息，不能把状态覆盖为查询失败、处理中或未知，也不能在未校验响应身份/对账时写回 `trade_no`。

## 生成要求

- 查询方法必须从本地代扣订单或上游入参读取 `out_order_no`/`trade_no`，不能临时随机生成。
- `trade_partner` 必须来自 decoded `submit_param.partner`，不是外层 `partner`。
- `trans_account_out` 必须与代扣执行请求保持一致。
- `payer_user_id` 不要因为代扣执行必传就强行要求查询接口也传；如当前规范要求补传，应在代码和说明中标明来源。
- 代扣执行返回给调用方时要携带可用于后续查询的 `out_order_no` 或 `trade_no`，避免调用方无法主动查询。
- 主动查询状态机必须保护终态：只有支付宝明确返回最终失败/关闭，且订单身份、金额、资金账号等字段匹配且无冲突时，才允许转为最终失败；查询异常、MAPI 业务失败、处理中响应或缺少关键对账字段不得覆盖原状态，也不得写回或返回响应业务字段污染本地订单/调用方。
- 必须提供独立的代扣主动查询测试，覆盖 XML 验签失败/缺少签名/XML 解析失败时不更新不写回、带 `<request><param name="...">` 的真实 MAPI XML 结构验签、终态保护、身份不匹配/缺失、身份字段混合冲突、金额或资金账号不匹配/缺失、对账字段混合冲突，以及未通过校验时 `trade_no/out_order_no` 不写回且不在返回值中透出响应业务字段。身份/对账未通过时返回值不能是 `updated`；`is_success=F`/MAPI 业务失败时不得把订单置为交易失败态。
