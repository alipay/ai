# alipay.dut.customer.agreement.unsign（协议解约）

## 接口定位

| 项 | 值 |
| --- | --- |
| 模块 | 签约 |
| 网关 | `https://mapi.alipay.com/gateway.do` |
| `service` | `alipay.dut.customer.agreement.unsign` |
| 接入模型 | 旧版 MAPI Query String + MAPI 签名 |
| 返回形态 | 协议类同步响应；解约结果可通过协议查询确认 |

该接口用于取消用户个人代扣协议。三方免密代扣签约链路必须覆盖解约请求构造、本地状态流转和必要的协议查询确认。

## 固定值

| 参数 | 值 | 规则 |
| --- | --- | --- |
| `product_code` | `DUT_AGENT_THIRD_P` | 必传 |
| `scene` | `INDUSTRY|B2B_TICKET_AGENT` | 必传 |
| `format` | `JSON` | 协议类接口优先传入，按实际响应兼容 JSON/XML |

## 请求参数

| 参数 | 含义 | 规则 |
| --- | --- | --- |
| `service` | 接口名称 | 固定为 `alipay.dut.customer.agreement.unsign` |
| `partner` | ISV/商户 PID | 从商户配置读取，不得硬编码 |
| `_input_charset` | 请求字符集 | 签名、URL 编码和响应兜底解码必须一致 |
| `sign_type` | 签名类型 | 按商户 MAPI 配置，常见为 `RSA` |
| `sign` | MAPI 签名 | 排除 `sign`、`sign_type`、空值和文件类参数后生成 |
| `product_code` | 签约产品码 | 固定 `DUT_AGENT_THIRD_P` |
| `scene` | 签约场景 | 固定 `INDUSTRY|B2B_TICKET_AGENT` |
| `agreement_no` | 支付宝协议号 | 优先使用签约成功后保存的协议号 |
| `alipay_user_id` | 用户支付宝 UID | 必传；从本地协议记录读取 |
| `external_user_id` | ISV 侧用户标识 | 有则传入并用于本地对账 |
| `external_sign_no` | 商户签约号 | 可选；如签约时使用，应从本地协议记录读取并同步保留，未使用则不传 |
| `third_party_type` | 用户 ID 类型标识 | 与 `alipay_user_id` 搭配时使用 `PARTNER` |

解约前必须能定位到协议。至少应有 `agreement_no`，或当前产品明确支持的其他定位组合；否则暂停说明缺少协议定位条件。

发起解约前必须 fail fast 校验 `agreement_no`、`alipay_user_id` 非空，并确认它们与本地协议记录匹配；不要只凭一个外部用户号直接拼解约请求。

如果本地协议记录已存在：

- 必须比对本地保存的 `alipay_user_id` 与解约入参一致。
- 如果调用方传入 `external_user_id`，必须比对本地保存的 `external_user_id` 与入参一致；不一致时拒绝解约，避免解约到错误用户协议。
- 组装请求时优先使用本地协议记录里的 `external_user_id`，不要让调用方入参覆盖本地协议身份。只有本地没有该字段、且调用方明确传入时，才可作为补充字段传给 MAPI。
- `external_sign_no` 只有签约时传入并已保存在本地协议记录中才随解约请求复用，必须从本地协议记录读取后条件性加入 MAPI 解约请求；签约未使用时不要在解约阶段随机生成或改为必填。

## `notify_url` 约束

当 `product_code=DUT_AGENT_THIRD_P` 时，协议解约不支持服务端 `notify_url`。

生成代码必须遵守：

- 不给解约接口传 `notify_url`。
- 不生成解约通知入口、解约通知验签或协议通知处理器。
- 解约结果通过同步响应、本地状态流转和/或 `alipay.dut.customer.agreement.query` 确认。

通用协议解约文档中可能出现 `notify_time`、`notify_type=dut_user_unsign`、`notify_id`、`unsign_time` 等解约通知字段。它们只作为历史 MAPI 参考，不适用于 `DUT_AGENT_THIRD_P` 签解约闭环；生成代码不能因此补出解约通知处理器。

## 返回和状态流转

处理建议：

- 通过本地身份校验并完成请求组装后发起 MAPI 解约调用；本地协议状态应在同步调用成功返回、或能确认请求已经成功发出后，再从 `NORMAL` 标记为 `UNSIGNING`，并保留请求流水。
- 如果 MAPI 同步调用抛出 HTTP/网络/读取异常，说明本次解约请求未获得可信受理结果，不要把本地协议永久置为 `UNSIGNING`；若实现上必须先置中间态，必须在同一异常分支内回滚到原可信状态并记录失败原因。
- 同步响应成功时，记录响应内容和解约时间。
- 如同步响应无法确认最终状态，调用协议查询对账。
- 确认协议不可用或已解约后，将本地协议置为 `UNSIGN`。
- 同步响应失败或查询失败时，不要删除协议记录；保留错误码用于重试和人工处理。

## 生成要求

- 签约链路必须提供解约方法，不能只生成签约和查询。
- 发起解约前必须校验 `agreement_no`、`alipay_user_id` 非空，并与本地协议记录一致；如果传入 `external_user_id`，也必须与本地协议记录一致，不能把不一致的 `external_user_id` 透传到解约请求。
- `external_sign_no` 保持可选且跟随本地协议记录；签约未传时解约不得强制要求或临时生成。测试要覆盖本地协议保存了 `external_sign_no` 时解约请求复用该值，未保存时请求不携带。
- 必须提供协议解约单元测试，覆盖 `agreement_no`/`alipay_user_id` 空值拒绝、`alipay_user_id` 与本地不一致拒绝、解约请求使用本地协议记录的 `alipay_user_id`、`external_user_id` 与本地不一致拒绝、`DUT_AGENT_THIRD_P` 下不传 `notify_url`，以及 HTTP/网络异常时本地协议不会被提前污染为 `UNSIGNING`。
- 不生成协议解约服务端通知。
- 解约请求签名前不要提前 URL 编码业务值；签名后再按 Query String 编码。
- 解约逻辑要与本地协议对象衔接，不能只打印日志或生成旁路方法。
