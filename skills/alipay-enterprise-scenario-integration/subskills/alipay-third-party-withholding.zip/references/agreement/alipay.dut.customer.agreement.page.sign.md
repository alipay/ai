# alipay.dut.customer.agreement.page.sign（协议页面签约）

## 接口定位

| 项 | 值 |
| --- | --- |
| 模块 | 签约 |
| 网关 | `https://mapi.alipay.com/gateway.do` |
| `service` | `alipay.dut.customer.agreement.page.sign` |
| 接入模型 | 旧版 MAPI Query String + MAPI 签名 |
| 返回形态 | 页面跳转；页面 `return_url` 只表示用户流程返回，协议状态要主动查询确认 |

该接口用于生成个人代扣协议签约页面。三方免密代扣场景下，生成签约链路时必须同时覆盖协议查询和协议解约。

## 固定值

| 参数 | 值 | 规则 |
| --- | --- | --- |
| `product_code` | `DUT_AGENT_THIRD_P` | 必传 |
| `sales_product_code` | `DUT_AGENT_THIRD_V2` | 必传 |
| `scene` | `INDUSTRY|B2B_TICKET_AGENT` | 必传 |
| `format` | `JSON` | 协议类接口优先传入，按 MAPI 参数参与签名 |

## 请求参数

| 参数 | 含义 | 规则 |
| --- | --- | --- |
| `service` | 接口名称 | 固定为 `alipay.dut.customer.agreement.page.sign` |
| `partner` | ISV/商户 PID | 从商户配置读取，不得硬编码 |
| `_input_charset` | 请求字符集 | 签名转字节、URL 编码和响应兜底解码必须一致 |
| `sign_type` | 签名类型 | 按商户 MAPI 配置，常见为 `RSA` |
| `sign` | MAPI 签名 | 排除 `sign`、`sign_type`、空值和文件类参数后生成 |
| `product_code` | 签约产品码 | 固定 `DUT_AGENT_THIRD_P` |
| `sales_product_code` | 销售产品码 | 固定 `DUT_AGENT_THIRD_V2` |
| `scene` | 签约场景 | 固定 `INDUSTRY|B2B_TICKET_AGENT` |
| `external_user_id` | ISV 侧唯一用户标识 | 稳定、可追踪，按用户生成 |
| `external_sign_no` | 商户签约号 | 可选；如项目已有协议号体系可传入并持久化，未传不得后续臆造或强制要求 |
| `access_info` | 签约接入信息 JSON | 支付宝 App H5：`{"channel":"ALIPAYAPP"}`；PC：`{"channel":"PC"}` |
| `return_url` | 页面同步跳转地址 | 页面承接使用，必须是可访问合法地址；不能作为最终签约状态 |
| `sign_validity_period` | 签约链接有效期 | 可选，接口样例常见 `2m`、`7d` |
| `sub_merchant` | 间连商户展示信息 JSON | 可选，仅产品路由要求时传 |
| `agreement_detail` | 协议细则 JSON | 可选，仅产品路由要求指定支付工具、支付渠道或协议细则时传 |
| `prod_properties` | 签约产品属性 JSON | 可选，仅产品路由要求时传 |
| `zm_auth_info` | 芝麻信用授权信息 JSON | 可选，仅产品路由要求芝麻授权时传 |

生成签约链接前必须 fail fast 校验 `external_user_id`、`return_url`、`access_info.channel` 非空且合法。不能生成空外部用户号的签约链接，也不能把非法 `channel` 静默降级为 PC。`external_sign_no` 不是必填；只有调用方传入时才进入签约请求和本地协议记录，后续查询/解约需要该字段定位时必须复用同一个值。生成代码应提供可选入参或请求 DTO 字段，并在请求参数里条件性加入 `external_sign_no`。

## `notify_url` 约束

当 `product_code=DUT_AGENT_THIRD_P` 时，协议页面签约不支持服务端 `notify_url`。

生成代码必须遵守：

- 不给该接口传 `notify_url`。
- 不生成签约通知入口、签约通知验签或 `AgreementNotifyHandler`。
- 不依赖协议异步通知推动本地状态。
- 页面返回后、支付前或本地协议状态过期时，通过 `alipay.dut.customer.agreement.query` 主动确认协议状态。

原始通用 MAPI 文档中可能包含协议通知章节或历史样例，但该产品码下不适用。

## 钱包 H5 签约启动

当 `access_info.channel=ALIPAYAPP` 或用户场景为支付宝钱包 H5 页面签约时，后端返回给前端的不是裸 MAPI URL，而是钱包 schema：

```text
alipays://platformapi/startapp?appId=20000067&url=<encoded_mapi_sign_url>
```

构造顺序：

1. 先按 MAPI 规则生成完整签约 URL，包含 `service=alipay.dut.customer.agreement.page.sign`、`format=JSON`、签名和已编码的 MAPI Query 参数。
2. 再把整条 MAPI 签约 URL 作为 schema 的 `url` 参数值做一次 URL encode。
3. 拼接 `alipays://platformapi/startapp?appId=20000067&url=` 和编码后的 MAPI URL。

`channel` 必须先 trim 并做大小写归一，只允许 `ALIPAYAPP`、`PC`。非法值直接拒绝；不要静默降级为 PC，也不要因为传入 `alipayapp` 或 `ALIPAYAPP ` 就返回裸 MAPI URL。

## 返回和落库

页面 `return_url` 回跳参数可包含 `agreement_no`、`external_sign_no`、`scene`、`status`、`sign_time`、`sign_modify_time`、`valid_time`、`invalid_time`、`product_code`、`alipay_user_id`、`external_user_id`、`zm_open_id`、`sign_type`、`sign` 等字段。

处理建议：

- 对 `return_url` 参数做 MAPI 验签。
- 持久化 `external_user_id`、`agreement_no`、`alipay_user_id`、`scene`、`product_code`、`status`、`sign_time`、`valid_time`、`invalid_time`；`external_sign_no` 仅在签约请求或可信返回中存在时持久化。
- `return_url` 只表示用户页面完成跳转，不直接把协议写成最终 `NORMAL`。
- 只有协议查询确认 `status=NORMAL` 且 `product_code=DUT_AGENT_THIRD_P`、`scene=INDUSTRY|B2B_TICKET_AGENT` 匹配时，才能把本地协议置为 `NORMAL`。

## 生成要求

- 签约链路必须提供 ALIPAYAPP 与 PC 两种链接构造分支。
- ALIPAYAPP 分支必须返回钱包 schema，schema 的 `url` 参数是整条 MAPI URL 的 encode 结果。
- 发起签约前必须校验 `external_user_id`、`return_url` 非空；缺失时直接拒绝，不落库为可签约状态。
- `external_sign_no` 保持可选；传入时必须进入签约请求、持久化到本地协议对象并后续一致复用，未传时不能随机生成、不能作为必填拦截。测试要分别覆盖未传时请求不含该字段、传入时请求包含并落库。
- 签约请求签名前不要提前 URL 编码业务值；签名后再按 Query String 编码。
- 不生成协议签约通知处理器。
- 对 `return_url` 域名可访问性、特殊字符、本机地址等风险给出接入提示。
