# alipay.dut.customer.agreement.query（协议查询）

## 接口定位

| 项 | 值 |
| --- | --- |
| 模块 | 签约 |
| 网关 | `https://mapi.alipay.com/gateway.do` |
| `service` | `alipay.dut.customer.agreement.query` |
| 接入模型 | 旧版 MAPI Query String + MAPI 签名 |
| 返回形态 | 协议类同步响应，按实际 JSON/XML 解析 |

该接口用于查询个人代扣协议状态。由于 `DUT_AGENT_THIRD_P` 签约和解约不支持服务端 `notify_url`，该接口是协议状态闭环的主要后端确认手段。

## 固定值

| 参数 | 值 | 规则 |
| --- | --- | --- |
| `product_code` | `DUT_AGENT_THIRD_P` | 必传 |
| `scene` | `INDUSTRY|B2B_TICKET_AGENT` | 使用 `external_sign_no` 或场景约束时必须传 |
| `format` | `JSON` | 协议类接口优先传入，按实际响应兼容 JSON/XML |

## 请求参数

| 参数 | 含义 | 规则 |
| --- | --- | --- |
| `service` | 接口名称 | 固定为 `alipay.dut.customer.agreement.query` |
| `partner` | ISV/商户 PID | 从商户配置读取，不得硬编码 |
| `_input_charset` | 请求字符集 | 签名、URL 编码和响应兜底解码必须一致 |
| `sign_type` | 签名类型 | 按商户 MAPI 配置，常见为 `RSA` |
| `sign` | MAPI 签名 | 排除 `sign`、`sign_type`、空值和文件类参数后生成 |
| `product_code` | 签约产品码 | 固定 `DUT_AGENT_THIRD_P` |
| `scene` | 签约场景 | 固定 `INDUSTRY|B2B_TICKET_AGENT` |
| `alipay_user_id` | 用户支付宝 UID | 常用定位条件；接通样例使用该字段 |
| `alipay_logon_id` | 用户支付宝登录号 | 可选定位条件；与 `alipay_user_id` 至少有一个定位字段，二者都传时以 `alipay_user_id` 为准 |
| `third_party_type` | 用户 ID 类型标识 | 与 `alipay_user_id` 搭配时使用 `PARTNER` |
| `external_sign_no` | 商户签约号 | 可选/条件参数；仅签约时使用过或本地已保存时传入，传入时不要省略 `scene` |
| `agreement_no` | 支付宝协议号 | 如本地已保存，可作为定位条件使用 |
| `app_id` | 公众平台 appId | 当 `alipay_user_id` 实际为 openId 时，与 openId 共同定位用户；普通支付宝 UID 场景不传 |

查询入参应按项目可获得字段组合构造。不要强制所有项目都必须传 `external_user_id`；原始协议查询文档和接通样例均可通过 `alipay_user_id` 等字段定位。`external_sign_no` 可省略；如果签约时传入并保存，查询需要该字段定位时必须从本地协议记录复用同一个值并进入 MAPI 查询请求，未传时不得随机生成或强制要求。测试应捕获实际查询请求，覆盖本地保存了 `external_sign_no` 时请求条件性携带，未保存时请求不携带。

如果服务商只能拿到签约员工 openid，可用 openid 作为查询入参中的用户定位值，并同时传 `app_id`。此时不要把 openid 当成后续代扣执行或主动查询的 `payer_user_id`；必须在协议查询响应验签、`is_success=T` 和身份字段校验通过后，读取返回明细里的 `principal_id`，把它作为该员工的支付宝 UID 持久化到本地协议记录的 `alipay_user_id` 字段或等价字段中。后续代扣执行和主动查询使用的 `payer_user_id` 都必须取这个可信支付宝 UID。若 openid 查询响应缺少 `principal_id`，不能把协议确认成可代扣状态。

## 调用时机

- 签约页面 `return_url` 返回后，主动确认协议状态。
- 发起代扣前，确认用户协议仍有效。
- 本地协议状态过期或不可信时，刷新协议状态。
- 发起解约后，按需对账确认协议是否已解约。

## 返回处理

返回字段通常包含 `is_success`、`error`、`sign_type`、`sign` 以及协议明细，例如 `agreement_no`、`alipay_user_id`、`principal_id`、`principal_type`、`product_code`、`scene`、`thirdpart_id`、`thirdpart_type`、`status`、`sign_time`、`sign_modify_time`、`valid_time`、`invalid_time`、`external_sign_no`、`external_user_id`、`agreement_detail`、`zm_open_id` 等。

处理建议：

- 先校验 HTTP 状态和响应字符集，再按 JSON/XML 解析。
- 对同步响应做 MAPI 验签；验签失败时不得更新本地协议状态。请求优先传 `format=JSON`，但生成代码仍必须兼容 XML 同步响应：JSON 解析失败或响应以 `<alipay>` 开头时，切换到 XML 解析和 XML 响应验签；JSON 响应解析不能只遍历顶层字段，必须兼容业务响应节点嵌套，例如 `response`、`alipay_dut_customer_agreement_query_response`、`customer_agreement_query_response` 等节点下的字段，并从业务节点抽取用于验签和状态确认的字段；XML 验签必须使用独立的 MAPI XML 验签参数抽取方法，忽略 `request/param` 回显节点，只抽取 `response` 下协议业务节点的直接子节点，不能把递归扁平化的 `xmlParser.parse(...)` 结果直接传给 `verify`，也不要把 XML 响应当作解析失败后直接结束。
- 必须检查 `is_success=T` 后才读取协议明细；`is_success=F` 或缺失时保留错误码/错误文案并返回查询失败。
- 解析失败、HTTP/传输失败、验签失败或 `is_success` 非 T 都属于“本次无法确认协议状态”，不得覆盖已有本地可信协议状态为 `FAILED` 或未签约；应记录查询失败原因并保持原状态。只有已验签响应明确证明协议不可用，且身份字段匹配时，才允许更新为失效/失败状态。
- 查询请求用 `alipay_user_id` 定位支付宝协议；本地协议记录通常由签约请求里的 `external_user_id` 建索引。确认查询结果落库时要显式传入并使用 `external_user_id` 更新原本的 `SIGNING` 记录，不要把 `alipay_user_id` 当作 `external_user_id` 查库。
- 必须比对返回的 `alipay_user_id` 与请求/本地记录一致；不一致时按串单风险拒绝确认。
- 如果本次使用 openid + `app_id` 查询，返回的 `alipay_user_id` 可能不等于请求 openid；此时应把 `principal_id` 作为协议主体支付宝 UID 校验和落库，不要拿请求 openid 与支付宝 UID 做等值比较。
- 如本地已有 `agreement_no`，必须比对返回值一致；如本地尚无 `agreement_no`，只能在本次验签、`is_success`、`status/product_code/scene/alipay_user_id` 全部通过后持久化返回的 `agreement_no`。
- 只有 `status=NORMAL` 且 `product_code=DUT_AGENT_THIRD_P`、`scene=INDUSTRY|B2B_TICKET_AGENT` 匹配时，才允许本地协议进入可代扣状态。
- 查询失败时保留明确错误码和错误文案，不要把未知响应当作未签约。
- `agreement_detail`、支付渠道细则、芝麻字段等作为扩展信息保存或透传，不要作为判断协议可代扣的唯一依据。

## 生成要求

- 签约链路必须提供协议查询方法，并在签约返回、支付前和解约后流程中可复用；如果生成 Controller/API，对外入口必须调用确认落库逻辑或提供独立确认入口，不能只把原始 MAPI 查询响应透出。
- 查询接口不生成服务端通知入口。
- `third_party_type=PARTNER` 与 `alipay_user_id` 的搭配应作为三方免密代扣默认实现。
- 协议确认方法不要只接收 `alipay_user_id` 一个参数；必须显式携带本地 `external_user_id` 和支付宝 `alipay_user_id`，并在已有协议时携带或读取本地 `agreement_no` 做一致性校验；本地协议保存了 `external_sign_no` 时，查询请求也要复用该值。
- 调用前必须 fail fast 校验 `alipay_user_id` 非空；如果用于更新本地记录，也必须校验 `external_user_id` 非空。
- 如果生成 openid 查询路径，协议确认方法必须显式区分 `employee_open_id` 和最终支付宝 UID：请求可用 openid + `app_id` 定位，落库、代扣执行和主动查询只能使用已验签响应中的 `principal_id` 作为 `alipay_user_id`/`payer_user_id` 来源。
- 测试必须覆盖解析失败、验签失败、`is_success=F` 时不覆盖已有 `NORMAL/SIGNING/UNSIGNING` 等可信状态。
- 测试必须覆盖 JSON 业务响应节点嵌套路径：例如协议字段位于 `response` 或 `alipay_dut_customer_agreement_query_response` 下时，仍可完成验签、`is_success`、`status/product_code/scene/alipay_user_id` 校验和落库；不能只覆盖扁平 JSON。
- 测试必须覆盖 XML 同步响应兼容路径：XML 验签通过且 `is_success=T/status=NORMAL/product_code/scene/alipay_user_id` 匹配时可确认协议；XML 验签失败、缺少签名或字段不匹配时不得落库为可代扣状态。协议查询测试文件自身必须覆盖带 `<request><param name="...">` 和 `<response>...协议业务节点...</response>` 的 MAPI 结构，避免请求回显节点参与验签；不能只用扁平 `<alipay><field>...`，也不能只靠代扣执行/查询测试间接覆盖。
- 如果项目无法获得 `alipay_user_id`、`agreement_no` 或已保存的 `external_sign_no` 中任何定位字段，应暂停说明缺少协议定位条件；不得为了满足定位字段而臆造 `external_sign_no`。
- 测试必须覆盖本地协议有 `external_sign_no` 时查询请求携带该字段、本地协议无该字段时查询请求不携带。
- 如果支持 openid 查询路径，测试必须覆盖：请求携带 openid 和 `app_id`；可信响应里的 `principal_id` 被保存为本地协议 `alipay_user_id`；后续代扣执行和主动查询使用该 UID 作为 `payer_user_id`；响应缺少 `principal_id` 时不得确认协议为 `NORMAL`。
