---
name: alipay-third-party-withholding
description: >-
  支付宝三方免密代扣集成专用 Skill。当用户提到"三方免密代扣"、"第三方免密代扣"、
  "火车票免密代扣"、"火车票票代代扣"、"12306 代理购票"、"火车票代扣接通样例"、
  "代扣协议签约"、"代扣协议查询"、"代扣协议解约"、"第三方代扣执行"、
  "代扣结果查询"、"submit_param"、"DUT_AGENT_THIRD_P"、
  "DUT_AGENT_THIRD_V2"、"mr_dut_third"、"enterprisePay"、"mapi.alipay.com"、
  "dut.agent.third"、"dut.agent.query.third" 等相关关键词时必须使用此 Skill。
  帮助服务商接入或排查支付宝 MAPI 三方免密代扣链路，当前覆盖火车票/12306 代理购票场景。
---

# 支付宝三方免密代扣集成 Skill

## 重要提示

支持两种使用方式：由方案型 Skill 调用时沿用上游已确定的免密代扣启用状态、接口范围和允许写入范围；独立使用时按本文档完成必要决策。

生成方案或代码时：

1. 先确定是否接入三方免密代扣、接口清单、签名方式、状态确认方式和 SDK/HTTP 接入方式。
2. 三方免密代扣不做拆分选择；一旦接入，必须覆盖签约 + 代扣完整五个接口和该产品实际支持的状态确认方式；不得只生成签约或代扣半链路。
3. 生成前读取 [三方免密代扣流程](references/third-party-withholding-flow.md)、[接口文档索引](references/api-contract.md)、[核心领域约束](references/core-constraints.md)、[通用代码生成规则](references/codegen-general-rules.md) 和 [字段与接口规则](references/field-interface-rules.md)；随后按完整链路逐个读取对应接口文档。
4. 按完整链路分段读取、分段生成、分段校验；不得把签约和代扣拆成可选范围让用户选择。
5. 这是旧版 MAPI 网关接入：使用 `service`、`partner`、Query String 和 MAPI `sign`；不得按 OpenAPI `method/app_id/biz_content` 模型生成。
6. 文档中找不到的字段、接口、通知或 SDK 能力，必须说明未找到，不能猜测生成。
7. 协议查询和协议解约的用户身份字段为 `alipay_user_id`。
8. 已有项目只做增量改造：第一轮只输出现有 MAPI/支付宝 SDK、签名工具、回调入口、目录结构、已有协议/订单 Entity/Service/Repository/Controller、已实现接口、业务衔接点和拟新增/修改文件清单，并按 [已有项目衔接契约](references/integration-contract.md) 给出拟定契约；无法推断协议或代扣订单如何衔接已有业务对象时暂停确认。
9. 代码生成环境必须运行本域自检脚本；Java/Maven、Node.js、Python、Go 和 .NET 项目还应执行对应技术栈的构建、测试和语法检查。
10. 只有本域官方自检脚本退出码为 `0`，才能声明三方免密代扣代码生成完成。不得用自写 checklist、报告表格、模型总结或生成工程里的 `scripts/*validate*.js` 替代本域官方自检脚本。

由主方案 Skill 调用时，必须遵守主方案阶段闸门；未进入三方免密代扣阶段前，不得读取本 Skill 的接口细节文档。

由多 Agent 主方案调用时：

1. 第一轮必须输出 `已加载 Skill: alipay-third-party-withholding (<SKILL.md 路径>)`，并列出沿用的上游免密代扣启用状态、接口范围和允许写入范围。
2. 只处理三方免密代扣代码和相关文档，不读取其他子 Skill。
3. 只生成或修改本域写入范围，例如 `src/main/java/**/withholding/**`、`src/main/java/**/mapi/**` 或用户指定目录。
4. 不修改公共构建文件、全局配置、`README.md`、启动入口或跨域消息聚合配置；已有项目中如需这些改动，只在回执中提出需求。
5. 输出本域已读文档、生成文件、接口/回调覆盖、本域自检结果和未覆盖边界。
6. 本域自检失败时先修正本域代码，不要求其他 Agent 兜底。
7. 回执必须给出本域官方自检脚本的原始命令、退出码和最后几行输出；退出码非 `0` 时不得写 `COMPLETED`、`生成完成`、`通过` 或同义结论。

---

## 步骤 1：确定模式

三方免密代扣只有一个模式：

| 模式 | 说明 | 接口范围 | 约束 |
|------|------|------|------|
| 免密代扣 | 用户先完成代扣协议授权，服务商在 12306 代理购票场景基于协议发起代扣 | 签约 + 代扣完整五接口 | 旧版 MAPI 网关；使用 `service`、`partner`、Query String 和 MAPI `sign` |

**决策规则**：

- 方案型 Skill 调用：如果上游方案已确定启用免密代扣，直接沿用，不要重复询问用户。
- 独立使用：模式默认且只能为“免密代扣”，不要把签约和代扣当成两个模式或两个可选范围让用户选择。
- 独立使用：只要用户要求接入三方免密代扣、火车票免密代扣、代扣协议、代扣执行、代扣结果查询或 `submit_param`，都必须按完整签约 + 代扣链路处理，共五个接口。
- 已有项目：如果上下文可推断项目已有签约、代扣或回调能力，只做增量补齐；无法推断业务衔接对象时暂停确认。

**链路完整性**：

| 链路 | 接口 | 必要回调 | 完整性要求 |
|------|------|----------|------------|
| 签约 | `alipay.dut.customer.agreement.page.sign`、`alipay.dut.customer.agreement.query`、`alipay.dut.customer.agreement.unsign` | 无协议服务端通知；页面流程需要 `return_url` 处理建议，状态用协议查询确认 | 覆盖签约请求构造、钱包 H5/PC 跳转、协议查询刷新、解约请求构造、协议状态落库；不得生成签约/解约 `notify_url` 或通知处理器 |
| 代扣 | `dut.agent.third`、`dut.agent.query.third` | 无接入方服务端通知；代扣结果通知面向商户侧 | 覆盖 `submit_param` 构造和内层字段校验、外层 MAPI 签名、同步 XML 解析、主动查询、`payer_user_id/out_order_no/trade_partner/ord_id_ext` 来源和映射；不得生成接入方代扣通知 handler 或外层代扣 `notify_url` |

---

## 步骤 2：接入流程

代码生成时先读取公共文档，再读取完整签约 + 代扣链路的接口文档和技术栈质量门禁；不要把签约和代扣拆成可选范围。

| 文档 | 读取时机 |
|------|----------|
| [三方免密代扣流程](references/third-party-withholding-flow.md) | 必读，理解完整签约 + 代扣链路和读取顺序 |
| [接口文档索引](references/api-contract.md) | 必读，确定五个接口的模块归属和读取边界 |
| [核心领域约束](references/core-constraints.md) | 必读，红线索引；细节以通用规则、字段规则和接口文档为准 |
| [通用代码生成规则](references/codegen-general-rules.md) | 必读，MAPI 签名、URL 编码、请求构造和响应处理 |
| [字段与接口规则](references/field-interface-rules.md) | 必读，固定常量、字段来源、接口覆盖和常见错误 |
| [已有项目衔接契约](references/integration-contract.md) | 已有项目增量改造时读取 |

接口文档必须完整读取：

| 链路 | 接口文档 |
|------|----------|
| 签约 | [协议页面签约](references/agreement/alipay.dut.customer.agreement.page.sign.md)、[协议查询](references/agreement/alipay.dut.customer.agreement.query.md)、[协议解约](references/agreement/alipay.dut.customer.agreement.unsign.md) |
| 代扣 | [第三方代扣执行](references/withholding/dut.agent.third.md)、[代扣结果查询](references/withholding/dut.agent.query.third.md) |

质量门禁按技术栈读取：

| 技术栈 | 文档 |
|--------|------|
| Java/Maven | [Java/Maven 质量门禁](references/quality-gates/java-maven.md) |
| Node.js | [Node.js 质量门禁](references/quality-gates/nodejs.md) |
| Python/Go/.NET | [Python/Go/.NET 质量门禁](references/quality-gates/python-go-dotnet.md) |

---

## 生成后校验

本 Skill 自带本域自检脚本，由 Skill/生成环境执行：

```bash
node alipay-third-party-withholding/scripts/validate_codegen.js <生成项目目录>
```

脚本会静态扫描生成项目，校验 MAPI 模型、接口覆盖、通知边界、签约/解约约束、`submit_param` 白名单和幂等、协议门禁、XML/JSON 响应验签与状态写回、主动查询对账、HTTP 字符集和流处理、技术栈质量门禁等规则，并检查是否误用 OpenAPI `biz_content` 或旧航空票 `air_dut_third`。

退出码 `0` 表示通过，`1` 表示生成代码不符合门禁，`2` 表示 validator 自身执行不可信。

必须执行上面的本域官方自检脚本，不能用自写脚本、手写 checklist、报告表格、`scripts/*validate*.js` 或模型总结替代。最终回复必须列出原始命令、退出码和最后几行输出；退出码不是 `0` 时不得写 `COMPLETED`、`生成完成`、`通过` 或同义结论。
