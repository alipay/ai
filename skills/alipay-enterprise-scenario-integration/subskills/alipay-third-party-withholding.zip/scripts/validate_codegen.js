#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const javaProjectGates = require("./lib/java-project-gates");

const root = process.argv[2];
if (!root) {
  console.error("用法：node alipay-third-party-withholding/scripts/validate_codegen.js <生成项目目录>");
  process.exit(2);
}

const projectDir = path.resolve(root);
if (!fs.existsSync(projectDir) || !fs.statSync(projectDir).isDirectory()) {
  console.error(`未找到生成项目目录：${projectDir}`);
  process.exit(2);
}

const SKIP_DIRS = new Set([
  ".git",
  "node_modules",
  "target",
  "build",
  "dist",
  ".gradle",
  ".idea",
  ".vscode",
  "__pycache__",
]);

const TEXT_EXTS = new Set([
  ".java",
  ".kt",
  ".js",
  ".ts",
  ".jsx",
  ".tsx",
  ".py",
  ".go",
  ".cs",
  ".php",
  ".rb",
  ".xml",
  ".yml",
  ".yaml",
  ".json",
  ".properties",
  ".md",
  ".txt",
]);

const CODE_EXTS = new Set([
  ".java",
  ".kt",
  ".js",
  ".ts",
  ".jsx",
  ".tsx",
  ".py",
  ".go",
  ".cs",
  ".php",
  ".rb",
  ".xml",
  ".yml",
  ".yaml",
  ".json",
  ".properties",
]);

function walk(dir, files = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (SKIP_DIRS.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walk(full, files);
    } else if (entry.isFile() && TEXT_EXTS.has(path.extname(entry.name))) {
      files.push(full);
    }
  }
  return files;
}

function readAll(files) {
  return files.map((file) => {
    try {
      return fs.readFileSync(file, "utf8");
    } catch (_) {
      return "";
    }
  }).join("\n");
}

function hasAny(text, patterns) {
  return patterns.some((pattern) => pattern.test(text));
}

function firstIndexOfAny(value, patterns) {
  const indexes = patterns
    .map((pattern) => value.search(pattern))
    .filter((index) => index >= 0);
  return indexes.length ? Math.min(...indexes) : -1;
}

function extractNamedFunctionBlock(value, names) {
  for (const name of names) {
    const match = new RegExp(`\\b${name}\\s*\\(`).exec(value);
    if (!match) continue;
    const open = value.indexOf("{", match.index);
    if (open < 0) continue;
    let depth = 0;
    let quote = null;
    let escaped = false;
    for (let index = open; index < value.length; index += 1) {
      const char = value[index];
      if (quote) {
        if (escaped) {
          escaped = false;
        } else if (char === "\\") {
          escaped = true;
        } else if (char === quote) {
          quote = null;
        }
        continue;
      }
      if (char === "\"" || char === "'" || char === "`") {
        quote = char;
        continue;
      }
      if (char === "{") depth += 1;
      if (char === "}") {
        depth -= 1;
        if (depth === 0) return value.slice(match.index, index + 1);
      }
    }
  }
  return "";
}

function hasRequiredFieldCheck(value, fieldAlternation) {
  const requiredWords = "requireText|requireNonBlank|requireNonEmpty|notBlank|required|validateRequired|assertNotBlank|hasText|isNotBlank";
  const emptyWords = "isBlank|isEmpty|trim\\(\\)|length\\s*[=!<>]=?\\s*0|len\\(|hasText|isBlank|null|undefined|空|缺少";
  return new RegExp(
    `(?:${requiredWords})[^;\\n]{0,220}(?:${fieldAlternation})|(?:${fieldAlternation})[^;\\n]{0,280}(?:${emptyWords})`,
    "i",
  ).test(value);
}

function hasMissingFieldFailure(value, fieldAlternation) {
  const requiredWords = "requireText|requireNonBlank|requireNonEmpty|notBlank|required|validateRequired|assertNotBlank|hasText|isNotBlank";
  const emptyWords = "==\\s*null|===\\s*null|\\|\\|[^;\\n]{0,120}isEmpty\\(\\)|\\|\\|[^;\\n]{0,120}isBlank\\(\\)|trim\\(\\)\\.isEmpty\\(\\)|!\\s*.*hasText|length\\s*(?:==|===|<=)\\s*0|len\\([^)]*\\)\\s*(?:==|<=)\\s*0|缺少|为空|空白";
  return new RegExp(
    `(?:${requiredWords})[^;\\n]{0,240}(?:${fieldAlternation})|(?:${fieldAlternation})[\\s\\S]{0,260}(?:${emptyWords})[\\s\\S]{0,260}(?:return\\s+["']fail["']|throw|异常|reject|拒绝|失败)`,
    "i",
  ).test(value);
}

function hasThrowingMissingFieldValidation(value, fieldAlternation) {
  const requiredWords = "requireText|requireNonBlank|requireNonEmpty|notBlank|required|validateRequired|assertNotBlank|hasText|isNotBlank";
  return new RegExp(
    `(?:${requiredWords})\\s*\\([^;\\n]{0,260}(?:${fieldAlternation})|throw\\s+new\\s+[A-Za-z0-9_.]*(?:Exception|Error)[^;\\n]{0,260}(?:${fieldAlternation}|缺少|缺失|为空|空白)`,
    "i",
  ).test(value);
}

function hasMissingFieldThrowAssertion(value, fieldAlternation) {
  const field = `(?:${fieldAlternation})`;
  const missing = `(?:(?:missing|misses|without|缺少|缺失)[\\s\\S]{0,220}${field}|${field}[\\s\\S]{0,220}(?:missing|misses|without|缺少|缺失))`;
  return new RegExp(
    `${missing}[\\s\\S]{0,760}(?:assertThrows|toThrow|rejects\\.toThrow|pytest\\.raises|assertRaises|Assert\\.Throws)`,
    "i",
  ).test(value);
}

function hasUnsignFailFastTest(value, fieldAlternation) {
  const field = `(?:${fieldAlternation})`;
  const legacyThrowingShape = new RegExp(
    `${field}[\\s\\S]{0,360}(?:null|empty|blank|空|缺少|缺失)[\\s\\S]{0,520}(?:assertThrows|toThrow|rejects\\.toThrow|IllegalArgumentException|ValidationException)`,
    "i",
  );
  const resultCode = /agreementNo|agreement_no/.test(fieldAlternation)
    ? "MISSING_AGREEMENT_NO"
    : "MISSING_ALIPAY_USER_ID";
  const resultShape = new RegExp(
    `(?:missing|blank|empty|缺少|缺失|空白)[A-Za-z0-9_]*${field}|${field}[\\s\\S]{0,420}(?:null|empty|blank|\\\"\\s*\\\"|\\\"\\s+\\\"|空|缺少|缺失)[\\s\\S]{0,760}(?:assertFalse\\s*\\([^)]*isSuccess\\s*\\(|${resultCode})`,
    "i",
  );
  return legacyThrowingShape.test(value) || resultShape.test(value);
}

function hasUnsignMismatchRejectTest(value, fieldAlternation) {
  const field = `(?:${fieldAlternation})`;
  const legacyThrowingShape = new RegExp(
    `${field}[\\s\\S]{0,520}(?:mismatch|different|wrong|other|不一致|错误|其他)[\\s\\S]{0,620}(?:assertThrows|toThrow|rejects\\.toThrow|IllegalStateException|ValidationException|拒绝|失败)`,
    "i",
  );
  const resultCode = /externalUserId|external_user_id/.test(fieldAlternation)
    ? "EXTERNAL_USER_ID_MISMATCH"
    : "IDENTITY_MISMATCH";
  const resultShape = new RegExp(
    `${field}[\\s\\S]{0,720}(?:mismatch|different|wrong|other|不一致|错误|其他|different UID)[\\s\\S]{0,900}(?:assertFalse\\s*\\([^)]*isSuccess\\s*\\(|${resultCode})`,
    "i",
  );
  return legacyThrowingShape.test(value) || resultShape.test(value);
}

function hasGuardedQueryResponseFieldWrite(value) {
  const setter = "order\\.set(?:TradeNo|OutOrderNo|TransAccountOut|Amount)\\s*\\([^;]*(?:parsed|result|response|resp)\\.get\\s*\\(\\s*[\"'](?:trade_no|tradeNo|out_order_no|outOrderNo|trans_account_out|transAccountOut|total_fee|totalFee|amount|ord_amt|ordAmt)[\"']";
  const identityWord = "orderIdentityMatched|identityMatched|sameOrder|matchesLocalOrder|订单身份|身份";
  const reconcileWord = "reconciled|isReconciled|accountMatched|amountMatched|对账|金额|资金账号";
  const guardedBlock = new RegExp(
    `if\\s*\\([^)]*(?:${identityWord})[^)]*(?:${reconcileWord})[^)]*\\)\\s*\\{[\\s\\S]{0,900}${setter}`,
    "i",
  );
  const earlyReject = new RegExp(
    `if\\s*\\([^)]*(?:!\\s*(?:${identityWord})|(?:${identityWord})\\s*==\\s*false|(?:${identityWord})\\s*===\\s*false)[^)]*(?:\\|\\||or)[^)]*(?:!\\s*(?:${reconcileWord})|(?:${reconcileWord})\\s*==\\s*false|(?:${reconcileWord})\\s*===\\s*false)[^)]*\\)\\s*\\{[\\s\\S]{0,360}(?:return|throw|continue)[\\s\\S]{0,900}${setter}`,
    "i",
  );
  return guardedBlock.test(value) || earlyReject.test(value);
}

function stripComments(value) {
  return value
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/\/\/.*$/gm, "");
}

function isCodeLikeFile(file) {
  return CODE_EXTS.has(path.extname(file));
}

const files = walk(projectDir);
const text = readAll(files);
function relativePath(file) {
  return path.relative(projectDir, file).split(path.sep).join("/");
}

function isTestFile(file) {
  const relative = relativePath(file);
  return /^src\/test\//i.test(relative)
    || /^tests?\//i.test(relative)
    || /(^|\/)__tests__\//i.test(relative)
    || /(^|\/)[^/]*(Test|Spec)\.[A-Za-z0-9]+$/i.test(relative)
    || /\.(test|spec)\.[A-Za-z0-9]+$/i.test(relative);
}

const testFiles = files.filter(isTestFile);
const sourceFiles = files.filter((file) => !isTestFile(file));
const sourceCodeFiles = sourceFiles.filter(isCodeLikeFile);
const javaFiles = files.filter((file) => path.extname(file) === ".java");
const sourceText = readAll(sourceFiles);
const sourceCodeText = readAll(sourceCodeFiles);
const testText = readAll(testFiles);
const mapiHttpClientFiles = sourceFiles.filter((file) => {
  const relative = relativePath(file);
  const body = fs.readFileSync(file, "utf8");
  return /MApiHttp|MapiHttp|HttpClient|HttpService|http-client/i.test(relative)
    || /HttpURLConnection|URLConnection|OkHttpClient|HttpClient|RestTemplate|fetch\(|axios|requests\.|http\.Client|httpclient|curl|urlopen|getResponseCode|statusCode|response\.status/i.test(body);
});
const mapiHttpClientText = readAll(mapiHttpClientFiles);
const mapiHttpClientTestFiles = testFiles.filter((file) => {
  const relative = relativePath(file);
  const basename = path.basename(file);
  const body = fs.readFileSync(file, "utf8");
  return /MApiHttp|MapiHttp|HttpClient|HttpService|http-client/i.test(relative)
    || /MApiHttp|MapiHttp|HttpClient|HttpService/i.test(basename)
    || /(?:MApiHttpClient|MApiTransportException|detectCharsetFromBody|readResponseBody|doGet\s*\()[\s\S]{0,1600}(?:GBK|encoding|charset|中文|read.*fail|body.*empty|transport|IOException|Throwing|Failing)/i.test(body);
});
const mapiHttpClientTestText = readAll(mapiHttpClientTestFiles);
const agreementSourceFiles = sourceFiles.filter((file) => {
  const relative = relativePath(file);
  const body = fs.readFileSync(file, "utf8");
  return /agreement|Agreement|协议/i.test(relative)
    || /alipay\.dut\.customer\.agreement|SERVICE_AGREEMENT/i.test(body);
});
const agreementSourceText = readAll(agreementSourceFiles);
const agreementSignSourceFiles = agreementSourceFiles.filter((file) => {
  const relative = relativePath(file);
  const body = fs.readFileSync(file, "utf8");
  return /AgreementSign|PageSign|page\.sign|协议页面签约|签约服务/i.test(relative)
    || /alipay\.dut\.customer\.agreement\.page\.sign|AgreementSign|pageSign/i.test(body);
});
const agreementSignSourceText = readAll(agreementSignSourceFiles);
const agreementQuerySourceFiles = agreementSourceFiles.filter((file) => {
  const relative = relativePath(file);
  const body = fs.readFileSync(file, "utf8");
  return /Query|query|协议查询/i.test(relative)
    || /alipay\.dut\.customer\.agreement\.query|confirmAgreementByQuery|AgreementQuery/i.test(body);
});
const agreementQuerySourceText = readAll(agreementQuerySourceFiles);
const agreementQueryRequestSourceFiles = agreementQuerySourceFiles.filter((file) => {
  const relative = relativePath(file);
  const basename = path.basename(file);
  const body = fs.readFileSync(file, "utf8");
  return /Query|query|协议查询/i.test(relative)
    || /Query|query|协议查询/i.test(basename)
    || /alipay\.dut\.customer\.agreement\.query|confirmAgreementByQuery|queryAgreement/i.test(body);
});
const agreementQueryRequestSourceText = readAll(agreementQueryRequestSourceFiles);
const agreementQueryTestFiles = testFiles.filter((file) => {
  const relative = relativePath(file);
  const basename = path.basename(file);
  const body = fs.readFileSync(file, "utf8");
  return /AgreementQuery|agreement.*query|协议查询/i.test(relative)
    || /AgreementQuery|agreement.*query|协议查询/i.test(basename)
    || /alipay\.dut\.customer\.agreement\.query|confirmAgreementByQuery|AgreementQuery/i.test(body);
});
const agreementQueryTestText = readAll(agreementQueryTestFiles);
const agreementUnsignSourceFiles = agreementSourceFiles.filter((file) => {
  const relative = relativePath(file);
  const body = fs.readFileSync(file, "utf8");
  return /Unsign|unsign|解约/i.test(relative)
    || /alipay\.dut\.customer\.agreement\.unsign|AgreementUnsign/i.test(body);
});
const agreementUnsignSourceText = readAll(agreementUnsignSourceFiles);
const agreementUnsignTestFiles = testFiles.filter((file) => {
  const relative = relativePath(file);
  const basename = path.basename(file);
  const body = fs.readFileSync(file, "utf8");
  return /Unsign|unsign|解约/i.test(relative)
    || /Unsign|unsign|解约/i.test(basename)
    || /alipay\.dut\.customer\.agreement\.unsign|AgreementUnsign/i.test(body);
});
const agreementUnsignTestText = readAll(agreementUnsignTestFiles);
const withholdQuerySourceFiles = sourceFiles.filter((file) => {
  const relative = relativePath(file);
  const basename = path.basename(file);
  const body = fs.readFileSync(file, "utf8");
  return /dut\.agent\.query\.third/i.test(relative)
    || /TrainTicketWithholdingQuery|WithholdingQuery|WithholdQuery|withhold.*query/i.test(basename)
    || /dut\.agent\.query\.third|queryWithhold|queryThird/i.test(body);
});
const withholdQuerySourceText = readAll(withholdQuerySourceFiles);
const withholdQueryHandlerSourceFiles = withholdQuerySourceFiles.filter((file) => {
  const basename = path.basename(file);
  const body = fs.readFileSync(file, "utf8");
  if (!/Query|query/i.test(basename)
    && /dut\.agent\.third|SERVICE_DUT_AGENT_THIRD|submit_param|submitParam/i.test(body)) {
    return false;
  }
  return /TrainTicketWithholdingQuery|WithholdingQuery|WithholdQuery|withhold.*query/i.test(basename)
    || (/dut\.agent\.query\.third|queryWithhold|queryThird/i.test(body)
      && /setStatus\s*\(|saveOrder|update.*Order|订单状态|trade_status/i.test(body));
});
const withholdQueryHandlerSourceText = readAll(withholdQueryHandlerSourceFiles);
const withholdQueryTestFiles = testFiles.filter((file) => {
  const relative = relativePath(file);
  const basename = path.basename(file);
  const body = fs.readFileSync(file, "utf8");
  return /dut\.agent\.query\.third/i.test(relative)
    || /TrainTicketWithholdingQuery|WithholdingQuery|WithholdQuery|withhold.*query/i.test(basename)
    || /withholding-query|withhold-query/i.test(relative)
    || /(?:TrainTicketWithholdingQueryService|WithholdingQueryResult|WithholdingQueryRequest|RECONCILIATION_MISMATCH|reconciliationPassed|isUpdated|query_result|notUpdated)[\s\S]{0,2200}(?:out_order_no|trade_no|total_fee|trans_account_out|identity|reconciliation|不更新|not updated|assertFalse)/i.test(body);
});
const withholdQueryTestText = readAll(withholdQueryTestFiles);
const withholdThirdSourceFiles = sourceFiles.filter((file) => {
  const relative = relativePath(file);
  const basename = path.basename(file);
  const body = fs.readFileSync(file, "utf8");
  if (/Query|Notify|Controller|Constants|Config|Properties/i.test(basename)) return false;
  return /TrainTicketWithholdingService|DutAgentThird|WithholdingService|withhold/i.test(relative)
    && /dut\.agent\.third|SERVICE_DUT_AGENT_THIRD|submit_param|submitParam/i.test(body);
});
const withholdThirdSourceText = readAll(withholdThirdSourceFiles);
const withholdThirdExecutionSourceFiles = withholdThirdSourceFiles.filter((file) => {
  const basename = path.basename(file);
  const body = fs.readFileSync(file, "utf8");
  if (/SubmitParam|Builder|Parser|Signer|HttpClient|RequestBuilder|ResponseParser|Constants|Config|Properties|Controller|Query|Notify/i.test(basename)) {
    return false;
  }
  return /dut\.agent\.third|SERVICE_DUT_AGENT_THIRD/i.test(body)
    || /TrainTicketWithholdingService|DutAgentThird|WithholdingService/i.test(basename);
});
const withholdThirdExecutionSourceText = readAll(
  withholdThirdExecutionSourceFiles.length ? withholdThirdExecutionSourceFiles : withholdThirdSourceFiles,
);
const withholdThirdTestFiles = testFiles.filter((file) => {
  const relative = relativePath(file);
  const basename = path.basename(file);
  const body = fs.readFileSync(file, "utf8");
  if (/Query|Notify/i.test(basename)) return false;
  return /TrainTicketWithholdingService|DutAgentThird|WithholdingService/i.test(basename)
    || (/dut\.agent\.third|SERVICE_DUT_AGENT_THIRD|submit_param|submitParam/i.test(body)
      && /代扣执行|payer_user_id|out_biz_no|callCounter|dut\.agent\.third/i.test(body))
    || /(?:WithholdingExecuteRequest|WithholdingExecuteResult|TrainTicketWithholdingService|AGREEMENT_NOT_VALID|PAYER_USER_ID_MISMATCH|PAYMENT_TIMEOUT|isIdempotent)[\s\S]{0,2200}(?:payerUserId|payer_user_id|SIGNING|UNSIGNING|FAILED|NORMAL|ord_pmt_timeout|assertFalse|assertTrue|not.*call|不调用)/i.test(body);
});
const withholdThirdTestText = readAll(withholdThirdTestFiles);
const xmlParserTestFiles = testFiles.filter((file) => {
  const relative = relativePath(file);
  const basename = path.basename(file);
  return /Xml.*Parser|XML.*Parser|MapiXml|ResponseParser/i.test(relative)
    || /Xml.*Parser|XML.*Parser|MapiXml|ResponseParser/i.test(basename);
});
const xmlParserTestText = readAll(xmlParserTestFiles);
const xmlParserSourceFiles = sourceFiles.filter((file) => {
  const relative = relativePath(file);
  const basename = path.basename(file);
  const body = fs.readFileSync(file, "utf8");
  return /Xml.*Parser|XML.*Parser|MapiXml|ResponseParser/i.test(relative)
    || /Xml.*Parser|XML.*Parser|MapiXml|ResponseParser/i.test(basename)
    || /MapiXmlResponseParser|XmlResponseParser|XML\s*同步响应|DocumentBuilderFactory/i.test(body);
});
const xmlParserSourceText = readAll(xmlParserSourceFiles);
const errors = [];
const warnings = [];

if (javaFiles.length) {
  javaProjectGates.checkJavaProfiledCoreComponents(javaFiles, errors, relativePath);
  javaProjectGates.checkJavaConcreteDemoDependency(javaFiles, errors, relativePath);
  javaProjectGates.checkJavaFailClosedDefaultBackoff(javaFiles, errors, relativePath);
  javaProjectGates.checkSpringBeanMethodBypass(javaFiles, errors, relativePath);
}

function requireWhen(condition, pattern, message) {
  if (condition && !pattern.test(text)) errors.push(message);
}

function requireSourceWhen(condition, pattern, message) {
  if (condition && !pattern.test(sourceText)) errors.push(message);
}

function warnWhen(condition, pattern, message) {
  if (condition && !pattern.test(text)) warnings.push(message);
}

function hasPattern(pattern) {
  return pattern.test(text);
}

function hasExplicitSignatureVerifyCall(value) {
  return /(?:\.|\b)(?:verify|checkSign|rsaCheck|verifySignature|verifyResponseSignature|verifyXmlResponse|verifyMapiResponse)\s*\(/i.test(value);
}

const EXPLICIT_FAILURE_STATUS_VALUE = String.raw`(?:(?:[A-Za-z_$][\w$]*\.)+(?:QUERY_FAILED|SYNC_FAILED|FAILED|FAIL|QueryFailed|SyncFailed|Failed|Fail)\b|(?:QUERY_FAILED|SYNC_FAILED|FAILED|FAIL)\b|["'](?:QUERY_FAILED|SYNC_FAILED|FAILED|FAIL|query_failed|sync_failed|failed|fail)["'])`;
const SET_STATUS_EXPLICIT_FAILURE = String.raw`setStatus\s*\(\s*${EXPLICIT_FAILURE_STATUS_VALUE}`;

const implementationText = stripComments(sourceCodeText);
const usesMapi = /mapi\.alipay\.com|gateway\.do|alipay\.dut\.customer\.agreement|dut\.agent\.(third|query\.third)/.test(implementationText);
const usesAgreementSign = /alipay\.dut\.customer\.agreement\.page\.sign/.test(implementationText);
const usesAgreementQuery = /alipay\.dut\.customer\.agreement\.query/.test(implementationText);
const usesAgreementUnsign = /alipay\.dut\.customer\.agreement\.unsign/.test(implementationText);
const usesDutThird = /dut\.agent\.third/.test(implementationText);
const usesDutQuery = /dut\.agent\.query\.third/.test(implementationText);
const usesWalletH5Sign = usesAgreementSign && /ALIPAYAPP|支付宝.*(App|钱包)|H5/i.test(text);
const hasJavaSource = sourceFiles.some((file) => path.extname(file) === ".java");
const usesCustomMapiSignature = usesMapi && /Signature\.getInstance|SHA1withRSA|SHA256withRSA|buildSignContent|rsaCheck|checkSign|verifySignature|privateKey|PublicKey/i.test(sourceText);
const usesCustomMapiHttpClient = usesMapi && /HttpURLConnection|URLConnection|OkHttpClient|HttpClient|RestTemplate|fetch\(|axios|requests\.|http\.Client|httpclient|curl|urlopen|getResponseCode|statusCode|response\.status/i.test(mapiHttpClientText || sourceText);
const strippedSourceText = stripComments(sourceText);
const strippedSourceCodeText = stripComments(sourceCodeText);
const strippedAgreementSourceText = stripComments(agreementSourceText);
const strippedAgreementSignSourceText = stripComments(agreementSignSourceText || agreementSourceText);
const strippedAgreementQuerySourceText = stripComments(agreementQuerySourceText || agreementSourceText);
const strippedAgreementQueryRequestSourceText = stripComments(agreementQueryRequestSourceText || agreementQuerySourceText || agreementSourceText);
const strippedAgreementUnsignSourceText = stripComments(agreementUnsignSourceText || agreementSourceText);
const strippedWithholdThirdSourceText = stripComments(withholdThirdSourceText || sourceText);
const strippedWithholdThirdExecutionSourceText = stripComments(withholdThirdExecutionSourceText || withholdThirdSourceText || sourceText);
const withholdThirdOrderText = strippedWithholdThirdExecutionSourceText;

if (!usesMApiLike(implementationText)) {
  errors.push("未检测到 MAPI 三方免密代扣相关 service 或关键参数；请确认已生成本域接入代码。");
}

if (usesMApiLike(implementationText)) {
  const requiredServices = [
    ["alipay.dut.customer.agreement.page.sign", usesAgreementSign],
    ["alipay.dut.customer.agreement.query", usesAgreementQuery],
    ["alipay.dut.customer.agreement.unsign", usesAgreementUnsign],
    ["dut.agent.third", usesDutThird],
    ["dut.agent.query.third", usesDutQuery],
  ];
  for (const [service, detected] of requiredServices) {
    if (!detected) {
      errors.push(`三方免密代扣启用后必须覆盖完整签约 + 代扣五接口，缺少 ${service} 实现；不得只生成签约或代扣半链路。`);
    }
  }
}

const usesAlipayLogonId = (value) => /\balipay_logon_id\b|\balipayLogonId\b|\bAlipayLogonId\b/.test(value);
if (usesAgreementQuery && usesAlipayLogonId(strippedAgreementQueryRequestSourceText)) {
  errors.push("协议查询的用户身份字段必须为 alipay_user_id。");
}
if (usesAgreementUnsign && usesAlipayLogonId(strippedAgreementUnsignSourceText)) {
  errors.push("协议解约的用户身份字段必须为 alipay_user_id。");
}

if (/air_dut_third/.test(text)) {
  errors.push("检测到 air_dut_third。火车票/12306 场景必须使用 mr_dut_third。");
}

if (/biz_content|bizContent|method=/.test(text) && usesMapi) {
  warnings.push("检测到 OpenAPI 风格字段 biz_content/method。请确认没有把 MAPI 接口误生成成 OpenAPI 接口。");
}

requireWhen(usesMapi, /mapi\.alipay\.com|gateway\.do/, "MAPI 接入必须包含 mapi.alipay.com/gateway.do 网关配置。");
requireSourceWhen(usesCustomMapiHttpClient, /if\s*\([^)]*(?:code|status|statusCode|response\.status|getResponseCode\(\))[^)]*(?:>=\s*300|<\s*200|!\s*\([^)]*>=\s*200[^)]*<\s*300|!\s*[^)]*(?:ok|successful|isSuccessful))[^)]*\)\s*\{?[\s\S]{0,320}throw|if\s*\([^)]*![^)]*(?:response\.ok|res\.ok|isSuccessful|successful)[^)]*\)\s*\{?[\s\S]{0,320}throw/i, "MAPI HTTP 同步调用遇到非 2xx 必须明确失败，不能把 errorStream/错误页当作正常 XML/JSON 解析。");
requireSourceWhen(usesCustomMapiHttpClient, /InputStreamReader\([^)]*(?:resolveInputCharset|Charset\.forName|getInputCharset|inputCharset|getContentType|Content-Type|contentType)|new\s+String\([^)]*,\s*(?:resolveInputCharset|Charset\.forName|getInputCharset|inputCharset|charset|encoding)|Buffer\.from\([^)]*\)\.toString\([^)]*(?:charset|encoding|inputCharset)|iconv|TextDecoder\([^)]*(?:charset|encoding|inputCharset)|Encoding\.GetEncoding\([^)]*(?:charset|encoding|inputCharset)|charset\s*=\s*(?:parse|resolve|detect|get)/i, "MAPI HTTP 同步响应读取字符集必须来自响应声明或 _input_charset，不能固定 UTF-8。");
const parsesMapiXml = usesDutThird || usesDutQuery || /MapiXmlResponseParser|XmlResponseParser|XML\s*同步|MAPI[\s\S]{0,120}XML/i.test(sourceText);
if (usesCustomMapiHttpClient && parsesMapiXml) {
  const hasXmlDeclarationCharsetResolution =
    /(?:parse|resolve|detect)[A-Za-z0-9_]*(?:Xml|XML)[A-Za-z0-9_]*(?:Encoding|Charset)|(?:Xml|XML)[A-Za-z0-9_]*(?:Encoding|Charset)|XML_DECLARATION|xmlDeclaration|Pattern\.compile\([^)]*encoding|Matcher\s+\w+\s*=|<\\\?xml[\s\S]{0,120}encoding|<\?xml[\s\S]{0,120}encoding/i.test(mapiHttpClientText);
  if (!hasXmlDeclarationCharsetResolution) {
    errors.push("MAPI HTTP 客户端读取 XML 同步响应时必须支持 XML declaration encoding 兜底；顺序应为 Content-Type charset -> XML declaration encoding -> _input_charset -> UTF-8，不能只看响应头。");
  }
  const hasXmlDeclarationHttpTest =
    /encoding=\\?["']GBK\\?["']|encoding\s*=\s*["']GBK["']|GBK/i.test(mapiHttpClientTestText)
    && /(?:["'](?:text|application)\/xml["']|Content-Type[^;\n]{0,120}(?:text|application)\/xml|(?:text|application)\/xml[^;\n]{0,160}(?:without|no|不带)\s*charset)/i.test(mapiHttpClientTestText)
    && /火车票|代扣|中文|Chinese|订单|成功|失败/i.test(mapiHttpClientTestText);
  if (!hasXmlDeclarationHttpTest) {
    errors.push("MAPI HTTP 客户端测试必须覆盖 Content-Type 为 text/xml/application/xml 且不带 charset、XML declaration 为 encoding=\"GBK\"、中文字段不乱码的场景。");
  }
}
if (usesCustomMapiHttpClient) {
  const responseBodyReadText = extractNamedFunctionBlock(mapiHttpClientText, [
    "readResponseBody",
    "readBody",
    "readResponse",
  ]) || mapiHttpClientText;
  const swallowsHttpBodyReadFailure =
    /catch\s*\([^)]*(?:IOException|Exception|Throwable|Error)[^)]*\)\s*\{[\s\S]{0,240}return\s+(?:new\s+byte\s*\[\s*0\s*\]|""|''|Buffer\.alloc\(\s*0\s*\)|new\s+Uint8Array\(\s*0\s*\)|null|undefined)\s*;/i.test(responseBodyReadText)
    && !/throw\s+new\s+[A-Za-z0-9_.]*TransportException|throw\s+[A-Za-z0-9_]*TransportException/i.test(responseBodyReadText);
  if (swallowsHttpBodyReadFailure) {
    errors.push("MAPI HTTP 响应体读取异常不能 catch 后返回空字符串/空字节数组/空 Buffer；必须向上传播或包装成传输异常，避免把网络读失败伪装成业务空响应。");
  }

  const hasJavaInputStreamBodyRead = hasJavaSource
    && /InputStream\s+\w+|InputStream\s*\)|getInputStream\(\)|getErrorStream\(\)/.test(mapiHttpClientText);
  const closesResponseStream =
    /try\s*\([^)]*(?:InputStream|Reader|ResponseBody|input\s*=|is\s*=)[^)]*\)|\b(?:input|is|reader|body)\.close\s*\(/i.test(mapiHttpClientText);
  if (hasJavaInputStreamBodyRead && !closesResponseStream) {
    errors.push("MAPI HTTP 响应流必须用 try-with-resources 或 close 关闭，不能只 disconnect 连接而遗漏 body InputStream。");
  }

  const hasBodyReadFailureTest =
    /assertThrows|toThrow|rejects\.toThrow|pytest\.raises|assertRaises|assert\.Panics|require\.Error|Assert\.Throws/i.test(mapiHttpClientTestText)
    && /throw\s+new\s+IOException|read.*异常|读取异常|body.*异常|body.*failure|read.*failure|ThrowingInputStream|FailingInputStream|FaultyInputStream|broken.*stream|stream.*error/i.test(mapiHttpClientTestText)
    || /MApiTransportException[\s\S]{0,420}(?:read|body|empty|IO error|Connection refused|transport)|(?:read|body|empty|IO error|Connection refused|transport)[\s\S]{0,420}MApiTransportException|doGet\s*\([^)]*\)[\s\S]{0,260}thenThrow\s*\([^)]*MApiTransportException/i.test(mapiHttpClientTestText);
  if (!hasBodyReadFailureTest) {
    errors.push("MAPI HTTP 客户端测试必须覆盖响应体读取异常会抛出明确传输异常，不能返回空响应。");
  }
}
if (hasJavaSource && parsesMapiXml
  && /ByteArrayInputStream\s*\([^)]*\.getBytes\s*\(\s*(?:StandardCharsets\.UTF_8|"UTF-8"|'UTF-8')?\s*\)\s*\)[\s\S]{0,800}\.parse\s*\(/.test(sourceText)) {
  errors.push("XML 同步响应若已在 HTTP 层解码为字符串，解析时必须使用 StringReader/InputSource 字符流；不能 xml.getBytes(UTF-8) 后用 ByteArrayInputStream 解析，避免 encoding=GBK 中文乱码。");
}
if (parsesMapiXml && xmlParserTestFiles.length) {
  const hasGbkXmlCase = /encoding=\\?["']GBK\\?["']|charset=gbk|GBK/i.test(xmlParserTestText)
    && /火车票|代扣|中文|成功|失败/.test(xmlParserTestText);
  if (!hasGbkXmlCase) {
    warnings.push("XML 同步响应解析测试建议覆盖 encoding=\"GBK\" 且包含中文字段，确认字符流解析不会乱码。");
  }
}
if (parsesMapiXml) {
  const usesLeafFlatteningParser =
    /collectLeafNodes|result\.put\s*\(\s*(?:element\.getNodeName\(\)|[^,]*getNodeName\(\))|getChildNodes\(\)[\s\S]{0,520}result\.put/i.test(xmlParserSourceText);
  const verifiesFlatParseResult =
    /(?:syncResult|parsed|respMap)\s*=\s*xmlParser\.parse\s*\([^;]+;[\s\S]{0,1200}signer\.verify\s*\(\s*(?:syncResult|parsed|respMap)\s*\)/i.test(sourceText)
    || /return\s+xmlParser\.parse\s*\([^;]+;[\s\S]{0,1600}signer\.verify\s*\(\s*respMap\s*\)/i.test(sourceText);
  if (usesLeafFlatteningParser && verifiesFlatParseResult) {
    errors.push("XML 同步响应验签不能复用所有叶子节点扁平化结果；必须提供独立的 MAPI XML 验签参数抽取方法，忽略 request/param 回显节点，只抽业务响应节点的直接子节点。");
  }
  const hasSourceLikeXmlSignatureTest =
    /<request[\s\S]{0,800}<param\s+name=|<param\s+name=["'][^"']+["'][\s\S]{0,1200}<response|<response[\s\S]{0,700}<(?:trade|agreement|alipay_dut_customer_agreement_query_response|dut_agent_query_third_response|dut_agent_third_response)/i.test(testText);
  if ((usesDutThird || usesDutQuery || usesAgreementQuery) && !hasSourceLikeXmlSignatureTest) {
    errors.push("XML 同步响应验签测试必须覆盖接近真实 MAPI 的结构：包含 request/param 回显节点和 response 下业务节点；不能只用 <alipay><field> 这种扁平 XML。");
  }
}
requireWhen(usesAgreementSign || usesAgreementQuery || usesAgreementUnsign, /DUT_AGENT_THIRD_P/, "协议类接口必须包含 product_code=DUT_AGENT_THIRD_P。");
requireWhen(usesAgreementSign, /DUT_AGENT_THIRD_V2/, "协议签约必须包含 sales_product_code=DUT_AGENT_THIRD_V2。");
requireWhen(usesAgreementSign || usesAgreementQuery || usesAgreementUnsign, /INDUSTRY\|B2B_TICKET_AGENT/, "协议类接口必须包含 scene=INDUSTRY|B2B_TICKET_AGENT。");
if ((usesAgreementSign || usesAgreementUnsign)
  && /(?:put|set|append|add|params?\s*\[|params?\.)\s*\(?\s*["']notify_url["']|notifyUrl\s*[:=]|notify_url\s*[:=]|getSignUrl\(\)|getUnsignUrl\(\)|signNotifyUrl|unsignNotifyUrl/i.test(agreementSourceText)) {
  errors.push("product_code=DUT_AGENT_THIRD_P 的签约/解约接口不支持 notify_url；不得给协议页面签约或协议解约请求传 notify_url。");
}
if ((usesAgreementSign || usesAgreementUnsign)
  && /AgreementNotifyHandler|handleSignNotify|handleUnsignNotify|signNotify|unsignNotify|notify\/sign|notify\/unsign|notifySign|notifyUnsign/i.test(agreementSourceText)) {
  errors.push("product_code=DUT_AGENT_THIRD_P 不支持签约/解约服务端通知；不得生成签约/解约通知 handler、controller 入口或相关协议通知逻辑。");
}

if (usesAgreementSign || usesAgreementQuery || usesAgreementUnsign) {
  const hasExternalSignNoCode = /externalSignNo|external_sign_no/.test(strippedAgreementSourceText);
  const hasExternalSignNoEntity = /(?:private|public|protected)\s+String\s+externalSignNo\b|(?:get|set)ExternalSignNo\s*\(|external_sign_no\s*[:=]/i.test(strippedAgreementSourceText);
  const hasExternalSignNoRequestAssembly = /(?:put|append|add|set|params?\s*\[|bizParams\.)\s*\(?\s*["']external_sign_no["']|externalSignNo[\s\S]{0,320}(?:bizParams|params|request|query|put|append|add|set)/i.test(strippedAgreementSourceText);
  const externalSignNoTests = agreementQueryTestText + "\n" + agreementUnsignTestText + "\n" + testText;
  const hasExternalSignNoPresentTest = /externalSignNo|external_sign_no/i.test(externalSignNoTests)
    && /(?:contains|toContain|assertEquals|toHaveProperty|包含|携带|落库|持久化|复用|reuse|persist|saved|request)/i.test(externalSignNoTests);
  const hasExternalSignNoAbsentTest = /externalSignNo|external_sign_no/i.test(externalSignNoTests)
    && /(?:not\s+contain|not\.toContain|assertFalse|absent|missing|省略|未传|不包含|不携带|不是必填|可省略)/i.test(externalSignNoTests);
  if (!hasExternalSignNoCode || !hasExternalSignNoEntity || !hasExternalSignNoRequestAssembly) {
    errors.push("external_sign_no 是可选字段但不能没有代码路径：签约链路必须提供可选入参/本地协议字段/请求组装；传入时进入 MAPI 请求并落库，未传时不生成不强制。");
  }
  if (!hasExternalSignNoPresentTest || !hasExternalSignNoAbsentTest) {
    errors.push("协议签约/查询/解约测试必须覆盖 external_sign_no 的传入与未传两条路径：传入时请求包含并落库/复用，未传时请求不携带且不拦截。");
  }
  const hasExternalSignNoQueryAssembly = /(?:put|append|add|set|params?\s*\[|bizParams\.)\s*\(?\s*["']external_sign_no["']|(?:getExternalSignNo|externalSignNo)[\s\S]{0,520}(?:SERVICE_AGREEMENT_QUERY|agreement\.query|queryAgreement|bizParams|params|request|put|append|add|set)/i.test(strippedAgreementQueryRequestSourceText);
  const hasExternalSignNoUnsignAssembly = /(?:put|append|add|set|params?\s*\[|bizParams\.)\s*\(?\s*["']external_sign_no["']|(?:getExternalSignNo|externalSignNo)[\s\S]{0,520}(?:SERVICE_AGREEMENT_UNSIGN|agreement\.unsign|unsign|bizParams|params|request|put|append|add|set)/i.test(strippedAgreementUnsignSourceText);
  const hasExternalSignNoQueryRequestTest = /externalSignNo|external_sign_no/i.test(agreementQueryTestText)
    && /(?:capturedUrl|capture|request|请求|contains|toContain|assertTrue|assertFalse|携带|不携带|包含|不包含)/i.test(agreementQueryTestText);
  const hasExternalSignNoUnsignRequestTest = /externalSignNo|external_sign_no/i.test(agreementUnsignTestText)
    && /(?:capturedUrl|capture|request|请求|contains|toContain|assertTrue|assertFalse|携带|不携带|包含|不包含|复用)/i.test(agreementUnsignTestText);
  if (usesAgreementQuery && hasExternalSignNoCode && !hasExternalSignNoQueryAssembly) {
    errors.push("协议查询如果本地协议保存了 external_sign_no，必须从本地协议记录复用并条件性加入 alipay.dut.customer.agreement.query 请求；只在签约中落库不算完整支持。");
  }
  if (usesAgreementUnsign && hasExternalSignNoCode && !hasExternalSignNoUnsignAssembly) {
    errors.push("协议解约如果本地协议保存了 external_sign_no，必须从本地协议记录复用并条件性加入 alipay.dut.customer.agreement.unsign 请求；不能只传 agreement_no/alipay_user_id 后丢失该定位字段。");
  }
  if (usesAgreementQuery && hasExternalSignNoCode && !hasExternalSignNoQueryRequestTest) {
    errors.push("协议查询测试必须捕获实际请求，覆盖本地有 external_sign_no 时请求携带、未保存时请求不携带。");
  }
  if (usesAgreementUnsign && hasExternalSignNoCode && !hasExternalSignNoUnsignRequestTest) {
    errors.push("协议解约测试必须捕获实际请求，覆盖本地有 external_sign_no 时请求复用携带、未保存时请求不携带。");
  }
}
if (usesAgreementQuery
  && /findAgreementByExternalUser\s*\(\s*alipayUserId\s*\)|findAgreementByExternalUser\s*\(\s*alipay_user_id\s*\)/.test(agreementSourceText)) {
  errors.push("协议查询确认落库必须区分 external_user_id 和 alipay_user_id：本地签约记录按 external_user_id 查找/更新，不能把 alipay_user_id 当 external_user_id 使用。");
}
if (usesAgreementSign) {
  const signText = agreementSignSourceText || agreementSourceText;
  if (!hasRequiredFieldCheck(signText, "externalUserId|external_user_id")) {
    errors.push("协议页面签约必须在发起 MAPI 前校验 external_user_id 非空；不能生成空外部用户号的签约链接。");
  }
  if (!hasRequiredFieldCheck(signText, "returnUrl|return_url")) {
    errors.push("协议页面签约必须在发起 MAPI 前校验 return_url 非空；return_url 只做页面承接，但不能为空。");
  }
}
if (usesAgreementQuery) {
  const queryText = agreementQuerySourceText || agreementSourceText;
  const queryCode = stripComments(queryText);
  const supportsOpenIdAgreementQuery =
    /(?:employeeOpenId|employee_open_id|openId|open_id|openid)[\s\S]{0,700}(?:appId|app_id)|(?:appId|app_id)[\s\S]{0,700}(?:employeeOpenId|employee_open_id|openId|open_id|openid)/i.test(queryText);
  if (!hasRequiredFieldCheck(queryText, "alipayUserId|alipay_user_id")) {
    errors.push("协议查询确认必须校验 alipay_user_id 非空；不能用空支付宝 UID 查询或确认协议。");
  }
  if (/confirmAgreementByQuery\s*\(\s*(?:final\s+)?String\s+alipayUserId\s*\)/.test(agreementSourceText)) {
    errors.push("协议查询确认方法不能只接收 alipayUserId 一个参数；必须显式传入 external_user_id 和 alipay_user_id，避免把支付宝 UID 当本地外部用户号。");
  }
  const exposesRawAgreementQueryOnly = /@(?:Get|Post)Mapping\s*\([^)]*(?:agreement\/query|agreement-query|协议查询)[\s\S]{0,820}queryService\.queryAgreement\s*\(/i.test(sourceText)
    && !/@(?:Get|Post)Mapping\s*\([^)]*(?:agreement\/(?:query|confirm)|agreement-confirm|协议查询|协议确认)[\s\S]{0,1000}confirmAgreementByQuery\s*\(/i.test(sourceText);
  if (exposesRawAgreementQueryOnly) {
    errors.push("对外协议查询入口不能只返回 queryAgreement(alipay_user_id) 的原始 MAPI 响应；必须提供调用 confirmAgreementByQuery(external_user_id, alipay_user_id) 或等价确认落库逻辑的入口，完成签约状态闭环。");
  }
  const verifiesAgreementQueryResponse =
    /verify\s*\(|checkSign|rsaCheck|verifySignature|MApiSigner|MApiSignature|signatureService\s*\.\s*verify|verifiedResponse|验签/i.test(queryText);
  if (!verifiesAgreementQueryResponse) {
    errors.push("协议查询同步响应在确认落库前必须做 MAPI 验签；不能只解析 body 后直接把协议置为 NORMAL。");
  }
  const supportsAgreementQueryXml =
    /MapiXml|XmlResponse|\bXML\b|DocumentBuilder|SAXParser|StringReader|parseXml|parseXML|fromstring|ElementTree|xml2js|fast-xml-parser|<alipay|响应.*\bXML\b|\bXML\b.*响应/i.test(queryText);
  const onlyParsesAgreementJson =
    /ObjectMapper|readTree|JsonNode|JSON\.parse|JSONParser|parseObject|JsonConvert|System\.Text\.Json/i.test(queryText)
    && !supportsAgreementQueryXml;
  if (onlyParsesAgreementJson) {
    errors.push("协议查询同步响应必须兼容 JSON/XML；不能只用 JSON parser 解析后在 XML 返回场景下无法确认协议状态。");
  }
  const parsesAgreementJson =
    /ObjectMapper|readTree|JsonNode|JSON\.parse|JSONParser|parseObject|JsonConvert|System\.Text\.Json/i.test(queryCode);
  const supportsNestedAgreementJson =
    /(?:get|path|at)\s*\(\s*["'](?:response|alipay_dut_customer_agreement_query_response|customer_agreement_query_response|dut_customer_agreement_query_response|agreement_query_response)["']\s*\)/i.test(queryCode)
    || /find(?:Value|Path|Parent)\s*\(\s*["'](?:is_success|alipay_user_id|agreement_no|status|product_code|scene)["']\s*\)/i.test(queryCode)
    || /(?:alipay_dut_customer_agreement_query_response|customer_agreement_query_response|dut_customer_agreement_query_response|agreement_query_response)[\s\S]{0,900}(?:is_success|alipay_user_id|agreement_no|status|product_code|scene)/i.test(queryCode)
    || /(?:flatten|collect|walk|traverse|visit)[A-Za-z0-9_]*(?:Json|JSON|Node|Object|Map)?\s*\([^)]*(?:JsonNode|json|node|object|map)[^)]*\)[\s\S]{0,1200}(?:isObject|fields\s*\(|children|entries|forEach)/i.test(queryCode);
  if (parsesAgreementJson && !supportsNestedAgreementJson) {
    errors.push("协议查询 JSON 响应解析不能只读取顶层字段；必须兼容 response/协议业务响应节点下的嵌套字段，并从业务节点抽取 is_success、agreement_no、alipay_user_id、status 等用于验签和状态确认。");
  }
  const hasNestedAgreementJsonTest =
    /\{[\s\S]{0,360}(?:\\?["']response\\?["']|\\?["']alipay_dut_customer_agreement_query_response\\?["']|\\?["']customer_agreement_query_response\\?["']|\\?["']agreement_query_response\\?["'])\s*[:=]\s*\{[\s\S]{0,1400}(?:\\?["']agreement_no\\?["']|\\?["']alipay_user_id\\?["']|\\?["']is_success\\?["']|\\?["']status\\?["'])[\s\S]{0,1800}(?:AgreementStatus\.NORMAL|NORMAL|assertEquals|toEqual|expect|确认|落库)/i.test(agreementQueryTestText)
    || /(?:putObject|createObjectNode|ObjectNode|JSONObject|Map\.of|LinkedHashMap)[\s\S]{0,420}(?:["']response["']|["']alipay_dut_customer_agreement_query_response["']|["']customer_agreement_query_response["']|["']agreement_query_response["'])[\s\S]{0,1400}(?:["']agreement_no["']|["']alipay_user_id["']|["']is_success["']|["']status["'])[\s\S]{0,1800}(?:AgreementStatus\.NORMAL|NORMAL|assertEquals|toEqual|expect|确认|落库)/i.test(agreementQueryTestText);
  if (parsesAgreementJson && !hasNestedAgreementJsonTest) {
    errors.push("协议查询测试必须覆盖 JSON 业务响应节点嵌套形态，例如 response 或 alipay_dut_customer_agreement_query_response 下包含 agreement_no/alipay_user_id/status，不能只测顶层扁平 JSON。");
  }
  const agreementXmlUsesFlatParseForVerify =
    /respMap\s*=\s*parseAgreementResponse\s*\([^)]*\)[\s\S]{0,1200}signer\.verify\s*\(\s*respMap\s*\)/i.test(queryText)
    && /return\s+xmlParser\.parse\s*\(/i.test(queryText)
    && !/extractSignParams|verifyXmlResponse|verifyMapiResponse|verifiedXmlParams|xmlSignParams/i.test(queryText);
  if (supportsAgreementQueryXml && agreementXmlUsesFlatParseForVerify) {
    errors.push("协议查询 XML 同步响应验签必须使用独立的 MAPI XML 验签参数抽取方法；不能把 xmlParser.parse/递归扁平化结果 respMap 直接传给 verify。");
  }
  const hasAgreementQuerySourceLikeXmlTest =
    /<request[\s\S]{0,800}<param\s+name=|<param\s+name=["'][^"']+["'][\s\S]{0,1200}<response|<response[\s\S]{0,900}<(?:agreement|alipay_dut_customer_agreement_query_response|customer_agreement_query_response|dut_customer_agreement_query_response)/i.test(agreementQueryTestText);
  if (supportsAgreementQueryXml && !hasAgreementQuerySourceLikeXmlTest) {
    errors.push("协议查询测试必须在 AgreementQuery 测试自身覆盖接近真实 MAPI 的 XML 响应结构：包含 request/param 回显节点和 response 下协议业务节点；不能只靠代扣 XML 测试覆盖。");
  }
  if (!/is_success|isSuccess/.test(queryText)) {
    errors.push("协议查询同步响应必须检查 is_success=T 后才能读取协议明细并更新本地协议状态。");
  }
  const readsReturnedAlipayUserId =
    /(?:textOrNull|asText|get|path|JsonNode|response|resp)[^;\n]{0,180}["']alipay_user_id["']|returnedAlipayUserId|responseAlipayUserId|queriedAlipayUserId|支付宝返回.*alipay_user_id/i.test(queryText);
  const readsReturnedPrincipalId =
    /(?:textOrNull|asText|get|path|JsonNode|response|resp)[^;\n]{0,180}["']principal_id["']|returnedPrincipalId|responsePrincipalId|principalId|principal_id/i.test(queryText);
  const comparesAlipayUserId =
    /(?:returnedAlipayUserId|responseAlipayUserId|queriedAlipayUserId|get\(["']alipay_user_id["']\)|path\(["']alipay_user_id["']\)|textOrNull\([^)]*["']alipay_user_id["'][^)]*\))[\s\S]{0,360}(?:equals|==|Objects\.equals|assertEquals|match|matches|validate|校验|匹配|不一致)|(?:Objects\.equals|equals|assertEquals)[\s\S]{0,260}(?:returnedAlipayUserId|responseAlipayUserId|queriedAlipayUserId|alipay_user_id)/i.test(queryText);
  if (supportsOpenIdAgreementQuery) {
    const persistsPrincipalIdAsAlipayUserId =
      /(?:returnedPrincipalId|responsePrincipalId|principalId|principal_id)[\s\S]{0,900}(?:setAlipayUserId|alipayUserId\s*=|alipay_user_id|payerUserId|payer_user_id|save|persist|update|落库|保存)|(?:setAlipayUserId|alipayUserId\s*=|alipay_user_id|payerUserId|payer_user_id|保存|落库)[\s\S]{0,900}(?:returnedPrincipalId|responsePrincipalId|principalId|principal_id)/i.test(queryText);
    const rejectsMissingPrincipalId =
      /(?:principalId|principal_id)[^;\n]{0,220}(?:isBlank|isEmpty|trim\(\)|length\s*[=!<>]=?\s*0|require|notBlank|hasText|为空|缺失)|(?:missing|缺少|为空)[^;\n]{0,220}(?:principalId|principal_id)/i.test(queryText);
    const hasOpenIdPrincipalTest =
      /(?:employeeOpenId|employee_open_id|openId|open_id|openid)[\s\S]{0,1600}(?:appId|app_id)[\s\S]{0,2000}(?:principalId|principal_id)[\s\S]{0,2200}(?:alipayUserId|alipay_user_id|payerUserId|payer_user_id|assertEquals|toEqual|expect|保存|落库)/i.test(agreementQueryTestText)
      || /(?:principalId|principal_id)[\s\S]{0,2000}(?:employeeOpenId|employee_open_id|openId|open_id|openid)[\s\S]{0,2200}(?:alipayUserId|alipay_user_id|payerUserId|payer_user_id|assertEquals|toEqual|expect|保存|落库)/i.test(agreementQueryTestText);
    if (!readsReturnedPrincipalId) {
      errors.push("协议查询支持员工 openid + app_id 定位时，必须读取可信响应里的 principal_id，并将其保存为本地协议 alipay_user_id，供协议解约和代扣链路使用。");
    }
    if (!persistsPrincipalIdAsAlipayUserId) {
      errors.push("协议查询支持员工 openid 路径时，必须把已验签响应 principal_id 持久化为本地协议 alipay_user_id 或等价支付宝 UID 字段，供协议解约和代扣链路使用。");
    }
    if (!rejectsMissingPrincipalId) {
      errors.push("协议查询使用 openid 定位时，响应 principal_id 是完成协议确认所需的支付宝 UID。");
    }
    if (!hasOpenIdPrincipalTest) {
      errors.push("协议查询测试必须覆盖 openid + app_id 查询路径：响应 principal_id 被保存为本地协议 alipay_user_id，供协议解约使用，并作为后续代扣 payer_user_id 的来源。");
    }
  } else {
    if (!readsReturnedAlipayUserId) {
      errors.push("使用支付宝 UID 查询协议时，必须读取响应里的 alipay_user_id 字段并用于一致性校验，不能只把请求入参写回本地协议。");
    }
    if (!comparesAlipayUserId) {
      errors.push("使用支付宝 UID 查询协议时，必须比对返回的 alipay_user_id 与请求/本地记录一致，不能确认到别人的协议。");
    }
  }
  const handlesAgreementNoConsistency =
    /(?:getAgreementNo\(\)|existingAgreementNo|localAgreementNo|savedAgreementNo|已有协议号|本地协议号)[\s\S]{0,360}(?:Objects\.equals|equals|assertEquals|==|!=|不一致|一致)|(?:Objects\.equals|equals|assertEquals)[\s\S]{0,260}(?:getAgreementNo\(\)|existingAgreementNo|localAgreementNo|savedAgreementNo)/i.test(queryText);
  if (!handlesAgreementNoConsistency) {
    errors.push("协议查询确认必须处理 agreement_no 一致性：已有协议号时比对一致，首次确认时持久化返回的 agreement_no。");
  }
  const setAgreementFailedStatus = String.raw`(?:persistFailed\b|setStatus\s*\(\s*(?:AgreementStatus\.FAILED|(?:[A-Za-z_$][\w$]*\.)+FAILED\b|FAILED\b|["'](?:FAILED|failed)["']))`;
  const overwritesAgreementOnUntrustedFailure =
    new RegExp(String.raw`catch\s*\([^)]*\)\s*\{[\s\S]{0,420}${setAgreementFailedStatus}`).test(queryText)
    || new RegExp(String.raw`!\s*verify[A-Za-z0-9_]*\s*\([^)]*\)[\s\S]{0,520}${setAgreementFailedStatus}`).test(queryText)
    || /isSuccess|is_success/i.test(queryText)
      && new RegExp(String.raw`(?:!"T"\.equalsIgnoreCase|!\s*["']T["']\.equalsIgnoreCase|is_success\s*非\s*T|isSuccess[^;\n]{0,120}(?:!=|!==|not|非))[\s\S]{0,420}${setAgreementFailedStatus}`).test(queryText);
  if (overwritesAgreementOnUntrustedFailure) {
    errors.push("协议查询的解析失败、验签失败或 is_success 非 T 属于不可确认/查询失败，不能覆盖已有本地协议为 FAILED；应记录查询失败并保持原可信状态，只有可信响应明确证明协议无效时才更新失效态。");
  }
}
if (usesAgreementUnsign) {
  const unsignText = agreementUnsignSourceText || agreementSourceText;
  const unsignCode = stripComments(unsignText);
  if (!hasRequiredFieldCheck(unsignText, "agreementNo|agreement_no")) {
    errors.push("协议解约必须在发起 MAPI 前校验 agreement_no 非空。");
  }
  if (!hasRequiredFieldCheck(unsignText, "alipayUserId|alipay_user_id")) {
    errors.push("协议解约必须在发起 MAPI 前校验 alipay_user_id 非空，并与本地协议记录匹配。");
  }
  const checksUnsignExternalUserConsistency =
    /(?:getExternalUserId\(\)|localExternalUserId|existingExternalUserId|savedExternalUserId|本地[^;\n]{0,80}external_user_id|本地[^;\n]{0,80}externalUserId)/i.test(unsignText)
    && /(?:externalUserId|external_user_id)[\s\S]{0,360}(?:equals|Objects\.equals|不一致|mismatch|different|IllegalStateException|ValidationException)|(?:equals|Objects\.equals)[\s\S]{0,260}(?:externalUserId|external_user_id)/i.test(unsignText);
  if (!checksUnsignExternalUserConsistency) {
    errors.push("协议解约如果入参携带 external_user_id，必须与本地协议记录的 external_user_id 一致；本地协议存在时不能直接透传调用方 external_user_id 覆盖本地协议身份。");
  }
  const unsignStatusWriteIndex = firstIndexOfAny(unsignCode, [
    /setStatus\s*\(\s*(?:AgreementStatus\.)?UNSIGNING\b/i,
    /status\s*=\s*(?:AgreementStatus\.)?UNSIGNING\b/i,
    /\bUNSIGNING\b[\s\S]{0,180}(?:saveAgreement|save|update)/i,
  ]);
  const unsignHttpCallIndex = firstIndexOfAny(unsignCode, [
    /httpClient\s*\.\s*(?:get|post|execute|send)\s*\(/i,
    /(?:mapiClient|client)\s*\.\s*(?:get|post|execute|send)\s*\(/i,
    /requests\.(?:get|post|request)\s*\(/i,
    /fetch\s*\(/i,
  ]);
  const hasUnsignRollbackOnTransportFailure =
    /catch\s*\([^)]*(?:IOException|Exception|Throwable|Error|RuntimeException)[^)]*\)\s*\{[\s\S]{0,900}(?:setStatus\s*\([^)]*(?:previous|original|old|prior|NORMAL|getStatus\(\)|AgreementStatus\.)|restore|rollback|revert|回滚|恢复|保持原状态)/i.test(unsignCode)
    || /try\s*\{[\s\S]{0,1200}setStatus\s*\([^)]*UNSIGNING[\s\S]{0,1200}(?:httpClient|mapiClient|client)\s*\.[\s\S]{0,1200}catch\s*\([^)]*\)\s*\{[\s\S]{0,900}(?:setStatus|restore|rollback|revert|回滚|恢复|保持原状态)/i.test(unsignCode);
  if (unsignStatusWriteIndex >= 0
    && unsignHttpCallIndex >= 0
    && unsignStatusWriteIndex < unsignHttpCallIndex
    && !hasUnsignRollbackOnTransportFailure) {
    errors.push("协议解约不能在 MAPI HTTP 调用尚未成功发出前就永久写入 UNSIGNING；如果先写中间态，HTTP/网络/读取异常分支必须回滚到原可信状态。");
  }
  if (!agreementUnsignTestFiles.length) {
    errors.push("协议解约必须有独立测试类/测试文件，覆盖解约必填参数、协议身份一致性和不传 notify_url。");
  } else {
    if (!hasUnsignFailFastTest(agreementUnsignTestText, "agreementNo|agreement_no")) {
      errors.push("协议解约测试必须覆盖 agreement_no 为空/空白时 fail fast。");
    }
    if (!hasUnsignFailFastTest(agreementUnsignTestText, "alipayUserId|alipay_user_id")) {
      errors.push("协议解约测试必须覆盖 alipay_user_id 为空/空白时 fail fast。");
    }
    if (!hasUnsignMismatchRejectTest(agreementUnsignTestText, "alipayUserId|alipay_user_id")) {
      errors.push("协议解约测试必须覆盖 alipay_user_id 与本地协议记录不一致时拒绝解约。");
    }
    if (!hasUnsignMismatchRejectTest(agreementUnsignTestText, "externalUserId|external_user_id")) {
      errors.push("协议解约测试必须覆盖 external_user_id 与本地协议记录不一致时拒绝解约，避免入参覆盖本地协议身份。");
    }
    if (!/(?:notify_url|notifyUrl)[\s\S]{0,360}(?:assertFalse|not.*contain|不包含|不传|absent|missing)|(?:assertFalse|not.*contain|不包含|不传|absent|missing)[\s\S]{0,360}(?:notify_url|notifyUrl)/i.test(agreementUnsignTestText)) {
      errors.push("协议解约测试必须覆盖 DUT_AGENT_THIRD_P 下解约请求不传 notify_url。");
    }
    if (!/(?:HTTP[^;\n]{0,120}(?:失败|异常|fail|exception|error)|http[^;\n]{0,180}(?:throw|fail|exception|error)|network|IOException|RuntimeException|transport|Throwing|Failing|Faulty|调用失败|网络异常|读取异常|抛异常)[\s\S]{0,900}(?:UNSIGNING|AgreementStatus|原状态|保持|回滚|restore|rollback|not\s+.*UNSIGNING|assertEquals)/i.test(agreementUnsignTestText)) {
      errors.push("协议解约测试必须覆盖 HTTP/网络/读取异常时本地协议保持原可信状态或回滚，不能提前停留在 UNSIGNING。");
    }
  }
}
requireWhen(usesWalletH5Sign, /alipays:\/\/platformapi\/startapp|platformapi\/startapp/, "支付宝钱包 H5 签约必须返回 alipays://platformapi/startapp schema，不能只返回 MAPI 签约直链。");
requireWhen(usesWalletH5Sign, /appId=20000067|appId["']?\s*[:=]\s*["']20000067["']/, "支付宝钱包 H5 签约 schema 必须使用 appId=20000067。");
requireWhen(usesWalletH5Sign, /URLEncoder\.encode|encodeURIComponent|QueryEscape|EscapeDataString|UrlEncode|urlencode|rawurlencode|urllib\.parse\.quote|quote_plus|quote\(/, "支付宝钱包 H5 签约 schema 的 url 参数必须对整条 MAPI 签约 URL 做 URL encode。");
requireSourceWhen(usesWalletH5Sign, /channel[^;\n]{0,160}\.trim\(|\.trim\(\)[^;\n]{0,160}channel|trim\([^)]*channel|strings\.TrimSpace\([^)]*channel|normalizeChannel|normalizedChannel|channel[^;\n]{0,160}normalize/i, "签约 channel 入参必须先 trim/去空格，再决定 ALIPAYAPP schema 或 PC 直链。");
requireSourceWhen(usesWalletH5Sign, /channel[^;\n]{0,160}\.toUpperCase\(|toUpperCase\([^)]*channel|equalsIgnoreCase\([^)]*channel|channel[^;\n]{0,160}equalsIgnoreCase|strings\.(ToUpper|EqualFold)\([^)]*channel|casefold\([^)]*channel|channel[^;\n]{0,160}casefold/i, "签约 channel 入参必须做大小写归一或大小写无关比较。");
requireSourceWhen(usesWalletH5Sign, /IllegalArgumentException[^;\n]{0,200}channel|channel[^;\n]{0,200}IllegalArgumentException|unsupported[^;\n]{0,120}channel|invalid[^;\n]{0,120}channel|非法[^;\n]{0,120}channel|不支持[^;\n]{0,120}channel|reject[^;\n]{0,120}channel|channel[^;\n]{0,120}reject/i, "签约 channel 必须按 ALIPAYAPP/PC 白名单校验，非法值直接拒绝。");
if (usesWalletH5Sign && hasJavaSource
  && /(?:channel|normalizedChannel|normalized)[^;\n]{0,200}toUpperCase\(\)|toUpperCase\(\)[^;\n]{0,80}(?:channel|normalizedChannel|normalized)/i.test(sourceText)
  && !/toUpperCase\(\s*(?:Locale|java\.util\.Locale)\.ROOT\s*\)/.test(sourceText)) {
  errors.push("Java 签约 channel 若使用 toUpperCase 归一化，必须传 Locale.ROOT，避免默认 Locale 影响 ALIPAYAPP/PC 判断。");
}
requireSourceWhen(usesCustomMapiSignature, /getBytes\([^)]*(?:resolveInputCharset|Charset\.forName|inputCharset|getInputCharset)|(?:Signature|signer|verifier)[\s\S]{0,500}(?:Charset\.forName|resolveInputCharset|inputCharset|getInputCharset)|Buffer\.from\([^)]*,\s*(?:inputCharset|charset|encoding)|\.update\([^)]*,\s*(?:inputCharset|charset|encoding)|Encoding\.GetEncoding\([^)]*(?:inputCharset|charset)|\.encode\([^)]*(?:input_charset|charset|encoding)/i, "MAPI 签名/验签转字节必须使用 _input_charset 对应字符集，不能固定 UTF-8 后又声明其他字符集。");
requireSourceWhen(usesCustomMapiSignature, /(?:["']sign_type["'][\s\S]{0,220}(?:continue|filter|skip|remove|delete|排除|过滤)|(?:remove|delete)\s*\(\s*["']sign_type["']\s*\)|["']sign_type["']\s*\.\s*equals\s*\(|(?:key|name)\s*[=!]=+\s*["']sign_type["'])/i, "MAPI 待签名串必须过滤 sign_type；常规请求和通知验签只过滤 sign/sign_type 后对其余原始参数排序拼接。");
if (usesCustomMapiSignature) {
  const exposesConfigurableSignType =
    /getSignType\s*\(|setSignType\s*\(|signType\s*=|["']sign_type["'][^;\n]{0,160}(?:getSignType|signType|config|properties|配置)/i.test(sourceText);
  const fixedRsaImplementation =
    /SHA1withRSA|SHA256withRSA|Signature\.getInstance\s*\(\s*SIGN_ALGORITHM\s*\)/i.test(sourceText)
    && !/MD5withRSA|DSA|MessageDigest\.getInstance\s*\(\s*["']MD5["']|Hmac/i.test(sourceText);
  const hasSignTypeRestriction =
    /(?:getSignType\s*\(\)|signType|sign_type)[\s\S]{0,260}(?:equalsIgnoreCase|equals|==)[\s\S]{0,120}["']RSA["'][\s\S]{0,360}(?:throw|Illegal|不支持|仅支持|only|reject|fail)|(?:仅支持|only supports?|不支持)[^;\n]{0,160}(?:RSA|sign_type|signType)/i.test(sourceText);
  const hasAlgorithmDispatch =
    /switch\s*\([^)]*(?:signType|sign_type|getSignType)|case\s+["'](?:MD5|DSA|RSA)["']|if\s*\([^)]*(?:signType|sign_type|getSignType)[^)]*(?:MD5|DSA|RSA)[^)]*\)[\s\S]{0,260}(?:MessageDigest|Signature\.getInstance)/i.test(sourceText);
  if (exposesConfigurableSignType && fixedRsaImplementation && !hasSignTypeRestriction && !hasAlgorithmDispatch) {
    errors.push("MAPI sign_type 可配置时，签名/验签实现必须与配置一致；如果代码只实现 RSA，请启动时校验只允许 sign_type=RSA，不能请求发 MD5/DSA 却仍用 RSA 签名。");
  }
}
requireWhen(usesDutThird || usesDutQuery, /mr_dut_third/, "第三方代扣执行/查询必须包含 protocol_code=mr_dut_third。");
requireWhen(usesDutThird || usesDutQuery, /DEFAULT/, "第三方代扣执行/查询必须包含 item_code=DEFAULT。");
requireWhen(usesDutThird, /enterprisePay/, "因公付代扣执行必须包含 enable_pay_channels=enterprisePay。");
requireWhen(usesDutThird, /assignJointAccountId|business_info|businessInfo/, "因公付代扣执行必须包含 business_info.assignJointAccountId。");
requireSourceWhen(usesDutThird, /(?:requireText|requireNonBlank|requireNonEmpty|notBlank|required|validateRequired|assertNotBlank|hasText|isNotBlank)[^;\n]{0,180}(?:assignJointAccountId|assign_joint_account_id)|(?:assignJointAccountId|assign_joint_account_id)[^;\n]{0,220}(?:isBlank|isEmpty|trim\(\)|length\s*[=!<>]=?\s*0|len\(|hasText|isBlank)/i, "代扣执行必须在发起请求前校验 assignJointAccountId 非空，不能带空 business_info.assignJointAccountId 落库或发 MAPI。");
requireSourceWhen(usesDutThird, /(?:requireText|requireNonBlank|requireNonEmpty|notBlank|required|validateRequired|assertNotBlank|hasText|isNotBlank)[^;\n]{0,180}(?:transAccountOut|trans_account_out)|(?:transAccountOut|trans_account_out)[^;\n]{0,220}(?:isBlank|isEmpty|trim\(\)|length\s*[=!<>]=?\s*0|len\(|hasText|isBlank)/i, "代扣执行必须在发起请求前校验 trans_account_out 非空，不能带空资金账号落库或发 MAPI。");
requireSourceWhen(usesDutThird, /(?:requireText|requireNonBlank|requireNonEmpty|notBlank|required|validateRequired|assertNotBlank|hasText|isNotBlank)[^;\n]{0,180}(?:payerUserId|payer_user_id)|(?:payerUserId|payer_user_id)[^;\n]{0,220}(?:isBlank|isEmpty|trim\(\)|length\s*[=!<>]=?\s*0|len\(|hasText|isBlank)/i, "代扣执行必须在发起请求前校验 payer_user_id 非空，不能带空付款人落库或发 MAPI。");
requireWhen(usesDutThird, /submit_param|submitParam/, "代扣执行必须包含 submit_param。");
requireWhen(usesDutThird, /payer_user_id|payerUserId/, "火车票代扣执行接通样例包含 payer_user_id；请确认执行请求传入实际付款人。");
requireWhen(usesDutThird, /alipay\.acquire\.mr\.ord\.createandpay|INNER_12306_SERVICE|inner.*service/i, "代扣执行必须校验 submit_param 内层 service=alipay.acquire.mr.ord.createandpay。");
requireWhen(usesDutThird, /ord_id_ext|ordIdExt/, "代扣执行必须从 submit_param 解码保存 12306 ord_id_ext。");
requireWhen(usesDutThird, /extract.*partner|partner.*extract|trade_partner|tradePartner|railwayPartner/i, "代扣执行必须从 submit_param 解码提取 12306 partner，作为后续 trade_partner。");
requireWhen(usesDutThird, /ord_pmt_timeout|ordPmtTimeout|pmtTimeout|paymentTimeout/i, "代扣执行必须只读解析 submit_param.ord_pmt_timeout，并在已过期或不足 60 秒时拒绝发起代扣。");
requireWhen(usesDutThird, /SUBMIT_PARAM_SIGN_ERROR|malformed|invalid.*submit|invalidSubmit|key=value|空 key|空key|异常字段|非法字段|产品契约外/i, "代扣执行必须对 submit_param 原始 Query String 做结构诊断：非 key=value、空 key、关键字段空值或产品契约外异常字段应拒绝或暂停确认，并保留 SUBMIT_PARAM_SIGN_ERROR 风险诊断。");
requireWhen(usesDutThird, /TRADE_BUYER_NOT_MATCH|payer(?:UserId|_user_id)[\s\S]{0,240}(?:match|same|consistent|bind|绑定|一致)|(?:submit_param|ord_id_ext|out_order_no)[\s\S]{0,240}payer(?:UserId|_user_id)/i, "代扣执行必须约束同一 submit_param/ord_id_ext/out_order_no 与同一 payer_user_id 绑定，不能换付款人重试。");

if (usesDutThird) {
  const submitParamValidationSource = strippedSourceText;
  const submitParamValidationTests = testText;
  const hasSubmitParamAllowedFields =
    /(?:ALLOWED|ALLOW|SUPPORTED|EXPECTED|PERMITTED|KNOWN|LEGAL|VALID)[A-Za-z0-9_]*(?:SUBMIT|SUBMIT_PARAM|INNER|QUERY|12306)[A-Za-z0-9_]*(?:FIELDS|KEYS|PARAMS)|(?:SUBMIT|SUBMIT_PARAM|INNER|QUERY|12306)[A-Za-z0-9_]*(?:ALLOWED|ALLOW|SUPPORTED|EXPECTED|PERMITTED|KNOWN|LEGAL|VALID)[A-Za-z0-9_]*(?:FIELDS|KEYS|PARAMS)|(?:allowed|supported|expected|permitted|known|legal|valid)(?:SubmitParam|Inner|Query|Railway|Train|12306)[A-Za-z0-9_]*(?:Fields|Keys|Params)|字段白名单|允许字段集合/i.test(submitParamValidationSource)
    && /service/.test(submitParamValidationSource)
    && /partner/.test(submitParamValidationSource)
    && /ord_id_ext|ordIdExt/.test(submitParamValidationSource);
  const hasSubmitParamRequiredFields =
    /(?:REQUIRED|MANDATORY|NON_EMPTY|NOT_BLANK)[A-Za-z0-9_]*(?:SUBMIT|SUBMIT_PARAM|INNER|QUERY|12306)[A-Za-z0-9_]*(?:FIELDS|KEYS|PARAMS)|(?:SUBMIT|SUBMIT_PARAM|INNER|QUERY|12306)[A-Za-z0-9_]*(?:REQUIRED|MANDATORY|NON_EMPTY|NOT_BLANK)[A-Za-z0-9_]*(?:FIELDS|KEYS|PARAMS)|(?:required|mandatory|nonEmpty|notBlank)(?:SubmitParam|Inner|Query|Railway|Train|12306)[A-Za-z0-9_]*(?:Fields|Keys|Params)|必填字段集合/i.test(submitParamValidationSource)
    && /service/.test(submitParamValidationSource)
    && /partner/.test(submitParamValidationSource)
    && /ord_id_ext|ordIdExt/.test(submitParamValidationSource);
  const hasSubmitParamAllowedEmptyFields =
    /(?:ALLOWED_EMPTY|ALLOW_EMPTY|EMPTY_ALLOWED|OPTIONAL_EMPTY|NULLABLE|MAY_BE_EMPTY)[A-Za-z0-9_]*(?:SUBMIT|SUBMIT_PARAM|INNER|QUERY|12306|FIELDS|KEYS|PARAMS)|(?:SUBMIT|SUBMIT_PARAM|INNER|QUERY|12306)[A-Za-z0-9_]*(?:ALLOWED_EMPTY|ALLOW_EMPTY|EMPTY_ALLOWED|OPTIONAL_EMPTY|NULLABLE|MAY_BE_EMPTY)[A-Za-z0-9_]*(?:FIELDS|KEYS|PARAMS)|(?:allowedEmpty|allowEmpty|emptyAllowed|nullable|optionalEmpty)(?:SubmitParam|Inner|Query|Railway|Train|12306)?(?:Fields|Keys|Params)?|允许空值字段集合|可空字段集合/i.test(submitParamValidationSource);
  const rejectsUnexpectedSubmitParamField =
    /(?:!\s*[A-Za-z0-9_.]*(?:allowed|supported|expected|permitted|known|legal|valid)[A-Za-z0-9_.]*(?:Fields|Keys|Params)?\.contains\s*\([^)]*(?:key|name|field)[^)]*\)|(?:allowed|supported|expected|permitted|known|legal|valid)[A-Za-z0-9_.]*(?:Fields|Keys|Params)?\.contains\s*\([^)]*(?:key|name|field)[^)]*\)\s*==\s*false)[\s\S]{0,360}(?:throw|SUBMIT_PARAM_SIGN_ERROR|reject|拒绝|非法字段|异常字段|产品契约外)|(?:非法字段|异常字段|产品契约外|unknown|unsupported|unexpected)[\s\S]{0,300}(?:throw|SUBMIT_PARAM_SIGN_ERROR|reject|拒绝)/i.test(submitParamValidationSource);
  const rejectsDuplicateSubmitParamKey =
    /(?:containsKey\s*\([^)]*(?:key|name|field)[^)]*\)|putIfAbsent\s*\([^)]*(?:key|name|field)[^)]*\)|seen(?:Keys|Fields|Params)?\s*\.\s*(?:contains|add)\s*\([^)]*(?:key|name|field)[^)]*\)|(?:duplicate|重复)[^;\n]{0,160}(?:key|字段|参数))[\s\S]{0,320}(?:throw|SUBMIT_PARAM_SIGN_ERROR|reject|拒绝)|(?:throw|SUBMIT_PARAM_SIGN_ERROR|reject|拒绝)[\s\S]{0,260}(?:duplicate|重复)[^;\n]{0,160}(?:key|字段|参数)/i.test(submitParamValidationSource);
  const rejectsEmptySubmitParamSegment =
    /(?:pair|segment|part)[A-Za-z0-9_]*\.isEmpty\(\)[\s\S]{0,260}(?:throw|SUBMIT_PARAM_SIGN_ERROR|reject|拒绝)|(?:contains\s*\(\s*["']&&["']\s*\)|endsWith\s*\(\s*["']&["']\s*\)|连续[^;\n]{0,80}&|结尾[^;\n]{0,80}&|空片段|empty segment|blank segment)[\s\S]{0,320}(?:throw|SUBMIT_PARAM_SIGN_ERROR|reject|拒绝)/i.test(submitParamValidationSource);
  const rejectsWrongSubmitParamDelimiter =
    /(?:contains\s*\(\s*["'];["']\s*\)|contains\s*\(\s*["']\\n["']\s*\)|contains\s*\(\s*["']\\r["']\s*\)|wrongDelimiter|invalidDelimiter|delimiter|分隔符|分号|换行|空白分隔)[\s\S]{0,360}(?:throw|SUBMIT_PARAM_SIGN_ERROR|reject|拒绝|非法|错误)|(?:non\s+key=value|inner service must|service\s+must\s+be|field not in whitelist)[\s\S]{0,260}(?:SUBMIT_PARAM_SIGN_ERROR|reject|拒绝|fail)/i.test(submitParamValidationSource);
  const rejectsEmptyRequiredSubmitParamField =
    /(?:required|mandatory|nonEmpty|notBlank|必填)[\s\S]{0,420}(?:isBlank|isEmpty|trim\(\)|blank|empty|空值|空白)[\s\S]{0,420}(?:throw|SUBMIT_PARAM_SIGN_ERROR|reject|拒绝)|(?:service|partner|ord_id_ext|ordIdExt)[\s\S]{0,260}(?:isBlank|isEmpty|trim\(\)|blank|empty|空值|空白)[\s\S]{0,260}(?:throw|SUBMIT_PARAM_SIGN_ERROR|reject|拒绝)/i.test(submitParamValidationSource);
  const hasUnexpectedSubmitParamFieldTest =
    /(?:unknown|extra|unexpected|unsupported|非法字段|异常字段|产品契约外|notAllowed|not_allowed|extra_field|bogus_key|unknown=|extra=)[\s\S]{0,900}(?:assertThrows|toThrow|rejects\.toThrow|pytest\.raises|assertRaises|Assert\.Throws|SUBMIT_PARAM_SIGN_ERROR)/i.test(submitParamValidationTests);
  const hasDuplicateSubmitParamKeyTest =
    /(?:(?:duplicate|重复)[\s\S]{0,360}(?:key|字段|参数)|(?:service|partner|ord_id_ext|ordIdExt)=[^&\s"']*&(?:service|partner|ord_id_ext|ordIdExt)=)[\s\S]{0,900}(?:assertThrows|toThrow|rejects\.toThrow|pytest\.raises|assertRaises|Assert\.Throws|SUBMIT_PARAM_SIGN_ERROR)/i.test(submitParamValidationTests);
  const hasMalformedSubmitParamJoinTest =
    /(?:&&|尾部\s*&|结尾\s*&|trailing ampersand|empty segment|空片段|非\s*key=value|non[- ]?key[- ]?value|["'];["']|;partner|;ord_|semicolon|分号|错误分隔符|wrongDelimiter|invalidDelimiter|\\n|换行|newline)[\s\S]{0,900}(?:assertThrows|toThrow|rejects\.toThrow|pytest\.raises|assertRaises|Assert\.Throws|SUBMIT_PARAM_SIGN_ERROR|assertFalse\s*\([^)]*isValid\s*\()/i.test(submitParamValidationTests);
  const hasEmptyRequiredSubmitParamFieldTest =
    /(?:service=(&|["']|\s|$)|partner=(&|["']|\s|$)|ord_id_ext=(&|["']|\s|$)|ordIdExt[^;\n]{0,120}(?:empty|blank|空)|必填字段[^;\n]{0,120}(?:空值|空白|empty|blank)|required[^;\n]{0,120}(?:empty|blank))[\s\S]{0,900}(?:assertThrows|toThrow|rejects\.toThrow|pytest\.raises|assertRaises|Assert\.Throws|SUBMIT_PARAM_SIGN_ERROR)/i.test(submitParamValidationTests);
  const hasAllowedEmptySubmitParamFieldTest =
    /(?:req_client_ip_ext=|notify_url=|return_url=|allowed empty|allowEmpty|允许空值|普通空值)[\s\S]{0,900}(?:assertEquals|assertTrue|toEqual|toContain|contains|保留|preserve|原样)/i.test(submitParamValidationTests);
  const hasRawSubmitParamPreservationTest =
    /(?:原始 Query String|raw query|string|base64|decode|decoded|不重排|不重拼|not rebuild|preserve)[\s\S]{0,900}(?:assertEquals|assertTrue|toEqual|toContain|contains)/i.test(submitParamValidationTests);

  if (!hasSubmitParamAllowedFields) {
    errors.push("submit_param 内层必须按已确认的 12306 样例字段清单维护允许字段集合；至少包含 service、partner、ord_id_ext，并用于诊断示例字段以外的参数。");
  }
  if (!hasSubmitParamRequiredFields) {
    errors.push("submit_param 内层必须集中维护必填字段集合，并校验 service、partner、ord_id_ext 等关键字段缺失或空白时 fail fast。");
  }
  if (!hasSubmitParamAllowedEmptyFields) {
    errors.push("submit_param 内层必须集中维护允许空值字段集合；普通允许空字段要原样保留，不能删除、补值、重排或重签。");
  }
  if (!rejectsUnexpectedSubmitParamField) {
    errors.push("submit_param 内层解析必须拒绝或暂停确认示例字段以外的参数，并返回 SUBMIT_PARAM_SIGN_ERROR 风险诊断；不能静默忽略未知字段继续代扣。");
  }
  if (!rejectsDuplicateSubmitParamKey) {
    errors.push("submit_param 内层解析必须检测重复 key 并拒绝或诊断，不能让后一个值覆盖前一个值继续代扣。");
  }
  if (!rejectsEmptySubmitParamSegment) {
    errors.push("submit_param 内层解析必须检测连续 `&` 或结尾 `&` 造成的空片段，并返回 SUBMIT_PARAM_SIGN_ERROR 风险诊断。");
  }
  if (!rejectsWrongSubmitParamDelimiter) {
    errors.push("submit_param 内层 Query String 只能用 `&` 拼接；必须拒绝 `;`、换行或空白等错误分隔方式。");
  }
  if (!rejectsEmptyRequiredSubmitParamField) {
    errors.push("submit_param 内层必填字段值为空或空白时必须拒绝或暂停确认，不能只判断 key 存在。");
  }
  if (!hasUnexpectedSubmitParamFieldTest) {
    errors.push("submit_param 字段白名单测试必须覆盖示例字段以外的参数会被拒绝或返回 SUBMIT_PARAM_SIGN_ERROR。");
  }
  if (!hasDuplicateSubmitParamKeyTest) {
    errors.push("submit_param 字段白名单测试必须覆盖重复 key 会被拒绝或返回 SUBMIT_PARAM_SIGN_ERROR。");
  }
  if (!hasMalformedSubmitParamJoinTest) {
    errors.push("submit_param 字段白名单测试必须覆盖连续/结尾 `&`、非 `key=value` 片段或 `;`/换行/空白等错误分隔方式。");
  }
  if (!hasEmptyRequiredSubmitParamFieldTest) {
    errors.push("submit_param 字段白名单测试必须覆盖必填字段缺失或值为空/空白会被拒绝。");
  }
  if (!hasAllowedEmptySubmitParamFieldTest) {
    errors.push("submit_param 字段白名单测试必须覆盖允许空值字段会被原样保留，不被删除、补值、重排或重签。");
  }
  if (!hasRawSubmitParamPreservationTest) {
    errors.push("submit_param 测试必须证明白名单校验只用于只读诊断，不会用解析结果重拼 submit_param；base64 前后仍保持原始 Query String。");
  }

  const hardcodesNumericOrdPmtTimeout = /(?:Long|Integer|Double)\.parse(?:Long|Int|Double)\s*\([^)]*(?:ordPmtTimeout|ord_pmt_timeout|pmtTimeout|paymentTimeout)|parseInt\s*\([^)]*(?:ordPmtTimeout|ord_pmt_timeout|pmtTimeout|paymentTimeout)/i.test(strippedSourceText);
  const hasTimeoutFormatStrategy = /(?:ordPmtTimeout|ord_pmt_timeout|pmtTimeout|paymentTimeout)[\s\S]{0,260}(?:ordPmtTimeoutFormat|paymentTimeoutFormat|timeoutFormat|ordPmtTimeoutParser|paymentTimeoutParser|timeoutParser|ordPmtTimeoutUnit|paymentTimeoutUnit|timeoutUnit|formatConfig|epoch(?:Seconds|Millis)|产品契约|配置化|真实样例)|(?:ordPmtTimeoutFormat|paymentTimeoutFormat|timeoutFormat|formatConfig|parseOrdPmtTimeout|ordPmtTimeoutParser|paymentTimeoutParser|timeoutParser|ordPmtTimeoutUnit|paymentTimeoutUnit|timeoutUnit|epoch(?:Seconds|Millis)|产品契约|配置化|真实样例)[\s\S]{0,260}(?:ordPmtTimeout|ord_pmt_timeout|pmtTimeout|paymentTimeout)/i.test(strippedSourceText)
    || /(?:DateTimeFormatter|Instant\.parse|LocalDateTime|OffsetDateTime|ZonedDateTime|Duration|TimeUnit|ChronoUnit)[\s\S]{0,520}(?:ordPmtTimeout|ord_pmt_timeout|pmtTimeout|paymentTimeout)|(?:ordPmtTimeout|ord_pmt_timeout|pmtTimeout|paymentTimeout)[\s\S]{0,520}(?:DateTimeFormatter|Instant\.parse|LocalDateTime|OffsetDateTime|ZonedDateTime|Duration|TimeUnit|ChronoUnit)/i.test(strippedSourceText);
  if (/ord_pmt_timeout|ordPmtTimeout|pmtTimeout|paymentTimeout/i.test(sourceText) && hardcodesNumericOrdPmtTimeout && !hasTimeoutFormatStrategy) {
    errors.push("ord_pmt_timeout 的格式必须来自真实样例/产品契约/配置化解析策略；不得无依据只用 Long.parseLong/parseInt 固定猜成 epoch 秒或单一数值格式。");
  }
  const declaresTimeoutStrategy = /OrdPmtTimeoutFormat|ordPmtTimeoutFormat|paymentTimeoutFormat|timeoutFormat|parseOrdPmtTimeout|ord_pmt_timeout[^\n]{0,120}format/i.test(sourceText);
  const hasTimeoutRuntimeConfig = /(?:@Value|ConfigurationProperties|Environment\.|getProperty\s*\(|System\.getenv|process\.env|application\.(?:ya?ml|properties)|config|properties|env)[\s\S]{0,320}(?:ordPmtTimeoutFormat|ord_pmt_timeout_format|ord[-_]?pmt[-_]?timeout[-_]?format|timeoutFormat)|(?:ordPmtTimeoutFormat|ord_pmt_timeout_format|ord[-_]?pmt[-_]?timeout[-_]?format|timeoutFormat)[\s\S]{0,320}(?:@Value|ConfigurationProperties|Environment\.|getProperty\s*\(|System\.getenv|process\.env|config|properties|env)|constructor[^\n]{0,200}(?:OrdPmtTimeoutFormat|ordPmtTimeoutFormat|timeoutFormat)|new\s+SubmitParamBuilder\s*\([^)]*(?:OrdPmtTimeoutFormat|timeoutFormat)|setOrdPmtTimeoutFormat\s*\([^;]*(?:properties|config|env|getProperty|OrdPmtTimeoutFormat\.(?!epochSeconds))|ord-pmt-timeout-format|ord_pmt_timeout_format|(?:ord[-_]?pmt[-_]?timeout[-_]?format|ordPmtTimeoutFormat)\s*[:=]\s*(?:\$\{|[A-Z_]+_|config|properties|env|epochMillis|dateTime)/i.test(text);
  const hasTimeoutFormatSwitchTest = /OrdPmtTimeoutFormat|ordPmtTimeoutFormat|timeoutFormat|epochMillis|dateTime|无法识别格式|unknown.*format|配置.*格式|构造参数.*格式/i.test(testText);
  if (/ord_pmt_timeout|ordPmtTimeout|pmtTimeout|paymentTimeout/i.test(sourceText) && declaresTimeoutStrategy && !hasTimeoutRuntimeConfig) {
    errors.push("ord_pmt_timeout 的配置化解析策略必须有运行时配置、构造参数或明确产品常量进入代码路径；只有类内 setter、默认 epochSeconds 枚举或注释说明不算格式来源落地。");
  }
  if (/ord_pmt_timeout|ordPmtTimeout|pmtTimeout|paymentTimeout/i.test(sourceText) && declaresTimeoutStrategy && !hasTimeoutFormatSwitchTest) {
    errors.push("submit_param.ord_pmt_timeout 测试必须覆盖格式来源/配置入口或构造参数能切换策略，并覆盖无法识别格式时拒绝或暂停；不能只测默认 epoch 秒。");
  }

  const hasPaymentAgreementGate = /(?:AgreementStatus\.NORMAL|AGREEMENT_STATUS_NORMAL|status\s*[=!]=+\s*["']NORMAL["']|协议[^;\n]{0,120}(?:NORMAL|有效|可代扣)|confirmAgreementByQuery|findAgreementByExternalUser|findByExternalUserId|findAgreementByNo|agreementRepository|agreementService|协议查询)[\s\S]{0,1800}(?:throw|IllegalStateException|ValidationException|reject|拒绝|不可代扣|未签约|return|null)|(?:throw|IllegalStateException|ValidationException|reject|拒绝|不可代扣|未签约|return|null)[\s\S]{0,1800}(?:AgreementStatus\.NORMAL|AGREEMENT_STATUS_NORMAL|协议[^;\n]{0,120}(?:NORMAL|有效|可代扣)|confirmAgreementByQuery|findAgreementByExternalUser|findByExternalUserId|findAgreementByNo)/i.test(strippedWithholdThirdSourceText);
  const paymentAgreementGateIndex = firstIndexOfAny(withholdThirdOrderText, [
    /checkAgreementValidity\s*\(/i,
    /AgreementStatus\.NORMAL|AGREEMENT_STATUS_NORMAL|confirmAgreementByQuery|findAgreementByExternalUser|findByExternalUserId|findAgreementByNo|协议[^;\n]{0,120}(?:NORMAL|有效|可代扣)/i,
  ]);
  const orderMapiCallIndex = firstIndexOfAny(withholdThirdOrderText, [
    /dut\.agent\.third|SERVICE_DUT_AGENT_THIRD|httpClient\.get\s*\(|httpClient\.post\s*\(|\.(?:execute|send)\s*\(/i,
  ]);
  const hasPaymentAgreementGateBeforeMapi = hasPaymentAgreementGate
    && paymentAgreementGateIndex >= 0
    && orderMapiCallIndex >= 0
    && paymentAgreementGateIndex < orderMapiCallIndex;
  const hasPaymentAgreementGateTest = /(?:AgreementStatus|协议|agreement|NORMAL|SIGNING|UNSIGNING|FAILED|未签约|不可代扣|AGREEMENT_NOT_VALID)[\s\S]{0,1600}(?:assertThrows|toThrow|rejects\.toThrow|callCount|times\s*\(\s*0\s*\)|never\s*\(\s*\)|not\s+call|不调用|拒绝|允许|放行|assertFalse\s*\([^)]*isSuccess\s*\(|AGREEMENT_NOT_VALID)/i.test(withholdThirdTestText);
  if (!hasPaymentAgreementGateBeforeMapi) {
    errors.push("发起 dut.agent.third 前必须先确认三方免密代扣协议有效：本地可信状态 NORMAL 或协议查询可信确认通过；无协议、SIGNING/UNSIGNING/FAILED、查询不可确认或身份不匹配时不得落新单或调用 MAPI。");
  }
  if (!hasPaymentAgreementGateTest) {
    errors.push("代扣执行测试必须覆盖支付前协议门禁：无协议、SIGNING/UNSIGNING/FAILED 或查询不可确认时不调用 dut.agent.third，只有 NORMAL/可信查询确认通过才允许继续。");
  }

  const agreementPayerComparable =
    /(?:getAlipayUserId\s*\(\)|agreement[^;\n]{0,120}(?:alipayUserId|alipay_user_id)|localAgreement[^;\n]{0,120}(?:alipayUserId|alipay_user_id)|paymentAgreement[^;\n]{0,120}(?:alipayUserId|alipay_user_id)|agreementAlipayUserId|boundAlipayUserId|协议[^;\n]{0,80}alipay_user_id)[\s\S]{0,520}(?:equals|Objects\.equals|==|===|!=|!==|不一致|mismatch|match|same|一致)[\s\S]{0,320}(?:payerUserId|payer_user_id|付款人)|(?:payerUserId|payer_user_id|付款人)[\s\S]{0,320}(?:equals|Objects\.equals|==|===|!=|!==|不一致|mismatch|match|same|一致)[\s\S]{0,520}(?:getAlipayUserId\s*\(\)|agreement[^;\n]{0,120}(?:alipayUserId|alipay_user_id)|localAgreement[^;\n]{0,120}(?:alipayUserId|alipay_user_id)|paymentAgreement[^;\n]{0,120}(?:alipayUserId|alipay_user_id)|agreementAlipayUserId|boundAlipayUserId|协议[^;\n]{0,80}alipay_user_id)/i.test(strippedWithholdThirdSourceText);
  const agreementPayerCheckIndex = firstIndexOfAny(withholdThirdOrderText, [
    /checkAgreementValidity\s*\(/i,
    /getAlipayUserId\s*\(\)/i,
    /agreement[^;\n]{0,120}(?:alipayUserId|alipay_user_id)/i,
    /localAgreement[^;\n]{0,120}(?:alipayUserId|alipay_user_id)/i,
    /paymentAgreement[^;\n]{0,120}(?:alipayUserId|alipay_user_id)/i,
    /agreementAlipayUserId|boundAlipayUserId/i,
  ]);
  const mapiCallIndex = firstIndexOfAny(withholdThirdOrderText, [
    /dut\.agent\.third|SERVICE_DUT_AGENT_THIRD|httpClient\.get\s*\(|httpClient\.post\s*\(|\.(?:execute|send)\s*\(/i,
  ]);
  const hasAgreementPayerCheckBeforeMapi = agreementPayerComparable
    && agreementPayerCheckIndex >= 0
    && mapiCallIndex >= 0
    && agreementPayerCheckIndex < mapiCallIndex;
  const hasAgreementPayerMismatchTest =
    /(?:agreement|协议)[\s\S]{0,900}(?:alipayUserId|alipay_user_id|支付宝\s*UID)[\s\S]{0,900}(?:payerUserId|payer_user_id|付款人)[\s\S]{0,900}(?:mismatch|different|wrong|other|不一致|不匹配|串单|其他|错误)[\s\S]{0,900}(?:assertThrows|toThrow|rejects\.toThrow|IllegalStateException|ValidationException|callCount|times\s*\(\s*0\s*\)|never\s*\(\s*\)|not\s+call|不调用|不落单|拒绝|assertFalse\s*\([^)]*isSuccess\s*\(|AGREEMENT_NOT_VALID|PAYER_USER_ID_MISMATCH)|(?:payerUserId|payer_user_id|付款人)[\s\S]{0,900}(?:agreement|协议)[\s\S]{0,900}(?:alipayUserId|alipay_user_id|支付宝\s*UID)[\s\S]{0,900}(?:mismatch|different|wrong|other|不一致|不匹配|串单|其他|错误)[\s\S]{0,900}(?:assertThrows|toThrow|rejects\.toThrow|IllegalStateException|ValidationException|callCount|times\s*\(\s*0\s*\)|never\s*\(\s*\)|not\s+call|不调用|不落单|拒绝|assertFalse\s*\([^)]*isSuccess\s*\(|AGREEMENT_NOT_VALID|PAYER_USER_ID_MISMATCH)/i.test(withholdThirdTestText);
  if (!hasAgreementPayerCheckBeforeMapi) {
    errors.push("代扣执行在确认协议 NORMAL 后，还必须校验协议主体与本次付款人一致：本地协议/可信查询响应中的 alipay_user_id 必须等于本次 dut.agent.third 的 payer_user_id；不一致时不得落新单或调用 MAPI。");
  }
  if (!hasAgreementPayerMismatchTest) {
    errors.push("代扣执行测试必须覆盖协议 alipay_user_id 与本次 payer_user_id 不一致时拒绝发起，并证明不落新单、不调用 dut.agent.third。");
  }

  const hasIdempotentReturnCode = /(?:idempotent|Idempotent|alreadyExists|duplicate|Duplicate|existingOrder|existingResult|returnExisting|幂等|重复)[\s\S]{0,1200}return\s+/i.test(strippedWithholdThirdSourceText);
  const hasNoSecondMapiCallTest = /(?:idempotent|Idempotent|幂等|重复)[\s\S]{0,1400}(?:callCount|times\s*\(\s*1\s*\)|verifyNoMoreInteractions|never\s*\(\s*\)|not\s+call|not\s+invoke|不再次调用|不再调用|只调用一次|不得再次|不生成新\s*out_biz_no|已有订单|已有结果)/i.test(testText);
  const idempotentLookupIndex = firstIndexOfAny(withholdThirdOrderText, [
    /findExistingForIdempotent|existingOrder|existingResult|returnExisting|idempotent|Idempotent|duplicate|Duplicate|幂等|重复/i,
    /findOrderByOutOrderNo|findOrderByOrdIdExt|findByOutOrderNo|findByOrdIdExt|findExistingOrder/i,
  ]);
  const agreementGateIndex = firstIndexOfAny(withholdThirdOrderText, [
    /AgreementStatus\.NORMAL|status\s*[=!]=+\s*["']NORMAL["']|协议[^;\n]{0,120}(?:NORMAL|有效|可代扣)|confirmAgreementByQuery|findAgreementByExternalUser|findAgreementByNo|agreementRepository|agreementService|协议查询/i,
  ]);
  const hasIdempotentLookupBeforeAgreementGate = idempotentLookupIndex >= 0
    && (agreementGateIndex < 0 || idempotentLookupIndex < agreementGateIndex);
  const hasIdempotentDespiteAgreementStateTest =
    /(?:idempotent|Idempotent|幂等|重复|已有订单|existingOrder|existingResult)[\s\S]{0,1800}(?:UNSIGNING|FAILED|SIGNING|非\s*NORMAL|not\s+normal|协议状态|agreement\s+status)[\s\S]{0,1800}(?:callCount|times\s*\(\s*1\s*\)|never\s*\(\s*\)|not\s+call|不调用|不落单|返回已有|已有结果|existingResult|idempotent)|(?:UNSIGNING|FAILED|SIGNING|非\s*NORMAL|not\s+normal|协议状态|agreement\s+status)[\s\S]{0,1800}(?:idempotent|Idempotent|幂等|重复|已有订单|existingOrder|existingResult)[\s\S]{0,1800}(?:callCount|times\s*\(\s*1\s*\)|never\s*\(\s*\)|not\s+call|不调用|不落单|返回已有|已有结果|existingResult|idempotent)/i.test(withholdThirdTestText);
  const outOrderNoLookupIndex = firstIndexOfAny(withholdThirdOrderText, [
    /findOrderByOutOrderNo\s*\(|findByOutOrderNo\s*\(|findExistingByOutOrderNo\s*\(|lookupExistingByOutOrderNo\s*\(|existingByOutOrderNo\s*\(/i,
  ]);
  const submitParamStructureReadIndex = firstIndexOfAny(withholdThirdOrderText, [
    /submitParamBuilder\s*\.\s*(?:build|decode|parse|validate|extract)/i,
    /buildSubmitParam\s*\(|decodeSubmitParam\s*\(|parseInnerParams\s*\(|validateForKeyedNewWithhold\s*\(|extractOrdIdExt/i,
    /Base64\.getDecoder\s*\(|substring\s*\([^)]*\?\s*\)/i,
  ]);
  const idempotentLookupReceivesParsedSubmitParam =
    /findExistingForIdempotent[^(]*\([\s\S]{0,520}(?:extractOrdIdExt|parseInnerParams|validateForKeyed|submitParamBuilder\s*\.\s*(?:extract|parse|validate|decode|build))/i.test(withholdThirdOrderText);
  const hasOutOrderNoLookupBeforeSubmitParamRead =
    outOrderNoLookupIndex >= 0
    && (submitParamStructureReadIndex < 0 || outOrderNoLookupIndex < submitParamStructureReadIndex)
    && !idempotentLookupReceivesParsedSubmitParam;
  const hasMalformedSubmitParamOutOrderNoIdempotentTest =
    /(?:bogus_key|extra_field|示例外字段|字段白名单以外|partner=&|缺少\s*partner|missing\s*partner|&&|连续\s*&|结尾\s*&|错误分隔符|wrongDelimiter|invalidDelimiter|结构异常)[\s\S]{0,2400}(?:assertEquals\s*\(\s*["']true["'][\s\S]{0,240}idempotent|idempotent[\s\S]{0,240}(?:assertEquals|toEqual)|callCount|times\s*\(\s*1\s*\)|不调用|不落新单|返回已有|已有结果)|(?:assertEquals\s*\(\s*["']true["'][\s\S]{0,240}idempotent|idempotent[\s\S]{0,240}(?:assertEquals|toEqual)|callCount|times\s*\(\s*1\s*\)|不调用|不落新单|返回已有|已有结果)[\s\S]{0,2400}(?:bogus_key|extra_field|示例外字段|字段白名单以外|partner=&|缺少\s*partner|missing\s*partner|&&|连续\s*&|结尾\s*&|错误分隔符|wrongDelimiter|invalidDelimiter|结构异常)/i.test(withholdThirdTestText);
  const submitParamTimeoutGateIndex = firstIndexOfAny(withholdThirdOrderText, [
    /validateAndExtract\s*\(/i,
    /checkPaymentTimeout|validatePaymentTimeout|PAYMENT_TIMEOUT/i,
    /(?:ordPmtTimeout|ord_pmt_timeout)[\s\S]{0,240}(?:expired|过期|不足\s*60|60\s*秒|throw|reject|拒绝|IllegalStateException|PAYMENT_TIMEOUT)/i,
  ]);
  const hasTimeoutGateBeforeIdempotency = submitParamTimeoutGateIndex >= 0
    && idempotentLookupIndex >= 0
    && submitParamTimeoutGateIndex < idempotentLookupIndex;
  const hasExpiredTimeoutIdempotentTest =
    /(?:ord_pmt_timeout|ordPmtTimeout|PAYMENT_TIMEOUT|过期|expired|不足\s*60|60\s*秒|timeout)[\s\S]{0,2200}(?:idempotent|Idempotent|幂等|重复|已有订单|existingOrder|existingResult)[\s\S]{0,2200}(?:callCount|times\s*\(\s*1\s*\)|never\s*\(\s*\)|not\s+call|不调用|不落单|返回已有|已有结果|existingResult|idempotent)|(?:idempotent|Idempotent|幂等|重复|已有订单|existingOrder|existingResult)[\s\S]{0,2200}(?:ord_pmt_timeout|ordPmtTimeout|PAYMENT_TIMEOUT|过期|expired|不足\s*60|60\s*秒|timeout)[\s\S]{0,2200}(?:callCount|times\s*\(\s*1\s*\)|never\s*\(\s*\)|not\s+call|不调用|不落单|返回已有|已有结果|existingResult|idempotent)/i.test(withholdThirdTestText);
  const idempotentReturnsRequestOutOrderNo =
    /(?:idempotent|Idempotent|existingOrder|existingResult|已有订单|幂等)[\s\S]{0,1600}(?:put|set|return|Map\.of)[^;\n]{0,220}["']out_order_no["'][^;\n]{0,160}(?:,\s*)?(?:outOrderNo|out_order_no)\b/i.test(strippedWithholdThirdSourceText);
  const hasCanonicalOutOrderNoHandling =
    /(?:existingOrder|existing|savedOrder|storedOrder)\.getOutOrderNo\s*\(\)[\s\S]{0,420}(?:put|set|return|Map\.of)[^;\n]{0,220}["']out_order_no["']|(?:put|set|return|Map\.of)[^;\n]{0,220}["']out_order_no["'][^;\n]{0,220}(?:existingOrder|existing|savedOrder|storedOrder)\.getOutOrderNo\s*\(\)|canonicalOutOrderNo|savedOutOrderNo|storedOutOrderNo|(?:existingOrder|existing|savedOrder|storedOrder)\.getOutOrderNo\s*\(\)[\s\S]{0,520}(?:outOrderNo|out_order_no)[\s\S]{0,520}(?:throw|reject|拒绝|诊断)|(?:outOrderNo|out_order_no)[\s\S]{0,520}(?:existingOrder|existing|savedOrder|storedOrder)\.getOutOrderNo\s*\(\)[\s\S]{0,520}(?:throw|reject|拒绝|诊断)/i.test(strippedWithholdThirdSourceText);
  const hasOrdIdExtDifferentOutOrderNoTest =
    /(?:differentOutOrderNo|otherOutOrderNo|anotherOutOrderNo|SECOND_OUT_ORDER|OTHER_OUT_ORDER|canonicalOutOrderNo|savedOutOrderNo|storedOutOrderNo|不同[^;\n]{0,120}(?:outOrderNo|out_order_no)|(?:outOrderNo|out_order_no)[^;\n]{0,120}不同|本次[^;\n]{0,120}(?:outOrderNo|out_order_no)[^;\n]{0,160}已有|已有[^;\n]{0,160}(?:outOrderNo|out_order_no)[^;\n]{0,120}本次)[\s\S]{0,2400}(?:ord_id_ext|ordIdExt)[\s\S]{0,2400}(?:idempotent|Idempotent|幂等|重复|已有订单|existingOrder|existingResult|assertEquals|assertThrows|toThrow|拒绝|诊断|canonical|getOutOrderNo)|(?:ord_id_ext|ordIdExt)[\s\S]{0,2400}(?:differentOutOrderNo|otherOutOrderNo|anotherOutOrderNo|SECOND_OUT_ORDER|OTHER_OUT_ORDER|canonicalOutOrderNo|savedOutOrderNo|storedOutOrderNo|不同[^;\n]{0,120}(?:outOrderNo|out_order_no)|(?:outOrderNo|out_order_no)[^;\n]{0,120}不同|本次[^;\n]{0,120}(?:outOrderNo|out_order_no)[^;\n]{0,160}已有|已有[^;\n]{0,160}(?:outOrderNo|out_order_no)[^;\n]{0,120}本次)[\s\S]{0,2400}(?:idempotent|Idempotent|幂等|重复|已有订单|existingOrder|existingResult|assertEquals|assertThrows|toThrow|拒绝|诊断|canonical|getOutOrderNo)/i.test(withholdThirdTestText);
  if (!hasIdempotentReturnCode) {
    errors.push("重复 submit_param/ord_id_ext/out_order_no 且 payer_user_id 相同时必须是真幂等：在调用 MAPI 前返回已有订单/已有同步结果/明确幂等结果，不能继续生成新 out_biz_no 并再次调用 dut.agent.third。");
  }
  if (!hasNoSecondMapiCallTest) {
    errors.push("代扣执行测试必须证明同 payer_user_id 的重复外部交易不会再次调用 dut.agent.third、不会生成新 out_biz_no；只测试“不抛错”不算幂等覆盖。");
  }
  if (!hasIdempotentLookupBeforeAgreementGate) {
    errors.push("同一 submit_param/ord_id_ext/out_order_no 且 payer_user_id 一致的已有订单重试，应先命中幂等并返回已有结果；协议 NORMAL 门禁用于新代扣发起，不能把已有订单重试挡在当前协议状态校验之前。");
  }
  if (!hasIdempotentDespiteAgreementStateTest) {
    errors.push("代扣执行测试必须覆盖已有订单幂等重试优先于新单协议门禁：当前协议状态变为 SIGNING/UNSIGNING/FAILED 时，同 payer_user_id 重复请求仍应返回已有结果、不落新单、不调用 dut.agent.third。");
  }
  if (!hasOutOrderNoLookupBeforeSubmitParamRead) {
    errors.push("已有订单幂等重试必须先按 out_order_no 查询已有订单，并且该查询必须发生在 submit_param 构造、base64、解码、解析、白名单/必填校验、ord_pmt_timeout 校验或 ord_id_ext 提取之前；不能把解析 submit_param 的结果作为 out_order_no 幂等查询的前置参数。");
  }
  if (!hasMalformedSubmitParamOutOrderNoIdempotentTest) {
    errors.push("代扣执行测试必须覆盖同 out_order_no 已命中且 payer_user_id 一致时，本次支付串缺少 partner、示例外字段、重复 key、连续/结尾 & 或错误分隔符等结构异常也应直接返回已有幂等结果，不触发 submit_param 结构诊断、不落新单、不调用 dut.agent.third。");
  }
  if (hasTimeoutGateBeforeIdempotency) {
    errors.push("已有订单幂等重试必须优先于 ord_pmt_timeout 时效门禁；不能在幂等命中前调用会因支付串过期/不足 60 秒而抛错的完整 submit_param 校验。");
  }
  if (!hasExpiredTimeoutIdempotentTest) {
    errors.push("代扣执行测试必须覆盖已有订单幂等重试不受 ord_pmt_timeout 过期/不足 60 秒影响：同 payer_user_id 重复请求应返回已有结果、不落新单、不调用 dut.agent.third。");
  }
  if (idempotentReturnsRequestOutOrderNo && !hasCanonicalOutOrderNoHandling) {
    errors.push("幂等命中已有订单时返回的 out_order_no 必须来自已有订单保存值，或在本次 out_order_no 与已有订单不一致时拒绝/诊断；不能把已有 out_biz_no/trade_no 和本次未落库 out_order_no 混合返回。");
  }
  if (!hasOrdIdExtDifferentOutOrderNoTest) {
    errors.push("代扣执行测试必须覆盖通过 ord_id_ext 命中已有订单但本次 out_order_no 不同的场景：返回已有订单 canonical out_order_no，或明确拒绝/诊断。");
  }
}
requireWhen(usesDutQuery, /trade_partner|tradePartner/, "代扣结果查询必须包含 trade_partner，用于传 12306 PID。");
requireWhen(usesDutQuery, /out_order_no|outOrderNo|trade_no|tradeNo/, "代扣结果查询必须包含 trade_no 或 out_order_no。");
requireWhen(usesDutQuery, /trans_account_out|transAccountOut/, "代扣结果查询必须包含 trans_account_out，且与代扣执行一致。");
requireWhen(usesDutQuery, /payer_user_id|payerUserId/, "火车票代扣结果查询 dut.agent.query.third 必须包含 payer_user_id。");
requireWhen(usesDutQuery, /query_time|queryTime/, "代扣结果查询必须包含 query_time。");

if (usesDutThird) {
  const thirdCheckText = withholdThirdSourceText || sourceText;
  const thirdCheckCode = stripComments(thirdCheckText);
  const parsesThirdXml =
    /xmlParser|parseXml|parseXML|MapiXml|DocumentBuilder|SAXParser|StringReader|<alipay|XML/i.test(thirdCheckText);
  const updatesThirdOrderFromXml =
    /setStatus\s*\(|saveOrder|repository\.save|order\.(?:setTradeNo|setOutOrderNo)\s*\(|SYNC_SUCCESS|SYNC_FAILED/i.test(thirdCheckCode);
  if (parsesThirdXml && updatesThirdOrderFromXml && !hasExplicitSignatureVerifyCall(thirdCheckCode)) {
    errors.push("代扣执行 dut.agent.third 的 XML 同步响应必须先做 MAPI 验签；验签通过后才允许更新订单状态或写回 trade_no/out_order_no。");
  }
  const hasThirdXmlSignatureFailureTest =
    /(?:XML|xml)[\s\S]{0,260}(?:sign|signature|验签)[\s\S]{0,520}(?:fail|失败|tamper|篡改|missing|缺少|parse|解析)[\s\S]{0,520}(?:not\s+update|not\s+write|不更新|不写回|保持|unchanged|原状态|assertEquals)/i.test(testText);
  if (parsesThirdXml && updatesThirdOrderFromXml && !hasThirdXmlSignatureFailureTest) {
    errors.push("代扣执行测试必须覆盖 XML 同步响应验签失败或缺少签名时，不更新订单状态、不写回 trade_no/out_order_no。");
  }
  const updatesThirdStatusOnSignatureFailure =
    new RegExp(String.raw`if\s*\([^)]*signatureVerified[^)]*\)\s*\{[\s\S]{0,1800}\}\s*else\s*\{[\s\S]{0,420}${SET_STATUS_EXPLICIT_FAILURE}`).test(thirdCheckCode)
    || new RegExp(String.raw`(?:signature_verify|验签失败|缺少签名|missing.*sign)[\s\S]{0,520}${SET_STATUS_EXPLICIT_FAILURE}`).test(thirdCheckCode);
  if (parsesThirdXml && updatesThirdStatusOnSignatureFailure) {
    errors.push("代扣执行 XML 验签失败/缺少签名/无法抽参时不得更新订单状态；不能把订单置为 SYNC_FAILED 或其他失败态，只能保持原状态并拒绝写回响应字段。");
  }
  const hasBadThirdSignatureFailureAssertion =
    /(?:XML|xml)[\s\S]{0,360}(?:sign|signature|验签)[\s\S]{0,900}(?:assertEquals|toEqual|toBe)[\s\S]{0,240}SYNC_FAILED|SYNC_FAILED[\s\S]{0,240}(?:验签失败|缺少签名|missing.*sign)/i.test(testText);
  if (hasBadThirdSignatureFailureAssertion) {
    errors.push("代扣执行验签失败测试不能断言 SYNC_FAILED；应断言订单保持发起代扣后的原状态且 trade_no/out_order_no 不写回。");
  }
  const returnsUntrustedThirdXmlFields =
    /(?:signature_verify|signatureVerified)[\s\S]{0,360}(?:["']fail["']|false)[\s\S]{0,1200}(?:new\s+LinkedHashMap<>\s*\(\s*syncResult\s*\)|putAll\s*\(\s*syncResult\s*\))/i.test(thirdCheckCode)
    && !/(?:safeResult|trustedResult|failureResult|sanitize|removeUntrusted|syncResult\.clear|remove\s*\(\s*["']trade_no["'])/i.test(thirdCheckCode);
  if (parsesThirdXml && returnsUntrustedThirdXmlFields) {
    errors.push("代扣执行 XML 验签失败/缺少签名时，不能把未验签的 syncResult 业务字段原样返回给调用方；只能返回失败诊断和本地已可信字段。");
  }
}

if (usesDutQuery) {
  const queryCheckText = withholdQueryHandlerSourceText || withholdQuerySourceText;
  const queryCheckCode = stripComments(queryCheckText);
  const queryRequestCode = stripComments(withholdQuerySourceText || queryCheckText);
  if (!hasRequiredFieldCheck(queryRequestCode, "payerUserId|payer_user_id")) {
    errors.push("代扣主动查询发起 dut.agent.query.third 前必须校验 payer_user_id 非空，不能带空付款人查询。");
  }
  const queryUsesStoredPayerUserId =
    /(?:order|existingOrder|withholdingOrder|withholdOrder|withholdingRecord|savedOrder|storedOrder|localOrder|paymentOrder|trainTicketOrder|代扣订单)[^;\n]{0,140}(?:getPayerUserId|payerUserId|payer_user_id)|(?:getPayerUserId|payerUserId|payer_user_id)[^;\n]{0,220}(?:order|existingOrder|withholdingOrder|withholdOrder|withholdingRecord|savedOrder|storedOrder|localOrder|paymentOrder|trainTicketOrder|代扣订单)/i.test(queryRequestCode);
  if (!queryUsesStoredPayerUserId) {
    errors.push("代扣主动查询的 payer_user_id 必须来自本地代扣订单保存的付款人 UID，并与执行代扣时的值一致；不能用 openid、临时入参或随机值补齐。");
  }
  const queryPayerUserIdLooksLikeOpenId =
    /(?:payerUserId|payer_user_id)\s*=\s*[^;\n]*(?:openId|open_id|openid|employeeOpenId|employee_open_id)\b/i.test(queryRequestCode)
    || /(?:put|add|set|param|parameter)[^;\n]{0,180}(?:payer_user_id|payerUserId)[^;\n]{0,180}(?:openId|open_id|openid|employeeOpenId|employee_open_id)\b/i.test(queryRequestCode)
    || /setPayerUserId\s*\([^)]*(?:openId|open_id|openid|employeeOpenId|employee_open_id)\b/i.test(queryRequestCode);
  if (queryPayerUserIdLooksLikeOpenId) {
    errors.push("代扣主动查询不能把员工 openid 作为 payer_user_id；openid 场景必须先用协议查询可信响应 principal_id 落库出支付宝 UID。");
  }
  const parsesQueryXml =
    /xmlParser|parseXml|parseXML|MapiXml|DocumentBuilder|SAXParser|StringReader|<alipay|XML/i.test(queryCheckText);
  const updatesQueryOrderFromXml =
    /setStatus\s*\(|saveOrder|repository\.save|order\.(?:setTradeNo|setOutOrderNo|setAmount|setTransAccountOut)\s*\(|QUERY_SUCCESS|QUERY_FAILED|QUERY_IN_PROGRESS/i.test(queryCheckCode);
  if (parsesQueryXml && updatesQueryOrderFromXml && !hasExplicitSignatureVerifyCall(queryCheckCode)) {
    errors.push("代扣查询 dut.agent.query.third 的 XML 同步响应必须先做 MAPI 验签；验签通过后才允许更新订单状态或写回响应字段。");
  }
  const hasQueryXmlSignatureFailureTest =
    /(?:XML|xml)[\s\S]{0,260}(?:sign|signature|验签)[\s\S]{0,520}(?:fail|失败|tamper|篡改|missing|缺少|parse|解析)[\s\S]{0,520}(?:not\s+update|not\s+write|不更新|不写回|保持|assertEquals)/i.test(withholdQueryTestText);
  if (parsesQueryXml && updatesQueryOrderFromXml && !hasQueryXmlSignatureFailureTest) {
    errors.push("代扣主动查询测试必须覆盖 XML 同步响应验签失败或缺少签名时，不更新订单状态、不写回 trade_no/out_order_no 等响应字段。");
  }
  const updatesQueryStatusOnXmlParseFailure =
    new RegExp(String.raw`catch\s*\([^)]*\)\s*\{[\s\S]{0,760}${SET_STATUS_EXPLICIT_FAILURE}[\s\S]{0,520}parse_failed|catch\s*\([^)]*\)\s*\{[\s\S]{0,760}parse_failed[\s\S]{0,520}${SET_STATUS_EXPLICIT_FAILURE}`).test(queryCheckCode);
  if (parsesQueryXml && updatesQueryStatusOnXmlParseFailure) {
    errors.push("代扣主动查询 XML 解析失败属于无法抽取签名参数的不可确认响应；不得更新为 QUERY_FAILED 或其他失败态，也不得写回响应字段。");
  }
  const updatesQueryStatusOnSignatureFailure =
    new RegExp(String.raw`if\s*\([^)]*!\s*signatureVerified[^)]*\)\s*\{[\s\S]{0,520}${SET_STATUS_EXPLICIT_FAILURE}`).test(queryCheckCode);
  if (parsesQueryXml && updatesQueryStatusOnSignatureFailure) {
    errors.push("代扣主动查询 XML 验签失败/缺少签名时不得更新订单状态；不能置为 QUERY_FAILED 或其他失败态。需保持原状态并拒绝写回响应字段。");
  }
  const returnsUntrustedQueryXmlFields =
    /if\s*\([^)]*!\s*signatureVerified[^)]*\)\s*\{[\s\S]{0,1200}putAll\s*\(\s*parsed\s*\)/i.test(queryCheckCode)
    && !/(?:safeResult|trustedResult|failureResult|sanitize|removeUntrusted|parsed\.clear|remove\s*\(\s*["']trade_no["'])/i.test(queryCheckCode);
  if (parsesQueryXml && returnsUntrustedQueryXmlFields) {
    errors.push("代扣主动查询 XML 验签失败/缺少签名时，不能把未验签的 parsed 业务字段原样返回给调用方；只能返回失败诊断和本地已可信字段。");
  }
  const returnsQueryBusinessFieldsAfterMismatch =
    /if\s*\([^)]*!\s*(?:orderIdentityMatched|identityMatched|sameOrder|reconciled|isReconciled)[^)]*\)\s*\{[\s\S]{0,2600}\}[\s\S]{0,7000}(?:result\.putAll\s*\(\s*parsed\s*\)|new\s+LinkedHashMap<>\s*\(\s*parsed\s*\))/i.test(queryCheckCode)
    && !/(?:safeResult|trustedResult|sanitizedResult|sanitize|removeUntrusted|result\.remove\s*\(\s*["']trade_no["']|if\s*\([^)]*actuallyUpdated[^)]*\)\s*\{[\s\S]{0,900}(?:result\.putAll\s*\(\s*parsed\s*\)|new\s+LinkedHashMap<>\s*\(\s*parsed\s*\))|return\s+result\s*;[\s\S]{0,600}else\s*\{[\s\S]{0,1200}(?:putAll\s*\(\s*parsed|new\s+LinkedHashMap<>\s*\(\s*parsed))/i.test(queryCheckCode);
  if (parsesQueryXml && returnsQueryBusinessFieldsAfterMismatch) {
    errors.push("代扣主动查询身份/对账未通过或未实际更新时，不能把已验签但未归属当前订单的 parsed 业务字段原样返回给调用方；只能返回不更新诊断和本地可信定位字段。");
  }
  const updatesQueryFailedOnBusinessFailure =
    new RegExp(String.raw`(?:is_success|isSuccess)[^;\n]{0,160}(?:非\s*T|business.*fail|业务失败)[\s\S]{0,520}${SET_STATUS_EXPLICIT_FAILURE}`, "i").test(queryCheckCode)
    || new RegExp(String.raw`if\s*\([^)]*(?:isSuccess|is_success)[^)]*\)[\s\S]{0,1400}\}\s*else\s*\{[\s\S]{0,520}${SET_STATUS_EXPLICIT_FAILURE}`, "i").test(queryCheckCode);
  if (parsesQueryXml && updatesQueryFailedOnBusinessFailure) {
    errors.push("代扣主动查询 is_success=F、错误码、缺少 trade_status 或 MAPI 业务失败不能把订单置为 QUERY_FAILED/交易失败态；应保持原状态并返回 business_failed/错误码等查询失败诊断。");
  }
  const updatesQueryFailed =
    /\bQUERY_FAILED\b/.test(queryCheckCode)
    || new RegExp(SET_STATUS_EXPLICIT_FAILURE).test(queryCheckCode)
    || /status\s*=\s*["'](?:QUERY_FAILED|FAILED|query_failed|failed)["']/.test(queryCheckCode);
  const protectsTerminalSuccess =
    /isTerminal|terminal|终态|最终成功|已成功|already\s+(?:success|paid)|skip.*success|(?:TRADE_SUCCESS|SUCCESS|PAID)[\s\S]{0,220}(?:skip|ignore(?:Update|Status|Result|\s)|不覆盖|保持|不更新)/i.test(queryCheckCode);
  if (updatesQueryFailed && !protectsTerminalSuccess) {
    errors.push("代扣主动查询更新失败状态前必须保护已确认成功的终态订单；查询失败或非成功响应不能覆盖通知已确认的最终成功。");
  }
  if (new RegExp(String.raw`(?:!|not\s+).*TRADE_SUCCESS[\s\S]{0,240}(?:\bQUERY_FAILED\b|${SET_STATUS_EXPLICIT_FAILURE})|else\s*\{[\s\S]{0,220}(?:\bQUERY_FAILED\b|${SET_STATUS_EXPLICIT_FAILURE})`, "i").test(queryCheckCode)
    && !/TRADE_CLOSED|TRADE_FINISHED|明确交易失败|transaction.*failed|trade.*failed|支付失败/i.test(queryCheckCode)) {
    errors.push("代扣主动查询必须区分查询调用失败、交易处理中和交易最终失败；不能把所有非 TRADE_SUCCESS 统一写成 QUERY_FAILED。");
  }
  const validatesQueryOrderIdentity =
    /(?:parsed|result|response|resp|fields|responseFields)\.get\s*\(\s*["'](?:out_order_no|outOrderNo|trade_no|tradeNo)["']\s*\)[\s\S]{0,520}order\.get(?:OutOrderNo|TradeNo)\(\)|order\.get(?:OutOrderNo|TradeNo)\(\)[\s\S]{0,520}(?:parsed|result|response|resp|fields|responseFields)\.get\s*\(\s*["'](?:out_order_no|outOrderNo|trade_no|tradeNo)["']\s*\)|Objects\.equals\s*\([^)]*(?:out_order_no|outOrderNo|trade_no|tradeNo)[^)]*order\.get(?:OutOrderNo|TradeNo)\(\)/i.test(queryCheckCode);
  if (!validatesQueryOrderIdentity) {
    errors.push("代扣主动查询更新订单状态前必须比对查询响应的 out_order_no/trade_no 等订单身份字段与本地订单一致，不能只按 trade_status 更新。");
  }
  const validatesQueryAmountOrAccount =
    /(?:parsed|result|response|resp|fields|responseFields)\.get\s*\(\s*["'](?:trans_account_out|transAccountOut|total_fee|totalFee|amount|ord_amt|ordAmt)["']\s*\)[\s\S]{0,560}order\.get(?:TransAccountOut|Amount|TotalFee)\(\)|order\.get(?:TransAccountOut|Amount|TotalFee)\(\)[\s\S]{0,560}(?:parsed|result|response|resp|fields|responseFields)\.get\s*\(\s*["'](?:trans_account_out|transAccountOut|total_fee|totalFee|amount|ord_amt|ordAmt)["']\s*\)|Objects\.equals\s*\([^)]*(?:trans_account_out|transAccountOut|total_fee|amount|ord_amt)[^)]*order\.get(?:TransAccountOut|Amount|TotalFee)\(\)|(?:parsed|result|response|resp|fields|responseFields)\.get\s*\(\s*["']total_fee["']\s*\)[\s\S]{0,1400}order\.getTotalFee\s*\(\)|(?:parsed|result|response|resp|fields|responseFields)\.get\s*\(\s*["']trans_account_out["']\s*\)[\s\S]{0,900}order\.getTransAccountOut\s*\(\)/i.test(queryCheckCode);
  if (!validatesQueryAmountOrAccount) {
    errors.push("代扣主动查询更新订单状态前必须比对查询响应的金额或资金账号等对账字段与本地订单一致；响应缺失关键对账字段时不得更新终态。");
  }
  const looseIdentityAnyMatch =
    /\b(?:outOrderNoMatches|outMatched|out_order_noMatched|outOrderMatched)\s*\|\|\s*(?:tradeNoMatches|tradeMatched|trade_noMatched)|(?:tradeNoMatches|tradeMatched|trade_noMatched)\s*\|\|\s*(?:outOrderNoMatches|outMatched|out_order_noMatched|outOrderMatched)|return\s+(?:outMatched|outOrderNoMatches|outOrderMatched)\s*\|\|\s*(?:tradeMatched|tradeNoMatches)/i.test(queryCheckCode);
  if (looseIdentityAnyMatch) {
    errors.push("代扣主动查询身份校验不能用 out_order_no 或 trade_no 任一匹配来放行；响应里出现且本地可比对的身份字段只要有冲突，就不得更新状态或写回字段。");
  }
  const looseReconcileAnyMatch =
    /\b(?:accountMatched|transAccountMatched|transAccountOutMatched)\s*\|\|\s*(?:amountMatched|feeMatched|totalFeeMatched)|(?:amountMatched|feeMatched|totalFeeMatched)\s*\|\|\s*(?:accountMatched|transAccountMatched|transAccountOutMatched)|return\s+(?:accountMatched|transAccountMatched|transAccountOutMatched)\s*\|\|\s*(?:amountMatched|feeMatched|totalFeeMatched)/i.test(queryCheckCode);
  if (looseReconcileAnyMatch) {
    errors.push("代扣主动查询对账校验不能用金额或资金账号任一匹配来放行；响应里出现且本地可比对的对账字段只要有冲突，就不得更新状态或写回字段。");
  }
  const writesQueryResponseField =
    /order\.set(?:TradeNo|OutOrderNo|TransAccountOut|Amount)\s*\([^;]*(?:parsed|result|response|resp)\.get\s*\(\s*["'](?:trade_no|tradeNo|out_order_no|outOrderNo|trans_account_out|transAccountOut|total_fee|totalFee|amount|ord_amt|ordAmt)["']/i.test(queryCheckCode);
  if (writesQueryResponseField && !hasGuardedQueryResponseFieldWrite(queryCheckCode)) {
    errors.push("代扣主动查询写回 trade_no/out_order_no/金额/资金账号等响应字段前，也必须通过订单身份和金额/资金账号对账校验；不能在校验分支外无条件写回响应字段。");
  }
  const hasMismatchNoUpdateBranch =
    /!\s*(?:orderIdentityMatched|identityMatched|sameOrder|reconciled|isReconciled)|订单身份\/对账字段不匹配|不匹配或缺失|mismatch|not.*match/i.test(queryCheckCode);
  const returnsGenericUpdated =
    /query_result["']\s*,\s*(?:[^;]*\?\s*["'][^"']+["']\s*:\s*)?["']updated["']|queryResult\s*[:=]\s*["']updated["']/i.test(queryCheckCode);
  const hasExplicitNoUpdateQueryResult =
    /query_result["']\s*,\s*["'](?:mismatch_not_updated|not_updated|identity_mismatch|reconcile_mismatch|skipped|no_update)["']|queryResult\s*[:=]\s*["'](?:mismatch_not_updated|not_updated|identity_mismatch|reconcile_mismatch|skipped|no_update)["']/i.test(queryCheckCode);
  if (hasMismatchNoUpdateBranch && returnsGenericUpdated && !hasExplicitNoUpdateQueryResult) {
    errors.push("代扣主动查询身份/对账未通过且没有实际更新时，query_result 不能仍返回 updated；应返回 mismatch_not_updated/not_updated 等明确结果。");
  }
  if (!withholdQueryTestFiles.length) {
    errors.push("代扣结果主动查询必须有独立测试类/测试文件，覆盖终态保护、身份/对账不匹配不更新和字段写回保护；不能只靠代扣执行或通知测试间接覆盖。");
  } else {
    const hasQueryPayerUserIdRequestTest =
      /(?:payerUserId|payer_user_id)[\s\S]{0,900}(?:assertEquals|toEqual|toContain|contains|captor|captured|请求|request)|(?:assertEquals|toEqual|toContain|contains|captor|captured|请求|request)[\s\S]{0,900}(?:payerUserId|payer_user_id)/i.test(withholdQueryTestText);
    if (!hasQueryPayerUserIdRequestTest) {
      errors.push("代扣主动查询测试必须捕获或断言 dut.agent.query.third 请求包含本地订单保存的 payer_user_id。");
    }
    const hasQueryMissingPayerUserIdTest =
      /(?:payerUserId|payer_user_id)[\s\S]{0,360}(?:null|empty|blank|空|缺少|缺失)[\s\S]{0,760}(?:assertThrows|toThrow|rejects\.toThrow|IllegalArgumentException|ValidationException|assertFalse|fail fast|失败|拒绝)|(?:missing|blank|empty|缺少|缺失|空白)[\s\S]{0,360}(?:payerUserId|payer_user_id)[\s\S]{0,760}(?:assertThrows|toThrow|rejects\.toThrow|IllegalArgumentException|ValidationException|assertFalse|fail fast|失败|拒绝)/i.test(withholdQueryTestText);
    if (!hasQueryMissingPayerUserIdTest) {
      errors.push("代扣主动查询测试必须覆盖 payer_user_id 缺失或空白时 fail fast，不调用 dut.agent.query.third。");
    }
    const hasTerminalProtectionQueryTest =
      /terminal|终态|最终成功|NOTIFY_SUCCESS|FINAL_SUCCESS|QUERY_SUCCESS|terminal_protected|不覆盖|保持/i.test(withholdQueryTestText);
    if (!hasTerminalProtectionQueryTest) {
      errors.push("代扣主动查询测试必须覆盖已成功终态不被查询失败、处理中或未知响应覆盖。");
    }
    const hasIdentityMismatchQueryTest =
      /(?:out_order_no|outOrderNo|trade_no|tradeNo|订单身份)[\s\S]{0,260}(?:mismatch|different|wrong|missing|miss|不一致|缺少|缺失)|(?:mismatch|different|wrong|missing|miss|不一致|缺少|缺失)[\s\S]{0,260}(?:out_order_no|outOrderNo|trade_no|tradeNo|订单身份)/i.test(withholdQueryTestText);
    if (!hasIdentityMismatchQueryTest) {
      errors.push("代扣主动查询测试必须覆盖查询响应 out_order_no/trade_no 与本地订单不一致或缺失时不更新订单状态和字段。");
    }
    const hasMixedIdentityConflictQueryTest =
      /(?:out_order_no|outOrderNo|订单号)[\s\S]{0,260}(?:trade_no|tradeNo|交易号)[\s\S]{0,520}(?:conflict|partial|mixed|one.*match|another.*mismatch|冲突|部分匹配|一个.*匹配|一个.*不匹配|另一个.*不匹配|matching\s+trade_no|mismatching\s+out_order_no)|(?:conflict|partial|mixed|one.*match|another.*mismatch|冲突|部分匹配|一个.*匹配|一个.*不匹配|另一个.*不匹配|matching\s+trade_no|mismatching\s+out_order_no)[\s\S]{0,520}(?:out_order_no|outOrderNo|订单号)[\s\S]{0,260}(?:trade_no|tradeNo|交易号)|(?:outOrderNo|out_order_no)[A-Za-z0-9_]*Mismatch[\s\S]{0,900}(?:Matching|matching)[\s\S]{0,120}(?:trade_no|tradeNo)/i.test(withholdQueryTestText);
    if (!hasMixedIdentityConflictQueryTest) {
      errors.push("代扣主动查询测试必须覆盖身份字段混合冲突：例如 out_order_no 不匹配但 trade_no 匹配时仍不更新、不写回。");
    }
    const hasReconcileMismatchQueryTest =
      /(?:trans_account_out|transAccountOut|total_fee|totalFee|amount|ord_amt|ordAmt|金额|资金账号)[\s\S]{0,260}(?:mismatch|different|wrong|missing|miss|不一致|缺少|缺失)|(?:mismatch|different|wrong|missing|miss|不一致|缺少|缺失)[\s\S]{0,260}(?:trans_account_out|transAccountOut|total_fee|totalFee|amount|ord_amt|ordAmt|金额|资金账号)/i.test(withholdQueryTestText);
    if (!hasReconcileMismatchQueryTest) {
      errors.push("代扣主动查询测试必须覆盖查询响应金额或资金账号不一致/缺失时不更新订单状态和字段。");
    }
    const hasMixedReconcileConflictQueryTest =
      /(?:trans_account_out|transAccountOut|资金账号)[\s\S]{0,260}(?:total_fee|totalFee|amount|金额)[\s\S]{0,520}(?:conflict|partial|mixed|one.*match|another.*mismatch|冲突|部分匹配|一个.*匹配|一个.*不匹配|另一个.*不匹配|matching\s+(?:total_fee|trans_account_out)|mismatching\s+(?:total_fee|trans_account_out))|(?:conflict|partial|mixed|one.*match|another.*mismatch|冲突|部分匹配|一个.*匹配|一个.*不匹配|另一个.*不匹配|matching\s+(?:total_fee|trans_account_out)|mismatching\s+(?:total_fee|trans_account_out))[\s\S]{0,520}(?:trans_account_out|transAccountOut|资金账号)[\s\S]{0,260}(?:total_fee|totalFee|amount|金额)|(?:totalFee|total_fee|transAccountOut|trans_account_out)[A-Za-z0-9_]*Mismatch[\s\S]{0,900}(?:Matching|matching)[\s\S]{0,120}(?:total_fee|trans_account_out|amount|资金账号)|reconciliationFieldMismatch[\s\S]{0,900}(?:totalFee|total_fee|transAccountOut|trans_account_out)[\s\S]{0,1200}(?:Matching|matching|MISMATCHING|mismatching)/i.test(withholdQueryTestText);
    if (!hasMixedReconcileConflictQueryTest) {
      errors.push("代扣主动查询测试必须覆盖对账字段混合冲突：例如金额匹配但资金账号不匹配时仍不更新、不写回。");
    }
    const hasFieldWriteProtectionQueryTest =
      /(?:trade_no|tradeNo|out_order_no|outOrderNo)[\s\S]{0,320}(?:not\s+update|not\s+overwrite|unchanged|same|不更新|不写回|不覆盖|保持|原值)|(?:assertEquals|expect|assertThat)[\s\S]{0,260}(?:tradeNo|trade_no|outOrderNo|out_order_no)[\s\S]{0,260}(?:old|original|原值|保持|unchanged|null)|assertNull\s*\([^)]*get(?:TradeNo|OutOrderNo)\s*\(/i.test(withholdQueryTestText);
    if (!hasFieldWriteProtectionQueryTest) {
      errors.push("代扣主动查询测试必须覆盖身份/对账未通过时 trade_no/out_order_no 等响应字段不会被写回污染本地订单。");
    }
    const hasNoUpdateResultQueryTest =
      /query_result[\s\S]{0,260}(?:mismatch_not_updated|not_updated|identity_mismatch|reconcile_mismatch|skipped|no_update|not\s+updated|不是\s*updated|不返回\s*updated|不能.*updated)|assertFalse\s*\([^)]*\.isUpdated\s*\(\s*\)\s*\)|assertFalse\s*\([^)]*isUpdated\s*\(\s*\)\s*\)/i.test(withholdQueryTestText);
    if (!hasNoUpdateResultQueryTest) {
      errors.push("代扣主动查询测试必须覆盖身份/对账未通过且未实际更新时 query_result 不是 updated。");
    }
    const hasNoBusinessFieldsReturnedOnMismatchTest =
      /(?:result\.get\s*\(\s*["'](?:trade_no|out_order_no|total_fee|trans_account_out)["']\s*\)[\s\S]{0,260}(?:assertNull|toBeUndefined|toBeNull|undefined|null|不存在|不返回)|assertNull\s*\(\s*result\.get(?:TradeNo|OutOrderNo|TotalFee|TransAccountOut)\s*\(\s*\)|(?:assertFalse|expect)[\s\S]{0,220}(?:containsKey|toHaveProperty)[\s\S]{0,260}(?:trade_no|out_order_no|total_fee|trans_account_out)|(?:不返回|不透出|不得返回|not.*leak|should not be leaked)[\s\S]{0,260}(?:trade_no|out_order_no|total_fee|trans_account_out|business field|业务字段))/i.test(withholdQueryTestText);
    if (!hasNoBusinessFieldsReturnedOnMismatchTest) {
      errors.push("代扣主动查询测试必须覆盖身份/对账未通过或未实际更新时，返回值不透出 trade_no/out_order_no/金额/资金账号等响应业务字段。");
    }
    const hasBusinessFailureNoStatusUpdateTest =
      /(?:is_success|isSuccess)[\s\S]{0,260}(?:F|false|业务失败|business_failed|error)[\s\S]{0,520}(?:WITHHOLDING|原状态|保持|not\s+update|not\s+overwrite|assertNotEquals[\s\S]{0,120}QUERY_FAILED|不置\s*QUERY_FAILED)|(?:business_failed|业务失败)[\s\S]{0,520}(?:QUERY_FAILED|原状态|保持|不更新)/i.test(withholdQueryTestText);
    if (!hasBusinessFailureNoStatusUpdateTest) {
      errors.push("代扣主动查询测试必须覆盖 is_success=F/MAPI 业务失败时保持原订单状态，不置 QUERY_FAILED/交易失败态，并返回查询失败诊断。");
    }
  }
}

if (usesDutThird && usesDutQuery && hasPattern(/outOrderNo\s*=\s*(generate|uuid|UUID|System\.currentTimeMillis|Date\.now)|setOutOrderNo\s*\(\s*(generate|uuid|UUID|System\.currentTimeMillis|Date\.now)|out_order_no["']?\s*[:=]\s*(generate|uuid|UUID|System\.currentTimeMillis|Date\.now)/)) {
  errors.push("检测到 out_order_no 疑似由时间戳/UUID/本地随机函数生成。火车票接通样例中 out_order_no 必须来自明确业务映射、代扣同步返回或上游入参。");
}

const usesWithholdNotify =
  /(?:class|interface|function|def|void|public|private|protected|const|let|var)\s+[A-Za-z0-9_$]*(?:WithholdingNotify|WithholdNotify|withholdNotify)[A-Za-z0-9_$]*\b/i.test(strippedSourceCodeText)
  || /\b(?:handleWithholdNotify|withholdingNotify|withholdNotify)\s*\(/i.test(strippedSourceCodeText)
  || /(?:@(?:Post|Get|Request)Mapping|router\.(?:post|get)|app\.(?:post|get))[\s\S]{0,220}(?:notify\/withhold|withhold\/notify)|["']\/[^"']*(?:notify\/withhold|withhold\/notify)[^"']*["']/.test(strippedSourceCodeText);
if (usesWithholdNotify) {
  errors.push("代扣结果通知面向商户侧，不是接入方服务端能力；生成代码不得包含接入方代扣通知 handler/controller、notify_id 幂等、notify_verify 或通知状态流转。");
}
const hasOuterWithholdNotifyUrl =
  /(?:SERVICE_DUT_AGENT_THIRD|dut\.agent\.third)[\s\S]{0,1600}(?:put|set|append|add|params?\s*\[|params?\.)\s*\(?\s*["']notify_url["']/i.test(strippedSourceCodeText)
  || /withholdNotifyUrl|notifyProperties\.getWithholdUrl\(\)|getWithholdUrl\(\)/i.test(strippedWithholdThirdSourceText || strippedSourceCodeText)
  || /(?:withhold|代扣|dut\.agent\.third)[\s\S]{0,180}notifyUrl\s*[:=]|notifyUrl\s*[:=][\s\S]{0,180}(?:withhold|代扣|dut\.agent\.third)/i.test(strippedWithholdThirdSourceText);
if (usesDutThird && hasOuterWithholdNotifyUrl) {
  errors.push("dut.agent.third 不为接入方接入代扣结果通知；不得给外层 MAPI 请求传接入方 notify_url，也不得新增 withholdNotifyUrl/notifyUrl 回调配置。12306 submit_param 内层 notify_url 只能作为商户侧原始参数保留。");
}
const withholdThirdCodeText = stripComments(withholdThirdSourceText);
const hasWithholdReturnUrlLogic =
  /(?:put|set|append|add|params?\s*\[|params?\.)\s*\(?\s*["']return_url["']/i.test(withholdThirdCodeText)
  || /\.get\s*\(\s*["']return_url["']\s*\)/i.test(withholdThirdCodeText)
  || /\b(?:innerReturnUrl|getInnerReturnUrl|withholdReturnUrl|getWithholdReturnUrl|returnUrl)\b/i.test(withholdThirdCodeText);
if (usesDutThird && hasWithholdReturnUrlLogic) {
  errors.push("dut.agent.third 不存在接入方 return_url 逻辑；12306 submit_param 内层 return_url 属于商户侧原始参数，只能随 submit_param 原样保留，不得生成接入方页面承接、验签、跳转或状态更新逻辑。");
}

if (usesDutThird && hasPattern(/\{\s*\\?"assignJointAccountId\\?"\s*:\s*\\?"/)) {
  warnings.push("检测到 business_info 可能为手拼 JSON。建议使用语言内 JSON 序列化工具，避免特殊字符破坏 JSON。");
}

function usesMApiLike(value) {
  return /mapi\.alipay\.com|gateway\.do|alipay\.dut\.customer\.agreement|dut\.agent\.(third|query\.third)|DUT_AGENT_THIRD_P|mr_dut_third|submit_param/.test(value);
}

console.log(`扫描文件数：${files.length}`);
if (warnings.length) {
  console.log("\n警告：");
  for (const warning of warnings) console.log(`- ${warning}`);
}
if (errors.length) {
  console.error("\n错误：");
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}
console.log("\n三方免密代扣自检通过。");
process.exit(0);
