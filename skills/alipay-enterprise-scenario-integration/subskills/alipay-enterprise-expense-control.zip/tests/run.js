#!/usr/bin/env node
"use strict";

const assert = require("assert");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawnSync } = require("child_process");

const skillDir = path.resolve(__dirname, "..");
const scriptsDir = path.join(skillDir, "scripts");
const validator = path.join(scriptsDir, "validate_codegen.js");
const runtime = path.join(scriptsDir, "lib", "validator-runtime.js");
const resolver = require(path.join(scriptsDir, "lib", "value-resolver.js"));
const javaProjectGates = require(path.join(scriptsDir, "lib", "java-project-gates.js"));

testRuntime();
testMissingSupportIsBroken();
testValueResolver();
require("./java-project-gates.test").run(javaProjectGates);
testFixtures();
testTicketMerchantPidRule();
testBusinessPriorityRule();
testFailClosedSpiBehavior();
testFailClosedUnsupportedOperationBoundary();
testPersistentExternalSpiState();
testIntegrationContract();
console.log("[alipay-enterprise-expense-control tests] OK");

function testRuntime() {
  const ok = runNode(["-e", `require(${JSON.stringify(runtime)}).runGuarded("test", () => {})`]);
  assert.strictEqual(ok.status, 0, output(ok));

  const broken = runNode(["-e", `require(${JSON.stringify(runtime)}).runGuarded("test", () => { missingFunction(); })`]);
  assert.strictEqual(broken.status, 2, output(broken));
  assert.match(output(broken), /\[test\] BROKEN/);
}

function testMissingSupportIsBroken() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-expense-broken-"));
  const isolatedValidator = path.join(dir, "validate_codegen.js");
  fs.copyFileSync(validator, isolatedValidator);
  const result = runNode([isolatedValidator, path.join(__dirname, "fixtures", "valid")]);
  assert.strictEqual(result.status, 2, output(result));
  assert.match(output(result), /BROKEN failed to load validator support/);
}

function testValueResolver() {
  const text = [
    "const EXPENSE_TYPE_TICKET = \"TICKET\";",
    "const RULE_VALUE_MERCHANT_12306 = \"{\\\"2088011519249952\\\":[\\\"-1\\\"]}\";",
    "$consultMode = '0';",
  ].join("\n");
  const constants = resolver.extractStringConstants(text);
  assert.strictEqual(resolver.resolveStringArg("ExpenseConstants.EXPENSE_TYPE_TICKET", constants), "TICKET");
  assert.strictEqual(resolver.resolveStringArg("$consultMode", constants), "0");
  assert.deepStrictEqual(resolver.valueTokens(text, "2088011519249952"), ["2088011519249952", "RULE_VALUE_MERCHANT_12306"]);
}

function testFixtures() {
  assertExit(path.join(__dirname, "fixtures", "valid"), 0);
  assertExit(path.join(__dirname, "fixtures", "invalid"), 1);
}

function testTicketMerchantPidRule() {
  const invalidDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-expense-ticket-"));
  fs.writeFileSync(path.join(invalidDir, "institution.py"), [
    "def create_institution():",
    "    return {",
    "        \"method\": \"alipay.ebpp.invoice.institution.create\",",
    "        \"standard_info_list\": [{",
    "            \"expense_type\": \"TICKET\",",
    "            \"expense_type_sub_category\": \"TICKET\",",
    "            \"standard_condition_info_list\": [{\"rule_factor\": \"MERCHANT\", \"rule_value\": \"{\\\"999\\\":[\\\"-1\\\"]}\"}],",
    "        }],",
    "    }",
  ].join("\n"));
  const invalid = runNode([validator, invalidDir]);
  assert.strictEqual(invalid.status, 1, output(invalid));
  assert.match(output(invalid), /must bind MERCHANT to 12306 merchant pid/);

  const validDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-expense-ticket-"));
  fs.writeFileSync(path.join(validDir, "institution.py"), fs.readFileSync(path.join(invalidDir, "institution.py"), "utf8")
    .replace("{\\\"999\\\":[\\\"-1\\\"]}", "{\\\"2088011519249952\\\":[\\\"-1\\\"]}"));
  assert.doesNotMatch(output(runNode([validator, validDir])), /must bind MERCHANT to 12306 merchant pid/);
}

function testBusinessPriorityRule() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-expense-priority-"));
  fs.writeFileSync(path.join(dir, "institution.py"), [
    "def create_institution():",
    "    return {",
    "        \"method\": \"alipay.ebpp.invoice.institution.create\",",
    "        \"standard_info_list\": [{",
    "            \"expense_type\": \"METRO\",",
    "            \"expense_type_sub_category\": \"METRO\",",
    "            \"standard_condition_info_list\": [{\"rule_factor\": \"CARD_TYPE\", \"rule_value\": [\"S0110000\"]}],",
    "        }],",
    "    }",
  ].join("\n"));
  writeScenario(dir, {
    schemaVersion: 1,
    status: "CONFIRMED",
    expenseType: "METRO",
    expenseTypeSubCategory: "METRO",
    sceneType: "TRAVEL",
    requiredRuleFactors: ["CARD_TYPE"],
    ruleFactorValues: { CARD_TYPE: ["S0110000"] },
    businessPriority: { enabled: true, merchantRestrictionFactors: ["MERCHANT"] },
  });
  const result = runNode([validator, dir]);
  assert.strictEqual(result.status, 1, output(result));
  assert.match(output(result), /business priority requires ALARM_CLOCK_TIME/);
  assert.match(output(result), /business priority requires at least one implemented merchant restriction factor/);

  const taotianDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-expense-taotian-priority-"));
  fs.writeFileSync(path.join(taotianDir, "institution.py"), [
    "def create_institution():",
    "    return {",
    "        \"method\": \"alipay.ebpp.invoice.institution.create\",",
    "        \"standard_info_list\": [{",
    "            \"expense_type\": \"DEFAULT\",",
    "            \"expense_type_sub_category\": \"DEFAULT\",",
    "            \"standard_condition_info_list\": [",
    "                {\"rule_factor\": \"ALI_PLATFORM_TYPE\", \"rule_value\": [\"TAOTIAN\", \"1688\"]},",
    "                {\"rule_factor\": \"ALARM_CLOCK_TIME\", \"rule_value\": {\"all\": True}},",
    "                {\"rule_factor\": \"MERCHANT\", \"rule_value\": [\"merchant\"]},",
    "            ],",
    "        }],",
    "    }",
  ].join("\n"));
  writeScenario(taotianDir, {
    schemaVersion: 1,
    status: "CONFIRMED",
    expenseType: "DEFAULT",
    expenseTypeSubCategory: "DEFAULT",
    sceneType: "DEFAULT",
    requiredRuleFactors: ["ALI_PLATFORM_TYPE"],
    ruleFactorValues: {
      ALI_PLATFORM_TYPE: ["TAOTIAN", "1688"],
      ALARM_CLOCK_TIME: { all: true },
      MERCHANT: ["merchant"],
    },
    businessPriority: { enabled: true, merchantRestrictionFactors: ["MERCHANT"] },
  });
  const taotian = runNode([validator, taotianDir]);
  assert.strictEqual(taotian.status, 1, output(taotian));
  assert.match(output(taotian), /do not support business priority/);
}

function writeScenario(dir, scenario) {
  const meta = path.join(dir, ".alipay-skill");
  fs.mkdirSync(meta, { recursive: true });
  fs.writeFileSync(path.join(meta, "scenario.json"), JSON.stringify(scenario, null, 2));
}

function testFailClosedSpiBehavior() {
  const failOpenDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-expense-fail-open-"));
  fs.writeFileSync(path.join(failOpenDir, "expensecontrol_spi.py"), [
    "SPI_METHOD = \"spi.alipay.commerce.ec.expensecontrol.consult\"",
    "def handle_consult(requested_amount):",
    "    # placeholder until the provider is wired",
    "    return requested_amount",
  ].join("\n"));
  const failOpen = runNode([validator, failOpenDir]);
  assert.strictEqual(failOpen.status, 1, output(failOpen));
  assert.match(output(failOpen), /placeholder code with fixed allow\/success\/quota\/idempotency result/);

  const failClosedDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-expense-fail-closed-"));
  fs.writeFileSync(path.join(failClosedDir, "expensecontrol_spi.py"), [
    "SPI_METHOD = \"spi.alipay.commerce.ec.expensecontrol.consult\"",
    "def handle_consult(requested_amount):",
    "    raise RuntimeError(\"quota provider is not configured\")",
  ].join("\n"));
  assertExit(failClosedDir, 0);
}

function testFailClosedUnsupportedOperationBoundary() {
  const allowedDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-expense-fail-closed-uoe-"));
  fs.writeFileSync(path.join(allowedDir, "FailClosedEnterpriseQuotaPort.java"), [
    "class FailClosedEnterpriseQuotaPort {",
    "  public long queryAvailableAmount() {",
    "    throw new UnsupportedOperationException(\"EnterpriseQuotaPort not configured; fail-closed\");",
    "  }",
    "}",
  ].join("\n"));
  assert.doesNotMatch(output(runNode([validator, allowedDir])), /stub implementation in queryAvailableAmount/);

  const stubDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-expense-uoe-stub-"));
  fs.writeFileSync(path.join(stubDir, "ExpenseControlSpiService.java"), [
    "class ExpenseControlSpiService {",
    "  public void createInstitution() {",
    "    throw new UnsupportedOperationException(\"later\");",
    "  }",
    "}",
  ].join("\n"));
  assert.match(output(runNode([validator, stubDir])), /stub implementation in createInstitution/);
}

function testPersistentExternalSpiState() {
  const unsafeDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-expense-memory-state-"));
  const unsafeFile = path.join(unsafeDir, "src", "main", "java", "com", "example", "app", "expense", "spi", "ExpenseControlQuotaStore.java");
  fs.mkdirSync(path.dirname(unsafeFile), { recursive: true });
  fs.writeFileSync(unsafeFile, [
    "@Component",
    "class ExpenseControlQuotaStore {",
    "  static final String PAY = \"spi.alipay.commerce.ec.expensecontrol.quota.pay\";",
    "  static final String REFUND = \"spi.alipay.commerce.ec.expensecontrol.quota.refund\";",
    "  static final String STATUS = \"spi.alipay.commerce.ec.expensecontrol.quotastatus.query\";",
    "  private final Map<String, String> quotaStates = new ConcurrentHashMap<>();",
    "  public void markDeducted(String tradeNo) { quotaStates.put(tradeNo, \"DEDUCTED\"); }",
    "}",
  ].join("\n"));
  assert.match(output(runNode([validator, unsafeDir])), /default process-local Map\/Set/);

  const safeDir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-expense-demo-state-"));
  fs.writeFileSync(path.join(safeDir, "ExternalExpenseControlStore.java"), [
    "@Profile(\"test\")",
    "@Component",
    "class ExternalExpenseControlStore {",
    "  static final String PAY = \"spi.alipay.commerce.ec.expensecontrol.quota.pay\";",
    "  static final String REFUND = \"spi.alipay.commerce.ec.expensecontrol.quota.refund\";",
    "  static final String STATUS = \"spi.alipay.commerce.ec.expensecontrol.quotastatus.query\";",
    "  private final Map<String, String> quotaStates = new ConcurrentHashMap<>();",
    "  public void markDeducted(String tradeNo) { quotaStates.put(tradeNo, \"DEDUCTED\"); }",
    "}",
  ].join("\n"));
  assert.doesNotMatch(output(runNode([validator, safeDir])), /default process-local Map\/Set/);
}

function testIntegrationContract() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "alipay-expense-contract-"));
  copyDir(path.join(__dirname, "fixtures", "valid"), dir);
  const meta = path.join(dir, ".alipay-skill");
  fs.mkdirSync(meta, { recursive: true });
  const contract = {
    schemaVersion: 1,
    projectMode: "existing",
    domains: {
      "expense-control": {
        status: "CONFIRMED",
        joinPoints: [{
          capability: "institution.create",
          status: "CONFIRMED",
          strategy: "service",
          evidenceFiles: ["expense_control.py"],
          symbols: ["ExpenseControlDirectory"],
        }],
        changes: [{ path: "expense_control.py", action: "reuse" }],
      },
    },
    gaps: [],
  };
  fs.writeFileSync(path.join(meta, "integration-contract.json"), JSON.stringify(contract, null, 2));
  assertExit(dir, 0, { ALIPAY_PROJECT_MODE: "existing" });
  contract.projectMode = "greenfield";
  fs.writeFileSync(path.join(meta, "integration-contract.json"), JSON.stringify(contract, null, 2));
  assertExit(dir, 1, { ALIPAY_PROJECT_MODE: "existing" });
  contract.projectMode = "existing";
  delete contract.domains["expense-control"].status;
  fs.writeFileSync(path.join(meta, "integration-contract.json"), JSON.stringify(contract, null, 2));
  assertExit(dir, 1, { ALIPAY_PROJECT_MODE: "existing" });
}

function assertExit(target, expected, extraEnv = {}) {
  const result = runNode([validator, target], extraEnv);
  assert.strictEqual(result.status, expected, output(result));
}

function runNode(args, extraEnv = {}) {
  return spawnSync(process.execPath, args, {
    encoding: "utf8",
    env: Object.assign({}, process.env, extraEnv),
  });
}

function output(result) {
  return `${result.stdout || ""}\n${result.stderr || ""}`.trim();
}

function copyDir(from, to) {
  for (const entry of fs.readdirSync(from, { withFileTypes: true })) {
    const source = path.join(from, entry.name);
    const target = path.join(to, entry.name);
    if (entry.isDirectory()) {
      fs.mkdirSync(target, { recursive: true });
      copyDir(source, target);
    } else {
      fs.copyFileSync(source, target);
    }
  }
}
