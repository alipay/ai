METHOD = "alipay.ebpp.invoice.institution.create"


def create_institution():
    return {
        "consult_mode": "0",
        "standard_info_list": [{
            "standard_condition_info_list": [{
                "rule_factor": "MERCHANT",
                "rule_value": "{\"2088011519249952\":[\"-1\"]}",
            }],
        }],
    }
