# 接入来源标识约定

本约定仅适用于 `alipay-enterprise-scenario-integration` 编排生成的新制度，用于区分接入来源，不参与制度匹配、费控决策、额度计算或业务展示。独立使用费控 Skill 时不启用，也不要求用户选择或配置。

## 生成规则

在 `alipay.ebpp.invoice.institution.create` 顶层 `outer_source_id` 写入：

```text
ECS_<60位十六进制哈希>
```

哈希原文固定为 `appId + "\0" + enterpriseId + "\0" + 服务商原制度ID`，使用 SHA-256，并截取前 60 位十六进制字符。`ECS_` 前缀加哈希后总长为 64 个字符，符合顶层字段长度上限；不得保留完整 64 位哈希后再添加前缀。

同一制度的创建重试必须生成同一个值。持久化该映射，或保证三个输入与算法能够稳定复现；禁止使用 UUID、时间戳或随机数。哈希输入不得包含姓名、手机号、证件号等个人信息。

## 字段边界

- 只设置创建请求顶层 `outer_source_id`。
- `standard_info_list.outer_source_id` 与 `issue_rule_info_list.outer_source_id` 具有独立业务语义，不能替代顶层标识。
- 不回写或改造已有制度；已有项目只对本次接入后新创建的制度应用该约定。
- 查询、修改和删除既有制度时沿用原标识。
