# alipay.ebpp.invoice.issuebatch.issuerecords.batchquery(手工发放发放明细分页查询)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
根据批次号分页查询手工发放的发放明细，可返回当前批次下员工的额度发放详情
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.ebpp.invoice.issuebatch.issuerecords.batchquery|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://ideservice.alipay.com/cms/site/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://ideservice.alipay.com/cms/site/04h2nx)|null|
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档|null|
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|特殊可选|32|企业ID**注意事项**如果使用企业ID对接，可不填写企业共同账户id和授权签约协议号|2088000194958956|
|institution_id|String|必须|32|制度ID|2023031500152617380000032000|
|issue_batch_id|String|必须|32|发放批次ID，创建手工发放时返回的issue_batch_id|2023020200152622280000000001|
|page_size|Number|必须|3|分页查询单页大小**注意事项**单页查询最大支持100条|10|
|page_num|Number|必须|10|分页查询页码|1|
|agreement_no|String|可选|32|授权签约协议号（该字段将废弃，不建议使用，可用enterprise_id字段替换）**注意事项**与企业共同账户id配合使用|20215425001112341234|
|account_id|String|可选|32|企业共同账户id（该字段将废弃，不建议使用，可用enterprise_id字段替换）**注意事项**与授权签约协议号配合使用|2088000194958956|
### 请求示例
#### 默认示例
##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayEbppInvoiceIssuebatchIssuerecordsBatchquery
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayEbppInvoiceIssuebatchIssuerecordsBatchqueryRequest request = new AlipayEbppInvoiceIssuebatchIssuerecordsBatchqueryRequest();
            AlipayEbppInvoiceIssuebatchIssuerecordsBatchqueryModel model = new AlipayEbppInvoiceIssuebatchIssuerecordsBatchqueryModel();
            
            // 设置企业id
            model.EnterpriseId = "2088000194958956";
            
            // 设置制度ID
            model.InstitutionId = "2023031500152617380000032000";
            
            // 设置发放批次id
            model.IssueBatchId = "2023020200152622280000000001";
            
            // 设置页大小
            model.PageSize = 10;
            
            // 设置页码
            model.PageNum = 1;
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayEbppInvoiceIssuebatchIssuerecordsBatchqueryResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.response.AlipayEbppInvoiceIssuebatchIssuerecordsBatchqueryResponse;
import com.alipay.api.request.AlipayEbppInvoiceIssuebatchIssuerecordsBatchqueryRequest;
import com.alipay.api.domain.AlipayEbppInvoiceIssuebatchIssuerecordsBatchqueryModel;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayEbppInvoiceIssuebatchIssuerecordsBatchquery {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayEbppInvoiceIssuebatchIssuerecordsBatchqueryRequest request = new AlipayEbppInvoiceIssuebatchIssuerecordsBatchqueryRequest();
        AlipayEbppInvoiceIssuebatchIssuerecordsBatchqueryModel model = new AlipayEbppInvoiceIssuebatchIssuerecordsBatchqueryModel();
        
        // 设置企业id
        model.setEnterpriseId("2088000194958956");
        
        // 设置制度ID
        model.setInstitutionId("2023031500152617380000032000");
        
        // 设置发放批次id
        model.setIssueBatchId("2023020200152622280000000001");
        
        // 设置页大小
        model.setPageSize(10L);
        
        // 设置页码
        model.setPageNum(1L);
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayEbppInvoiceIssuebatchIssuerecordsBatchqueryResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayEbppInvoiceIssuebatchIssuerecordsBatchqueryRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayEbppInvoiceIssuebatchIssuerecordsBatchqueryRequest();
$model = array();

// 设置企业id
$model['enterprise_id'] = "2088000194958956";

// 设置制度ID
$model['institution_id'] = "2023031500152617380000032000";

// 设置发放批次id
$model['issue_batch_id'] = "2023020200152622280000000001";

// 设置页大小
$model['page_size'] = 10;

// 设置页码
$model['page_num'] = 1;

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.ebpp.invoice.issuebatch.issuerecords.batchquery&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"enterprise_id":"2088000194958956",
	"institution_id":"2023031500152617380000032000",
	"issue_batch_id":"2023020200152622280000000001",
	"page_size":10,
	"page_num":1
}' 
```
 

### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|page_num|Number|必须|100|分页查询页码|1|
|page_size|Number|必须|3|分页查询单页大小|10|
|total_page_count|String|必须|100|总页数，单位：页|500|
|issue_record_info_list|IssueRecordInfo|必须|null|当前批次下的发放记录信息列表||
|issue_record_info_list.quota_id|String|可选|32|发放状态为发放成功的可返回额度id，未发放和发放中的无法返回额度id|2023041100152611720000750466|
|issue_record_info_list.issue_quota|String|必须|20|发放金额，支持两位小数，单位为（元）|188.00|
|issue_record_info_list.issue_status|Number|必须|4|发放状态描述 0: "未发放" 1: "发放成功" 2: "待作废" 3: "已作废" 4: "作废失败，有消费记录" 5: "发放中"|1|
|issue_record_info_list.owner_type|String|必须|32|用来指定owner_id的类型，具体返回值参考枚举值**枚举值**支付宝id:EMPLOYEE手机号:PHONE员工企业码id:ENTERPRISE_PAY_UID支付宝openId:EMPLOYEE_OPEN_ID|EMPLOYEE|
|issue_record_info_list.owner_id|String|特殊可选|32|根据owner_type返回对应的owner_id，例如：owner_type为PHONE，则owner_id返回手机号|2088402623900043|
|issue_record_info_list.owner_open_id|String|可选|32|切换open_id后请使用：owner_type为PHONE，返回员工手机号，owner_type为EMPLOYEE，返回员工open_id，owner_type为ENTERPRISE_PAY_UID，返回员工企业码id|2088402623900043|
|issue_record_info_list.user_name|String|可选|32|发放对应的员工名称|张三|
|issue_record_info_list.currency|String|可选|3|发放额度对应的币种**枚举值**英镑:GBP港元:HKD美元:USD新加坡元:SGD日元:JPY加拿大元:CAD澳大利亚元:AUD欧元:EUR新西兰元:NZD韩圆:KRW泰铢:THB瑞士法郎:CHF瑞典克朗:SEK丹麦克朗:DKK挪威克朗:NOK马来西亚林吉特:MYR印度尼西亚盾:IDR菲律宾比索:PHP毛里求斯卢比:MUR以色列新谢克尔:ILS斯里兰卡卢比:LKR俄国卢布:RUB阿联酋迪拉姆:AED捷克克郎:CZK南非兰特:ZAR卡塔尔里亚尔:QAR人民币:CNY**注意事项**创建制度时如未设置currency字段，默认为人民币|USD|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_ebpp_invoice_issuebatch_issuerecords_batchquery_response":{
		"code":"10000",
		"msg":"Success",
		"page_num":1,
		"page_size":10,
		"total_page_count":"500",
		"issue_record_info_list":[
			{
				"quota_id":"2023041100152611720000750466",
				"issue_quota":"188.00",
				"issue_status":1,
				"owner_type":"EMPLOYEE",
				"owner_id":"2088402623900043",
				"owner_open_id":"2088402623900043",
				"user_name":"张三",
				"currency":"USD"
			}
		]
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_ebpp_invoice_issuebatch_issuerecords_batchquery_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|PERMISSION_DENIED|权限不足，未能查到企业和isv之间的映射关系|检查传入的企业id是否正确，或者account_id和agreement_no组合是否正确|