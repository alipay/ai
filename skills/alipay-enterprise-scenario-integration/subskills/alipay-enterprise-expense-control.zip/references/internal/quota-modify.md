# alipay.ebpp.invoice.expensecontrol.quota.modify(修改余额/点券)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
修改余额或点券对应的额度，可用于增加额度、减少额度、删除额度等操作。
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.ebpp.invoice.expensecontrol.quota.modify|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://ideservice.alipay.com/cms/site/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://ideservice.alipay.com/cms/site/04h2nx)|null|
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档|null|
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|特殊可选|32|企业ID**注意事项**通过企业码2.0签约接口签约，如填写企业id，accout_id和agreement_no可以不填写**必选条件**通过企业码2.0签约接口签约的企业该字段必填|2088000194958956|
|quota_id|String|必须|32|额度ID|2021062800152601350000001468|
|amount|String|特殊可选|20|变更的金额/余额，日元或者韩元以（元）为单位，其他币种以（分）为单位，当变更的资产类型为次卡时，单位为次**注意事项**当为ADD、DEDUCT，amount必须大于0；日元和韩元最小单位为元，当修改日元或者韩元时以元为单位，其他币种以分为单位填写，币种以创建制度时填写的currency为准。**必选条件**当操作类型为ADD、DEDUCT时，amount必须填写|10|
|action|String|必须|32|变更模式**枚举值**增加额度:ADD减少额度:DEDUCT修改余额转赠属性:MODIFY_SHARE_MODE**注意事项**ADD - 给余额/点券增加amount， DEDUCT - 给余额/点券扣减amount， MODIFY_SHARE_MODE-仅支持修改余额是否可转赠。|ADD|
|outer_source_id|String|必须|32|外部操作幂等ID（接入方接口调用幂等控制ID）|TN00000000000001|
|share_mode|String|可选|16|是否可转赠，1表示可转赠，0表示不可转赠**枚举值**不可转赠:0可转赠:1**注意事项**只支持修改余额的是否可转赠类型，不支持点券，次卡|1|
|account_id|String|可选|32|企业共同账户ID（该字段将废弃，不建议使用，可用enterprise_id字段替换）**注意事项**通过企业码1.0接口签约的共同账户，和agreement_no搭配使用|2088000194958956|
|agreement_no|String|可选|32|授权签约协议号（该字段将废弃，不建议使用，可用enterprise_id字段替换）**注意事项**可通过签约消息获取。配合企业共同账户id使用，当填写企业共同账户id时，此字段必填|20215425001112341234|
|platform|String|可选|100|外部平台编码**注意事项**通常为接入方大写英文缩写|RJ|
### 请求示例
#### 默认示例
##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayEbppInvoiceExpensecontrolQuotaModify
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayEbppInvoiceExpensecontrolQuotaModifyRequest request = new AlipayEbppInvoiceExpensecontrolQuotaModifyRequest();
            AlipayEbppInvoiceExpensecontrolQuotaModifyModel model = new AlipayEbppInvoiceExpensecontrolQuotaModifyModel();
            
            // 设置企业ID
            model.EnterpriseId = "2088000194958956";
            
            // 设置额度ID
            model.QuotaId = "2021062800152601350000001468";
            
            // 设置变更的金额/余额
            model.Amount = "10";
            
            // 设置变更模式
            model.Action = "ADD";
            
            // 设置外部操作幂等ID（接入方接口调用幂等控制ID）
            model.OuterSourceId = "TN00000000000001";
            
            // 设置是否可转赠
            model.ShareMode = "1";
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayEbppInvoiceExpensecontrolQuotaModifyResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.response.AlipayEbppInvoiceExpensecontrolQuotaModifyResponse;
import com.alipay.api.domain.AlipayEbppInvoiceExpensecontrolQuotaModifyModel;
import com.alipay.api.request.AlipayEbppInvoiceExpensecontrolQuotaModifyRequest;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayEbppInvoiceExpensecontrolQuotaModify {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayEbppInvoiceExpensecontrolQuotaModifyRequest request = new AlipayEbppInvoiceExpensecontrolQuotaModifyRequest();
        AlipayEbppInvoiceExpensecontrolQuotaModifyModel model = new AlipayEbppInvoiceExpensecontrolQuotaModifyModel();
        
        // 设置企业ID
        model.setEnterpriseId("2088000194958956");
        
        // 设置额度ID
        model.setQuotaId("2021062800152601350000001468");
        
        // 设置变更的金额/余额
        model.setAmount("10");
        
        // 设置变更模式
        model.setAction("ADD");
        
        // 设置外部操作幂等ID（接入方接口调用幂等控制ID）
        model.setOuterSourceId("TN00000000000001");
        
        // 设置是否可转赠
        model.setShareMode("1");
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayEbppInvoiceExpensecontrolQuotaModifyResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayEbppInvoiceExpensecontrolQuotaModifyRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayEbppInvoiceExpensecontrolQuotaModifyRequest();
$model = array();

// 设置企业ID
$model['enterprise_id'] = "2088000194958956";

// 设置额度ID
$model['quota_id'] = "2021062800152601350000001468";

// 设置变更的金额/余额
$model['amount'] = "10";

// 设置变更模式
$model['action'] = "ADD";

// 设置外部操作幂等ID（接入方接口调用幂等控制ID）
$model['outer_source_id'] = "TN00000000000001";

// 设置是否可转赠
$model['share_mode'] = "1";

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.ebpp.invoice.expensecontrol.quota.modify&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"enterprise_id":"2088000194958956",
	"quota_id":"2021062800152601350000001468",
	"amount":"10",
	"action":"ADD",
	"outer_source_id":"TN00000000000001",
	"share_mode":"1"
}' 
```
 

### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|success|Boolean|必须|10|是否成功|true|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_ebpp_invoice_expensecontrol_quota_modify_response":{
		"code":"10000",
		"msg":"Success",
		"success":true
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_ebpp_invoice_expensecontrol_quota_modify_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|APPROVED_QUOTA_MODIFY_ERROR|需审批的额度不允许修改|创建额度时如果企业指定了额度需审批后才能生效，则不支持通过该接口修改额度|
|COUPON_MODIFY_SHARE_MODE_ERROR|点券不支持设置是否可转赠|如果要修改是否可转赠类型，请确保额度的类型是余额，目前暂不支持修改点券的是否可转赠类型|
|PERMISSION_DENIED|可能因为入参的企业ID有误，导致权限不足，未能查到企业和isv之间的映射关系。|可以通过检查入参的企业ID来解决，如确认企业ID无误后未能解决，请联系企业码客服或技术支持。|
|QUOTA_EXCEED|额度超限|请修改额度|
|QUOTA_INSUFFICIENT|额度不足|可以通过修改扣减额度来解决，如未能解决，请联系企业码客服或技术支持。|
|QUOTA_LOCKED|存在已锁定的额度|重试|
|QUOTA_NO_EXISTS|额度不存在|可以通过修改额度参数来解决，如未能解决，请联系企业码客服或技术支持。|
|QUOTA_TYPE_NOT_MODIFY|额度类型不满足修改条件|额度不可修改|
|QUOTA_USED|额度已被使用|额度已被使用|
|REQUEST_REPEAT|请求重复|该错误码已废弃，如果使用相同幂等id操作，系统按操作成功返回，不会重复处理。|