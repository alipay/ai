# 企业码费控 - 内部费控模式

## 概述

内部费控模式下，服务商将管控规则和额度通过接口同步到企业码，由企业码进行费控管控。

## 流程图

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           内部费控模式流程                               │
└─────────────────────────────────────────────────────────────────────────┘

【制度管理】
场景前置决策：生成制度创建代码前，如果方案型 Skill 或用户上下文已给出费用类型和费用类型子类，直接沿用；如果无法推断，必须先询问用户确认。未确认场景前不得生成制度创建代码。

企业管理员 → 服务商系统 → 支付宝企业码
   │              │              │
   ├─创建费控制度─┤→ alipay.ebpp.invoice.institution.create
   │              │              │      【关键步骤：需先确认场景和选择规则因子】
   │              │              │      1. 查阅官方费用类型文档确认费用类型和费用类型子类（场景）
   │              │              │      2. 查阅官方场景约束文档确定必须使用的规则因子
   │              │              │      3. 查阅官方规则因子文档获取值结构和示例值
   │              │              │      4. 查阅官方发放规则文档获取字段示例值（可选）
   │              │              │      5. 查阅下方官方制度创建接口文档
   ├─编辑费控制度─┤→ alipay.ebpp.invoice.institution.modify
   ├─删除费控制度─┤→ alipay.ebpp.invoice.institution.delete
   ├─查询制度列表─┤→ alipay.ebpp.invoice.institution.pageinfo.query
   ├─查询制度详情─┤→ alipay.ebpp.invoice.institution.detailinfo.query
   └─查询适用成员─┘→ alipay.ebpp.invoice.institution.scopepageinfo.query
                      (员工数>1000或部门数>100时使用)

【手工发放管理】（可选，适用于差旅、招待等场景）
企业管理员 → 服务商系统 → 支付宝企业码
   │              │              │
   └─手工发放额度─┤→ alipay.ebpp.invoice.expensecontrol.quota.create
   └─查询发放明细─┘→ alipay.ebpp.invoice.issuebatch.issuerecords.batchquery

【额度管理】（可选）
企业管理员 → 服务商系统 → 支付宝企业码
   │              │              │
   ├─查询可用额度─┤→ alipay.ebpp.invoice.expensecontrol.quota.query
   ├─修改可用额度─┤→ alipay.ebpp.invoice.expensecontrol.quota.modify
   └─删除可用额度─┘→ alipay.ebpp.invoice.expensecontrol.quota.delete
```

## 接口文档

| 阶段 | 接口说明 | 接口文档 | 备注 |
|------|----------|----------|------|
| **制度管理** | 创建费控制度 | [institution-create](https://opendocs.alipay.com/pre-open/2e513b45_alipay.ebpp.invoice.institution.create.md) | **关键步骤**：<br>1. 确认[费用类型和子类](https://ideservice.alipay.com/cms/site/07nn3i.md)<br>2. 选择[规则因子](https://ideservice.alipay.com/cms/site/07nqp0.md)<br>3. 查看[规则因子明细](https://ideservice.alipay.com/cms/site/07nqoz.md)<br>4. 配置[发放规则](https://ideservice.alipay.com/cms/site/07nwcs.md)（可选） |
| | 编辑费控制度 | [institution-modify](https://opendocs.alipay.com/pre-open/c79eaa94_alipay.ebpp.invoice.institution.modify.md) | |
| | 删除费控制度 | [institution-delete](https://opendocs.alipay.com/pre-open/05b50752_alipay.ebpp.invoice.institution.delete.md) | |
| | 查询制度列表 | [institution-pageinfo-query](https://opendocs.alipay.com/pre-open/3f4a1bf7_alipay.ebpp.invoice.institution.pageinfo.query.md) | |
| | 查询制度详情 | [institution-detailinfo-query](https://opendocs.alipay.com/pre-open/c742319f_alipay.ebpp.invoice.institution.detailinfo.query.md) | |
| | 查询适用成员 | [institution-scopepageinfo-query](https://opendocs.alipay.com/pre-open/aeb34914_alipay.ebpp.invoice.institution.scopepageinfo.query.md) | 员工>1000或部门>100时使用 |
| **手工发放管理**（可选） | 创建手工发放额度 | [quota-create](https://opendocs.alipay.com/pre-open/99f395e9_alipay.ebpp.invoice.expensecontrol.quota.create.md) | 适用于差旅、招待等场景 |
| | 查询发放明细 | [issuebatch-issuerecords-query](https://opendocs.alipay.com/pre-open/1f1edddf_alipay.ebpp.invoice.issuebatch.issuerecords.batchquery.md) | |
| **额度管理**（可选） | 查询员工可用额度 | [quota-query](https://opendocs.alipay.com/pre-open/485b4d89_alipay.ebpp.invoice.expensecontrol.quota.query.md) | |
| | 修改员工可用额度 | [quota-modify](https://opendocs.alipay.com/pre-open/8e60ac5c_alipay.ebpp.invoice.expensecontrol.quota.modify.md) | |
| | 删除员工可用额度 | [quota-delete](https://opendocs.alipay.com/pre-open/3cf6a733_alipay.ebpp.invoice.expensecontrol.quota.delete.md) | |

## 参考文档

- [费用类型枚举](https://ideservice.alipay.com/cms/site/07nn3i.md) - 费用类型及子类定义
- [费用类型与规则因子约束](https://ideservice.alipay.com/cms/site/07nqp0.md) - 各场景下规则因子的使用约束
- [使用规则因子枚举](https://ideservice.alipay.com/cms/site/07nqoz.md) - 所有规则因子详细说明
- [发放规则字段说明](https://ideservice.alipay.com/cms/site/07nwcs.md) - 发放规则字段详细说明
