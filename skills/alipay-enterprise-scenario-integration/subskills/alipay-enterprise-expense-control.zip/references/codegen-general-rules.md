# 费控通用代码生成规则

本文件适用于所有技术栈。具体技术栈门禁见 [费控 Java/Maven 质量门禁](quality-gates/java-maven.md)、[费控 Node.js 质量门禁](quality-gates/nodejs.md) 和 [费控 Python/Go/.NET 质量门禁](quality-gates/python-go-dotnet.md)。

1. 接口、字段、枚举、规则因子、SPI 字段和业务结构只来自已读取文档；文档未找到时说明缺失，不猜测补齐。
2. 请求字段、响应字段、SPI 字段分开使用，不得互相迁移。
3. 必须使用对应语言的官方 SDK，或文档支持的 HTTP(S)/SPI 接入方式。
4. 不得生成 stub、mock、空实现或固定成功返回来绕过编译、验签、接口缺失或能力缺失。
5. SPI 和通知接入必须实现真实验签、幂等、失败处理；外部费控还必须处理咨询、扣减、退还和状态查询链路。
6. 接入方业务逻辑可以通过 Port、Adapter、回调接口或等价扩展点交付；扩展点尚未绑定真实实现时必须失败关闭，例如抛出明确的未配置异常、返回文档允许的失败结果或阻止应用启动。默认 fail-closed Bean 必须能被接入方真实实现无冲突覆盖，例如使用 `@ConditionalOnMissingBean` 或互斥 profile。显式 fail-closed Adapter 可以抛异常，优先使用自定义 NotConfigured 异常；`UnsupportedOperationException` 仅允许出现在边界清晰的 fail-closed 默认 Adapter 中，不得代替 SDK 调用、安全校验或已选择业务能力的实现。不得回显请求值来构造允许/成功结果，也不得只记录日志或只更新幂等状态后确认业务成功。
7. 外部费控的扣减、恢复、退款、状态查询和幂等属于服务商真实资金/额度状态，必须通过支持持久化、事务和多实例一致性的业务 Port/Repository 落地。进程内 Map/Set 状态机只能用于明确的 demo/test 配置，不能作为默认生产实现。
8. 内部费控制度创建/修改必须在服务入口落实已确认的额度或发放来源：发放规则、限额条件、手工发放三类至少一类实际进入请求结构；缺失时 fail fast，不得只在注释、README 或回执中说明。
9. 可替换的 Store、Repository、Callback、Port 等生产扩展点必须先定义接口，Service、Handler、Controller、AutoConfiguration 等核心运行组件依赖接口，不得直接依赖 demo/test 具体实现。
10. Spring profile 只能限制 demo/test 存储、回调、适配器或示例配置；核心 Handler、Router、Controller、Service、AutoConfiguration、启动监听器必须默认可装配。
11. Spring 自动配置、初始化或 `@PostConstruct` 不得直接调用同类中的 `@Bean` 方法来获取依赖；必须注入真实 Bean、`ObjectProvider` 或事件监听，避免绕过 `@ConditionalOnBean` 和 profile 条件。
12. 未知通知类型或未知 `msg_method` 默认不得成功确认；除非显式 unknown handler 写清确认策略，否则必须返回失败或抛异常。
13. 已有项目增量接入时，第一轮只盘点现有 SDK、Central Portal 当前 SDK 版本、配置、费控服务、SPI/通知入口、目录结构、已有费用/制度/额度 Entity/Service/Repository/Controller 和已实现费控接口，并输出业务衔接点、拟新增/修改文件清单和拟定 `.alipay-skill/integration-contract.json`；Java/Maven 项目必须把 `alipay-sdk-java` 升级到当前版本列入计划，用户确认前不得修改代码或写入契约。
14. 已有项目不得重写公共构建文件、配置体系、启动入口或现有 SPI/通知网关；如需公共改动，先列为计划或回执中的待处理项。
15. 已有项目中，制度、额度或 SPI 结果默认必须衔接已有费控业务对象；孤立旁路模块必须先说明原因并等待用户确认。
16. 已有项目生成后必须使用 `ALIPAY_PROJECT_MODE=existing` 运行本域 validator；契约中不得保留 `NEEDS_USER_CONFIRM`，声明的文件和符号必须真实存在。
17. 生成后必须运行对应语言的依赖解析、构建、测试或最接近的自检；无法运行时说明原因。已有项目全量测试原本失败时，记录 baseline 并运行本域/增量范围自检。
18. SDK 或文档不支持时，说明不支持，不猜类名、方法名、接口名、字段名或规则因子。
19. 存在场景方案生成的 `.alipay-skill/scenario.json` 时，制度创建按[接入来源标识约定](scenario-source-identifier.md)处理；不询问用户、不作为业务配置，独立费控接入不启用。
20. 本域 validator 运行时使用 `curl` 从 `interface-docs.json` 记录的官方 URL 获取当前 Markdown，并对临时网络失败自动重试。运行环境必须能访问 `opendocs.alipay.com`；重试后仍无法获取时按 validator 基础设施失败处理，不得使用历史字段或枚举继续校验。
