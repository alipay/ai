# 费控 Java/Maven 质量门禁

本文件只用于费控 Skill 生成 Java/Maven 代码时的工程质量、SDK、消息接入和失败处理门禁。跨语言通用原则见 [费控通用代码生成规则](../codegen-general-rules.md)，字段、接口、枚举和嵌套结构规则见 [费控字段和接口规则](../field-interface-rules.md)。非 Java 技术栈不要把本文件作为硬门禁。

## 输出注释

1. 生成代码注释中不得手写“字段白名单”“白名单字段”或“白名单：...”这类自报来源；文档真实枚举、规则因子或业务名称中包含“白名单”时可以保留。
2. 需要说明字段来源时，只写“字段来源：接口文档业务请求参数表”。

## Java SDK 来源

1. Java 调用必须使用官方 `Request + Model + request.setBizModel(model)`；禁止手拼 `biz_content`、调用 `setBizContent`、用 JSON 或 Map 请求体绕过 SDK Model。
2. 禁止生成本地支付宝 SDK stub、mock 或影子类；源码中不得创建 `com.alipay.api` 包。
3. 生成 Java 代码前必须完成 SDK 预检。新 Maven 项目和已有项目叠加接入都必须用以下单条命令读取 Central Portal 页面，并从页面中的 `pkg:maven/com.alipay.sdk/alipay-sdk-java@<version>` 或 Maven dependency snippet 提取 `alipay-sdk-java` 当前版本：

```bash
curl -sL "https://central.sonatype.com/artifact/com.alipay.sdk/alipay-sdk-java"
```
4. Java/Maven 接入目标版本一律使用 Central Portal 当前版本。已有项目如果已有旧版 `alipay-sdk-java`，增量改造计划中必须列出升级依赖和同步说明文档；用户确认计划后执行升级。
5. 如果 auto mode、沙箱、网络策略或命令审批禁止执行上述 `curl`，不得改用记忆中的版本，也不得使用 `search.maven.org/solrsearch` 兜底；必须停止 Java/Maven 代码生成，请求用户授权执行该 `curl`，或要求用户明确提供 Central Portal 当前版本。
6. 提取出的 `alipay-sdk-java` 版本必须匹配 `^[0-9]+\.[0-9]+\.[0-9]+\.ALL$`。不符合该格式时，视为抓到了页面资源版本或其他无关版本，必须重新从 `pkg:maven/...@<version>` 或 dependency snippet 提取。
7. 必须用 `jar tf` 验证计划使用的 `Request`、`Response`、`Model` 类真实存在。
8. 找不到 SDK getter/setter 或源码包缺失时，使用 `jar tf`、`javap -classpath <sdk.jar> <class>` 或 IDE 反编译确认真实类和方法；不得用反射、`getMethod/invoke`、`BeanUtils`、Map 包装等方式绕过官方 SDK Request/Model/Response 的编译期类型。
9. Maven 依赖解析或真实 SDK 编译失败时，保留官方 SDK 调用代码并基于 SDK 类型、版本和引用文档修正；不得改写为 stub、非 SDK Model 调用或猜测类名。
10. 禁止安全和接口完整性 stub：验签方法不得 `return true`，SDK 接口方法不得 `return null` 充数，也不得抛 `UnsupportedOperationException` 代替实现。显式的未配置 fail-closed Adapter 可以抛清晰异常，优先使用自定义 NotConfigured 异常。
11. 公开 SDK 方法的入参必须落到请求 Model、嵌套结构、校验逻辑或明确的业务分支中；如果某个能力暂不实现，不要暴露对应参数。

## Java/Maven 工程质量

1. 生成环境必须运行本域 validator；该 Node 脚本属于 Skill 生成质量门禁，不作为接入方 Java 工程依赖。
2. 有 Maven 工程时必须尝试编译；编译失败时，必须保留官方 SDK 代码并基于依赖、类型或文档修正。
3. 校验失败时必须优先修正 SDK 类型、字段路径和嵌套结构；不得删除已选择模块的接口能力、方法或业务分支来绕过校验。确需裁剪时，必须在交付说明中明确列为未覆盖边界。
4. 代码目录可以按接入方习惯组织；校验以接口、SDK 类和业务字段识别域归属，不要求固定存在 `expense` 包。
5. 外部费控扣减、恢复、退款、状态查询和幂等必须落到支持持久化、事务和多实例一致性的 Port/Repository；默认生产 Bean 不得用进程内 Map/Set 充当额度账本。内存状态机只能放在 test/demo profile。
6. Spring 注入接口如果只有 profile 条件实现，默认配置必须明确激活对应 profile，或提供无条件的真实/fail-closed 实现。
7. 生成工程必须包含可执行测试；Spring Boot 新工程还必须有上下文装配测试。`mvn test` 执行零个测试不算通过。
8. 修改已有制度嵌套项时，测试必须验证请求只包含文档允许修改的字段；不得因为 SDK 提供 setter 就重复提交文档声明不可变或无需填写的字段。
9. SPI 必选数值字段必须覆盖合法值、缺失值和格式非法值测试；缺失或解析失败必须返回参数错误，不能默认成 `0` 或其他业务数值后继续调用额度 Port。
10. SPI 响应签名模式必须由配置显式选择。启用加签时，测试必须覆盖签名异常并证明响应不会自动降级为未签名成功或业务响应；关闭加签时应走独立、可审计的配置分支。

## Java 消息接入

费控制度接口本身不需要 WebSocket 通知入口。独立使用费控 Skill 且确有费控通知处理时，只允许官方 `AlipayMsgClient + MsgHandler`，并遵守以下规则：

1. 不得引入 `Java-WebSocket`、`javax.websocket`、`jakarta.websocket`。
2. 不得手写连接协议层、鉴权消息、心跳、ack 或自定义验签流程。
3. 必须生成可执行接入代码：持有 `AlipayMsgClient` 实例，完成 `getInstance`、`setSecurityConfig(signType, privateKey, alipayPublicKey)`、`setMessageHandler`、`connect` 和关闭逻辑；`setSecurityConfig` 第一个参数是签名类型（通常 `RSA2`），不得传 `appId`。
4. `MsgHandler.onMessage` 分发到业务 handler 后必须处理失败结果，不能只记录日志后吞掉失败。
5. 未知 `msgApi` / `msg_method` 默认不得返回 success、`true` 或标记已处理；必须返回 fail、抛异常，或委托显式 unknown handler 并由该 handler 明确是否可确认消费。

被方案型 Skill 调用并由主方案统一消息接入时，本域不得生成独立 `AlipayMsgClient.getInstance`、`setMessageHandler` 或 `connect`；如确有费控通知处理，只生成可被主路由器调用的业务 handler。
