# 费控 Node.js 质量门禁

本文件只约束 Node.js 生成代码。通用原则见 [费控通用代码生成规则](../codegen-general-rules.md)，字段和接口来源见 [费控字段和接口规则](../field-interface-rules.md)。

1. 必须读取真实安装的 `alipay-sdk` 导出形态。CommonJS 使用 `const { AlipaySdk } = require("alipay-sdk")`；不得写 `require("alipay-sdk").default`。
2. OpenAPI 2.0 `alipaySdk.exec(method, params, options)` 中，`appAuthToken` 必须作为第二个参数里的网关通参参与签名，例如 `exec(method, { bizContent, appAuthToken })`。
3. 制度管理必须覆盖创建、修改、删除、详情查询、分页查询和适用范围查询；不得用 stub 或固定成功返回代替接口调用。
4. 制度创建必须按文档结构生成 `standard_info_list`；`standard_condition_info_list` 必须挂在使用规则下，费用子类型使用 `standard_info_list.expense_type_sub_category`，不得生成文档不存在、近义改名、扁平化或跨接口借用字段。
5. 制度适用范围使用 `institution_scope_info` 或文档列出的 owner 字段；不得自造员工、部门、范围等近义字段。
6. 制度创建必须显式写入所选费控模式：内部费控 `consult_mode='0'`，外部费控 `consult_mode='1'`；不得依赖接口默认值表达模式。
7. 内部费控创建制度不得只生成商户、时间、位置等使用限制。调用 `institution.create` 前必须具备以下之一：`issue_rule_info_list` 发放规则、制度可用额度的限额条件，或已实现手工发放接口 `alipay.ebpp.invoice.expensecontrol.quota.create`。
8. 内部费控的额度、金额、阈值、比例、时间窗口等业务策略值必须来自用户入参、明确配置或已确认方案；不得静默写死为默认业务值。
9. 外部费控必须覆盖咨询、扣减、退还和状态查询 SPI；SPI 验签、幂等和失败处理必须是真实现实代码。
10. 生成后必须通过 `node --check`、模块加载和 `npm test`；测试脚本存在但失败时不得宣布生成完成。
11. 不得生成 SDK stub、固定成功返回、空验签或本地模拟接口来绕过 SDK 能力缺失。
