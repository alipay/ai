# 已有项目衔接契约

已有项目增量接入时，第一轮先输出盘点和拟定契约，不修改代码。用户确认后，在生成目录写入 `.alipay-skill/integration-contract.json`，再开始费控代码修改。

契约用于说明制度、额度或 SPI 能力接到哪些既有对象或入口。它不是业务运行依赖，只是 Skill 生成和校验证据。

最小结构：

```json
{
  "schemaVersion": 1,
  "projectMode": "existing",
  "baseline": {
    "sdkVersion": "当前项目版本",
    "targetSdkVersion": "Central Portal 当前版本",
    "buildStatus": "passed | failed | not-run"
  },
  "domains": {
    "expense-control": {
      "status": "CONFIRMED",
      "joinPoints": [
        {
          "capability": "institution.create",
          "status": "CONFIRMED",
          "strategy": "service",
          "evidenceFiles": ["src/main/.../ExpensePolicyService.java"],
          "symbols": ["ExpensePolicyService"]
        }
      ],
      "changes": [
        { "path": "src/main/.../ExpenseControlService.java", "action": "add" }
      ]
    }
  },
  "gaps": []
}
```

规则：

1. `gaps` 中不得保留 `NEEDS_USER_CONFIRM`。
2. `domains["expense-control"].status` 必须是 `CONFIRMED` 或 `NOT_APPLICABLE`。
3. `joinPoints` 支持 service、repository、controller、event、gateway、spi、other 等策略，不要求 handler 或 SPI 直接引用某个类型。
4. `evidenceFiles` 和 `changes.path` 必须指向项目内真实文件，不得逃出项目目录。
5. 如果无法确认制度、额度或 SPI 结果如何衔接已有费控对象，先在 `gaps` 说明并暂停，不生成孤立旁路模块。

校验已有项目时使用：

```bash
ALIPAY_PROJECT_MODE=existing node alipay-enterprise-expense-control/scripts/validate_codegen.js <项目目录>
```
