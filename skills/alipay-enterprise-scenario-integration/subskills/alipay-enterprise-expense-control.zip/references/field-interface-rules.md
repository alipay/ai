# 费控字段和接口生成规则

本文件只约束费控字段来源、接口完整性、枚举来源和制度嵌套结构。跨语言生成原则见 [费控通用代码生成规则](codegen-general-rules.md)，各技术栈工程门禁见对应质量门禁文档。

## 通用规则

1. 接口、请求字段、枚举、规则因子和 SPI 字段只来自当前模式已读取的流程文档、接口文档和 common 文档。
2. 请求字段必须保留文档路径；顶层字段如 `enterprise_id`，嵌套字段如 `standard_info_list.standard_condition_info_list.rule_factor`。
3. 枚举值必须来自枚举、规则因子、通知或 SPI 文档，不能按中文含义自造近义值。
4. 字段或枚举校验失败时，先修正文档路径和嵌套结构；不得通过删除已选择模块的接口能力、方法或业务分支来绕过。
5. 文档标为必选且具有数值、日期或结构化类型的字段必须严格解析。缺失、格式非法或超出业务范围时返回文档允许的参数错误；不得把解析失败静默替换为 `0`、空集合、当前时间或其他可参与真实业务计算的默认值。
6. 生成接口调用代码前必须先输出本域接口证据表：接口方法名、接口 Markdown、示例代码位置或片段、SDK/HTTP(S) 接入方式确认、Request/Model/Response 或字段来源、关键字段路径、嵌套结构、枚举和规则因子来源。证据缺失时继续查文档或暂停说明，不得按业务语义猜字段、类名或方法名。
7. Java/Maven 场景中，证据表必须写明 SDK Request/Model/Response 类，并通过 SDK jar 检查或 `javap` 确认关键 getter/setter；不得用反射、Map 包装或本地 stub 绕过未确认的 SDK 类型。

## 模块完成标准

- 制度管理：`alipay.ebpp.invoice.institution.create`、`alipay.ebpp.invoice.institution.modify`、`alipay.ebpp.invoice.institution.delete`、`alipay.ebpp.invoice.institution.detailinfo.query`、`alipay.ebpp.invoice.institution.pageinfo.query`、`alipay.ebpp.invoice.institution.scopepageinfo.query`。
- 手工发放管理：`alipay.ebpp.invoice.expensecontrol.quota.create`、`alipay.ebpp.invoice.issuebatch.issuerecords.batchquery`。
- 额度管理：`alipay.ebpp.invoice.expensecontrol.quota.query`、`alipay.ebpp.invoice.expensecontrol.quota.modify`、`alipay.ebpp.invoice.expensecontrol.quota.delete`。
- 外部费控：除制度管理外，必须覆盖 SPI 集成规范、额度咨询、额度扣减、额度退还、额度状态查询和测试用例。

## 外部费控 SPI 约束

- 响应是否加签由开放平台服务配置与接入方部署配置共同确定。代码应显式表达签名模式；启用响应加签时，签名失败必须阻断响应或返回明确系统失败，不能在异常分支自动降级为未签名响应。
- 必选金额等强类型业务字段必须先完成格式和范围校验，再调用额度咨询、扣减、退还或状态存储；非法值不得进入业务 Port。

## 制度管理结构约束

制度接口的规则、场景、范围和发放规则是嵌套结构，禁止按业务语义自造扁平字段。

- 费用类型和费用子类必须按 [费用类型枚举](common/expense-type-enum.md) 的映射成对使用；例如某个 `expense_type` 选定后，`expense_type_sub_category` 只能取该费用类型下列出的子类。`consume_mode=DEFAULT` 只表示消费模式，不得当作费用子类默认值。
- 生效时间、规则、范围、发放规则等字段必须使用文档字段和路径；不得按业务语义近义改名、扁平化到顶层或跨接口借用。常见反例包括把生效时间改写为 `effective_time` / `expire_time`，或创建 `use_rules` 顶层字段。
- 内部费控创建制度时，不能只配置商户、时间、位置等使用限制。`alipay.ebpp.invoice.institution.create` 至少必须具备以下之一：`issue_rule_info_list` 发放规则、制度可用额度的限额条件、或已选择并实现手工发放接口 `alipay.ebpp.invoice.expensecontrol.quota.create`。
- 可视为制度可用额度限额条件的规则因子仅包括：`QUOTA_DAY`、`QUOTA_WEEK`、`QUOTA_MONTH`、`QUOTA_SEASON`、`QUOTA_YEAR`、`QUOTA_TOTAL`。`MERCHANT`、`ALARM_CLOCK_TIME`、`ALLOW_MINIMUM`、`OWNER_PAY_MINIMUM`、`QUOTA_ONCE`、`QUOTA_ONCE_PERCENT`、`QUOTA_UNLIMITED` 均不能单独满足该要求。
- 发放规则必须放在 `issue_rule_info_list` 文档结构下；不得创建近义的发放规则字段。
- 适用范围必须按 `institution_scope_info` 或接口文档支持的范围字段生成；不得创建近义的员工、部门或范围字段。
- 修改制度必须使用 [制度修改接口文档](common/institution-modify.md) 的修改结构；不得把创建接口的结构直接搬到修改接口。
- 修改已有嵌套项时，先按文档区分定位字段、可修改字段和不可变字段。以 `modify_condition_list` 为例，`rule_id` 用于定位已有条件，提交新的 `rule_value`；文档声明不可变或“无需填写”的 `rule_factor` 不得重复提交。新增条件仍按 `add_condition_list` 的字段要求生成，不能套用修改已有条件的限制。
- 不要写一个“万能修改方法”却只落地部分参数。基础信息修改、使用规则修改、适用范围修改应拆成清晰方法；方法入参收了额度、时间、范围或规则信息，就必须写入制度修改接口文档对应结构。
- 修改制度下使用规则时，不得把 `standard_info_list` 当作制度修改接口顶层字段。必须使用 `modify_standard_detail_info` 下的结构，例如 `modify_standard_detail_info.modify_standard_list`、`modify_standard_detail_info.add_standard_list`、`modify_standard_detail_info.delete_standard_id_list`。
- 修改制度适用范围时，必须使用 `modify_scope_info`；不得复用创建接口的 `institution_scope_info` 路径。
