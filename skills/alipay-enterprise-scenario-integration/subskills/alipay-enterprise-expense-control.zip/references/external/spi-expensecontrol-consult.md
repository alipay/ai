# spi.alipay.commerce.ec.expensecontrol.expensecontrol.consult(企业费控咨询SPI)
用于拉起收银台时渲染企业因公付规则是否可用。根据对应企业、员工以及其拥有的规则，咨询员工对应规则下的可用额度。

注意：

在调用 SPI 时，外部商户响应报文中的统一错误码只有两种：10000 和 40004，具体信息如下图所示：

| code（返回码） | msg（返回码描述） | sub_code（明细返回码） | sub_msg（明细返回码描述） | 解决方案 |
|---|---|---|---|---|
| 10000 | Success（接口调用成功，调用结果请参考具体的 SPI 文档所对应的业务返回参数） | - | - | - |
| 40004 | Business Failed（业务处理失败） | 对应业务错误码，明细错误码和解决方案请参见具体的 SPI 文档。 | - | - |

## 公共请求参数
|参数|类型|是否必选|最大长度|描述|示例值|
|---|---|---|---|---|---|
|method|String|必选|128|接口名称|alipay.trade.order.settle|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|version|String|必选|3|版本号，默认1.0|1.0|
|utc_timestamp|String|必选|19|发送请求的时间戳，单位秒|1699271704|
|sign_type|String|必选|10|签名类型，开发者在支付宝开放平台配置接口加签方式|RSA2|
|sign|String|必选|344|商户请求参数的签名串|详见示例|

## 业务请求参数
|参数|类型|是否必选|最大长度|描述|示例值|
|---|---|---|---|---|---|
|trade_no|String|必选|128|支付宝正向交易单号|2021092222001106280506131871|
|enterprise_id|String|必选|64|企业id|2088000450803244|
|employee_id|String|必选|64|消费员工id|2288094003774365|
|standard_id_list|String[]|必选|64|支付宝费控使用规则ID列表|["2021060300152601000000000001","2021060300152601000000000002"]|
|apply_amount|Number|必选|32|咨询的金额，单位是分|2000|
|biz_date|Date|必选|32|业务时间|2022-11-28 00:00:01|
|out_trade_no|String|可选|128|外部商户交易号|OUT011123232344|
|merchant_ext_info|MerchantExtInfo|可选|-|商户扩展信息，可选项，用于在外算链路透传外部服务商写入的商户信息|-|
|merchant_ext_info.external_shop_id|String|必选|100|外部门店id，由服务商通过蚂蚁门店入驻写入|xxxx|

## 公共响应参数
|参数|类型|是否必选|最大长度|描述|示例值|
|---|---|---|---|---|---|
|code|String|必选|-|网关返回码|40004|
|msg|String|必选|-|网关返回码描述|Business Failed|
|sub_code|String|可选|-|业务返回码，参见具体的API接口文档|ACQ.TRADE_HAS_SUCCESS|
|sub_msg|String|可选|-|业务返回码描述，参见具体的API接口文档|交易已被支付|
|sign|String|必选|-|签名|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|

## 业务响应参数
|参数|类型|是否必选|最大长度|描述|示例值|
|---|---|---|---|---|---|
|result|ExpenseControlConsultResult[]|必选|-|费控咨询结果|-|
|result.standard_id|String|必选|64|对应入参的规则ID|2021060300152601000000000001|
|result.available_amount|Number|必选|32|规则可用金额（分）|2000|
|result.consult_status|Boolean|必选|8|规则执行结果|false|
|result.result_code|String|可选|256|结果编码|INVALID_STANDARD|
|result.result_msg|String|可选|64|执行结果描述|找不到对应规则|

**result_code枚举值：**
- INVALID_STANDARD：找不到对应规则
- QUOTA_NOT_ENOUGH：额度不足
- QUOTA_OCCUPIED：额度已被占用（咨询的单据，对应额度已被扣减（DEDUCT）或退款（REFUND））

## 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|查看是否有逻辑错误|
|INVALID_PARAMETER|参数有误，参数不正确|参数错误，检查入参是否正确|
|UNKNOWN_ERROR|通用错误类型|兜底业务异常，如被限流、无权限等|

## 请求示例
```bash
curl -X POST 'SPI_IMPLEMENTATION_URL?sign=${sign}&method=spi.alipay.commerce.ec.expensecontrol.expensecontrol.consult&charset=UTF-8&version=1.0&utc_timestamp=${now}&sign_type=RSA2' \
--header 'Content-Type: application/x-www-form-urlencoded;charset=UTF-8' \
--data-urlencode 'trade_no=2021092222001106280506131871' \
--data-urlencode 'enterprise_id=2088000450803244' \
--data-urlencode 'employee_id=2288094003774365' \
--data-urlencode 'standard_id_list=["2021060300152601000000000001","2021060300152601000000000002"]' \
--data-urlencode 'apply_amount=2000' \
--data-urlencode 'biz_date=2022-11-28 00:00:01' \
--data-urlencode 'out_trade_no=OUT011123232344' \
--data-urlencode 'merchant_ext_info={
	"external_shop_id":"xxxx"
}'
```

**说明：**SPI_IMPLEMENTATION_URL是开发者在开放平台实现Spi接口时填写的后端服务地址

## 响应示例
### 正常响应示例
```json
{
    "response": {
        "code": "10000",
        "msg": "Success",
        "result": [
            {
                "standard_id": "2021060300152601000000000001",
                "available_amount": 2000,
                "consult_status": false,
                "result_code": "INVALID_STANDARD",
                "result_msg": "找不到对应规则"
            }
        ]
    },
    "sign": "ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```

### 异常响应示例
```json
{
    "response": {
        "code": "40004",
        "msg": "Business Failed",
        "sub_code": "SYSTEM_ERROR",
        "sub_msg": "系统繁忙"
    },
    "sign": "ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
