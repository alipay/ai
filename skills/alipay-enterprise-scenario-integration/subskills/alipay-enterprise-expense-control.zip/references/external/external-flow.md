# 企业码费控 - 外部费控模式

## 概述

外部费控模式下，企业码在支付中通过 SPI 接口咨询服务商进行费控。

**准入条件**：服务商必须满足「解决其内部多平台额度一致性问题」的条件才允许准入。

**性能要求**：接口响应时间必须在 600ms 内（含网络耗时）。

## 流程图

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           外部费控模式流程                               │
└─────────────────────────────────────────────────────────────────────────┘

【前置配置】（首次接入时需小二配置）
├─ 企业咨询耗时放开（800ms）
├─ ISV接口调用信息配置
├─ ISV展示名称配置
├─ 企业咨询配置
└─ ISV限流信息（可选）

【制度管理】（consult_mode=1）
场景前置决策：生成制度创建代码前，如果方案型 Skill 或用户上下文已给出费用类型和费用类型子类，直接沿用；如果无法推断，必须先询问用户确认。未确认场景前不得生成制度创建代码。

同内部费控模式，但创建或修改费控制度时：
【关键步骤：需先确认场景和选择规则因子】
1. 确认费用类型和费用类型子类（场景）
2. 根据场景查阅 ../common/expense-type-constraints.md 确定必须使用的规则因子
   （外部费控不可使用额度类规则因子）
3. 查阅 ../common/rule-factors.md 获取规则因子值的结构和示例值
4. 设置 consume_mode=DEFAULT（外部费控只支持此模式）
5. issue_rule_info_list 必须为空（外部费控不可创建发放规则）
6. 查阅 ../common/institution-create.md 接口文档

【员工支付流程】
员工 → 商户 → 支付宝支付中台 → 支付宝企业码 → 服务商系统
 │       │            │              │              │
 │       │            │              ├─额度咨询─────┤→ spi.alipay.commerce.ec.expensecontrol.expensecontrol.consult
 │       │            │              │   (查询员工额度)
 │       │            │              │←─────────────┘
 │       │            │←─────────────┘
 │       │            │  拉起收银台
 │       │            │←员工确认支付
 │       │            │
 │       │            │←额度扣减─────┐
 │       │            │              ├─额度扣减─────┤→ spi.alipay.commerce.ec.expensecontrol.quota.pay
 │       │            │              │   (扣减员工额度)
 │       │            │              │←─────────────┘
 │       │←─────────────────────────┘
 │       │
 │       │←【1分钟后确认支付结果】
 │       │    企业码 → 支付宝：查询支付结果
 │       │    企业码 → 服务商：spi.alipay.commerce.ec.expensecontrol.quotastatus.query（查询额度状态）
 │       │    [若支付结果未知且ISV已扣减额度]
 │       │    企业码 → 服务商：spi.alipay.commerce.ec.expensecontrol.quota.refund（refund_mode=RECOVER）
 │       │
 │       │←【支付成功】
 │       │    企业码 → 服务商：spi.alipay.commerce.ec.expensecontrol.quotastatus.query
 │       │    [若ISV未扣减或已恢复额度]
 │       │    企业码 → 服务商：spi.alipay.commerce.ec.expensecontrol.quota.pay（扣减额度）
 │       │
 │       │←【支付退款】
 │       │    企业码 → 服务商：spi.alipay.commerce.ec.expensecontrol.quotastatus.query
 │       │    [若ISV未扣减或已恢复额度]
 │       │    企业码 → 服务商：spi.alipay.commerce.ec.expensecontrol.quota.pay（扣减额度）
 │       │    企业码 → 服务商：spi.alipay.commerce.ec.expensecontrol.quota.refund（refund_mode=REFUND）
 │       │
 └───────┘←查看支付结果
```

## 接入步骤

1. **前置配置**：联系支付宝小二完成基础配置
2. **接入制度管理**：覆盖制度创建、修改、删除、详情查询、分页查询、适用范围查询；创建/修改时设置 `consult_mode=1`，`consume_mode=DEFAULT`，使用规则不能使用额度规则因子，不能配置发放规则
3. **实现 SPI 接口**：额度咨询、扣减、退还、状态查询
4. **联调测试**：确保通过所有验证用例
5. **上线运行**

## 接口文档

| 阶段 | 接口说明 | 接口文档 | 备注 |
|------|----------|----------|------|
| **制度管理** | 创建费控制度 | [institution-create.md](../common/institution-create.md) | **关键步骤**：<br>1. 确认[费用类型和子类](../common/expense-type-enum.md)<br>2. 选择[规则因子](../common/expense-type-constraints.md)（**不可使用额度类规则因子**）<br>3. 查看[规则因子明细](../common/rule-factors.md)<br>4. 设置 `consult_mode=1`，`consume_mode=DEFAULT`<br>5. `issue_rule_info_list` 必须为空（外部费控不可配置发放规则） |
| | 编辑费控制度 | [institution-modify.md](../common/institution-modify.md) | |
| | 删除费控制度 | [institution-delete.md](../common/institution-delete.md) | |
| | 查询制度列表 | [institution-pageinfo-query.md](../common/institution-pageinfo-query.md) | |
| | 查询制度详情 | [institution-detailinfo-query.md](../common/institution-detailinfo-query.md) | |
| | 查询适用成员 | [institution-scopepageinfo-query.md](../common/institution-scopepageinfo-query.md) | 员工>1000或部门>100时使用 |
| **SPI 接口** | SPI 集成规范 | [spi-integration.md](spi-integration.md) | |
| | 额度咨询 | [spi-expensecontrol-consult.md](spi-expensecontrol-consult.md) | |
| | 额度扣减 | [spi-quota-pay.md](spi-quota-pay.md) | |
| | 额度退还 | [spi-quota-refund.md](spi-quota-refund.md) | |
| | 额度状态查询 | [spi-quotastatus-query.md](spi-quotastatus-query.md) | |
| | 测试用例 | [spi-test-cases.md](spi-test-cases.md) | |

## 参考文档

- [费用类型枚举](../common/expense-type-enum.md) - 费用类型及子类定义
- [费用类型与规则因子约束](../common/expense-type-constraints.md) - 各场景下规则因子的使用约束
- [使用规则因子枚举](../common/rule-factors.md) - 所有规则因子详细说明
