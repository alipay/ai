# SPI接口测试用例

## 接口验证用例
### 1、额度咨询
**接口名称：spi.alipay.commerce.ec.expensecontrol.expensecontrol.consult**

#### 用例1.1：员工额度充足，执行成功
**入参：**  
员工可用额度大于5元，拉起收银台时，咨询对应可用的一个使用规则下5元额度

```json
{
 "standard_id_list": ["2022120200152608070000011111"],
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "biz_date": "2022-12-12 12:12:12",
  "apply_amount": 500
}
```

**出参：**  
返回对应规则执行通过，并且可用金额为5元

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": [{
   "standard_id": "2022120200152608070000011111",
    "available_amount": 500,
    "consult_status": true,
    "result_code": null,
    "result_msg": null
  }]
}
```

#### 用例1.2： 员工额度不足，执行成功
**入参：**  
员工可用额度（或者对应使用规则的可用额度）只剩3元，拉起收银台时，咨询对应可用的一个使用规则下的5元额度

```json
{
 "standard_id_list": ["2022120200152608070000011111"],
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "biz_date": "2022-12-12 12:12:12",
  "apply_amount": 500
}
```

**出参：**  
返回对应规则执行通过，并且可用金额为3元

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": [{
   "standard_id": "2022120200152608070000011111",
    "available_amount": 300,
    "consult_status": true,
    "result_code": null,
    "result_msg": null
  }]
}
```

#### 用例1.3 员工无额度，执行失败
入参：  
员工可用额度（或者对应使用规则的可用额度）为0元或无可用额度，拉起收银台时，咨询对应可用的一个使用规则下的5元额度

```json
{
 "standard_id_list": ["2022120200152608070000011111"],
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "biz_date": "2022-12-12 12:12:12",
  "apply_amount": 500
}
```

**出参：**  
返回对应规则执行通过，并且可用金额为3元

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": [{
   "standard_id": "2022120200152608070000011111",
    "available_amount": 0,
    "consult_status": false,
    "result_code": "QUOTA_NOT_ENOUGH",
    "result_msg": "额度不足"
  }]
}
```

#### 用例1.4：规则额度，部分规则额度充足，部分规则不足，部分规则无额度，部分执行成功
**入参：**  
员工在使用规则"2022120200152608070000011111"下有10元可用额度，  
员工在使用规则"2022120200152608070000022222"下有3元可用额度，  
员工在使用规则"2022120200152608070000033333"下没有可用额度  
拉起收银台时，咨询对应可用的三个使用规则下的5元额度

```json
{
 "standard_id_list": ["2022120200152608070000011111", "2022120200152608070000022222", "2022120200152608070000033333"],
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "biz_date": "2022-12-12 12:12:12",
  "apply_amount": 500
}
```

**出参：**  
返回对应规则，前两个为执行通过，并返回可用额度。最后一个没有额度则执行不通过。

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": [{
   "standard_id": "2022120200152608070000011111",
    "available_amount": 500,
    "consult_status": true,
    "result_code": null,
    "result_msg": null
  },{
   "standard_id": "2022120200152608070000022222",
    "available_amount": 300,
    "consult_status": true,
    "result_code": null,
    "result_msg": null
  },{
   "standard_id": "2022120200152608070000033333",
    "available_amount": 0,
    "consult_status": false,
    "result_code": "QUOTA_NOT_ENOUGH",
    "result_msg": "额度不足"
  }]
}
```

#### 用例1.5： 该订单号额度已被规则占用（已被扣减），只有已扣减的规则执行成功
员工在使用规则"2022120200152608070000011111"下有10元可用额度，  
员工在使用规则"2022120200152608070000022222"下有3元可用额度，  
员工在使用规则"2022120200152608070000033333"下没有可用额度  
**前提：**  
调用用例2.1后。对应订单号"2022122022001475311408888888"的额度，已被规则"2022120200152608070000011111"占用。则在拉起收银台时咨询可用三个使用规则下的5元额度  
**入参：**

```json
{
 "standard_id_list": ["2022120200152608070000011111", "2022120200152608070000022222", "2022120200152608070000033333"],
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "biz_date": "2022-12-12 12:12:12",
  "apply_amount": 500
}
```

**出参：**  
因为订单号"2022122022001475311408888888"额度已被规则"2022120200152608070000011111"占用，则此规则返回成功，其他规则返回失败

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": [{
   "standard_id": "2022120200152608070000011111",
    "available_amount": 500,
    "consult_status": true,
    "result_code": null,
    "result_msg": null
  },{
   "standard_id": "2022120200152608070000022222",
    "available_amount": 0,
    "consult_status": false,
    "result_code": "QUOTA_OCCUPIED",
    "result_msg": "额度已被占用"
  },{
   "standard_id": "2022120200152608070000033333",
    "available_amount": 0,
    "consult_status": false,
    "result_code": "QUOTA_OCCUPIED",
    "result_msg": "额度已被占用"
  }]
}
```

#### 用例 1.6：该订单号额度已被规则占用（已被退款），所有规则执行失败
**前提：**先执行用例 3.3  
**入参：**

```json
{
 "standard_id_list": ["2022120200152608070000011111", "2022120200152608070000022222", "2022120200152608070000033333"],
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "biz_date": "2022-12-12 12:12:12",
  "apply_amount": 500
}
```

**出参：**  
因为订单号"2022122022001475311408888888"额度已被退款，则此所有规则都执行失败。

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": [{
   "standard_id": "2022120200152608070000011111",
    "available_amount": 0,
    "consult_status": false,
    "result_code": "QUOTA_OCCUPIED",
    "result_msg": "额度已被占用"
  },{
   "standard_id": "2022120200152608070000022222",
    "available_amount": 0,
    "consult_status": false,
    "result_code": "QUOTA_OCCUPIED",
    "result_msg": "额度已被占用"
  },{
   "standard_id": "2022120200152608070000033333",
    "available_amount": 0,
    "consult_status": false,
    "result_code": "QUOTA_OCCUPIED",
    "result_msg": "额度已被占用"
  }]
}
```

#### 用例 1.7：该订单号额度已被规则占用（已被恢复），正常执行
**前提：**先执行用例 3.1  
后续执行逻辑与用例 1.1 - 1.4 相同

### 2、额度扣减
**接口名称：spi.alipay.commerce.ec.expensecontrol.quota.pay**

#### 用例 2.1：额度充足正常扣减
**入参：**  
前提：首先执行用例 1.4，用户选择规则"2022120200152608070000011111"进行支付，此时需扣减5元额度。规则中（用户账户中）可用额度大于5元。

```json
{
 "standard_id": "2022120200152608070000011111",
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "biz_date": "2022-12-12 12:12:12",
  "apply_amount": 500
}
```

**出参：**  
额度扣减成功

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": true,
    "result_code": null,
    "result_msg": null
  }
}
```

#### 用例 2.2：额度不充足，扣减失败
**入参：**  
前提：首先执行用例 1.4，用户选择规则"2022120200152608070000011111"进行支付，此时需扣减5元额度。规则中（用户账户中）可用额度不足5元（如：只剩3元）。

```json
{
 "standard_id": "2022120200152608070000011111",
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "biz_date": "2022-12-12 12:12:12",
  "apply_amount": 500
}
```

**出参：**  
额度扣减成功

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": false,
    "result_code": "QUOTA_NOT_ENOUGH",
    "result_msg": "额度不足"
  }
}
```

#### 用例 2.3：没有额度，扣减失败
**入参：**  
前提：首先执行用例 1.4，用户选择规则"2022120200152608070000011111"进行支付，此时需扣减5元额度。规则中（用户账户中）没有可用额度，或可用额度为0元

```json
{
 "standard_id": "2022120200152608070000011111",
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "biz_date": "2022-12-12 12:12:12",
  "apply_amount": 500
}
```

**出参：**  
额度扣减成功

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": false,
    "result_code": "QUOTA_NOT_ENOUGH",
    "result_msg": "额度不足"
  }
}
```

#### 用例 2.4：额度已被扣减（同一订单号，规则ID与金额和上次扣减相等），幂等成功
**前提：**先执行用例 2.1，同一订单号再进行一次扣减，规则ID与金额和用例 2.1 相同  
**入参：**

```json
{
 "standard_id": "2022120200152608070000011111",
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "biz_date": "2022-12-12 12:12:12",
  "apply_amount": 500
}
```

**出参：**  
额度扣减幂等成功

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": true,
    "result_code": null,
    "result_msg": null
  }
}
```

#### 用例 2.5：额度已被扣减（同一订单号，规则ID或金额和上次扣减不同），扣减失败
**前提：**先执行用例 2.1，同一订单号再进行一次扣减，规则ID与金额任意一个和用例 2.1 不同  
**入参**

```json
{
 "standard_id": "2022120200152608070000022222",
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "biz_date": "2022-12-12 12:12:12",
  "apply_amount": 400
}
```

**出参：**  
额度扣减幂等成功

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": false,
    "result_code": "QUOTA_DEDUCTED",
    "result_msg": "额度已被扣减"
  }
}
```

#### 用例 2.6：额度已被退款，扣减失败
**前提：**先执行用例 3.3  
**入参：**  
额度已被退款后，再次进行扣减

```json
{
 "standard_id": "2022120200152608070000011111",
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "biz_date": "2022-12-12 12:12:12",
  "apply_amount": 500
}
```

**出参：**  
额度扣减失败

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": false,
    "result_code": "QUOTA_REFUNDED",
    "result_msg": "额度已被退款"
  }
}
```

#### 用例 2.7：额度已被恢复，正常扣减
**前提：**先执行用例 3.1  
后续执行逻辑与用例 2.1 相同

### 3、额度退还
**接口名称：**spi.alipay.commerce.ec.expensecontrol.quota.refund

#### 用例 3.1：额度已被扣减，正常退还（恢复）
**前提：**先执行用例 2.1  
**入参：**  
额度被扣减成功后，因最后支付失败需要进行额度的恢复，恢复的金额等于扣减的金额。一般会在扣减后一分钟左右进行恢复。

```json
{
 "refund_mode": "RECOVER",
  "trade_no": "2022122022001475311408888888",
  "refund_no": "-1",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "refund_time": "2022-12-12 12:13:00",
  "refund_amount": 500
}
```

**出参：**  
额度恢复成功

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": true,
    "result_code": null,
    "result_msg": null
  }
}
```

#### 用例 3.2：额度已被退还（恢复），正常退还（恢复），幂等成功
**前提：**先执行用例 3.1  
再重复执行用例 3.1 获取到相同的成功幂等结果

#### 用例 3.3：额度已被扣减，正常退还（退款）
**前提：**先执行用例 2.1  
**入参：**  
用户发起退款，部分退款1元

```json
{
 "refund_mode": "REFUND",
  "trade_no": "2022122022001475311408888888",
  "refund_no": "2022121930000200950606666666",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "refund_time": "2022-12-12 12:13:00",
  "refund_amount": 100
}
```

**出参：**  
退款成功

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": true,
    "result_code": null,
    "result_msg": null
  }
}
```

#### 用例 3.4：额度已被退还（退款），相同退款单号正常退还（退款），幂等成功
**前提：**先执行用例 3.3  
**入参：**  
相同退款单号 refund_no 进行退款

```json
{
 "refund_mode": "REFUND",
  "trade_no": "2022122022001475311408888888",
  "refund_no": "2022121930000200950606666666",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "refund_time": "2022-12-12 12:13:00",
  "refund_amount": 100
}
```

**出参：**  
退款幂等成功

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": true,
    "result_code": null,
    "result_msg": null
  }
}
```

#### 用例 3.5：额度已被退还（退款），不同退款单号正常退还（退款），正常退还（退款）
**前提：**先执行用例 3.3  
**入参：**  
用户又发起退款，退款金额2元

```json
{
 "refund_mode": "REFUND",
  "trade_no": "2022122022001475311408888888",
  "refund_no": "2022121930000200950606666667",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "refund_time": "2022-12-12 12:13:00",
  "refund_amount": 200
}
```

**出参：**  
退款成功

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": true,
    "result_code": null,
    "result_msg": null
  }
}
```

#### 用例 3.6：额度未被操作/交易号未找到，退还（恢复）失败
**入参：**  
前提额度未被扣减过，直接发起额度恢复

```json
{
 "refund_mode": "RECOVER",
  "trade_no": "2022122022001475311408888888",
  "refund_no": "2022121930000200950606666666",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "refund_time": "2022-12-12 12:13:00",
  "refund_amount": 200
}
```

**出参：**  
退还（恢复）失败

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": false,
    "result_code": "QUOTA_NOT_DEDUCT",
    "result_msg": "额度未被扣减"
  }
}
```

#### 用例 3.7：额度未被操作/交易号未找到，退还（退款）失败
**入参：**  
前提额度未被扣减过，直接发起额度退款

```json
{
 "refund_mode": "REFUND",
  "trade_no": "2022122022001475311408888888",
  "refund_no": "2022121930000200950606666666",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "refund_time": "2022-12-12 12:13:00",
  "refund_amount": 200
}
```

**出参：**  
退还（退款）失败

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": false,
    "result_code": "QUOTA_NOT_DEDUCT",
    "result_msg": "额度未被扣减"
  }
}
```

#### 用例 3.8：额度已被退还（退款），正常退还（恢复）失败
**前提：**先执行用例 3.3  
**入参：**  
前提额度已被退款，又发起额度恢复

```json
{
 "refund_mode": "RECOVER",
  "trade_no": "2022122022001475311408888888",
  "refund_no": "2022121930000200950606666666",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "refund_time": "2022-12-12 12:13:00",
  "refund_amount": 200
}
```

**出参：**  
退还（恢复）失败

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": false,
    "result_code": "QUOTA_REFUNDED",
    "result_msg": "额度已被退款"
  }
}
```

#### 用例 3.9：额度已被退还（恢复），正常退还（退款）失败
**前提：**先执行用例 3.1  
**入参：**  
前提额度已被恢复，又发起额度退款

```json
{
 "refund_mode": "REFUND",
  "trade_no": "2022122022001475311408888888",
  "refund_no": "2022121930000200950606666666",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "refund_time": "2022-12-12 12:13:00",
  "refund_amount": 200
}
```

**出参：**  
退还（退款）失败

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": false,
    "result_code": "QUOTA_RECOVERED",
    "result_msg": "额度已被恢复"
  }
}
```

#### 用例 3.10：额度已扣减，退还（恢复）额度大于扣减额度，失败
**前提：**先执行用例 2.1  
**入参：**  
额度被扣减成功后，因最后支付失败需要进行额度的恢复，恢复的金额需等于扣减的金额。如果恢复金额大于扣减金额，则失败。一般会在扣减后一分钟左右进行恢复。

```json
{
 "refund_mode": "RECOVER",
  "trade_no": "2022122022001475311408888888",
  "refund_no": "-1",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "refund_time": "2022-12-12 12:13:00",
  "refund_amount": 600
}
```

**出参：**  
额度恢复成功

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": false,
    "result_code": "AMOUNT_EXCEED",
    "result_msg": "退款额度已超限"
  }
}
```

#### 用例 3.11：额度已扣减，退还（退款）额度总和大于扣减额度，失败
**前提：**先执行用例 2.1  
**入参：**  
用户发起退款，部分退款10元，超过扣款金额

```json
{
 "refund_mode": "REFUND",
  "trade_no": "2022122022001475311408888888",
  "refund_no": "2022121930000200950606666666",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
  "refund_time": "2022-12-12 12:13:00",
  "refund_amount": 1000
}
```

**出参：**  
退款成功

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "result": false,
    "result_code": "AMOUNT_EXCEED",
    "result_msg": "退款额度已超限"
  }
}
```

### 4、额度状态查询
**接口名称：**spi.alipay.commerce.ec.expensecontrol.quotastatus.query

#### 用例 4.1：额度未被扣减/未找到订单号，返回空
**入参：**  
交易号下，额度未被扣减过

```json
{
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
}
```

**出参：**

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "quota_deduct_info": null,
    "quota_refund_info_list": null
  }
}
```

#### 用例 4.2：额度已被扣减，返回扣减数据（扣减状态）
**前提：**先执行用例 2.1  
**入参：**  
查询用例 2.1 对应交易单号的状态，已被扣减

```json
{
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
}
```

**出参：**

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "quota_deduct_info": {
      "trade_no": "2022122022001475311408888888",
      "status": "DEDUCTED",
      "amount": 500,
      "standard_id": "2022120200152608070000011111"
    },
    "quota_refund_info_list": null
  }
}
```

#### 用例 4.3：额度扣减后被恢复，返回扣减数据（恢复状态）
**前提：**先执行用例 3.1  
**入参：**  
查询用例 3.1 对应交易单号的状态，已被恢复

```json
{
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
}
```

**出参：**

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "quota_deduct_info": {
      "trade_no": "2022122022001475311408888888",
      "status": "RECOVERED",
      "amount": 500,
      "standard_id": null
    },
    "quota_refund_info_list": null
  }
}
```

#### 用例 4.4：额度扣减后被恢复又被扣减，返回扣减数据（扣减状态）
**前提：**先执行用例 2.7  
**入参：**  
查询用例 2.7 对应交易单号的状态，已被扣减

```json
{
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
}
```

**出参：**

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "quota_deduct_info": {
      "trade_no": "2022122022001475311408888888",
      "status": "DEDUCTED",
      "amount": 500,
      "standard_id": "2022120200152608070000011111"
    },
    "quota_refund_info_list": null
  }
}
```

#### 用例 4.5：额度已被退款，返回退款列表
**前提：**先执行用例 3.3  
**入参：**  
查询用例 3.3 对应交易单号的状态，已被退款

```json
{
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
}
```

**出参：**

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "quota_deduct_info": {
      "trade_no": "2022122022001475311408888888",
      "status": "DEDUCTED",
      "amount": 500,
      "standard_id": "2022120200152608070000011111"
    },
    "quota_refund_info_list": [{
      "trade_no": "2022122022001475311408888888",
      "refund_no": "2022121930000200950606666666",
      "refund_amount": 100
    }]
  }
}
```

#### 用例 4.6：额度已被多次退款，返回退款列表
**前提：**先执行用例 3.5  
**入参：**  
查询用例 3.5 对应交易单号的状态，已被多次退款，返回退款列表

```json
{
  "trade_no": "2022122022001475311408888888",
  "employee_id": "2288007000011111",
  "enterprise_id": "2088210759111111",
}
```

**出参：**

```json
{
  "code": "10000",
  "msg": null,
  "sub_code": null,
  "sub_msg": null,
  "result": {
    "quota_deduct_info": {
      "trade_no": "2022122022001475311408888888",
      "status": "DEDUCTED",
      "amount": 500,
      "standard_id": "2022120200152608070000011111"
    },
    "quota_refund_info_list": [{
      "trade_no": "2022122022001475311408888888",
      "refund_no": "2022121930000200950606666666",
      "refund_amount": 100
    },{
      "trade_no": "2022122022001475311408888888",
      "refund_no": "2022121930000200950606666667",
      "refund_amount": 200
    }]
  }
}
```
