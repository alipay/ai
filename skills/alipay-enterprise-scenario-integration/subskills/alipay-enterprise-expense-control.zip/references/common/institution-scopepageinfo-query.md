# alipay.ebpp.invoice.institution.scopepageinfo.query(分页查询制度下人员)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
分页查询制度下适用范围列表
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.ebpp.invoice.institution.scopepageinfo.query|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://ideservice.alipay.com/cms/site/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://ideservice.alipay.com/cms/site/04h2nx)|null|
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档|null|
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|account_id|String|特殊可选|32|企业共同账户id（该字段将废弃，不建议使用，可用enterprise_id字段替换）**注意事项**通过企业码1.0接口签约的共同账户，和agreement_no搭配使用。**必选条件**该字段将废弃，不建议使用，可用enterprise_id字段替换|2088000194958956|
|agreement_no|String|特殊可选|32|授权签约协议号（该字段将废弃，不建议使用，可用enterprise_id字段替换）**注意事项**可通过签约消息获取。配合共同账户id使用，当填写企业共同账户id时，此字段必填。**必选条件**该字段将废弃，不建议使用，可用enterprise_id字段替换|20215425001112341234|
|enterprise_id|String|特殊可选|32|企业id**注意事项**通过企业码2.0签约接口签约，只填写企业id，无需填写共同账户id和授权签约协议号。|2088000194958956|
|institution_id|String|必须|32|制度id|2022071800152609780000004052|
|owner_type|String|可选|32|适配id类型**枚举值**员工支付宝id:EMPLOYEE员工企业码id:ENTERPRISE_PAY_UID员工手机号:PHONE**注意事项**请与创建制度下适配范围时传的owner_type保持一致，企业id对接支持PHONE和ENTERPRISE_PAY_UID类型，共同账户id对接仅支持EMPLOYEE|PHONE|
|page_num|Number|必须|100|页码|10|
|page_size|Number|必须|100|页大小**注意事项**单页查询上限为100|100|
### 请求示例
#### 默认示例
##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayEbppInvoiceInstitutionScopepageinfoQuery
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayEbppInvoiceInstitutionScopepageinfoQueryRequest request = new AlipayEbppInvoiceInstitutionScopepageinfoQueryRequest();
            AlipayEbppInvoiceInstitutionScopepageinfoQueryModel model = new AlipayEbppInvoiceInstitutionScopepageinfoQueryModel();
            
            // 设置企业id
            model.EnterpriseId = "2088000194958956";
            
            // 设置制度id
            model.InstitutionId = "2022071800152609780000004052";
            
            // 设置适配id类型
            model.OwnerType = "PHONE";
            
            // 设置页码
            model.PageNum = 10;
            
            // 设置页大小
            model.PageSize = 100;
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayEbppInvoiceInstitutionScopepageinfoQueryResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.response.AlipayEbppInvoiceInstitutionScopepageinfoQueryResponse;
import com.alipay.api.request.AlipayEbppInvoiceInstitutionScopepageinfoQueryRequest;
import com.alipay.api.domain.AlipayEbppInvoiceInstitutionScopepageinfoQueryModel;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;

public class AlipayEbppInvoiceInstitutionScopepageinfoQuery {

    public static void main(String[] args) throws AlipayApiException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());

        // 构造请求参数以调用接口
        AlipayEbppInvoiceInstitutionScopepageinfoQueryRequest request = new AlipayEbppInvoiceInstitutionScopepageinfoQueryRequest();
        AlipayEbppInvoiceInstitutionScopepageinfoQueryModel model = new AlipayEbppInvoiceInstitutionScopepageinfoQueryModel();
        
        // 设置企业id
        model.setEnterpriseId("2088000194958956");
        
        // 设置制度id
        model.setInstitutionId("2022071800152609780000004052");
        
        // 设置适配id类型
        model.setOwnerType("PHONE");
        
        // 设置页码
        model.setPageNum(10L);
        
        // 设置页大小
        model.setPageSize(100L);
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayEbppInvoiceInstitutionScopepageinfoQueryResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayEbppInvoiceInstitutionScopepageinfoQueryRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayEbppInvoiceInstitutionScopepageinfoQueryRequest();
$model = array();

// 设置企业id
$model['enterprise_id'] = "2088000194958956";

// 设置制度id
$model['institution_id'] = "2022071800152609780000004052";

// 设置适配id类型
$model['owner_type'] = "PHONE";

// 设置页码
$model['page_num'] = 10;

// 设置页大小
$model['page_size'] = 100;

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.ebpp.invoice.institution.scopepageinfo.query&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"enterprise_id":"2088000194958956",
	"institution_id":"2022071800152609780000004052",
	"owner_type":"PHONE",
	"page_num":10,
	"page_size":100
}' 
```
 

### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|page_num|Number|必须|100|页码|10|
|page_size|Number|必须|100|页大小|100|
|total_page_count|Number|必须|100|总页数|100|
|adapter_type|String|必须|32|制度适用范围类型**枚举值**全员:EMPLOYEE_ALL指定员工:EMPLOYEE_SELECT指定部门:EMPLOYEE_DEPARTMENT**注意事项**若适用范围为EMPLOYEE_ALL，则表示制度对企业下全员生效，owner_id_list不返回；若适配范围为EMPLOYEE_SELECT，owner_id_list返回员工对应的id信息，返回的id类型通过owner_type区分；若适配范围为EMPLOYEE_DEPARTMENT，则表示对指定的部门生效，返回owner_id_list为部门id列表|EMPLOYEE_ALL|
|owner_id_list|String|特殊可选|100|适配id列表**注意事项**adapter_type为： EMPLOYEE_DEPARTMENT：返回部门ID EMPLOYEE_SELECT：当owner_type为PHONE时返回手机号，其他值则根据对接方式返回支付宝用户ID，或企业码员工ID。|["2288078000164693"]|
|onwer_open_id_list|String|可选|100|适配开放id列表**注意事项**切换 open_id 后请使用此字段： adapter_type为： EMPLOYEE_DEPARTMENT：返回部门ID EMPLOYEE_SELECT：当owner_type为PHONE时返回手机号，其他值则根据对接方式返回open_id，或企业码员工ID|["asdfxxxx"]|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_ebpp_invoice_institution_scopepageinfo_query_response":{
		"code":"10000",
		"msg":"Success",
		"page_num":10,
		"page_size":100,
		"total_page_count":100,
		"adapter_type":"EMPLOYEE_ALL",
		"owner_id_list":[
			"2288078000164693"
		],
		"onwer_open_id_list":[
			"asdfxxxx"
		]
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_ebpp_invoice_institution_scopepageinfo_query_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|PERMISSION_DENIED|权限不足，未能查到企业和ISV之间的映射关系|检查传入的企业ID是否正确|