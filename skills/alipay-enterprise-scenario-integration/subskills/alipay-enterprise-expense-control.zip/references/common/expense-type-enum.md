# 费用类型和费用类型子类枚举

| 费用类型（ExpenseType） | 名称 | 费用类型子类（expenseTypeSubCategory） | 子类名称 |
| --- | --- | --- | --- |
| MEAL | 餐饮 | TAKE_AWAY | 外卖 |
| | | REACH_SHOP | 到店用餐 |
| METRO | 地铁 | METRO | 地铁 |
| BUS | 公交 | BUS | 公交 |
| CAR | 用车 | CAR | 用车 |
| HOTEL | 酒店 | REACH_SHOP_HOTEL | 到店住宿 |
| MALL | 商城 | OFFLINE_MALL | 线下商超 |
| LIVINGSERVICE | 生活服务 | LIVINGSERVICE | 生活服务 |
| TICKET | 票务 | TICKET | 票务 |
| OIL | 加油 | REACH_SHOP_OIL | 到店加油 |
| DEFAULT | 默认 | DEFAULT | 默认 |
| HEALTH | 医疗 | REACH_HOSPITAL | 到院就医 |
