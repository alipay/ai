# alipay.ebpp.invoice.institution.modify(制度编辑)
支持第三方代理调用：本接口支持第三方开发者代用户发起调用
## 通用场景
制度编辑，支持制度基本信息、制度下适用范围、制度下使用规则和发放规则的修改。
### 公共请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|app_id|String|必选|32|支付宝分配给开发者的应用ID|2014072300007148|
|method|String|必选|128|接口名称|alipay.ebpp.invoice.institution.modify|
|format|String|可选|40|仅支持JSON|JSON|
|charset|String|必选|10|请求使用的编码格式，如utf-8,gbk,gb2312等|utf-8|
|sign_type|String|必选|10|商户生成签名字符串所使用的签名算法类型，目前支持RSA2和RSA，推荐使用RSA2|RSA2|
|sign|String|必选|344|商户请求参数的签名串，详见[签名](https://ideservice.alipay.com/cms/site/02khjm)|详见示例|
|timestamp|String|必选|19|发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"|2014-07-24 03:07:50|
|version|String|必选|3|调用的接口版本，固定为：1.0|1.0|
|app_auth_token|String|可选|40|详见[应用授权概述](https://ideservice.alipay.com/cms/site/04h2nx)|null|
|biz_content|String|必选||请求参数的集合，最大长度不限，除公共参数外所有请求参数都必须放在这个参数中传递，具体参照各产品快速接入文档|null|
### 业务请求参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|enterprise_id|String|特殊可选|32|企业id**注意事项**通过企业码2.0签约接口签约，只填写企业id，无需填写共同账户id和授权签约协议号。|2088123412341234|
|institution_id|String|必须|32|制度id|2022031000152617000000000001|
|institution_name|String|可选|50|制度名称**注意事项**敏感词校验，请避免填写敏感词|费用制度|
|effective|String|可选|32|制度是否启用**枚举值**停用:0启用:1**注意事项**制度停用时，制度下的使用规则不生效，发放规则停止发放资产；启用时，制度下的使用规则生效，员工名下可用资产仍然可用。制度启停影响制度下适用人员的因公付，请谨慎操作。|0|
|institution_desc|String|可选|200|制度描述**注意事项**敏感词校验，请避免填写敏感词|餐补制度|
|effective_start_date|Date|可选|32|制度生效起始时间**注意事项**最小粒度为天，最早是当日，时分秒必须为00:00:00。|2022-09-10 00:00:00|
|effective_end_date|Date|可选|32|制度生效结束时间（可空），最小粒度为天，最早是当日**注意事项**最小粒度为天，结束时间不早于起始时间，时分秒必须为23:59:59，最晚不超过2222-01-01 23:59:59|2022-09-30 23:59:59|
|consult_mode|String|可选|16|费控咨询模式： 0-支付宝内部计算规则可用金额 1-咨询外部服务商规则可用金额**枚举值**支付宝内部计算:0咨询外部服务商:1**注意事项**咨询模式为1时，存在以下约束： 1、不可创建发放规则 2、不可创建额度相关规则的条件 3、使用规则的消费模式只支持“默认”。 由于咨询模式为1时存在以上约束，因此在修改咨询模式时需要注意如果不满足以上约束，会导致无法修改。请提前对不满足要求的内容做修改后再修改咨询模式。|0|
|modify_scope_info|ModifyScopeInfo|可选|null|制度下适用范围修改信息**注意事项**不填写不修改，不支持同时修改制度下适用范围和制度其他信息。如需修改适配范围，仅填写本字段，企业id，制度id即可。||
|modify_scope_info.adapter_type|String|必须|32|制度的适用范围类型**枚举值**适用企业下全员:EMPLOYEE_ALL指定员工:EMPLOYEE_SELECT指定部门:EMPLOYEE_DEPARTMENT|EMPLOYEE_ALL|
|modify_scope_info.owner_type|String|特殊可选|32|归属id类型**枚举值**企业员工id:ENTERPRISE_PAY_UID员工手机号:PHONE**注意事项**由于指定员工时，支持填写多类id表征员工，因此需要填写该字段表示员工id类型，当该字段为ENTERPRISE_PAY_UID时，owner_id要填写企业码的员工id，当该字段为PHONE时，owner_id要填写员工手机号（以录入员企关系时输入的手机号为准）**必选条件**当adapter_type为指定员工时，需要该字段表示添加的员工id类型|ENTERPRISE_PAY_UID|
|modify_scope_info.add_owner_id_list|String|可选|100|增加的归属id列表**注意事项**如果adapter_type为EMPLOYEE_ALL时，无需填写该字段；当指定员工时，添加的员工id个数和删除的员工id个数总数不超过1000；当指定部门时，添加的部门id个数和删除的部门id个数总数不超过100；添加的id列表和删除的id列表不能重复。|["1001004110381022"]|
|modify_scope_info.delete_owner_id_list|String|可选|100|删除归属id列表**注意事项**如果adapter_type为EMPLOYEE_ALL时，无需填写该字段；当指定员工时，添加的员工id个数和删除的员工id个数总数不超过1000；当指定部门时，添加的部门id个数和删除的部门id个数总数不超过100；添加的id列表和删除的id列表不能重复。|["2288000000040864"]|
|modify_standard_detail_info|ModifyStandardDetailInfo|可选|null|修改的使用规则详情**注意事项**可对制度下使用规则进行增、删、改，不填写则不修改||
|modify_standard_detail_info.delete_standard_id_list|String|可选|32|待删除的使用规则id列表**注意事项**制度下至少要保留一个使用规则，不能全部删除|["2024090500000000000000008502"]|
|modify_standard_detail_info.modify_standard_list|ModifyStandardInfo|可选|null|待修改的使用规则信息列表**注意事项**如需修改制度下使用规则，则需要填写该字段||
|modify_standard_detail_info.modify_standard_list.standard_id|String|必须|32|修改的使用规则id|"2024090500152000000000008502"|
|modify_standard_detail_info.modify_standard_list.standard_name|String|可选|20|使用规则名称**注意事项**有长度限制，最多20个字符，有敏感词校验|到店规则|
|modify_standard_detail_info.modify_standard_list.standard_desc|String|可选|200|使用规则描述**注意事项**有长度限制，最多200个字符，有敏感词校验|到店就餐使用规则|
|modify_standard_detail_info.modify_standard_list.payment_policy|String|可选|32|支付策略 当笔消费金额大于规则可用余额时，用于控制支付策略。COMBINATION表示支持因公资产和个人资产组合支付，PERSONAL表示整单个人支付。**枚举值**组合支付:COMBINATION整单个人支付:PERSONAL**注意事项**如需修改支付策略，请填写该字段|COMBINATION|
|modify_standard_detail_info.modify_standard_list.consume_mode|String|可选|32|消费模式**枚举值**点券模式:COUPON_ONLY点券+余额模式:COUPON_AND_CAP默认模式:DEFAULT次卡模式:COUNT**注意事项**点券模式：消费时找员工的点券，没有或者用完了不可付； 点券+余额模式：消费时找员工的点券，没有找员工的余额，没有或者用完了不可付；次卡模式：消费时找员工的次卡，没有或者用完了不可付； 默认模式：有给员工设置员工余额以员工余额为准，用完为止。否则只受规则里的限额和企业账户资金上限管控；|COUPON_ONLY|
|modify_standard_detail_info.modify_standard_list.personal_qrcode_mode|Number|可选|32|个人收款码转账是否支持因公付。可选值：0（不支持）、1（支持）|1|
|modify_standard_detail_info.modify_standard_list.open_rule_id|String|可选|32|使用规则绑定的开票规则id**注意事项**如果使用规则已经绑定开票规则，目前不支持更改开票规则，如果未绑定，可填写要绑定的开票规则id|"2024090500152000040000008668"|
|modify_standard_detail_info.modify_standard_list.asset_share_source_info|AssetShareSourceInfo|可选|null|当前规则可使用的其他资产来源信息||
|modify_standard_detail_info.modify_standard_list.asset_share_source_info.share_mode|String|可选|32|当前规则可用的资产来源类型，搭配source_id_list使用。**枚举值**制度:INSTITUTION**注意事项**如果当前值为INSTITUTION，source_id_list内填写制度id列表，表示当前规则可使用列表中的制度的资产。|INSTITUTION|
|modify_standard_detail_info.modify_standard_list.asset_share_source_info.source_id_list|String|可选|28|资产共享来源id列表，与share_mode配合设置，如果share_mode为INSTITUTION，该值则填写制度id列表**注意事项**事项一：目前最多支持10个制度id； 事项二：不能设置本使用规则所属的制度id； 事项三：仅支持发放币种相同的制度之间共享资产； 事项四：制度的multi_employee_share_mode需要一致才可共享。|["2023031600152614950000031117"]|
|modify_standard_detail_info.modify_standard_list.delete_condition_id_list|String|可选|32|待删除的条件id列表**注意事项**列表内id不允许重复，也不允许和修改的条件列表重复|["2024090500152600000000008502"]|
|modify_standard_detail_info.modify_standard_list.modify_condition_list|StandardConditionInfo|必须|null|修改的条件列表**注意事项**条件类型不支持修改||
|modify_standard_detail_info.modify_standard_list.modify_condition_list.rule_id|String|特殊可选|32|费控条件ID**注意事项**创建时由支付宝生成，无需外部传入，修改时条件时需要填写**必选条件**当接口类型为查询、编辑时必填|2021052100152602010000000001|
|modify_standard_detail_info.modify_standard_list.modify_condition_list.rule_factor|String|可选|32|条件类型**注意事项**指定条件id修改条件时，该字段不可变更，因此无需填写。 如需填写请参考文档填写 [详细文档](expense-type-constraints.md)|QUOTA_TOTAL|
|modify_standard_detail_info.modify_standard_list.modify_condition_list.rule_value|String|必须|65535|费控条件值**注意事项**请参考文档填写[详细文档](expense-type-constraints.md)|500|
|modify_standard_detail_info.modify_standard_list.modify_condition_list.rule_operator|String|可选|32|费控条件操作符 枚举值： LT("=","大于等于") GT(">","大于")**枚举值**小于:LT小于等于:LE等于:EQ不等于:NE大于等于:GE大于:GT**注意事项**该字段为保留字段，目前未被使用，无需填写|LE|
|modify_standard_detail_info.modify_standard_list.modify_condition_list.rule_name|String|可选|32|费控条件名称**注意事项**敏感词校验，请避免填写敏感词|单次消费金额|
|modify_standard_detail_info.modify_standard_list.add_condition_list|StandardConditionInfo|可选|null|要添加的条件列表||
|modify_standard_detail_info.modify_standard_list.add_condition_list.rule_id|String|特殊可选|32|费控条件ID**注意事项**创建时由支付宝生成，无需外部传入，修改时条件时需要填写**必选条件**当接口类型为查询、编辑时必填|2021052100152602010000000001|
|modify_standard_detail_info.modify_standard_list.add_condition_list.rule_factor|String|可选|32|条件类型**注意事项**指定条件id修改条件时，该字段不可变更，因此无需填写。 如需填写请参考文档填写 [详细文档](expense-type-constraints.md)|QUOTA_TOTAL|
|modify_standard_detail_info.modify_standard_list.add_condition_list.rule_value|String|必须|65535|费控条件值**注意事项**请参考文档填写[详细文档](expense-type-constraints.md)|500|
|modify_standard_detail_info.modify_standard_list.add_condition_list.rule_operator|String|可选|32|费控条件操作符 枚举值： LT("=","大于等于") GT(">","大于")**枚举值**小于:LT小于等于:LE等于:EQ不等于:NE大于等于:GE大于:GT**注意事项**该字段为保留字段，目前未被使用，无需填写|LE|
|modify_standard_detail_info.modify_standard_list.add_condition_list.rule_name|String|可选|32|费控条件名称**注意事项**敏感词校验，请避免填写敏感词|单次消费金额|
|modify_standard_detail_info.add_standard_list|StandardInfo|可选|null|新增的使用规则列表**注意事项**制度下最多有10条使用规则，新增的使用规则是否启用、有效期、费用类型默认与制度保持一致，无需填写。||
|modify_standard_detail_info.add_standard_list.standard_id|String|可选|32|制度ID（创建使用规则时非必填）|2022091300152608010000334322|
|modify_standard_detail_info.add_standard_list.outer_source_id|String|可选|64|外部使用规则id，制度内使用规则该字段不允许重复**注意事项**事项一：制度内使用规则该字段不允许重复。 事项二：创建制度时该字段必填。 事项三：创建使用规则时选填，如果填写可保证创建使用规则幂等。|123456|
|modify_standard_detail_info.add_standard_list.standard_name|String|必须|50|规则名称|单笔额度1元钱|
|modify_standard_detail_info.add_standard_list.open_rule_id|String|可选|32|开票规则id，可通过接口alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create 创建并得到开票规则ID|2021070100152721370000002201|
|modify_standard_detail_info.add_standard_list.payment_policy|String|可选|32|支付策略 当笔消费金额大于规则可用余额时，用于控制支付策略，该字段缺省时采取因公账户和个人账户组合支付策略**枚举值**全部个人支付:PERSONAL因公账户和个人账户组合支付:COMBINATION|PERSONAL|
|modify_standard_detail_info.add_standard_list.consume_mode|String|可选|32|消费模式，不填为默认模式，枚举值：COUPON_ONLY（仅支持点券） COUPON_AND_CAP（支持点券+余额） DEFAULT（默认模式） COUNT（仅支持次卡） 点券：消费时找员工的点券，没有或者用完了不可付； 点券+余额：消费时找员工的点券，没有找员工的余额，没有或者用完了不可付； 默认：有给员工设置员工余额以员工余额为准，用完为止。否则只受规则里的限额和企业账户资金上限管控； 次卡：消费时找员工的次卡，没有或者用完了不可付。**枚举值**仅支持点券:COUPON_ONLY支持点券+余额:COUPON_AND_CAP默认模式:DEFAULT仅支持次卡:COUNT|COUPON_ONLY|
|modify_standard_detail_info.add_standard_list.expense_type_sub_category|String|可选|32|费用类型子类**枚举值**外卖:TAKE_AWAY到店:REACH_SHOP地铁:METRO用车:CAR默认:DEFAULT**注意事项**更多费用类型子类，查看详细文档 [详细文档](expense-type-enum.md)|TAKE_AWAY|
|modify_standard_detail_info.add_standard_list.standard_desc|String|可选|48|使用规则描述(敏感词校验)|使用规则描述样例|
|modify_standard_detail_info.add_standard_list.standard_condition_info_list|StandardConditionInfo|可选|null|使用规则条件列表||
|modify_standard_detail_info.add_standard_list.standard_condition_info_list.rule_id|String|特殊可选|32|费控条件ID**注意事项**创建时由支付宝生成，无需外部传入，修改时条件时需要填写**必选条件**当接口类型为查询、编辑时必填|2021052100152602010000000001|
|modify_standard_detail_info.add_standard_list.standard_condition_info_list.rule_factor|String|可选|32|条件类型**注意事项**指定条件id修改条件时，该字段不可变更，因此无需填写。 如需填写请参考文档填写 [详细文档](expense-type-constraints.md)|QUOTA_TOTAL|
|modify_standard_detail_info.add_standard_list.standard_condition_info_list.rule_value|String|必须|65535|费控条件值**注意事项**请参考文档填写[详细文档](expense-type-constraints.md)|500|
|modify_standard_detail_info.add_standard_list.standard_condition_info_list.rule_operator|String|可选|32|费控条件操作符 枚举值： LT("=","大于等于") GT(">","大于")**枚举值**小于:LT小于等于:LE等于:EQ不等于:NE大于等于:GE大于:GT**注意事项**该字段为保留字段，目前未被使用，无需填写|LE|
|modify_standard_detail_info.add_standard_list.standard_condition_info_list.rule_name|String|可选|32|费控条件名称**注意事项**敏感词校验，请避免填写敏感词|单次消费金额|
|modify_standard_detail_info.add_standard_list.asset_share_source_info|AssetShareSourceInfo|可选|null|当前规则可使用的其他资产来源信息||
|modify_standard_detail_info.add_standard_list.asset_share_source_info.share_mode|String|可选|32|当前规则可用的资产来源类型，搭配source_id_list使用。**枚举值**制度:INSTITUTION**注意事项**如果当前值为INSTITUTION，source_id_list内填写制度id列表，表示当前规则可使用列表中的制度的资产。|INSTITUTION|
|modify_standard_detail_info.add_standard_list.asset_share_source_info.source_id_list|String|可选|28|资产共享来源id列表，与share_mode配合设置，如果share_mode为INSTITUTION，该值则填写制度id列表**注意事项**事项一：目前最多支持10个制度id； 事项二：不能设置本使用规则所属的制度id； 事项三：仅支持发放币种相同的制度之间共享资产； 事项四：制度的multi_employee_share_mode需要一致才可共享。|["2023031600152614950000031117"]|
|modify_standard_detail_info.add_standard_list.personal_qrcode_mode|Number|可选|32|个人收款码转账是否支持因公付，默认为0。可选值：0（不支持）、1（支持）**注意事项**适用场景：个人收款码转账需支持因公付。默认无需设置此字段|0|
|modify_issue_rule_detail_info|ModifyIssueRuleDetailInfo|可选|null|修改的发放规则详情**注意事项**可对制度下发放规则进行增、删、改，不填写则不修改||
|modify_issue_rule_detail_info.delete_issue_rule_id_list|String|可选|32|删除的发放规则id列表**注意事项**列表内的id不允许重复|["2024090500150000040000040033"]|
|modify_issue_rule_detail_info.add_issue_rule_list|IssueRuleInfo|可选|null|新增发放规则列表**注意事项**制度下最多有10条发放规则||
|modify_issue_rule_detail_info.add_issue_rule_list.issue_rule_name|String|可选|20|发放规则名称**注意事项**创建或修改时，会校验敏感词，请避免填写敏感词。|日额度|
|modify_issue_rule_detail_info.add_issue_rule_list.issue_rule_id|String|特殊可选|32|发放规则id**注意事项**创建时无需填写，修改时必填**必选条件**当接口类型为查询、编辑时必填|2022032400152624930000000001|
|modify_issue_rule_detail_info.add_issue_rule_list.target_type|String|可选|32|发放规则归属的目标类型**枚举值**制度:INSTITUTION**注意事项**制度创建接口无需填写此字段。新增发放规则接口需要填写该字段，指定新增规则对应的目标类型，例如：新增发放规则为制度下的发放规则，则填写INSTITUTION|INSTITUTION|
|modify_issue_rule_detail_info.add_issue_rule_list.target_id|String|可选|32|目标id**注意事项**制度创建接口无需填写此字段，发放规则新增时与target_type配合填写，当target_type为INSTITUTION时，该字段填写对应的制度id，表示创建的发放规则为指定制度id下的发放规则|2023042600152617860000076000|
|modify_issue_rule_detail_info.add_issue_rule_list.outer_source_id|String|可选|64|外部发放规则id**注意事项**事项一：制度内发放规则该字段不允许重复。 事项二：创建制度时该字段必填。 事项三：创建发放规则时选填，如果填写可保证创建发放规则幂等。|123456|
|modify_issue_rule_detail_info.add_issue_rule_list.quota_type|String|必须|32|额度类型**枚举值**点券:COUPON余额:CAP|COUPON|
|modify_issue_rule_detail_info.add_issue_rule_list.issue_type|String|必须|32|发放类型**枚举值**按日发放:ISSUE_DAY按月发放:ISSUE_MONTH按周发放:ISSUE_WEEK按季发放:ISSUE_SEASON按年发放:ISSUE_YEAR按间夜发放:ISSUE_ROOM_NIGHT**注意事项**更多说明请参考文档[接入文档](issue-rule-fields.md)|ISSUE_MONTH|
|modify_issue_rule_detail_info.add_issue_rule_list.effective_period|String|可选|100|生效时间段**注意事项**发放资产的有效时间段，该字段为空时，默认为不限制。当发放资产为余额时，仅支持设置为不限，当发放资产为点券时，可支持设置多种值。具体传值格式请参考文档 [接入文档](issue-rule-fields.md)|{\"all\":true}|
|modify_issue_rule_detail_info.add_issue_rule_list.invalid_mode|Number|可选|32|累计类型，默认为0 可选值：0（不可累计）、1（可累计）、2（累计天数）、3（累计到指定日期）**注意事项**当资产按日、月、周、季、年周期发放时，资产有效期默认为周期起始和结束时间，如果想延长资产的有效期，可通过该字段自定义发放资产的结束时间期，例如：发放周期为按日发放，默认点券有效期为发放日的00:00:00-23:59:59，通过将该字段设置为1，发放点券时结束时间将设置为长期有效。如果设置为2或3，需要配置invalid_mode_value使用，具体设置说明请参考文档[接入文档](issue-rule-fields.md)|0|
|modify_issue_rule_detail_info.add_issue_rule_list.invalid_mode_value|String|可选|10240|累计类型值**注意事项**与invalid_mode配置使用，具体使用说明请参考文档 [接入文档](issue-rule-fields.md)|3213|
|modify_issue_rule_detail_info.add_issue_rule_list.issue_amount_value|String|必须|10240|发放金额，单位元**注意事项**支持两种发放： 1、按城市发放不同的金额 2、按统一标准发放金额 具体填写说明请参考文档[接入文档](issue-rule-fields.md)|200|
|modify_issue_rule_detail_info.add_issue_rule_list.share_mode|Number|可选|32|是否可转赠**注意事项**可选值：0（不可转赠）、1（可转赠），默认为0。 该字段决定发放规则发放的资产是否可转赠给同制度下的其他人员|0|
|modify_issue_rule_detail_info.add_issue_rule_list.issue_start_date|Date|特殊可选|32|发放规则有效起始时间**注意事项**如果target_type指定INSTITUTION，则使用制度有效期起始时间，无法指定。|2022-08-10 00:00:00|
|modify_issue_rule_detail_info.add_issue_rule_list.issue_end_date|Date|特殊可选|32|发放规则有效结束时间**注意事项**如果target_type指定INSTITUTION，则使用制度有效期结束时间，无法指定|2022-12-31 23:59:59|
|modify_issue_rule_detail_info.modify_issue_rule_list|ModifyIssueRuleInfo|可选|null|修改发放规则列表||
|modify_issue_rule_detail_info.modify_issue_rule_list.issue_rule_id|String|必须|32|发放规则id**注意事项**修改发放规则时，该字段必填|"2024090500152621040000040033"|
|modify_issue_rule_detail_info.modify_issue_rule_list.issue_rule_name|String|可选|20|发放规则名称**注意事项**有长度限制，最多20个字符，有敏感词校验|发放餐补|
|modify_issue_rule_detail_info.modify_issue_rule_list.quota_type|String|可选|32|发放规则发放的额度类型**枚举值**点券:COUPON余额:CAP**注意事项**修改额度类型后，从下个周期开始按新额度类型发放|COUPON|
|modify_issue_rule_detail_info.modify_issue_rule_list.issue_type|String|可选|32|额度发放周期**枚举值**按日发放:ISSUE_DAY按月发放:ISSUE_MONTH按周发放:ISSUE_WEEK按季度发放:ISSUE_SEASON按年发放:ISSUE_YEAR按间夜发放:ISSUE_ROOM_NIGHT|ISSUE_DAY|
|modify_issue_rule_detail_info.modify_issue_rule_list.effective_period|String|可选|32|发放资产的有效时间段，该字段为空时，默认为不限制。当发放资产为余额时，仅支持设置为不限，当发放资产为点券时，可支持设置多种值。具体传值格式请参考文档 [接入文档](issue-rule-fields.md)|{\"all\":true}|
|modify_issue_rule_detail_info.modify_issue_rule_list.invalid_mode|Number|可选|32|累计类型，默认为0 可选值：0（不可累计）、1（可累计）、2（累计天数）、3（累计到指定日期）**注意事项**当资产按日、月、周、季、年周期发放时，资产有效期默认为周期起始和结束时间，如果想延长资产的有效期，可通过该字段自定义发放资产的结束时间期，例如：发放周期为按日发放，默认点券有效期为发放日的00:00:00-23:59:59，通过将该字段设置为1，发放点券时结束时间将设置为长期有效。如果设置为2或3，需要配置invalid_mode_value使用，具体设置说明请参考文档[接入文档](issue-rule-fields.md)|0|
|modify_issue_rule_detail_info.modify_issue_rule_list.invalid_mode_value|String|可选|32|累计类型值**注意事项**invalidModel=0，可不填 invalidModel=1，可不填 invalidModel=2，填写格式为数字，范围0<n<=365 invalidModel=3，填写格式为日期格式，2023-04-25 00:00，最大值为2100-01-01 00:00:00； 字段详情用法可参照[文档](issue-rule-fields.md)|10|
|modify_issue_rule_detail_info.modify_issue_rule_list.issue_amount_value|String|可选|10|发放金额（不传则不修改），单位（元）**注意事项**按城市不同发放标准示例值："[{\"cities\":[\"321000\",\"321100\"],\"amount\":\"50\"},{\"cities\":[\"321200\",\"321300\"],\"amount\":\"150\"}]"；字段详情用法可参照[文档](issue-rule-fields.md)|200|
|modify_issue_rule_detail_info.modify_issue_rule_list.share_mode|Number|可选|32|是否可转赠（不传则不修改），可选值：0（不可转赠）、1（可转赠），默认为0。该字段决定发放规则发放的资产是否可转赠给同制度下的其他人员**注意事项**按城市发放不支持可转赠|0|
|agreement_no|String|可选|32|授权签约协议号 （该字段将废弃，不建议使用，可用enterprise_id字段替换）**注意事项**可通过签约消息获取。配合共同账户id使用，当填写企业共同账户id时，此字段必填。|20215425001181407500|
|account_id|String|可选|32|企业共同账户id （该字段将废弃，不建议使用，可用enterprise_id字段替换）**注意事项**通过企业码1.0接口签约的共同账户，和agreement_no搭配使用。|2088000194958956|
### 请求示例
#### 默认示例
##### csharp
```
 using System;
using System.Collections.Generic;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;
using Aop.Api.Domain;
using Aop.Api.Util;
namespace SdkDemoTest
{
    public class AlipayEbppInvoiceInstitutionModify
    {
        public static void Main(string[] args) 
        {
            // 初始化SDK
            IAopClient alipayClient = new DefaultAopClient(GetAlipayConfig());
            // 构造请求参数以调用接口
            AlipayEbppInvoiceInstitutionModifyRequest request = new AlipayEbppInvoiceInstitutionModifyRequest();
            AlipayEbppInvoiceInstitutionModifyModel model = new AlipayEbppInvoiceInstitutionModifyModel();
            
            // 设置企业id
            model.EnterpriseId = "2088123412341234";
            
            // 设置制度id
            model.InstitutionId = "2022031000152617000000000001";
            
            // 设置制度名称
            model.InstitutionName = "费用制度";
            
            // 设置是否启用
            model.Effective = "0";
            
            // 设置制度描述
            model.InstitutionDesc = "餐补制度";
            
            // 设置制度生效起始时间
            model.EffectiveStartDate = "2022-09-10 00:00:00";
            
            // 设置制度生效结束时间（可空）
            model.EffectiveEndDate = "2022-09-30 23:59:59";
            
            // 设置费控咨询模式
            model.ConsultMode = "0";
            
            // 设置适用范围修改信息
            ModifyScopeInfo modifyScopeInfo = new ModifyScopeInfo();
            List<String> deleteOwnerIdList = new List<String>();
            deleteOwnerIdList.Add("2288000000040864");
            modifyScopeInfo.DeleteOwnerIdList = deleteOwnerIdList;
            modifyScopeInfo.AdapterType = "EMPLOYEE_ALL";
            modifyScopeInfo.OwnerType = "ENTERPRISE_PAY_UID";
            List<String> addOwnerIdList = new List<String>();
            addOwnerIdList.Add("1001004110381022");
            modifyScopeInfo.AddOwnerIdList = addOwnerIdList;
            model.ModifyScopeInfo = modifyScopeInfo;
            
            // 设置修改的使用规则详情
            ModifyStandardDetailInfo modifyStandardDetailInfo = new ModifyStandardDetailInfo();
            List<String> deleteStandardIdList = new List<String>();
            deleteStandardIdList.Add("2024090500000000000000008502");
            modifyStandardDetailInfo.DeleteStandardIdList = deleteStandardIdList;
            List<StandardInfo> addStandardList = new List<StandardInfo>();
            StandardInfo addStandardList0 = new StandardInfo();
            addStandardList0.StandardId = "2022091300152608010000334322";
            addStandardList0.StandardDesc = "使用规则描述样例";
            List<StandardConditionInfo> standardConditionInfoList = new List<StandardConditionInfo>();
            StandardConditionInfo standardConditionInfoList0 = new StandardConditionInfo();
            standardConditionInfoList0.RuleId = "2021052100152602010000000001";
            standardConditionInfoList0.RuleFactor = "QUOTA_TOTAL";
            standardConditionInfoList0.RuleName = "单次消费金额";
            standardConditionInfoList0.RuleValue = "500";
            standardConditionInfoList.Add(standardConditionInfoList0);
            addStandardList0.StandardConditionInfoList = standardConditionInfoList;
            addStandardList0.ExpenseTypeSubCategory = "TAKE_AWAY";
            addStandardList0.PersonalQrcodeMode = 0;
            addStandardList0.PaymentPolicy = "PERSONAL";
            addStandardList0.ConsumeMode = "COUPON_ONLY";
            addStandardList0.OuterSourceId = "123456";
            AssetShareSourceInfo assetShareSourceInfohPmWZ = new AssetShareSourceInfo();
            assetShareSourceInfohPmWZ.ShareMode = "INSTITUTION";
            List<String> sourceIdListaXWYp = new List<String>();
            sourceIdListaXWYp.Add("2023031600152614950000031117");
            assetShareSourceInfohPmWZ.SourceIdList = sourceIdListaXWYp;
            addStandardList0.AssetShareSourceInfo = assetShareSourceInfohPmWZ;
            addStandardList0.StandardName = "单笔额度1元钱";
            addStandardList0.OpenRuleId = "2021070100152721370000002201";
            addStandardList.Add(addStandardList0);
            modifyStandardDetailInfo.AddStandardList = addStandardList;
            List<ModifyStandardInfo> modifyStandardList = new List<ModifyStandardInfo>();
            ModifyStandardInfo modifyStandardList0 = new ModifyStandardInfo();
            modifyStandardList0.StandardId = "\"2024090500152000000000008502\"";
            modifyStandardList0.StandardDesc = "到店就餐使用规则";
            modifyStandardList0.PersonalQrcodeMode = 1;
            modifyStandardList0.PaymentPolicy = "COMBINATION";
            modifyStandardList0.ConsumeMode = "COUPON_ONLY";
            List<StandardConditionInfo> modifyConditionList = new List<StandardConditionInfo>();
            StandardConditionInfo modifyConditionList0 = new StandardConditionInfo();
            modifyConditionList0.RuleId = "2021052100152602010000000001";
            modifyConditionList0.RuleFactor = "QUOTA_TOTAL";
            modifyConditionList0.RuleName = "单次消费金额";
            modifyConditionList0.RuleValue = "500";
            modifyConditionList.Add(modifyConditionList0);
            modifyStandardList0.ModifyConditionList = modifyConditionList;
            AssetShareSourceInfo assetShareSourceInfoSwJfQ = new AssetShareSourceInfo();
            assetShareSourceInfoSwJfQ.ShareMode = "INSTITUTION";
            List<String> sourceIdListIXmbO = new List<String>();
            sourceIdListIXmbO.Add("2023031600152614950000031117");
            assetShareSourceInfoSwJfQ.SourceIdList = sourceIdListIXmbO;
            modifyStandardList0.AssetShareSourceInfo = assetShareSourceInfoSwJfQ;
            modifyStandardList0.StandardName = "到店规则";
            List<StandardConditionInfo> addConditionList = new List<StandardConditionInfo>();
            StandardConditionInfo addConditionList0 = new StandardConditionInfo();
            addConditionList0.RuleId = "2021052100152602010000000001";
            addConditionList0.RuleFactor = "QUOTA_TOTAL";
            addConditionList0.RuleName = "单次消费金额";
            addConditionList0.RuleValue = "500";
            addConditionList.Add(addConditionList0);
            modifyStandardList0.AddConditionList = addConditionList;
            modifyStandardList0.OpenRuleId = "\"2024090500152000040000008668\"";
            List<String> deleteConditionIdList = new List<String>();
            deleteConditionIdList.Add("2024090500152600000000008502");
            modifyStandardList0.DeleteConditionIdList = deleteConditionIdList;
            modifyStandardList.Add(modifyStandardList0);
            modifyStandardDetailInfo.ModifyStandardList = modifyStandardList;
            model.ModifyStandardDetailInfo = modifyStandardDetailInfo;
            
            // 设置修改的发放规则详情
            ModifyIssueRuleDetailInfo modifyIssueRuleDetailInfo = new ModifyIssueRuleDetailInfo();
            List<String> deleteIssueRuleIdList = new List<String>();
            deleteIssueRuleIdList.Add("2024090500150000040000040033");
            modifyIssueRuleDetailInfo.DeleteIssueRuleIdList = deleteIssueRuleIdList;
            List<IssueRuleInfo> addIssueRuleList = new List<IssueRuleInfo>();
            IssueRuleInfo addIssueRuleList0 = new IssueRuleInfo();
            addIssueRuleList0.IssueStartDate = "2022-08-10 00:00:00";
            addIssueRuleList0.InvalidMode = 0;
            addIssueRuleList0.TargetType = "INSTITUTION";
            addIssueRuleList0.IssueType = "ISSUE_MONTH";
            addIssueRuleList0.EffectivePeriod = "{\"all\":true}";
            addIssueRuleList0.OuterSourceId = "123456";
            addIssueRuleList0.ShareMode = 0;
            addIssueRuleList0.TargetId = "2023042600152617860000076000";
            addIssueRuleList0.IssueRuleId = "2022032400152624930000000001";
            addIssueRuleList0.IssueAmountValue = "200";
            addIssueRuleList0.IssueEndDate = "2022-12-31 23:59:59";
            addIssueRuleList0.InvalidModeValue = "3213";
            addIssueRuleList0.IssueRuleName = "日额度";
            addIssueRuleList0.QuotaType = "COUPON";
            addIssueRuleList.Add(addIssueRuleList0);
            modifyIssueRuleDetailInfo.AddIssueRuleList = addIssueRuleList;
            ModifyIssueRuleInfo modifyIssueRuleList = new ModifyIssueRuleInfo();
            modifyIssueRuleList.InvalidMode = 0;
            modifyIssueRuleList.InvalidModeValue = "10";
            modifyIssueRuleList.IssueType = "ISSUE_DAY";
            modifyIssueRuleList.EffectivePeriod = "{\"all\":true}";
            modifyIssueRuleList.ShareMode = 0;
            modifyIssueRuleList.IssueRuleName = "发放餐补";
            modifyIssueRuleList.IssueRuleId = "\"2024090500152621040000040033\"";
            modifyIssueRuleList.IssueAmountValue = "200";
            modifyIssueRuleList.QuotaType = "COUPON";
            modifyIssueRuleDetailInfo.ModifyIssueRuleList = modifyIssueRuleList;
            model.ModifyIssueRuleDetailInfo = modifyIssueRuleDetailInfo;
            
            request.SetBizModel(model);
            // 第三方代调用模式下请设置app_auth_token
            // request.PutOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

            AlipayEbppInvoiceInstitutionModifyResponse response = alipayClient.Execute(request);

            if(!response.IsError)
            {
                Console.WriteLine("调用成功");
            }
            else
            {
                Console.WriteLine("调用失败");
            }
        }

        private static AlipayConfig GetAlipayConfig()
        {
            string privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
            string alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
            AlipayConfig alipayConfig = new AlipayConfig();
            alipayConfig.ServerUrl = "https://openapi.alipay.com/gateway.do";
            alipayConfig.AppId = "<-- 请填写您的AppId，例如：2019091767145019 -->";
            alipayConfig.PrivateKey = privateKey;
            alipayConfig.Format = "json";
            alipayConfig.AlipayPublicKey = alipayPublicKey;
            alipayConfig.Charset = "UTF-8";
            alipayConfig.SignType = "RSA2";
            return alipayConfig;
        }
    }
}
```
 

##### java
```
 package com.java.sdk.demo;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.AlipayConfig;
import com.alipay.api.domain.ModifyIssueRuleInfo;
import com.alipay.api.domain.StandardInfo;
import com.alipay.api.request.AlipayEbppInvoiceInstitutionModifyRequest;
import com.alipay.api.domain.IssueRuleInfo;
import com.alipay.api.domain.AlipayEbppInvoiceInstitutionModifyModel;
import com.alipay.api.domain.ModifyScopeInfo;
import com.alipay.api.domain.AssetShareSourceInfo;
import com.alipay.api.domain.StandardConditionInfo;
import com.alipay.api.domain.ModifyStandardDetailInfo;
import com.alipay.api.response.AlipayEbppInvoiceInstitutionModifyResponse;
import com.alipay.api.domain.ModifyStandardInfo;
import com.alipay.api.domain.ModifyIssueRuleDetailInfo;

import com.alipay.api.FileItem;
import java.util.Base64;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class AlipayEbppInvoiceInstitutionModify {

    public static void main(String[] args) throws AlipayApiException, ParseException {
        // 初始化SDK
        AlipayClient alipayClient = new DefaultAlipayClient(getAlipayConfig());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT+8"));

        // 构造请求参数以调用接口
        AlipayEbppInvoiceInstitutionModifyRequest request = new AlipayEbppInvoiceInstitutionModifyRequest();
        AlipayEbppInvoiceInstitutionModifyModel model = new AlipayEbppInvoiceInstitutionModifyModel();
        
        // 设置企业id
        model.setEnterpriseId("2088123412341234");
        
        // 设置制度id
        model.setInstitutionId("2022031000152617000000000001");
        
        // 设置制度名称
        model.setInstitutionName("费用制度");
        
        // 设置是否启用
        model.setEffective("0");
        
        // 设置制度描述
        model.setInstitutionDesc("餐补制度");
        
        // 设置制度生效起始时间
        model.setEffectiveStartDate(sdf.parse("2022-09-10 00:00:00"));
        
        // 设置制度生效结束时间（可空）
        model.setEffectiveEndDate(sdf.parse("2022-09-30 23:59:59"));
        
        // 设置费控咨询模式
        model.setConsultMode("0");
        
        // 设置适用范围修改信息
        ModifyScopeInfo modifyScopeInfo = new ModifyScopeInfo();
        List<String> deleteOwnerIdList = new ArrayList<String>();
        deleteOwnerIdList.add("2288000000040864");
        modifyScopeInfo.setDeleteOwnerIdList(deleteOwnerIdList);
        modifyScopeInfo.setAdapterType("EMPLOYEE_ALL");
        modifyScopeInfo.setOwnerType("ENTERPRISE_PAY_UID");
        List<String> addOwnerIdList = new ArrayList<String>();
        addOwnerIdList.add("1001004110381022");
        modifyScopeInfo.setAddOwnerIdList(addOwnerIdList);
        model.setModifyScopeInfo(modifyScopeInfo);
        
        // 设置修改的使用规则详情
        ModifyStandardDetailInfo modifyStandardDetailInfo = new ModifyStandardDetailInfo();
        List<String> deleteStandardIdList = new ArrayList<String>();
        deleteStandardIdList.add("2024090500000000000000008502");
        modifyStandardDetailInfo.setDeleteStandardIdList(deleteStandardIdList);
        List<StandardInfo> addStandardList = new ArrayList<StandardInfo>();
        StandardInfo addStandardList0 = new StandardInfo();
        addStandardList0.setStandardId("2022091300152608010000334322");
        addStandardList0.setStandardDesc("使用规则描述样例");
        List<StandardConditionInfo> standardConditionInfoList = new ArrayList<StandardConditionInfo>();
        StandardConditionInfo standardConditionInfoList0 = new StandardConditionInfo();
        standardConditionInfoList0.setRuleId("2021052100152602010000000001");
        standardConditionInfoList0.setRuleFactor("QUOTA_TOTAL");
        standardConditionInfoList0.setRuleName("单次消费金额");
        standardConditionInfoList0.setRuleValue("500");
        standardConditionInfoList.add(standardConditionInfoList0);
        addStandardList0.setStandardConditionInfoList(standardConditionInfoList);
        addStandardList0.setExpenseTypeSubCategory("TAKE_AWAY");
        addStandardList0.setPersonalQrcodeMode(0L);
        addStandardList0.setPaymentPolicy("PERSONAL");
        addStandardList0.setConsumeMode("COUPON_ONLY");
        addStandardList0.setOuterSourceId("123456");
        AssetShareSourceInfo assetShareSourceInfosoJxP = new AssetShareSourceInfo();
        assetShareSourceInfosoJxP.setShareMode("INSTITUTION");
        List<String> sourceIdListJtbql = new ArrayList<String>();
        sourceIdListJtbql.add("2023031600152614950000031117");
        assetShareSourceInfosoJxP.setSourceIdList(sourceIdListJtbql);
        addStandardList0.setAssetShareSourceInfo(assetShareSourceInfosoJxP);
        addStandardList0.setStandardName("单笔额度1元钱");
        addStandardList0.setOpenRuleId("2021070100152721370000002201");
        addStandardList.add(addStandardList0);
        modifyStandardDetailInfo.setAddStandardList(addStandardList);
        List<ModifyStandardInfo> modifyStandardList = new ArrayList<ModifyStandardInfo>();
        ModifyStandardInfo modifyStandardList0 = new ModifyStandardInfo();
        modifyStandardList0.setStandardId("\"2024090500152000000000008502\"");
        modifyStandardList0.setStandardDesc("到店就餐使用规则");
        modifyStandardList0.setPersonalQrcodeMode(1L);
        modifyStandardList0.setPaymentPolicy("COMBINATION");
        modifyStandardList0.setConsumeMode("COUPON_ONLY");
        List<StandardConditionInfo> modifyConditionList = new ArrayList<StandardConditionInfo>();
        StandardConditionInfo modifyConditionList0 = new StandardConditionInfo();
        modifyConditionList0.setRuleId("2021052100152602010000000001");
        modifyConditionList0.setRuleFactor("QUOTA_TOTAL");
        modifyConditionList0.setRuleName("单次消费金额");
        modifyConditionList0.setRuleValue("500");
        modifyConditionList.add(modifyConditionList0);
        modifyStandardList0.setModifyConditionList(modifyConditionList);
        AssetShareSourceInfo assetShareSourceInfoAlwwD = new AssetShareSourceInfo();
        assetShareSourceInfoAlwwD.setShareMode("INSTITUTION");
        List<String> sourceIdListFbqYJ = new ArrayList<String>();
        sourceIdListFbqYJ.add("2023031600152614950000031117");
        assetShareSourceInfoAlwwD.setSourceIdList(sourceIdListFbqYJ);
        modifyStandardList0.setAssetShareSourceInfo(assetShareSourceInfoAlwwD);
        modifyStandardList0.setStandardName("到店规则");
        List<StandardConditionInfo> addConditionList = new ArrayList<StandardConditionInfo>();
        StandardConditionInfo addConditionList0 = new StandardConditionInfo();
        addConditionList0.setRuleId("2021052100152602010000000001");
        addConditionList0.setRuleFactor("QUOTA_TOTAL");
        addConditionList0.setRuleName("单次消费金额");
        addConditionList0.setRuleValue("500");
        addConditionList.add(addConditionList0);
        modifyStandardList0.setAddConditionList(addConditionList);
        modifyStandardList0.setOpenRuleId("\"2024090500152000040000008668\"");
        List<String> deleteConditionIdList = new ArrayList<String>();
        deleteConditionIdList.add("2024090500152600000000008502");
        modifyStandardList0.setDeleteConditionIdList(deleteConditionIdList);
        modifyStandardList.add(modifyStandardList0);
        modifyStandardDetailInfo.setModifyStandardList(modifyStandardList);
        model.setModifyStandardDetailInfo(modifyStandardDetailInfo);
        
        // 设置修改的发放规则详情
        ModifyIssueRuleDetailInfo modifyIssueRuleDetailInfo = new ModifyIssueRuleDetailInfo();
        List<String> deleteIssueRuleIdList = new ArrayList<String>();
        deleteIssueRuleIdList.add("2024090500150000040000040033");
        modifyIssueRuleDetailInfo.setDeleteIssueRuleIdList(deleteIssueRuleIdList);
        List<IssueRuleInfo> addIssueRuleList = new ArrayList<IssueRuleInfo>();
        IssueRuleInfo addIssueRuleList0 = new IssueRuleInfo();
        addIssueRuleList0.setIssueStartDate(sdf.parse("2022-08-10 00:00:00"));
        addIssueRuleList0.setInvalidMode(0L);
        addIssueRuleList0.setTargetType("INSTITUTION");
        addIssueRuleList0.setIssueType("ISSUE_MONTH");
        addIssueRuleList0.setEffectivePeriod("{\"all\":true}");
        addIssueRuleList0.setOuterSourceId("123456");
        addIssueRuleList0.setShareMode(0L);
        addIssueRuleList0.setTargetId("2023042600152617860000076000");
        addIssueRuleList0.setIssueRuleId("2022032400152624930000000001");
        addIssueRuleList0.setIssueAmountValue("200");
        addIssueRuleList0.setIssueEndDate(sdf.parse("2022-12-31 23:59:59"));
        addIssueRuleList0.setInvalidModeValue("3213");
        addIssueRuleList0.setIssueRuleName("日额度");
        addIssueRuleList0.setQuotaType("COUPON");
        addIssueRuleList.add(addIssueRuleList0);
        modifyIssueRuleDetailInfo.setAddIssueRuleList(addIssueRuleList);
        ModifyIssueRuleInfo modifyIssueRuleList = new ModifyIssueRuleInfo();
        modifyIssueRuleList.setInvalidMode(0L);
        modifyIssueRuleList.setInvalidModeValue("10");
        modifyIssueRuleList.setIssueType("ISSUE_DAY");
        modifyIssueRuleList.setEffectivePeriod("{\"all\":true}");
        modifyIssueRuleList.setShareMode(0L);
        modifyIssueRuleList.setIssueRuleName("发放餐补");
        modifyIssueRuleList.setIssueRuleId("\"2024090500152621040000040033\"");
        modifyIssueRuleList.setIssueAmountValue("200");
        modifyIssueRuleList.setQuotaType("COUPON");
        modifyIssueRuleDetailInfo.setModifyIssueRuleList(modifyIssueRuleList);
        model.setModifyIssueRuleDetailInfo(modifyIssueRuleDetailInfo);
        
        request.setBizModel(model);
        // 第三方代调用模式下请设置app_auth_token
        // request.putOtherTextParam("app_auth_token", "<-- 请填写应用授权令牌 -->");

        AlipayEbppInvoiceInstitutionModifyResponse response = alipayClient.execute(request);
        System.out.println(response.getBody());

        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
            // sdk版本是"4.38.0.ALL"及以上,可以参考下面的示例获取诊断链接
            // String diagnosisUrl = DiagnosisUtils.getDiagnosisUrl(response);
            // System.out.println(diagnosisUrl);
        }
    }

    private static AlipayConfig getAlipayConfig() {
        String privateKey  = "<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->";
        String alipayPublicKey = "<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->";
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setServerUrl("https://openapi.alipay.com/gateway.do");
        alipayConfig.setAppId("<-- 请填写您的AppId，例如：2019091767145019 -->");
        alipayConfig.setPrivateKey(privateKey);
        alipayConfig.setFormat("json");
        alipayConfig.setAlipayPublicKey(alipayPublicKey);
        alipayConfig.setCharset("UTF-8");
        alipayConfig.setSignType("RSA2");
        return alipayConfig;
    }
}
```
 

##### php
```
 <?php
require_once '../aop/AopClient.php';
require_once '../aop/AopCertClient.php';
require_once '../aop/AopCertification.php';
require_once '../aop/AlipayConfig.php';
require_once '../aop/request/AlipayEbppInvoiceInstitutionModifyRequest.php';

// 初始化SDK
$alipayClient = new AopClient(getAlipayConfig());
// 构造请求参数以调用接口
$request = new AlipayEbppInvoiceInstitutionModifyRequest();
$model = array();

// 设置企业id
$model['enterprise_id'] = "2088123412341234";

// 设置制度id
$model['institution_id'] = "2022031000152617000000000001";

// 设置制度名称
$model['institution_name'] = "费用制度";

// 设置是否启用
$model['effective'] = "0";

// 设置制度描述
$model['institution_desc'] = "餐补制度";

// 设置制度生效起始时间
$model['effective_start_date'] = "2022-09-10 00:00:00";

// 设置制度生效结束时间（可空）
$model['effective_end_date'] = "2022-09-30 23:59:59";

// 设置费控咨询模式
$model['consult_mode'] = "0";

// 设置适用范围修改信息
$modifyScopeInfo = array();
$deleteOwnerIdList = array();
$deleteOwnerIdList[] = "2288000000040864";
$modifyScopeInfo['delete_owner_id_list'] = $deleteOwnerIdList;
$modifyScopeInfo['adapter_type'] = "EMPLOYEE_ALL";
$modifyScopeInfo['owner_type'] = "ENTERPRISE_PAY_UID";
$addOwnerIdList = array();
$addOwnerIdList[] = "1001004110381022";
$modifyScopeInfo['add_owner_id_list'] = $addOwnerIdList;
$model['modify_scope_info'] = $modifyScopeInfo;

// 设置修改的使用规则详情
$modifyStandardDetailInfo = array();
$deleteStandardIdList = array();
$deleteStandardIdList[] = "2024090500000000000000008502";
$modifyStandardDetailInfo['delete_standard_id_list'] = $deleteStandardIdList;
$addStandardList = array();
$addStandardList0 = array();
$addStandardList0['standard_id'] = "2022091300152608010000334322";
$addStandardList0['standard_desc'] = "使用规则描述样例";
$standardConditionInfoList = array();
$standardConditionInfoList0 = array();
$standardConditionInfoList0['rule_id'] = "2021052100152602010000000001";
$standardConditionInfoList0['rule_factor'] = "QUOTA_TOTAL";
$standardConditionInfoList0['rule_name'] = "单次消费金额";
$standardConditionInfoList0['rule_value'] = "500";
$standardConditionInfoList[] = $standardConditionInfoList0;
$addStandardList0['standard_condition_info_list'] = $standardConditionInfoList;
$addStandardList0['expense_type_sub_category'] = "TAKE_AWAY";
$addStandardList0['personal_qrcode_mode'] = 0;
$addStandardList0['payment_policy'] = "PERSONAL";
$addStandardList0['consume_mode'] = "COUPON_ONLY";
$addStandardList0['outer_source_id'] = "123456";
$assetShareSourceInfoHPOaT = array();
$assetShareSourceInfoHPOaT['share_mode'] = "INSTITUTION";
$sourceIdListgYXza = array();
$sourceIdListgYXza[] = "2023031600152614950000031117";
$assetShareSourceInfoHPOaT['source_id_list'] = $sourceIdListgYXza;
$addStandardList0['asset_share_source_info'] = $assetShareSourceInfoHPOaT;
$addStandardList0['standard_name'] = "单笔额度1元钱";
$addStandardList0['open_rule_id'] = "2021070100152721370000002201";
$addStandardList[] = $addStandardList0;
$modifyStandardDetailInfo['add_standard_list'] = $addStandardList;
$modifyStandardList = array();
$modifyStandardList0 = array();
$modifyStandardList0['standard_id'] = "\"2024090500152000000000008502\"";
$modifyStandardList0['standard_desc'] = "到店就餐使用规则";
$modifyStandardList0['personal_qrcode_mode'] = 1;
$modifyStandardList0['payment_policy'] = "COMBINATION";
$modifyStandardList0['consume_mode'] = "COUPON_ONLY";
$modifyConditionList = array();
$modifyConditionList0 = array();
$modifyConditionList0['rule_id'] = "2021052100152602010000000001";
$modifyConditionList0['rule_factor'] = "QUOTA_TOTAL";
$modifyConditionList0['rule_name'] = "单次消费金额";
$modifyConditionList0['rule_value'] = "500";
$modifyConditionList[] = $modifyConditionList0;
$modifyStandardList0['modify_condition_list'] = $modifyConditionList;
$assetShareSourceInfomFJPQ = array();
$assetShareSourceInfomFJPQ['share_mode'] = "INSTITUTION";
$sourceIdListhOXxA = array();
$sourceIdListhOXxA[] = "2023031600152614950000031117";
$assetShareSourceInfomFJPQ['source_id_list'] = $sourceIdListhOXxA;
$modifyStandardList0['asset_share_source_info'] = $assetShareSourceInfomFJPQ;
$modifyStandardList0['standard_name'] = "到店规则";
$addConditionList = array();
$addConditionList0 = array();
$addConditionList0['rule_id'] = "2021052100152602010000000001";
$addConditionList0['rule_factor'] = "QUOTA_TOTAL";
$addConditionList0['rule_name'] = "单次消费金额";
$addConditionList0['rule_value'] = "500";
$addConditionList[] = $addConditionList0;
$modifyStandardList0['add_condition_list'] = $addConditionList;
$modifyStandardList0['open_rule_id'] = "\"2024090500152000040000008668\"";
$deleteConditionIdList = array();
$deleteConditionIdList[] = "2024090500152600000000008502";
$modifyStandardList0['delete_condition_id_list'] = $deleteConditionIdList;
$modifyStandardList[] = $modifyStandardList0;
$modifyStandardDetailInfo['modify_standard_list'] = $modifyStandardList;
$model['modify_standard_detail_info'] = $modifyStandardDetailInfo;

// 设置修改的发放规则详情
$modifyIssueRuleDetailInfo = array();
$deleteIssueRuleIdList = array();
$deleteIssueRuleIdList[] = "2024090500150000040000040033";
$modifyIssueRuleDetailInfo['delete_issue_rule_id_list'] = $deleteIssueRuleIdList;
$addIssueRuleList = array();
$addIssueRuleList0 = array();
$addIssueRuleList0['issue_start_date'] = "2022-08-10 00:00:00";
$addIssueRuleList0['invalid_mode'] = 0;
$addIssueRuleList0['target_type'] = "INSTITUTION";
$addIssueRuleList0['issue_type'] = "ISSUE_MONTH";
$addIssueRuleList0['effective_period'] = "{\"all\":true}";
$addIssueRuleList0['outer_source_id'] = "123456";
$addIssueRuleList0['share_mode'] = 0;
$addIssueRuleList0['target_id'] = "2023042600152617860000076000";
$addIssueRuleList0['issue_rule_id'] = "2022032400152624930000000001";
$addIssueRuleList0['issue_amount_value'] = "200";
$addIssueRuleList0['issue_end_date'] = "2022-12-31 23:59:59";
$addIssueRuleList0['invalid_mode_value'] = "3213";
$addIssueRuleList0['issue_rule_name'] = "日额度";
$addIssueRuleList0['quota_type'] = "COUPON";
$addIssueRuleList[] = $addIssueRuleList0;
$modifyIssueRuleDetailInfo['add_issue_rule_list'] = $addIssueRuleList;
$modifyIssueRuleList = array();
$modifyIssueRuleList['invalid_mode'] = 0;
$modifyIssueRuleList['invalid_mode_value'] = "10";
$modifyIssueRuleList['issue_type'] = "ISSUE_DAY";
$modifyIssueRuleList['effective_period'] = "{\"all\":true}";
$modifyIssueRuleList['share_mode'] = 0;
$modifyIssueRuleList['issue_rule_name'] = "发放餐补";
$modifyIssueRuleList['issue_rule_id'] = "\"2024090500152621040000040033\"";
$modifyIssueRuleList['issue_amount_value'] = "200";
$modifyIssueRuleList['quota_type'] = "COUPON";
$modifyIssueRuleDetailInfo['modify_issue_rule_list'] = $modifyIssueRuleList;
$model['modify_issue_rule_detail_info'] = $modifyIssueRuleDetailInfo;

$request->setBizContent(json_encode($model,JSON_UNESCAPED_UNICODE));
// 如果是第三方代调用模式，请设置app_auth_token（应用授权令牌）
$responseResult = $alipayClient->execute($request, null, "<-- 请填写应用授权令牌 -->", null);
$responseApiName = str_replace(".","_",$request->getApiMethodName())."_response";
$response = $responseResult->$responseApiName;
if(!empty($response->code)&&$response->code==10000){
    echo("调用成功");
}
else{
    echo("调用失败");
}

function getAlipayConfig()
{
    $privateKey  = '<-- 请填写您的应用私钥，例如：MIIEvQIBADANB ... ... -->';
    $alipayPublicKey = '<-- 请填写您的支付宝公钥，例如：MIIBIjANBg... -->';
    $alipayConfig = new AlipayConfig();
    $alipayConfig->setServerUrl('https://openapi.alipay.com/gateway.do');
    $alipayConfig->setAppId('<-- 请填写您的AppId，例如：2019091767145019 -->');
    $alipayConfig->setPrivateKey($privateKey);
    $alipayConfig->setFormat('json');
    $alipayConfig->setAlipayPublicKey($alipayPublicKey);
    $alipayConfig->setCharset('UTF-8');
    $alipayConfig->setSignType('RSA2');
    return $alipayConfig;
}
```
 

##### http
```
 curl 'https://openapi.alipay.com/gateway.do?charset=UTF-8&method=alipay.ebpp.invoice.institution.modify&format=json&sign=${sign}&app_id=${appid}&version=1.0&sign_type=RSA2&timestamp=${now}' \
 -F 'app_auth_token=${app_auth_token}' \
 -F 'biz_content={
	"enterprise_id":"2088123412341234",
	"institution_id":"2022031000152617000000000001",
	"institution_name":"费用制度",
	"effective":"0",
	"institution_desc":"餐补制度",
	"effective_start_date":"2022-09-10 00:00:00",
	"effective_end_date":"2022-09-30 23:59:59",
	"consult_mode":"0",
	"modify_scope_info":{
		"delete_owner_id_list":[
			"2288000000040864"
		],
		"adapter_type":"EMPLOYEE_ALL",
		"owner_type":"ENTERPRISE_PAY_UID",
		"add_owner_id_list":[
			"1001004110381022"
		]
	},
	"modify_standard_detail_info":{
		"delete_standard_id_list":[
			"2024090500000000000000008502"
		],
		"add_standard_list":[
			{
				"standard_id":"2022091300152608010000334322",
				"standard_desc":"使用规则描述样例",
				"standard_condition_info_list":[
					{
						"rule_id":"2021052100152602010000000001",
						"rule_factor":"QUOTA_TOTAL",
						"rule_name":"单次消费金额",
						"rule_value":"500"
					}
				],
				"expense_type_sub_category":"TAKE_AWAY",
				"personal_qrcode_mode":0,
				"payment_policy":"PERSONAL",
				"consume_mode":"COUPON_ONLY",
				"outer_source_id":"123456",
				"asset_share_source_info":{
					"share_mode":"INSTITUTION",
					"source_id_list":[
						"2023031600152614950000031117"
					]
				},
				"standard_name":"单笔额度1元钱",
				"open_rule_id":"2021070100152721370000002201"
			}
		],
		"modify_standard_list":[
			{
				"standard_id":"\"2024090500152000000000008502\"",
				"standard_desc":"到店就餐使用规则",
				"personal_qrcode_mode":1,
				"payment_policy":"COMBINATION",
				"consume_mode":"COUPON_ONLY",
				"modify_condition_list":[
					{
						"rule_id":"2021052100152602010000000001",
						"rule_factor":"QUOTA_TOTAL",
						"rule_name":"单次消费金额",
						"rule_value":"500"
					}
				],
				"asset_share_source_info":{
					"share_mode":"INSTITUTION",
					"source_id_list":[
						"2023031600152614950000031117"
					]
				},
				"standard_name":"到店规则",
				"add_condition_list":[
					{
						"rule_id":"2021052100152602010000000001",
						"rule_factor":"QUOTA_TOTAL",
						"rule_name":"单次消费金额",
						"rule_value":"500"
					}
				],
				"open_rule_id":"\"2024090500152000040000008668\"",
				"delete_condition_id_list":[
					"2024090500152600000000008502"
				]
			}
		]
	},
	"modify_issue_rule_detail_info":{
		"delete_issue_rule_id_list":[
			"2024090500150000040000040033"
		],
		"add_issue_rule_list":[
			{
				"issue_start_date":"2022-08-10 00:00:00",
				"invalid_mode":0,
				"target_type":"INSTITUTION",
				"issue_type":"ISSUE_MONTH",
				"effective_period":"{\\\"all\\\":true}",
				"outer_source_id":"123456",
				"share_mode":0,
				"target_id":"2023042600152617860000076000",
				"issue_rule_id":"2022032400152624930000000001",
				"issue_amount_value":"200",
				"issue_end_date":"2022-12-31 23:59:59",
				"invalid_mode_value":"3213",
				"issue_rule_name":"日额度",
				"quota_type":"COUPON"
			}
		],
		"modify_issue_rule_list":{
			"invalid_mode":0,
			"invalid_mode_value":"10",
			"issue_type":"ISSUE_DAY",
			"effective_period":"{\\\"all\\\":true}",
			"share_mode":0,
			"issue_rule_name":"发放餐补",
			"issue_rule_id":"\"2024090500152621040000040033\"",
			"issue_amount_value":"200",
			"quota_type":"COUPON"
		}
	}
}' 
```
 

### 公共响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|code|String|必须|~|网关返回码，[详见文档](https://docs.open.alipay.com/common/105806)|40004|
|msg|String|必须|~|网关返回码描述，[详见文档](https://docs.open.alipay.com/common/105806)|Business Failed|
|sub_code|String|可选|~|业务返回码，参见具体的API接口文档||
|sub_msg|String|可选|~|业务返回码描述，参见具体的API接口文档||
|sign|String|必须|64|签名，[详见文档](https://docs.open.alipay.com/291/106074)|DZXh8eeTuAHoYE3w1J+POiPhfDxOYBfUNn1lkeT/V7P4zJdyojWEa6IZs6Hz0yDW5Cp/viufUb5I0/V5WENS3OYR8zRedqo6D+fUTdLHdc+EFyCkiQhBxIzgngPdPdfp1PIS7BdhhzrsZHbRqb7o4k3Dxc+AAnFauu4V6Zdwczo=|
### 业务响应参数
|参数英文名|类型|是否必选|长度/取值|描述|示例值|
|---|---|---|---|---|---|
|result|Boolean|必须|10|修改是否成功|true|
|standard_id_info_list|StandardIdInfo|可选|null|新增使用规则后会返回外部幂等id和使用规则id的映射关系||
|standard_id_info_list.standard_id|String|必须|100|使用规则id|2022020900152608000000000001|
|standard_id_info_list.outer_source_id|String|必须|100|外部使用规则id|123456|
|issue_rule_id_info_list|IssueRuleIdInfo|可选|null|新增发放规则时返回外部幂等id和发放规则id的映射关系||
|issue_rule_id_info_list.issue_rule_id|String|必须|100|发放规则id|2022031000152621000000000001|
|issue_rule_id_info_list.outer_source_id|String|必须|100|外部发放规则id|123456|
### 响应示例
#### 正常响应示例
```
 {
	"alipay_ebpp_invoice_institution_modify_response":{
		"code":"10000",
		"msg":"Success",
		"result":true,
		"standard_id_info_list":[
			{
				"standard_id":"2022020900152608000000000001",
				"outer_source_id":"123456"
			}
		],
		"issue_rule_id_info_list":[
			{
				"issue_rule_id":"2022031000152621000000000001",
				"outer_source_id":"123456"
			}
		]
	},
	"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"
}
```
 
#### 异常响应示例
```
 {"alipay_ebpp_invoice_institution_modify_response":{"code":"20000","msg":"Service Currently Unavailable","sub_code":"isp.unknow-error","sub_msg":"系统繁忙"},"sign":"ERITJKEIJKJHKKKKKKKHJEREEEEEEEEEEE"}
```
 
### 业务错误码
|错误码|错误描述|解决方案|
|---|---|---|
|SYSTEM_ERROR|系统繁忙|服务器异常 可能发生了网络或者系统异常，导致服务调用失败，商户可以用同样的请求发起重试|
|INVALID_PARAMETER|参数有误|请根据接口返回的参数非法的具体错误信息，修改参数后进行重试|
|INSTITUTION_MODIFY_FAIL|更新制度失败（该错误码已废弃）|系统异常重试|
|INSTITUTION_NOT_EXIST_ERROR|制度不存在|调整制度规则ID|
|MODIFY_CONSULT_FAILED_CONSUME|制度下使用规则的消费模式非默认，制度咨询模式不允许修改为外算|修改制度下使用规则的消费模式为DEFAULT再修改制度咨询模式为外算|
|MODIFY_CONSULT_FAILED_ISSUE|制度下存在发放规则，制度咨询模式不允许修改为外算|请删除制度下发放规则后再修改咨询模式为外算|
|PERMISSION_DENIED|权限不足，未能查到企业和ISV之间的映射关系|检查传入的企业ID是否正确|
|RECORD_EXIST|outer_source_id已存在，制度下使用规则和发放规则的outer_source_id不允许重复|请更改outer_source_id，确保制度下使用规则和发放规则不重复|