# 使用规则因子枚举

## 时间类规则因子
| **枚举code** | **名称** | **值格式** | **示例值** | **注意事项** |
| --- | --- | --- | --- | --- |
| ALARM_CLOCK_TIME | 使用时间 | 1、时间不限<br/>{"all":true}<br/>2、工作日/节假日<br/>{"regular":{"workday":[["00:00","23:00"]],"holiday":[["00:00","04:00"]]}}<br/>3、自定义设置<br/>{<br/>  "custom": {<br/>    "monday": [["12:00", "13:30"],["12:00", "13:30"]],<br/>    "tuesday": [["12:00", "13:30"],["12:00", "13:30"]],<br/>    "wednesday": [["12:00", "13:30"],["12:00", "13:30"]],<br/>    "thursday": [["12:00", "13:30"],["12:00", "13:30"]],<br/>    "friday": [["12:00", "13:30"],["12:00", "13:30"]],<br/>    "saturday":[["12:00", "13:30"],["12:00", "13:30"]],<br/>    "sunday": [["12:00", "13:30"],["12:00", "13:30"]],<br/>  }<br/>} | {"regular":{"workday":[["00:00","23:00"]],"holiday":[["00:00","04:00"]]}} | 1、不传默认不限<br/>2、可支持跨天功能<br/>+ "monday": [["12:00","13:30"]表示周一12点到13:30。<br/>+ "monday": [["12:00","10:30","1"]表示周一12点到周二10:30。"1"表示是否跨天，不填写该值默认不跨天。<br/>3、跨天时间设置需要注意当日时间和次日时间不能有交叠且当日时间间隔不能超过24小时<br/>错误示范：<br/>+ "monday": [["10:00","10:30","1"]] 周一起始时间和结束时间间隔超过24小时。<br/>+ "monday": [["10:00","9:30","1"]], "tuesday": [["09:00","08:30","1"]]周一结束时间和周二起始时间有交叠。 |




## 位置类规则因子
| **枚举code** | **名称** | **值格式** | **示例值** | **注意事项** |
| --- | --- | --- | --- | --- |
| AREA | 可用位置 | 1、不限制<br/>{"mode": "notLimit"}<br/>2、限制城市<br/>{"mode":"limitCity",<br/>"adcodeList":["adcode1","adcode2"]}<br/>3、限制范围<br/>{<br/>"mode":"limitCoordinateRange","coordinateRange": [{<br/>"longitude":"经度值",<br/>"latitude":"纬度值",<br/>"radius":"半径值",<br/>"poiId":"兴趣点id"<br/>}]}<br/>4、限制国家<br/>{"mode":"limitCountry",<br/>"countryList":["392","418"]} | {"mode":"limitCoordinateRange","coordinateRange":[{"longitude":"120.37288","latitude":"30.310355","poiId":"B0HUOHGZS3","radius":10000}]} | 1、不限制<br/>{"mode": "notLimit"}<br/>2、coordinateRange列表内最多设置10个位置<br/>3、radius单位为米<br/>4、adcode可在网上搜索<br/>"中华人民共和国行政区划代码"查看对应城市的取值。<br/>5、poiId:高德地图搜索POI返回的ID<br/>地址：[https://lbs.amap.com/api/webservice/guide/api/search/](https://lbs.amap.com/api/webservice/guide/api/search/)<br/>6、限制国家类型，countryList请填写国家三位数字编码，填写值参考附录：国家编码 |
| SHIPPING_ADDRESS | 可用收餐地址 | [<br/>{"addressId":"地址id",<br/>"adCode":"城市code",<br/>"longitude":"经度值",<br/>"latitude":"纬度值"}<br/>] | [{"addressId":"1840000000007461","adCode":"820000","longitude":"113.562928","latitude":"22.123025"}] | 不限制地址<br/>[{"addressId":"-1","adCode":"-1","longitude":"-1","latitude":"-1"}]<br/>企业地址可从开放接口获取：alipay.commerce.ec.enterprise.address.query |
| BOARDING_LOCATION | 上车地点 | 1、不限制<br/>{"mode": "notLimit"}<br/>2、限制范围<br/>{"mode":"limitCoordinateRange",<br/>"coordinateRange": [{<br/>"longitude":"经度值",<br/>"latitude":"纬度值",<br/>"radius":"半径值"<br/>}]} | {"mode":"limitCoordinateRange","coordinateRange":[{"longitude":"121.516783","latitude":"31.231963","radius":2000}]} | 1、不限制<br/>{"mode": "notLimit"}<br/>2、radius单位为米 |
| GET_OFF_LOCATION | 下车地点 | 1、不限制<br/>{"mode": "notLimit"}<br/>2、限制范围<br/>{"mode":"limitCoordinateRange",<br/>"coordinateRange": [{<br/>"longitude":"经度值",<br/>"latitude":"纬度值",<br/>"radius":"半径值"<br/>}]} | {"mode":"limitCoordinateRange","coordinateRange":[{"longitude":"121.516783","latitude":"31.231963","radius":2000}]} | 1、不限制<br/>{"mode": "notLimit"}<br/>2、radius单位为米 |




## 商户类规则因子
| **枚举code** | **名称** | **值格式** | **示例值** | **注意事项** |
| --- | --- | --- | --- | --- |
| MEAL_MERCHANT | 指定餐饮商户名单 | {<br/>"pid1":["shopid1","shopid2"],<br/>"pid2":["shopid3","shopid4"]<br/>} | {"20880023114896xx":["-1"],<br/>"20888114411605xx":["20150610000770000000001827xx"]} | shopId值包含-1，代表不限门店，如：<br/>{"2088xxxx":["-1"]} |
| MERCHANT | 商户名单 | {<br/>"pid1":["shopid1","shopid2"],<br/>"pid2":["shopid3","shopid4"]<br/>} | {"20880023114896xx":["-1"],<br/>"20888114411605xx":["20150610000770000000001827xx"]} | shopId值包含-1，代表不限门店，如：<br/>{"2088xxxx":["-1"]} |
| MCC | 商户类型 | {<br/>"一级类目1":["二级类目1","二级类目2"],<br/>"一级类目2":["二级类目3","二级类目4"]<br/>} | {"A0002": ["21","B0017", "23"]} | 餐饮到店：<br/>1、支持餐饮下所有类目<br/>{"A0001": ["-1"]}<br/>2、支持餐饮下的西式正餐类目<br/>{"A0001": ["B0002"]}<br/><br/>到店加油：<br/>1、支持交通出行下所有类目<br/>{"A0006": ["-1"]}<br/>2、支持交通出行下的加油卡、加油服务类目<br/>{"A0006": ["B0090"]}<br/><br/>到店住宿：   1、支持酒旅景区下所有类目<br/>{"A0010": ["-1"]}<br/>2、支持酒旅景区下酒店的类目<br/>{"A0010": ["B0157"]}<br/><br/>线下商超：<br/>1、支持零售批发下所有类目<br/>{"A0002": ["-1"]}<br/>2、支持零售批发下的超市类目<br/>{"A0002": ["B0015"]}<br/><br/>到院就医<br/>1、支持医疗卫生下所有类目<br/>{"A0009": ["-1"]}<br/>2、支持医疗卫生下的公立医院类目<br/>{"A0009": ["B0143"]} |
| BRAND | 品牌 | {<br/>"brandSource":"AUTH_BRAND(认证品牌)/ALL(全量品牌)",<br/> "brandIdList":["",""]<br/>} | {"brandSource":"ALL","brandIdList":["2022032500502042000000151567"]} | brandIdList限制200个 |
| SHOP | 门店 | ["企业码门店id1","企业码门店id2"] | ["2015061000077000000000182xx1","2015061000077000000000182xx2"] | 门店数量限制100个 |
| SHOP_GROUP | 门店组 | ["门店组1","门店组2"] | ["1826212311778500xx1","1826212311778500xx2"] |  |
| RECEIPT_IDENTITY_WHITE_LIST | 白名单 | ["收单身份1","收单身份2"] | ["202301180015262813000000xxx","202301180015262813000000xx1"] | 白名单收单身份组，需提前申请小二配置 |
| RECEIPT_IDENTITY_BLACK_LIST | 黑名单 | ["收单身份1","收单身份2"] | ["202301180015262813000000xxx","202301180015262813000000xx1"] | 黑名单收单身份组，需提前申请小二配置 |
| MERCHANT_LABEL | 商家服务标签 | ["服务1","服务2"] | ["INVOICE"] | 1、外卖可选枚举值如下：<br/>INVOICE-可开票<br/>2、到店加油可选枚举值如下：<br/>NON_PLATFORM_OIL-非平台型加油站<br/>NATIONWIDE_OIL-全国加油站<br/>3、其他可选枚举值如下：<br/>SUPPORT_INVOICE-支持开票<br/>USE_INVOICE-开过票 |
| ALI_PLATFORM_TYPE | 线上淘系商户 | ["淘系商户code1","淘系商户code2"] | ["TAOTIAN","1688"] | 可选枚举值如下：<br/>TAOTIAN-淘宝&天猫<br/>1688-1688平台 |
| COMPOSITE_MERCHANT | 复合商户 | {<br/> "mcc":{"A0001":["-1"]},<br/> "receiptIdentityWhiteList": ["",""],<br/>"brand":{<br/>"brandSource":"AUTH_BRAND(认证品牌)/ALL(全量品牌)",<br/> "brandIdList":["",""] },<br/>"shopIdList":["",""],<br/>"shopGroupIdList":["",""]<br/>} | {<br/> "mcc":{"A0001":["-1"]},<br/> "receiptIdentityWhiteList": ["202301180015262813000000xxx"],<br/>"brand":{<br/> "brandSource":"ALL",<br/> "brandIdList":["2022032500502042000000xx1","2022032500502042000000xx2"]<br/> },<br/>"shopIdList":["2015061000077000000000182xx1","2015061000077000000000182xx2"],<br/>"shopGroupIdList":["1826212311778500xx1","1826212311778500xx2"]<br/>} | 复合规则因子中商户满足任意过滤条件均视为规则通过。<br/>mcc：商户类型<br/>brand：品牌<br/>receiptIdentityWhiteList：商户组（需向企业码小二申请配置收单账号为商户组，适用于对mcc/品牌进行商户补齐，也可单独使用）<br/>shopIdList：门店id<br/>shopGroupIdList：门店组id |

### 因公优先规则组合

因公优先是可选增强能力，不是某个费用类型的专属规则，也不是制度默认生成项。只有用户明确提出需要因公优先时，才判断场景是否支持并生成规则组合；用户未提及时保持关闭，不主动询问、不额外生成 `ALARM_CLOCK_TIME` 或商户限制规则。使用 `ALI_PLATFORM_TYPE` 的淘系平台场景（`TAOTIAN`、`1688` 等）不支持因公优先，不应询问或生成因公优先规则组合。

用户明确启用，且场景支持因公优先时必须同时满足：

1. 配置 `ALARM_CLOCK_TIME` 使用时间规则。
2. 至少配置一个有效商户限制规则：`MEAL_MERCHANT`、`MERCHANT`、`COMPOSITE_MERCHANT`、`SHOP_GROUP`、`SHOP`、`RECEIPT_IDENTITY_WHITE_LIST`。
3. `COMPOSITE_MERCHANT` 只有 `receiptIdentityWhiteList`、`shopIdList`、`shopGroupIdList` 中至少一个列表非空时，才计为有效商户限制。
4. 该组合不能替代费用类型自身在 `expense-type-constraints.md` 中规定的必用规则因子。


## 额度类规则因子

以下因子中，只有 `QUOTA_DAY`、`QUOTA_WEEK`、`QUOTA_MONTH`、`QUOTA_SEASON`、`QUOTA_YEAR`、`QUOTA_TOTAL` 属于制度可用额度的限额条件，可用于满足“内部费控制度至少有一个限额条件”的生成校验。

`QUOTA_ONCE`、`QUOTA_ONCE_PERCENT` 属于单次支付规则，`ALLOW_MINIMUM`、`OWNER_PAY_MINIMUM` 属于订单/个人支付门槛，`QUOTA_UNLIMITED` 表示不限额；这些因子可以作为使用规则，但不视为制度可用额度的限额条件。

| **枚举code** | **名称** | **值格式** | **示例值** | **注意事项** |
| --- | --- | --- | --- | --- |
| QUOTA_DAY | 每日额度限制 | 10 | 10 | 金额值以（元）为单位的数值，可以精确到小数点后两位。 |
| QUOTA_WEEK | 每周额度限制 | 10 | 10 | 金额值以（元）为单位的数值，可以精确到小数点后两位。 |
| QUOTA_MONTH | 每月额度限制 | 10 | 10 | 金额值以（元）为单位的数值，可以精确到小数点后两位。 |
| QUOTA_SEASON | 每季额度限制 | 10 | 10 | 金额值以（元）为单位的数值，可以精确到小数点后两位。 |
| QUOTA_YEAR | 每年额度限制 | 10 | 10 | 金额值以（元）为单位的数值，可以精确到小数点后两位。 |
| QUOTA_TOTAL | 有效期总额度 | 10 | 10 | 金额值以（元）为单位的数值，可以精确到小数点后两位。 |
| QUOTA_ONCE | 单次限额 | 10 | 10 | 单次支付规则，限制单次最多可因公付金额；不属于制度可用额度的限额条件。金额值以（元）为单位的数值，可以精确到小数点后两位。 |
| ALLOW_MINIMUM | 消费最低限额 | 10 | 10 | 订单金额最低满多少可以因公付，属于订单门槛；不属于制度可用额度的限额条件。金额值以（元）为单位的数值，可以精确到小数点后两位。 |
| OWNER_PAY_MINIMUM | 个付低消限额 | 10 | 10 | 个人支付最低满多少金额可以因公付，属于个人支付门槛；不属于制度可用额度的限额条件。金额值以（元）为单位的数值，可以精确到小数点后两位。 |
| QUOTA_UNLIMITED | 不限额度 | MAX | MAX | 固定值MAX，表示不限额；不属于制度可用额度的限额条件。 |
| QUOTA_ONCE_PERCENT | 按比例单次额度 | 20 | 20 | 订单金额百分之多少的金额可以因公付，属于单次支付规则；不属于制度可用额度的限额条件。百分比，10%填10，只支持10的倍数。 |




## 其他
| **枚举code** | **名称** | **值格式** | **示例值** | **注意事项** |
| --- | --- | --- | --- | --- |
| GOODS_ID | 商品ID白名单 | 商品id1,商品id2 | 200015,200016 | 限制5000个id以内，总长不超过65535个字符 |
| GOODS_ID_BLACK_LIST | 商品ID黑名单 | 商品id1,商品id2 | 200015,200016 | 限制5000个id以内，总长不超过65535个字符 |
| CURRENCY_LIST | 消费币种列表 | ["币种code1","币种code2"] | ["USD","EUR"] | 可配置币种列表参考附录：币种列表 |
| SERVICE | 服务产品 | 1、指定服务列表<br/>{"mode":"specify","serviceIdList":["服务id1"]}<br/>2、不限制服务<br/>{"mode":"default"} | {"mode":"specify","serviceIdList":["1634114792935157761"]} | 服务id可联系企业码技术支持订购服务后获取。外卖服务id-2026032001557644，用车服务id-1633315632749248514
| SUPPLIER_CHANNEL | 供应商渠道 | ["EleTakeAwayStandard"] | ["EleTakeAwayStandard"] | 外卖使用，仅支持EleTakeAwayStandard |
| TAKE_AWAY_CATEGORY | 外卖品类 | ["类目1","类目2"] | 1、全量餐饮美食<br/>["MEAL"]<br/>2、全部快餐便当品类<br/>["FAST_FOOD_LUNCH"]<br/>3、兰州拉面、热干面、螺蛳粉<br/>["LANZHOU_STRETCHED_NOODLES","HOT_DRIED_NOODLES","SNAIL_POWDER"] | 参考附录：外卖品类标准值 |
| BOOK_SWITCH | 是否开启预定 | on | on | 1、开启提前预订<br/>on<br/>2、关闭提前预订<br/>off |
| MARKED_WORDS | 填单页文案提示 | xxx | 请适量点餐，避免浪费 | |
| CROSS_CITY | 是否允许跨城 | boolean类型<br/>true-允许修改<br/>false-不允许修改 | false | |
| CAR_TYPE | 车型 | {<br/>"carType":[经济型]<br/>} | {"carType":["ECONOMY","PREMIER","SELECT","BUSINESS","LUXURY"]} | ECONOMY-经济型<br/>PREMIER-优享<br/>SELECT-专车<br/>BUSINESS-商务型<br/>LUXURY-豪华型 |
| ALLOW_CHANGE_DESTINATION | 允许修改目的地 | boolean类型<br/>true-允许修改<br/>false-不允许修改 | false | 允许修改目的地时，需要选择上下车点 |
| ALLOW_BOOK_CAR | 允许预约用车 | boolean类型<br/>true-允许预约<br/>false-不允许预约 | true | |
| FILL_REASON | 填写申请理由 | 1.需要填写<br/>{"mode":"force"}<br/>2.无需填写<br/>{"mode":"notNeed"} | {"mode":"force"} | |
| REQUIRE_APPROVE | 是否需审批 | boolean类型<br/>true-需要审批<br/>false-无需审批 | true | 需要审批，需要联动审批单流程 |
| CARD_TYPE | 卡类型 | ["卡1","卡2"] | ["S0320100","S0330100"] | 公交卡code<br/>邵阳公交电子卡-T0430500<br/>常德电子公交卡-T0430700<br/>吉首电子公交卡-T0433101<br/>更多参考附录：公交卡类型枚举<br/>地铁卡code<br/>上海地铁卡-S0310001<br/>北京地铁卡-S0110000<br/>杭州地铁卡-S0330100<br/>更多参考附录：地铁卡类型枚举 |
| SELF_TAKE_SWITCH | 是否开启到店自提 | 1、开启到店自提<br/>on<br/>2、关闭到店自提<br/>off | on |  |
| GOODS_CATEGORY_BLACK_LIST | 商品类目黑名单 | ["类目1","类目2"] | 1、全量餐饮类目<br/>["MEAL"]<br/>2、全部中式糕点类目<br/>["CHINESE_PASTRY"]<br/>3、啤酒、白酒、黄酒<br/>["BEER","CHINESE_LIQUOR","YELLOW_WINE"] | 参考附录：商品类目标准值 |
| OIL_CATEGORY | 油品类型 | ["油品类型"] | ["FUEL_DSL_0"] | 1、若用户使用企业码到店加油列表，选择油品下单并享受相应的折扣，为了防止选错商品导致享受错误的折扣，需要根据实际用户车辆情况限制可选油品。（注：该限制并不能影响实际用户交易时购买何种商品，仍需要商家人工核实）<br/>2、目前只支持限制单个油品类型，可选枚举值请参考<br/>附录：油品类型标准值 |




## 附录：
### 地铁卡类型枚举
| **地铁卡编码** | **地铁卡** |
| --- | --- |
| S0320300 | 徐州地铁乘车码 |
| S0320400 | 常州地铁电子乘车卡 |
| S0340200 | 芜湖轨道电子乘车卡 |
| S0410300 | 洛阳轨道交通电子卡 |
| S0650100 | 乌鲁木齐地铁 |
| S0150100 | 呼和浩特电子地铁卡 |
| S0430100 | 长沙地铁/磁浮乘车码 |
| S0370100 | 济南地铁乘车码 |
| S1530100 | 昆明地铁日票卡 |
| S1610100 | 西安地铁乘车码 |
| T1230100 | 哈尔滨支付宝乘车卡 |
| T1310100 | 随申码（上海城市出行码） |
| S1350200 | 厦门交通码(公交/地铁/BRT/居民轮渡)  |
| S0320500 | 苏州地铁电子乘车卡 |
| S0130100 | 石家庄地铁乘车码 |
| S0440100 | 广州地铁公共交通码 |
| T1210600 | 鸭绿江通电子公交卡 |
| S0331000 | 台州轨道交通乘车码 |
| ST331000 | 台州轻轨测试卡 |
| S0620101 | 兰州地铁电子卡 |
| S0450100 | 南宁地铁乘车码 |
| S0330700 | 金华轨道交通 |
| S0441900 | 东莞轨道乘车码 |
| S0350100 | e福州电子地铁卡 |
| S0350200 | 厦门地铁BRT电子卡 |
| S0330200 | 宁波轨道交通乘车码 |
| S0410100 | 郑州地铁商易行卡 |
| S0310001 | 上海地铁Metro大都会乘车码 |
| T1210100 | 沈阳盛京通电子乘车码 |
| T0500100 | 重庆公共交通乘车码 |
| S1510100 | 成都电子乘车码 |
| S0440600 | 佛山地铁乘车码 |
| S0360100 | 鹭鹭行乘车码 |
| S0340100 | 合肥轨道交通乘车码 |
| S0610100 | 西安电子地铁卡 |
| T1440300 | 深圳通乘车码 |
| S0220100 | 长春E出行电子乘车卡 |
| S0530100 | 昆明地铁乘车码 |
| S0320200 | 无锡地铁电子卡 |
| S0320100 | 南京地铁电子卡 |
| S0420100 | 武汉地铁乘车码 |
| T0430500 | 邵阳电子公交卡 |
| S0110000 | 北京轨道交通乘车码 |
| S0330100 | 杭州地铁乘车码 |


### 公交卡类型枚举
| 公交卡编码 | 公交卡名称 | 适用城市 |
| --- | --- | --- |
| T0433101 | 吉首电子公交卡 | 湘西土家族苗族自治州 |
| T0430500 | 邵阳公交电子卡 | 邵阳 |
| T0431000 | 郴州电子公交卡 |  |
| T0430700 | 常德电子公交卡 | |


### 外卖品类标准值
| parent_code（父级标准值） | standard_code（标准值） | standard_code_desc<br/>（标准值描述） |
| --- | --- | --- |
| | MEAL | 餐饮 |
| MEAL | FAST_FOOD_LUNCH | 快餐便当 |
| MEAL | CHINESE_CUISINE | 中式菜系 |
| MEAL | SNACKS_BBQ | 小吃/烧烤 |
| MEAL | DESSERT_DRINKS | 奶茶果汁 |
| MEAL | GLOBAL_CUISINE | 全球美食 |
| MEAL | HOT_POT | 香锅火锅 |
| FAST_FOOD_LUNCH | ROAST_PORK_WITH_RICE | 烤肉拌饭 |
| FAST_FOOD_LUNCH | FRIED_RICE | 炒饭 |
| FAST_FOOD_LUNCH | MAOCAI | 冒菜 |
| FAST_FOOD_LUNCH | BARBECUE_CHILLED_NOODLES | 烤冷面 |
| FAST_FOOD_LUNCH | PAN_FRIED | 生煎 |
| FAST_FOOD_LUNCH | COOL_SKIN_AND_POWDER | 凉皮/凉粉 |
| FAST_FOOD_LUNCH | LANZHOU_STRETCHED_NOODLES | 兰州拉面 |
| FAST_FOOD_LUNCH | CHONGQING_NOODLES | 重庆小面 |
| FAST_FOOD_LUNCH | HOT_DRIED_NOODLES | 热干面 |
| FAST_FOOD_LUNCH | SHA_COUNTY_SNACKS | 沙县小吃 |
| FAST_FOOD_LUNCH | STEAMED_VERMICELLI_ROLL | 肠粉 |
| FAST_FOOD_LUNCH | HOT_AND_SOUR_RICE_NOODLES | 酸辣粉 |
| FAST_FOOD_LUNCH | GRUEL_STORE | 粥店 |
| FAST_FOOD_LUNCH | SOYBEAN_MILK_AND_FRIED_BREAD_STICK | 豆浆油条 |
| FAST_FOOD_LUNCH | STEAMED_CHICKEN_NOURISHING_CHICKEN | 蒸鸡滋补鸡 |
| FAST_FOOD_LUNCH | MEAT_SANDWICH_STEAMED_BUNS | 肉夹馍 |
| FAST_FOOD_LUNCH | CAKE_WITH_SHALLOT_OIL | 葱油饼 |
| FAST_FOOD_LUNCH | BURNT_BREAD_AND_PIE_AND_HAND_CRAWLER | 烧饼/馅饼/手抓饼 |
| FAST_FOOD_LUNCH | OTHER_FAST_FOOD | 其他快餐 |
| FAST_FOOD_LUNCH | CROCK_POT_SOUP | 瓦罐汤 |
| FAST_FOOD_LUNCH | SNAIL_POWDER | 螺蛳粉 |
| FAST_FOOD_LUNCH | RICE_NOODLES_RICE_NOODLES | 米粉米线 |
| FAST_FOOD_LUNCH | NOODLE | 面馆 |
| FAST_FOOD_LUNCH | SPICY_AND_HOT_AND_ODEN | 麻辣烫/关东煮 |
| FAST_FOOD_LUNCH | HAMBURGER_FRIES | 汉堡薯条 |
| FAST_FOOD_LUNCH | RICE_BOWL | 盖浇饭 |
| FAST_FOOD_LUNCH | CHAOSHAN_CASSEROLE_PORRIDGE | 潮汕砂锅粥 |
| FAST_FOOD_LUNCH | CASSEROLE_RICE | 煲仔饭 |
| FAST_FOOD_LUNCH | CURRY_RICE | 咖喱饭 |
| FAST_FOOD_LUNCH | YELLOW_BRAISED_CHICKEN_RICE | 黄焖鸡米饭 |
| FAST_FOOD_LUNCH | ROASTED_RICE | 烧腊饭 |
| FAST_FOOD_LUNCH | DONKEY_MEAT_IS_FIRED | 驴肉火烧 |
| FAST_FOOD_LUNCH | BUN_SOUP_BUNS | 包子汤包 |
| FAST_FOOD_LUNCH | SHACHA_NOODLES | 沙茶面 |
| FAST_FOOD_LUNCH | BEIJING_FRIED_SAUCE_NOODLES | 北京炸酱面 |
| FAST_FOOD_LUNCH | STEAMED_BUNS | 泡馍 |
| FAST_FOOD_LUNCH | PANCAKE | 煎饼 |
| FAST_FOOD_LUNCH | SPICY_SOUP | 胡辣汤 |
| FAST_FOOD_LUNCH | VERMICELLI_SOUP | 粉丝汤 |
| FAST_FOOD_LUNCH | NOURISHING_STEW | 滋补炖汤 |
| FAST_FOOD_LUNCH | LAMB_BROTH | 羊肉汤 |
| FAST_FOOD_LUNCH | BEEF_SOUP | 牛肉汤 |
| FAST_FOOD_LUNCH | RIB_RICE | 排骨饭 |
| FAST_FOOD_LUNCH | BEEF_RICE | 牛肉饭 |
| FAST_FOOD_LUNCH | WONTON_SCRIBE | 馄饨抄手 |
| FAST_FOOD_LUNCH | DUMPLINGS | 饺子 |
| FAST_FOOD_LUNCH | NAIL_POLLEN | 花甲粉 |
| FAST_FOOD_LUNCH | POT_STICKERS | 锅贴 |
| FAST_FOOD_LUNCH | CRISPY_CHICKEN_RICE | 脆皮鸡饭 |
| FAST_FOOD_LUNCH | BARREL_RICE | 木桶饭 |
| CHINESE_CUISINE | ANHUI_CUISINE | 徽菜 |
| CHINESE_CUISINE | GUIZHOU_PROVINCE | 贵州菜 |
| CHINESE_CUISINE | TAIWANESE_FOOD | 台湾菜 |
| CHINESE_CUISINE | JIANGXI_FOOD | 江西菜 |
| CHINESE_CUISINE | FUJIAN_CUISINE | 闽菜 |
| CHINESE_CUISINE | HONG_KONG_FOOD_AND_TEA_RESTAURANT | 港菜/茶餐厅 |
| CHINESE_CUISINE | PRIVATE_KITCHENS | 私房菜 |
| CHINESE_CUISINE | HUAIYANG_CUISINE | 淮扬菜 |
| CHINESE_CUISINE | CREATIVE_CUISINE | 创意菜 |
| CHINESE_CUISINE | A_VEGETARIAN_DIET | 素食 |
| CHINESE_CUISINE | HALAL_FOOD | 清真菜 |
| CHINESE_CUISINE | HUBEI_CUISINE | 湖北菜 |
| CHINESE_CUISINE | FARM_STYLE | 农家菜 |
| CHINESE_CUISINE | HENAN_DISHES | 河南菜 |
| CHINESE_CUISINE | BEIJING_CUISINE | 北京菜 |
| CHINESE_CUISINE | LOCAL_CUISINES | 本帮菜 |
| CHINESE_CUISINE | OTHER_CUISINES | 其他菜系 |
| CHINESE_CUISINE | SICHUAN_AND_HUNAN | 川湘菜 |
| CHINESE_CUISINE | GUANGDONG_CUISINE | 粤菜 |
| CHINESE_CUISINE | COMPOSED | 东北菜 |
| CHINESE_CUISINE | YUNNAN_CUISINE | 云南菜 |
| CHINESE_CUISINE | JIANGSU_AND_ZHEJIANG_CUISINE | 江浙菜 |
| CHINESE_CUISINE | NORTHWEST_CUISINE | 西北菜 |
| CHINESE_CUISINE | SHANDONG_CUISINE | 鲁菜 |
| CHINESE_CUISINE | XINJIANG_CUISINE | 新疆菜 |
| CHINESE_CUISINE | SEAFOOD | 海鲜 |
| SNACKS_BBQ | OCTOPUS_BALLS | 章鱼小丸子 |
| SNACKS_BBQ | OTHER_SNACKS | 其他小吃 |
| SNACKS_BBQ | BOWL_CHICKEN | 钵钵鸡 |
| SNACKS_BBQ | SKEWERS_OF_INCENSE | 串串香 |
| SNACKS_BBQ | CRAYFISH | 小龙虾 |
| SNACKS_BBQ | FRIED_CHICKEN_SKEWERS | 炸鸡炸串 |
| SNACKS_BBQ | GRILL | 烧烤 |
| SNACKS_BBQ | CHICKEN_RACKS | 鸡架 |
| SNACKS_BBQ | MARINATED_COOKED_FOOD | 卤味熟食 |
| SNACKS_BBQ | BRACKED_AND_FRIED_LIVER | 卤煮/炒肝 |
| DESSERT_DRINKS | OTHER_DESSERT_DRINKS | 其他甜品饮品 |
| DESSERT_DRINKS | CAKE | 蛋糕 |
| DESSERT_DRINKS | FRUIT_FISHING | 水果捞 |
| DESSERT_DRINKS | MILK_TEA_JUICE | 奶茶果汁 |
| DESSERT_DRINKS | DESSERT | 甜品 |
| DESSERT_DRINKS | BREAD | 面包 |
| DESSERT_DRINKS | CHINESE_AND_WESTERN_PASTRIES | 中西糕点 |
| DESSERT_DRINKS | ICE_CREAM | 冰淇淋 |
| DESSERT_DRINKS | COFFEE | 咖啡 |
| GLOBAL_CUISINE | SPANISH_CUISINE | 西班牙菜 |
| GLOBAL_CUISINE | BAKED_RICE | 焗饭 |
| GLOBAL_CUISINE | KOREAN_STYLE_BARBECUE | 韩式烤肉 |
| GLOBAL_CUISINE | PIZZA_PASTA | 披萨意面 |
| GLOBAL_CUISINE | SALAD_AND_LIGHT_FOOD | 沙拉/轻食 |
| GLOBAL_CUISINE | MALAYSIAN_CUISINE | 马来西亚菜 |
| GLOBAL_CUISINE | VIETNAMESE_CUISINE | 越南菜 |
| GLOBAL_CUISINE | SINGAPOREAN_CUISINE | 新加坡菜 |
| GLOBAL_CUISINE | INDIAN_CUISINE | 印度菜 |
| GLOBAL_CUISINE | THAI_CUISINE | 泰国菜 |
| GLOBAL_CUISINE | SANDWICH | 三明治 |
| GLOBAL_CUISINE | KOREAN_CUISINE | 韩国料理 |
| GLOBAL_CUISINE | SASHIMI_SUSHI | 刺身寿司 |
| GLOBAL_CUISINE | JAPANESE_BBQ | 日式烧烤 |
| GLOBAL_CUISINE | A_LIGHT_JAPANESE_MEAL | 日式简餐 |
| GLOBAL_CUISINE | JAPANESE_CUISINE | 日本料理 |
| GLOBAL_CUISINE | OTHER_WESTERN_FOOD | 其他西餐 |
| GLOBAL_CUISINE | CENTRAL_ASIAN_AND_MIDDLE_EASTERN_CUISINE | 中亚/中东菜 |
| GLOBAL_CUISINE | MEXICAN_CUISINE | 墨西哥菜 |
| GLOBAL_CUISINE | FRENCH_CUISINE | 法国菜 |
| GLOBAL_CUISINE | ITALIAN_CUISINE | 意大利菜 |
| GLOBAL_CUISINE | STEAK | 牛排 |
| HOT_POT | SLOW_COOKER | 焖锅 |
| HOT_POT | LITTLE_HOT_POT | 小火锅 |
| HOT_POT | FISH_HOT_POT | 鱼火锅 |
| HOT_POT | LAMB_SPINE_HOT_POT | 羊蝎子 |
| HOT_POT | SI_CHUANG_HOT_POT | 川渝火锅 |
| HOT_POT | BEI_JING_HOT_POT | 铜锅涮肉 |
| HOT_POT | BEEF_HOT_POT | 牛肉火锅 |
| HOT_POT | SPICY_HOT_POT | 麻辣香锅 |
| HOT_POT | CASSEROLES | 砂锅 |
| HOT_POT | ROAST_FISH | 烤鱼 |
| HOT_POT | CHICKEN_HOT_POT | 鸡公煲 |
| HOT_POT | OTHER_HOT_POT | 其他火锅 |
| HOT_POT | DRY_POT | 干锅 |
| HOT_POT | HONG_KONG_HOT_POT | 港式火锅/打边炉 |


### 商品类目标准值
| parent_code（父级标准值） | standard_code（标准值） | standard_code_desc<br/>（标准值描述） |
| --- | --- | --- |
|  | MEAL | 餐饮 |
| MEAL | CHINESE_PASTRY | 中式糕点 |
| MEAL | SWEET_SOUP | 糖水/甜汤 |
| MEAL | FROZEN_DESSERT | 冷冻甜品 |
| MEAL | WESTERN_PASTRY | 西式糕点 |
| MEAL | COARSE_GRAIN | 粗粮类 |
| MEAL | NOODLE | 面类 |
| MEAL | RICE | 米类 |
| MEAL | RICE_NOODLE | 粉类 |
| MEAL | SPECIALTY_DISH | 特色菜品 |
| MEAL | HOT_DISH | 热菜 |
| MEAL | COLD_DISH | 凉菜 |
| MEAL | HOT_POT_SKEWER | 火锅/串串/麻辣烫/冒菜/香锅 |
| MEAL | GRILLED_FRIED_BOILED_SKEWER | 烤串/炸串/煮串 |
| MEAL | SOUP | 汤 |
| MEAL | THICK_SOUP | 羹 |
| MEAL | PACKAGED_BEVERAGE | 包装饮品 |
| MEAL | FRESH_BEVERAGE | 现制饮品 |
| MEAL | OTHER_SET_MEAL | 其他套餐 |
| MEAL | FOUR_PERSON_SET_MEAL | 四人套餐 |
| MEAL | TWO_PERSON_SET_MEAL | 双人套餐 |
| MEAL | SINGLE_SET_MEAL | 单人套餐 |
| MEAL | THREE_PERSON_SET_MEAL | 三人套餐 |
| MEAL | SALAD_LIGHT_FOOD_TOPPING | 沙拉轻食加料类 |
| MEAL | RICE_NOODLE_TOPPING | 米面食物加料类 |
| MEAL | BEVERAGE_TOPPING | 饮品加料类 |
| MEAL | SOUP_TOPPING | 汤羹加料类 |
| MEAL | DIPPING_SAUCE_SEASONING | 蘸料/调味料 |
| MEAL | DISH_TOPPING | 菜肴加料类 |
| MEAL | DESSERT_TOPPING | 甜品加料类 |
| MEAL | OTHER_TOPPING | 其他加料 |
| MEAL | WESTERN_CUISINE | 西餐 |
| MEAL | SOUTHEAST_ASIAN_CUISINE | 东南亚菜 |
| MEAL | WINE | 葡萄酒 |
| MEAL | FRESH_COCKTAIL | 现制鸡尾酒 |
| MEAL | OTHER_ALCOHOL | 其他酒水 |
| MEAL | CHINESE_LIQUOR | 白酒 |
| MEAL | BEER | 啤酒 |
| MEAL | YELLOW_WINE | 黄酒 |
| MEAL | INFORMATION_NOTICE | 信息说明 |
| MEAL | OTHER_NON_FOOD | 其他非食品 |
| MEAL | VOUCHER | 代金券 |
| MEAL | FLOWER | 鲜花 |
| MEAL | BUFFET | 自助餐 |
| MEAL | NON_FOOD_RETAIL | 非餐零售商品 |
| MEAL | POT_STOVE | 锅具/炉具 |
| MEAL | TABLEWARE | 餐具 |
| CHINESE_PASTRY | CRISP_PASTRY | 酥/酥饼 |
| CHINESE_PASTRY | CAKE_TYPE | 糕类 |
| SWEET_SOUP | GINGER_MILK_CUSTARD | 姜撞奶 |
| SWEET_SOUP | HERBAL_JELLY | 龟苓膏 |
| SWEET_SOUP | RED_BEAN_DESSERT | 豆沙类甜品 |
| SWEET_SOUP | FRUIT_SWEET_SOUP | 水果类甜汤 |
| SWEET_SOUP | BIRDS_NEST_DESSERT | 燕窝甜品 |
| SWEET_SOUP | YOGURT_PRODUCT | 酸奶制品 |
| SWEET_SOUP | PEACH_GUM_DESSERT | 桃胶甜品 |
| SWEET_SOUP | ICE_JELLY | 冰粉 |
| SWEET_SOUP | SAGO_DESSERT | 西米露 |
| SWEET_SOUP | FRUIT_MIX | 水果捞 |
| SWEET_SOUP | TARO_BALL_DESSERT | 芋圆甜品 |
| SWEET_SOUP | FOUR_FRUIT_SOUP | 四果汤 |
| SWEET_SOUP | TOFU_PUDDING_DESSERT | 豆花类甜品 |
| SWEET_SOUP | DOUBLE_SKIN_MILK | 双皮奶 |
| SWEET_SOUP | OTHER_SWEET_SOUP | 其他糖水/甜汤 |
| FROZEN_DESSERT | SMOOTHIE_SHAVED_ICE | 冰沙/刨冰 |
| FROZEN_DESSERT | FROZEN_YOGURT | 冻酸奶 |
| FROZEN_DESSERT | MILKSHAKE | 奶昔 |
| FROZEN_DESSERT | STIR_FRIED_YOGURT | 炒酸奶 |
| FROZEN_DESSERT | ICE_CREAM | 冰淇淋 |
| FROZEN_DESSERT | OTHER_FROZEN_DESSERT | 其他冷冻甜品 |
| FROZEN_DESSERT | JELLY_PUDDING | 果冻/布丁 |
| WESTERN_PASTRY | FRUIT_CAKE | 水果蛋糕 |
| WESTERN_PASTRY | BISCUIT | 饼干 |
| WESTERN_PASTRY | PORK_FLOSS_CAKE | 肉松蛋糕 |
| WESTERN_PASTRY | OTHER_WESTERN_DESSERT | 其他西式甜品 |
| WESTERN_PASTRY | FRESH_MILK_CAKE | 鲜奶蛋糕 |
| WESTERN_PASTRY | CHOCOLATE_CAKE | 巧克力蛋糕 |
| WESTERN_PASTRY | SANDWICH | 三明治 |
| WESTERN_PASTRY | CUPCAKE | 纸杯蛋糕 |
| WESTERN_PASTRY | PUFF | 泡芙 |
| WESTERN_PASTRY | EGG_TART | 蛋挞 |
| WESTERN_PASTRY | DONUT | 甜甜圈 |
| WESTERN_PASTRY | BREAD_TOAST | 面包/吐司 |
| WESTERN_PASTRY | PIE | 派类 |
| WESTERN_PASTRY | LAYER_CAKE | 千层蛋糕 |
| WESTERN_PASTRY | PANCAKE | 班戟 |
| WESTERN_PASTRY | MOUSSE_CAKE | 慕斯蛋糕 |
| WESTERN_PASTRY | ICE_CREAM_CAKE | 冰淇淋蛋糕 |
| WESTERN_PASTRY | BIRTHDAY_CAKE | 生日蛋糕 |
| COARSE_GRAIN | OTHER_COARSE_GRAIN | 其他粗粮 |
| COARSE_GRAIN | BOILED_COARSE_GRAIN | 煮类粗粮 |
| COARSE_GRAIN | STEAMED_COARSE_GRAIN | 蒸类粗粮 |
| NOODLE | WONTON | 馄饨/云吞/抄手 |
| NOODLE | PIZZA | 披萨 |
| NOODLE | BURGER | 汉堡 |
| NOODLE | OTHER_NOODLE | 其他面类 |
| NOODLE | DUMPLING_POTSTICKER | 饺子/锅贴 |
| NOODLE | FRIED_DOUGH_STICK | 油条 |
| NOODLE | FLAT_BREAD_PIE | 饼/夹饼/卷饼/馅饼 |
| NOODLE | LIANGPI | 凉皮 |
| NOODLE | STEAMED_TWISTED_ROLL | 花卷 |
| NOODLE | NOODLES | 面条 |
| NOODLE | STEAMED_BUN | 包子 |
| NOODLE | STEAMED_BREAD | 馒头/馍 |
| RICE | GLUTINOUS_RICE_PRODUCT | 糯米制成品 |
| RICE | PORRIDGE | 粥类 |
| RICE | RICE_MEAL | 饭类 |
| RICE_NOODLE | VERMICELLI | 粉条/粉丝 |
| RICE_NOODLE | OTHER_RICE_NOODLE | 其他粉/米线类 |
| RICE_NOODLE | RICE_NOODLES | 米线/米粉 |
| RICE_NOODLE | LIANGFEN | 凉粉 |
| RICE_NOODLE | RICE_ROLL | 肠粉 |
| RICE_NOODLE | HO_FUN | 河粉 |
| RICE_NOODLE | LUOSIFEN | 螺蛳粉 |
| SPECIALTY_DISH | CRAYFISH | 小龙虾 |
| HOT_DISH | ROASTED | 烤类 |
| HOT_DISH | PAN_FRIED | 煎类 |
| HOT_DISH | STEWED_BOILED | 炖菜/水煮类 |
| HOT_DISH | DEEP_FRIED | 油炸类 |
| HOT_DISH | BRAISED_DISH | 烩菜 |
| HOT_DISH | QUICK_FRIED | 熘类 |
| HOT_DISH | QUICK_BOILED | 汆类 |
| HOT_DISH | CLAY_POT | 砂锅类 |
| HOT_DISH | STEAMED | 蒸类 |
| HOT_DISH | GRILLED | 扒类 |
| HOT_DISH | BRAISED_STIR_FRIED | 烧类/炒菜/焖菜 |
| HOT_DISH | CARAMELIZED | 拔丝类 |
| HOT_DISH | OTHER_HOT_DISH | 其他类热菜 |
| HOT_DISH | DRY_POT | 干锅类 |
| HOT_DISH | BAKED | 焗类 |
| HOT_DISH | TEPPANYAKI | 铁板类 |
| COLD_DISH | OTHER_COLD_DISH | 其他类凉菜 |
| COLD_DISH | PICKLED_COLD_DISH | 腌类凉菜 |
| COLD_DISH | MIXED_COLD_DISH | 拌凉菜 |
| COLD_DISH | SALAD_LIGHT_MEAL | 沙拉轻食 |
| COLD_DISH | FROZEN_COLD_DISH | 冻类凉菜 |
| COLD_DISH | SMOKED_COLD_DISH | 熏类凉菜 |
| COLD_DISH | BRAISED_COLD_DISH | 卤类凉菜 |
| COLD_DISH | SASHIMI | 刺身 |
| HOT_POT_SKEWER | MALATANG_COMBO | 麻辣烫组合 |
| HOT_POT_SKEWER | OTHER_MIXED_DISH_COMBO | 其他混合菜肴组合 |
| HOT_POT_SKEWER | XIANGGUO_COMBO | 香锅组合 |
| HOT_POT_SKEWER | SKEWER_MALATANG | 串串/麻辣烫 |
| HOT_POT_SKEWER | CHUANCHUANXIANG_COMBO | 串串香组合 |
| HOT_POT_SKEWER | HOT_POT | 火锅 |
| HOT_POT_SKEWER | MAOCAI_XIANGGUO | 冒菜/香锅 |
| HOT_POT_SKEWER | HOT_POT_BASE | 火锅锅底 |
| HOT_POT_SKEWER | MAOCAI_COMBO | 冒菜组合 |
| HOT_POT_SKEWER | XIANGGUO_BASE | 香锅锅底 |
| HOT_POT_SKEWER | READY_HOT_POT | 成品火锅 |
| GRILLED_FRIED_BOILED_SKEWER | GRILLED_FRIED_BOILED_VEG_SKEWER | 烤/炸/煮蔬菜串 |
| GRILLED_FRIED_BOILED_SKEWER | FRIED_CHICKEN | 炸鸡 |
| GRILLED_FRIED_BOILED_SKEWER | GRILLED_FRIED_BOILED_MEAT_SKEWER | 烤/炸/煮肉串 |
| GRILLED_FRIED_BOILED_SKEWER | FRENCH_FRIES | 炸薯条 |
| GRILLED_FRIED_BOILED_SKEWER | GRILLED_FRIED_BOILED_SEAFOOD_SKEWER | 烤/炸/煮海鲜串 |
| GRILLED_FRIED_BOILED_SKEWER | GRILLED_FRIED_BOILED_STAPLE | 烤/炸/煮类主食 |
| GRILLED_FRIED_BOILED_SKEWER | GRILLED_FRIED_BOILED_AQUATIC_SKEWER | 烤/炸/煮水产制品串 |
| GRILLED_FRIED_BOILED_SKEWER | OTHER_GRILLED_FRIED_BOILED_SKEWER | 其他烤/炸/煮串 |
| SOUP | SPICY_SOUP | 胡辣汤 |
| SOUP | SEAFOOD_SOUP | 海鲜汤 |
| SOUP | OTHER_SOUP | 其他汤 |
| SOUP | MEAT_SOUP | 肉汤 |
| SOUP | EGG_DROP_SOUP | 蛋花汤 |
| SOUP | BONE_SOUP | 骨头汤 |
| SOUP | VEGETABLE_SOUP | 蔬菜汤 |
| SOUP | DUMPLING_SOUP | 疙瘩汤 |
| SOUP | SAUCE_SOUP | 酱汤 |
| SOUP | HOT_SOUR_SOUP | 酸辣汤 |
| THICK_SOUP | TOFU_BRAIN | 豆腐脑/咸豆花 |
| THICK_SOUP | VEGETABLE_THICK_SOUP | 蔬菜羹 |
| THICK_SOUP | SEAFOOD_THICK_SOUP | 海鲜羹 |
| THICK_SOUP | EGG_CUSTARD | 蛋羹 |
| THICK_SOUP | MEAT_THICK_SOUP | 肉羹 |
| THICK_SOUP | OTHER_THICK_SOUP | 其他羹 |
| PACKAGED_BEVERAGE | TEA_DRINK | 茶饮 |
| PACKAGED_BEVERAGE | CARBONATED_DRINK | 碳酸饮料 |
| PACKAGED_BEVERAGE | FRUIT_VEGETABLE_JUICE | 果蔬汁 |
| PACKAGED_BEVERAGE | DAIRY_SOY_DRINK | 乳/豆制品饮料 |
| PACKAGED_BEVERAGE | OTHER_RETAIL_DRINK | 其他零售饮料 |
| PACKAGED_BEVERAGE | DRINKING_WATER | 饮用水 |
| FRESH_BEVERAGE | FRESH_TEA | 现制纯茶类 |
| FRESH_BEVERAGE | FRESH_FRUIT_VEGETABLE_JUICE | 现制果蔬汁 |
| FRESH_BEVERAGE | FRESH_MILK_TEA | 现制奶茶类 |
| FRESH_BEVERAGE | FRESH_SOY_MILK | 现制豆乳制品 |
| FRESH_BEVERAGE | FRESH_COFFEE | 现制咖啡 |




### 油品类型标准值
| standard_code（标准值） | standard_code_desc（标准值描述） |
| --- | --- |
| FUEL_DSL_0 | 0#柴油 |
| FUEL_DSL_N10 | -10#柴油 |
| FUEL_DSL_N20 | -20#柴油 |
| FUEL_DSL_N35 | -35#柴油 |
| FUEL_DSL_N50 | -50#柴油 |
| FUEL_LNG | 液化天然气（LNG） |
| FUEL_CNG | 压缩天然气（CNG） |
| FUEL_LPG | 液化石油气（LPG） |
| FUEL_GAS_92 | 92#汽油 |
| FUEL_GAS_95 | 95#汽油 |
| FUEL_GAS_98 | 98#汽油 |


### 币种列表
| 币种code | 币种名称 |
| --- | --- |
| CNY | 人民币 |
| GBP | 英镑 |
| HKD | 港元 |
| USD | 美元 |
| SGD | 新加坡元 |
| JPY | 日元 |
| CAD | 加拿大元 |
| AUD | 澳大利亚元 |
| EUR | 欧元 |
| NZD | 新西兰元 |
| KRW | 韩圆 |
| THB | 泰铢 |
| CHF | 瑞士法郎 |
| SEK | 瑞典克朗 |
| DKK | 丹麦克朗 |
| NOK | 挪威克朗 |
| MYR | 马来西亚林吉特 |
| IDR | 印度尼西亚盾 |
| PHP | 菲律宾比索 |
| MUR | 毛里求斯卢比 |
| ILS | 以色列新谢克尔 |
| LKR | 斯里兰卡卢比 |
| RUB | 俄国卢布 |
| AED | 阿联酋迪拉姆 |
| CZK | 捷克克郎 |
| ZAR | 南非兰特 |
| QAR | 卡塔尔里亚尔 |




### 国家编码
| 国家编码 | 国家名称 |
| --- | --- |
| 050 | 孟加拉国 |
| 392 | 日本 |
| 096 | 文莱 |
| 196 | 塞浦路斯 |
| 792 | 土耳其 |
| 496 | 蒙古 |
| 376 | 以色列 |
| 398 | 哈萨克斯坦 |
| 410 | 韩国 |
| 795 | 土库曼斯坦 |
| 356 | 印度 |
| 116 | 柬埔寨 |
| 512 | 阿曼 |
| 414 | 科威特 |
| 458 | 马来西亚 |
| 634 | 卡塔尔 |
| 417 | 吉尔吉斯斯坦 |
| 418 | 老挝 |
| 360 | 印度尼西亚 |
| 064 | 不丹 |
| 462 | 马尔代夫 |
| 682 | 沙特阿拉伯 |
| 364 | 伊朗 |
| 144 | 斯里兰卡 |
| 760 | 叙利亚 |
| 860 | 乌兹别克斯坦 |
| 784 | 阿联酋 |
| 586 | 巴基斯坦 |
| 762 | 塔吉克斯坦 |
| 004 | 阿富汗 |
| 048 | 巴林 |
| 400 | 约旦 |
| 422 | 黎巴嫩 |
| 368 | 伊拉克 |
| 104 | 缅甸 |
| 764 | 泰国 |
| 524 | 尼泊尔 |
| 887 | 也门 |
| 702 | 新加坡 |
| 626 | 东帝汶 |
| 704 | 越南 |
| 408 | 朝鲜 |
| 608 | 菲律宾 |
| 090 | 所罗门群岛 |
| 184 | 库克群岛 |
| 580 | 北马里亚纳 |
| 242 | 斐济 |
| 583 | 密克罗尼西亚联邦 |
| 584 | 马绍尔群岛 |
| 585 | 帕劳 |
| 882 | 萨摩亚 |
| 036 | 澳大利亚 |
| 554 | 新西兰 |
| 598 | 巴布亚新几内亚 |
| 258 | 法属波利尼西亚 |
| 776 | 汤加 |
| 798 | 图瓦卢 |
| 548 | 瓦努阿图 |
| 191 | 克罗地亚 |
| 250 | 法国 |
| 492 | 摩纳哥 |
| 470 | 马耳他 |
| 372 | 爱尔兰 |
| 352 | 冰岛 |
| 056 | 比利时 |
| 276 | 德国 |
| 233 | 爱沙尼亚 |
| 752 | 瑞典 |
| 578 | 挪威 |
| 756 | 瑞士 |
| 616 | 波兰 |
| 380 | 意大利 |
| 040 | 奥地利 |
| 440 | 立陶宛 |
| 100 | 保加利亚 |
| 442 | 卢森堡 |
| 300 | 希腊 |
| 246 | 芬兰 |
| 620 | 葡萄牙 |
| 642 | 罗马尼亚 |
| 203 | 捷克 |
| 643 | 俄罗斯 |
| 688 | 塞尔维亚 |
| 348 | 匈牙利 |
| 724 | 西班牙 |
| 208 | 丹麦 |
| 428 | 拉脱维亚 |
| 703 | 斯洛伐克 |
| 528 | 荷兰 |
| 826 | 英国 |
| 705 | 斯洛文尼亚 |
| 804 | 乌克兰 |
| 192 | 古巴 |
| 084 | 伯利兹 |
| 052 | 巴巴多斯 |
| 591 | 巴拿马 |
| 340 | 洪都拉斯 |
| 780 | 特立尼达和多巴哥 |
| 670 | 圣文森特和格林纳丁斯 |
| 044 | 巴哈马 |
| 484 | 墨西哥 |
| 188 | 哥斯达黎加 |
| 320 | 危地马拉 |
| 332 | 海地 |
| 662 | 圣卢西亚 |
| 222 | 萨尔瓦多 |
| 124 | 加拿大 |
| 212 | 多米尼克 |
| 388 | 牙买加 |
| 840 | 美国 |
| 028 | 安提瓜和巴布达 |
| 558 | 尼加拉瓜 |
| 659 | 圣基茨和尼维斯 |
| 308 | 格林纳达 |
| 068 | 玻利维亚 |
| 740 | 苏里南 |
| 862 | 委内瑞拉 |
| 600 | 巴拉圭 |
| 218 | 厄瓜多尔 |
| 328 | 圭亚那 |
| 170 | 哥伦比亚 |
| 604 | 秘鲁 |
| 858 | 乌拉圭 |
| 032 | 阿根廷 |
| 076 | 巴西 |
| 072 | 博茨瓦纳 |
| 270 | 冈比亚 |
| 690 | 塞舌尔 |
| 174 | 科摩罗 |
| 450 | 马达加斯加 |
| 132 | 佛得角 |
| 231 | 埃塞俄比亚 |
| 012 | 阿尔及利亚 |
| 232 | 厄立特里亚 |
| 430 | 利比里亚 |
| 178 | 刚果 |
| 454 | 马拉维 |
| 434 | 利比亚 |
| 478 | 毛里塔尼亚 |
| 710 | 南非 |
| 854 | 布基纳法索 |
| 638 | 留尼汪（法） |
| 716 | 津巴布韦 |
| 818 | 埃及 |
| 180 | 刚果民主共和国 |
| 480 | 毛里求斯 |
| 262 | 吉布提 |
| 384 | 科特迪瓦 |
| 120 | 喀麦隆 |
| 024 | 安哥拉 |
| 266 | 加蓬 |
| 288 | 加纳 |
| 466 | 马里 |
| 324 | 几内亚 |
| 204 | 贝宁 |
| 226 | 赤道几内亚 |
| 624 | 几内亚比绍 |
| 404 | 肯尼亚 |
| 426 | 莱索托 |
| 646 | 卢旺达 |
| 108 | 布隆迪 |
| 768 | 多哥 |
