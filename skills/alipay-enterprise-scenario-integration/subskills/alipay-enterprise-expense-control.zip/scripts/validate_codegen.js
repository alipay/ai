#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const os = require("os");
const { spawnSync } = require("child_process");

let runGuarded;
let extractStringConstants;
let resolveStringArg;
let valueExpressionPattern;
let valueTokens;
let validateIntegrationContract;
let javaProjectGates;
let createInterfaceDocs;
try {
  ({ runGuarded } = require("./lib/validator-runtime"));
  ({ extractStringConstants, resolveStringArg, valueExpressionPattern, valueTokens } = require("./lib/value-resolver"));
  ({ validateIntegrationContract } = require("./lib/integration-contract"));
  javaProjectGates = require("./lib/java-project-gates");
  ({ createInterfaceDocs } = require("./lib/interface-docs"));
} catch (err) {
  console.error(`[alipay-enterprise-expense-control] BROKEN failed to load validator support: ${err && err.stack ? err.stack : err}`);
  process.exit(2);
}

const skillDir = path.resolve(__dirname, "..");
const targetDir = path.resolve(process.argv[2] || ".");
const ALIPAY_SDK_VERSION_PATTERN = /^[0-9]+\.[0-9]+\.[0-9]+\.ALL$/;
const interfaceDocs = createInterfaceDocs(skillDir);

/**
 * 企业码费控代码生成校验器。
 *
 * 重点防止三类高风险问题：
 * 1. 制度字段和嵌套结构按业务含义猜测，而不是来自接口文档。
 * 2. 内部费控制度没有额度/发放来源，或外部费控 SPI 只是固定成功的占位实现。
 * 3. 业务枚举只认内联字符串，导致正常的 Constants.VALUE 写法被误报。
 *
 * main() 负责语言分流，各语言分支完成本域检查后由 report() 统一汇总。
 */

// 顶层制度 Model 与嵌套规则 DTO 分别绑定官方接口，用于从实时 Markdown 推导 setter。
const modelDocs = {
  AlipayEbppInvoiceInstitutionCreateModel: "alipay.ebpp.invoice.institution.create",
  AlipayEbppInvoiceInstitutionModifyModel: "alipay.ebpp.invoice.institution.modify",
  AlipayEbppInvoiceInstitutionDeleteModel: "alipay.ebpp.invoice.institution.delete",
  AlipayEbppInvoiceInstitutionDetailinfoQueryModel: "alipay.ebpp.invoice.institution.detailinfo.query",
  AlipayEbppInvoiceInstitutionPageinfoQueryModel: "alipay.ebpp.invoice.institution.pageinfo.query",
  AlipayEbppInvoiceInstitutionScopepageinfoQueryModel: "alipay.ebpp.invoice.institution.scopepageinfo.query",
};

const nestedDocs = {
  StandardInfo: ["alipay.ebpp.invoice.institution.create", "standard_info_list"],
  StandardConditionInfo: ["alipay.ebpp.invoice.institution.create", "standard_info_list.standard_condition_info_list"],
  InstitutionScopeInfo: ["alipay.ebpp.invoice.institution.create", "institution_scope_info"],
  IssueRuleInfo: ["alipay.ebpp.invoice.institution.create", "issue_rule_info_list"],
  ModifyScopeInfo: ["alipay.ebpp.invoice.institution.modify", "modify_scope_info"],
  ModifyStandardDetailInfo: ["alipay.ebpp.invoice.institution.modify", "modify_standard_detail_info"],
  ModifyIssueRuleDetailInfo: ["alipay.ebpp.invoice.institution.modify", "modify_issue_rule_detail_info"],
};

const requiredTokens = [
  "AlipayEbppInvoiceInstitutionCreateRequest",
  "AlipayEbppInvoiceInstitutionModifyRequest",
  "AlipayEbppInvoiceInstitutionDeleteRequest",
  "AlipayEbppInvoiceInstitutionDetailinfoQueryRequest",
  "AlipayEbppInvoiceInstitutionPageinfoQueryRequest",
  "AlipayEbppInvoiceInstitutionScopepageinfoQueryRequest",
];

const nodeRequiredTokens = [
  "alipay.ebpp.invoice.institution.create",
  "alipay.ebpp.invoice.institution.modify",
  "alipay.ebpp.invoice.institution.delete",
  "alipay.ebpp.invoice.institution.detailinfo.query",
  "alipay.ebpp.invoice.institution.pageinfo.query",
  "alipay.ebpp.invoice.institution.scopepageinfo.query",
];

runGuarded("alipay-enterprise-expense-control", main);

function main() {
  const errors = [];
  const warnings = [];
  if (!fs.existsSync(targetDir)) fail(`target directory not found: ${targetDir}`);
  validateIntegrationContract(targetDir, ["expense-control"], errors);
  checkSharedScenarioRules(errors);

  const javaFiles = walk(targetDir).filter((f) => f.endsWith(".java"));
  const nodeProject = isNodeProject(targetDir);

  // Java、Node.js 和其他语言使用不同的可靠校验面。
  if (javaFiles.length === 0 && nodeProject) {
    checkNodeProject("alipay-enterprise-expense-control", nodeRequiredTokens, errors, warnings);
    report("alipay-enterprise-expense-control", errors, warnings);
    return;
  }
  if (javaFiles.length === 0) {
    checkCrossLanguageExpenseProject(errors, warnings);
    report("alipay-enterprise-expense-control", errors, warnings);
    return;
  }

  const domainFiles = javaFiles.filter(isExpenseFile);
  const allText = domainFiles.map((f) => fs.readFileSync(f, "utf8")).join("\n");
  const allCode = stripJavaComments(allText);
  const projectText = javaFiles.map((f) => fs.readFileSync(f, "utf8")).join("\n");
  checkJavaMavenSdkLatest(errors);
  checkSdkStubs(javaFiles, errors);
  checkSdkReflectionBypass(domainFiles, errors);
  checkUnsafeStubs(domainFiles, errors);
  checkFailOpenBusinessPlaceholders(domainFiles, errors);
  checkJavaRequiredNumericParsing(domainFiles, errors);
  checkJavaSpiResponseSigningPolicy(domainFiles, errors);
  checkJavaExternalSpiProtocolFieldNames(domainFiles, errors);
  checkJavaExternalSpiStatePersistence(domainFiles, projectText, errors);
  javaProjectGates.checkJavaProductionStateStores(domainFiles, errors, rel);
  javaProjectGates.checkJavaStateTransitionPersistence(domainFiles, errors, rel);
  if (process.env.ALIPAY_VALIDATE_AGGREGATE !== "1") {
    checkJavaMessageClientStartupFailure(javaFiles, errors);
    javaProjectGates.checkJavaAlipayMsgClientContracts(javaFiles, errors, rel);
    javaProjectGates.checkSpringProfileWiring(targetDir, javaFiles, errors, rel);
    javaProjectGates.checkJavaProfiledCoreComponents(domainFiles, errors, rel);
    javaProjectGates.checkJavaConcreteDemoDependency(javaFiles, errors, rel);
    javaProjectGates.checkJavaFailClosedDefaultBackoff(javaFiles, errors, rel);
    javaProjectGates.checkSpringBeanMethodBypass(javaFiles, errors, rel);
    javaProjectGates.checkJavaTestEvidence(targetDir, javaFiles, errors);
  }
  checkSdkModelUsage(allText, modelDocs, errors);
  checkRawBizContent(allText, errors);
  checkCoverage(allCode, requiredTokens, errors);
  checkPackagePaths(javaFiles, errors);
  checkSetters(domainFiles, errors);
  checkImmutableModifyConditionFields(domainFiles, errors);
  checkUnusedSdkMethodParams(domainFiles, errors);
  checkExpenseFabricatedFields(allText, errors);
  checkExpenseTypeSubtypeConsistency(allText, projectText, errors);
  checkInstitutionFundingOrQuotaGuard(allText, projectText, errors);
  checkInstitutionModifyDepth(allText, warnings);
  if (hasManualWhitelistComment(allText)) errors.push("code comments must not hand-write field whitelist notes; use 字段来源：接口文档业务请求参数表");
  report("alipay-enterprise-expense-control", errors, warnings);
}

// These rules are independent of implementation language. They run before
// language-specific branches so standalone expense-control integration and
// aggregate scenario integration enforce the same business facts.
function checkSharedScenarioRules(errors) {
  const files = walk(targetDir).filter((file) =>
    /\.(?:java|js|cjs|mjs|ts|py|go|cs|php|rb)$/i.test(file)
    && !/(^|\/)(?:test|tests|__tests__|docs?)\//i.test(rel(file).split(path.sep).join("/")));
  const texts = files.map((file) => stripSourceComments(fs.readFileSync(file, "utf8"), file));
  const allText = texts.join("\n");
  const institutionText = texts.filter(hasInstitutionScenarioContext).join("\n");
  if (!institutionText) return;

  const isTicket = hasFieldValue(institutionText, allText,
    ["expense_type", "expenseType", "ExpenseType"], ["setExpenseType"], "TICKET")
    && hasFieldValue(institutionText, allText,
      ["expense_type_sub_category", "expenseTypeSubCategory", "ExpenseTypeSubCategory"],
      ["setExpenseTypeSubCategory"], "TICKET");
  if (isTicket && !hasMerchantPidBinding(institutionText, allText)) {
    errors.push("TICKET/TICKET institution rules must bind MERCHANT to 12306 merchant pid 2088011519249952");
  }

  const scenario = readOptionalScenario();
  if (scenario && scenario.schemaVersion === 2 && scenario.status === "CONFIRMED") {
    checkScenarioSourceIdentifier(institutionText, allText, errors);
  }
  if (scenario && isTaotianPlatformScenario(scenario)
      && scenario.businessPriority && scenario.businessPriority.enabled) {
    errors.push("ALI_PLATFORM_TYPE=TAOTIAN/1688 scenarios do not support business priority; set businessPriority.enabled=false");
  }
  if (scenario && scenario.businessPriority && scenario.businessPriority.enabled) {
    checkBusinessPriorityRules(scenario, institutionText, allText, errors);
  }
}

function checkScenarioSourceIdentifier(institutionText, allText, errors) {
  const markerEvidence = sourceWindows(allText, /ECS_/g, 1400).join("\n");
  const hasPrefix = /["']ECS_["']/.test(markerEvidence);
  const hasSha256 = /SHA-?256|sha256/i.test(markerEvidence);
  const hasHexEncoding = /hexdigest|digest\s*\(\s*["']hex["']|hash\s*\(\s*["']sha256["']|HexFormat|toHexString|encodeHexString|EncodeToString|bytesToHex|\.hex\s*\(|%0?2?x/i.test(markerEvidence);
  const hasDigestTruncation = /\[\s*:\s*60\s*\]|(?:substring|slice|substr)\s*\(\s*0\s*,\s*60\s*\)|\.take\s*\(\s*60\s*\)/i.test(markerEvidence);
  const hasInputs = /app_?id|appId/i.test(markerEvidence)
    && /enterprise_?id|enterpriseId/i.test(markerEvidence)
    && /(?:provider|original|source|outer)[\w\s]{0,40}institution[\w\s]{0,20}id|institution[\w\s]{0,40}(?:provider|original|source|outer)[\w\s]{0,20}id/i.test(markerEvidence);
  const hasNullSeparator = /\\0|\\u0000|\u0000/.test(markerEvidence);
  const hasTopLevelAssignment = /setOuterSourceId\s*\(\s*[^;\n]*(?:ecs|skill|source|outerSourceId)/i.test(institutionText)
    || hasTopLevelHttpSourceIdentifier(institutionText)
    || /(?:put|set)\s*\(\s*["']outer_source_id["']\s*,\s*[^;)\n]*(?:ecs|skill|source)/i.test(institutionText);

  if (!hasTopLevelAssignment) {
    errors.push("scenario-generated institution create must assign the integration source identifier to top-level outer_source_id; nested standard/issue rule outer_source_id does not count");
  }
  if (!hasPrefix || !hasSha256 || !hasHexEncoding || !hasDigestTruncation || !hasInputs || !hasNullSeparator) {
    errors.push("scenario integration source identifier must use the documented deterministic 64-character format");
  }
  if (/ECS_V\d+_/i.test(markerEvidence)) {
    errors.push("integration source identifier prefix must not contain a Skill version segment");
  }
  if (/(?:UUID|randomUUID|Math\.random|SecureRandom|currentTimeMillis|nanoTime|Date\.now|time\.time)\s*\(/i.test(markerEvidence)) {
    errors.push("integration source identifier must be stable across retries; UUID, random values, and timestamps are not allowed");
  }
}

function hasTopLevelHttpSourceIdentifier(text) {
  const endpoint = /alipay\.ebpp\.invoice\.institution\.create/gi;
  for (const match of text.matchAll(endpoint)) {
    const requestTail = text.slice(match.index, match.index + 2200);
    const nestedIndex = requestTail.search(/["'](?:standard_info_list|issue_rule_info_list)["']/i);
    const topLevelPrefix = nestedIndex >= 0 ? requestTail.slice(0, nestedIndex) : requestTail;
    if (/["']outer_source_id["']\s*:\s*[^,\n]*(?:build[_A-Za-z]*ecs|ecs[_A-Za-z]*outer|skill[_A-Za-z]*source|institution[_A-Za-z]*source[_A-Za-z]*id)/i.test(topLevelPrefix)) {
      return true;
    }
  }
  return false;
}

function sourceWindows(text, pattern, radius) {
  const windows = [];
  for (const match of text.matchAll(pattern)) {
    windows.push(text.slice(Math.max(0, match.index - radius), match.index + match[0].length + radius));
  }
  return windows;
}

function isTaotianPlatformScenario(scenario) {
  const values = scenario && scenario.ruleFactorValues
    ? scenario.ruleFactorValues.ALI_PLATFORM_TYPE
    : null;
  const flattened = Array.isArray(values) ? values : [values];
  return flattened.some((value) => value === "TAOTIAN" || value === "1688");
}

function readOptionalScenario() {
  const file = path.join(targetDir, ".alipay-skill", "scenario.json");
  if (!fs.existsSync(file)) return null;
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch (_) {
    return null; // The aggregate validator reports malformed scenario.json.
  }
}

function stripSourceComments(text, file) {
  if (/\.(?:py|rb)$/i.test(file)) return text.replace(/^\s*#.*$/gm, "");
  return text.replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");
}

function hasInstitutionScenarioContext(text) {
  return /alipay\.ebpp\.invoice\.institution\.(?:create|modify)|AlipayEbppInvoiceInstitution(?:Create|Modify)|institution[_ .](?:create|modify)|standard_info_list|standardInfoList|setExpenseType|setExpenseTypeSubCategory|setSceneType|setRuleFactor/i.test(text);
}

function hasFieldValue(scopeText, allText, fieldNames, setterNames, value) {
  for (const token of valueTokens(allText, value)) {
    const expression = token === value
      ? `\\\\*["']${escapeRegExp(value)}\\\\*["']`
      : `(?:(?:\\b[A-Za-z_][A-Za-z0-9_]*\\s*(?:\\.|::)\\s*)?\\b${escapeRegExp(token)}\\b)`;
    for (const setter of setterNames) {
      if (new RegExp(`\\b${escapeRegExp(setter)}\\s*\\(\\s*${expression}`).test(scopeText)) return true;
    }
    for (const field of fieldNames) {
      if (new RegExp(`(?:["']${escapeRegExp(field)}["']|\\b${escapeRegExp(field)}\\b)\\s*(?:=>|:|=)\\s*${expression}`).test(scopeText)) return true;
    }
  }
  return false;
}

function hasMerchantPidBinding(scopeText, allText) {
  if (!hasFieldValue(scopeText, allText, ["rule_factor", "ruleFactor", "RuleFactor"], ["setRuleFactor"], "MERCHANT")) return false;
  return hasNearbyResolvedValue(scopeText, allText, "MERCHANT", "2088011519249952", 1200);
}

function hasNearbyResolvedValue(scopeText, allText, leftValue, rightValue, maxDistance) {
  for (const left of valueTokens(allText, leftValue)) {
    for (const right of valueTokens(allText, rightValue)) {
      const leftPattern = tokenUsagePattern(left, leftValue);
      const rightPattern = tokenUsagePattern(right, rightValue);
      if (new RegExp(`${leftPattern}[\\s\\S]{0,${maxDistance}}${rightPattern}`).test(scopeText)
          || new RegExp(`${rightPattern}[\\s\\S]{0,${maxDistance}}${leftPattern}`).test(scopeText)) return true;
    }
  }
  return false;
}

function tokenUsagePattern(token, literal) {
  if (token === literal) return `\\\\*["']${escapeRegExp(literal)}\\\\*["']`;
  return `(?:(?:\\b[A-Za-z_][A-Za-z0-9_]*\\s*(?:\\.|::)\\s*)?\\b${escapeRegExp(token)}\\b)`;
}

function checkBusinessPriorityRules(scenario, scopeText, allText, errors) {
  if (!hasFieldValue(scopeText, allText, ["rule_factor", "ruleFactor", "RuleFactor"], ["setRuleFactor"], "ALARM_CLOCK_TIME")) {
    errors.push("business priority requires ALARM_CLOCK_TIME in the institution rule structure");
  }
  const allowed = ["MEAL_MERCHANT", "MERCHANT", "COMPOSITE_MERCHANT", "SHOP_GROUP", "SHOP", "RECEIPT_IDENTITY_WHITE_LIST"];
  const selected = scenario.businessPriority.merchantRestrictionFactors;
  const implemented = Array.isArray(selected) && selected.filter((factor) =>
    allowed.includes(factor)
    && hasFieldValue(scopeText, allText, ["rule_factor", "ruleFactor", "RuleFactor"], ["setRuleFactor"], factor));
  if (!implemented || implemented.length === 0) {
    errors.push("business priority requires at least one implemented merchant restriction factor");
    return;
  }
  if (implemented.includes("COMPOSITE_MERCHANT")) {
    const capability = scenario.ruleFactorCapabilities && scenario.ruleFactorCapabilities.COMPOSITE_MERCHANT;
    if (capability && capability.valueSource === "ENTERPRISE_INPUT") {
      const hasDocumentedFields = ["receiptIdentityWhiteList", "shopIdList", "shopGroupIdList"]
        .every((key) => allText.includes(key));
      const hasFailClosedValidation = /COMPOSITE_MERCHANT[\s\S]{0,1800}(?:validate|check|nonEmpty|isEmpty|throw|raise)|(?:validate|check|nonEmpty|isEmpty|throw|raise)[\s\S]{0,1800}COMPOSITE_MERCHANT/i.test(allText);
      if (!hasDocumentedFields || !hasFailClosedValidation) {
        errors.push("runtime COMPOSITE_MERCHANT configuration must validate that receiptIdentityWhiteList, shopIdList, or shopGroupIdList has at least one non-empty list");
      }
    } else {
      const value = scenario.ruleFactorValues && scenario.ruleFactorValues.COMPOSITE_MERCHANT;
      const valid = value && ["receiptIdentityWhiteList", "shopIdList", "shopGroupIdList"]
        .some((key) => Array.isArray(value[key]) && value[key].length > 0);
      if (!valid) errors.push("COMPOSITE_MERCHANT counts for business priority only with a non-empty receiptIdentityWhiteList, shopIdList, or shopGroupIdList");
    }
  }
  const platformCapability = scenario.ruleFactorCapabilities && scenario.ruleFactorCapabilities.ALI_PLATFORM_TYPE;
  if (platformCapability && platformCapability.valueSource === "ENTERPRISE_INPUT") {
    const rejectsUnsupportedCombination = /TAOTIAN/.test(allText)
      && /1688/.test(allText)
      && /(?:businessPriority|business_priority|因公优先)/i.test(allText)
      && /(?:throw|raise|reject|invalid|not\s+support|不支持)/i.test(allText);
    if (!rejectsUnsupportedCombination) {
      errors.push("runtime ALI_PLATFORM_TYPE configuration must reject TAOTIAN/1688 combined with business priority before institution submission");
    }
  }
}

// -----------------------------------------------------------------------------
// Node.js：制度字段、费控模式、额度来源、SDK 调用和工程执行检查。
// -----------------------------------------------------------------------------

function isNodeProject(dir) {
  const files = walk(dir);
  return files.some((f) => path.basename(f) === "package.json")
    && files.some((f) => /\.(?:js|cjs|mjs|ts)$/i.test(f));
}

function checkNodeProject(name, requiredTokens, errors, warnings) {
  const packageFile = findFile(targetDir, "package.json");
  if (!packageFile) {
    errors.push("Node.js project must contain package.json");
    return;
  }

  let pkg = {};
  try {
    pkg = JSON.parse(fs.readFileSync(packageFile, "utf8"));
  } catch (err) {
    errors.push(`package.json is not valid JSON: ${err.message}`);
    return;
  }

  const jsFiles = walk(targetDir).filter((f) => /\.(?:js|cjs|mjs)$/i.test(f) && isNodeExpenseFile(f));
  const implementationFiles = jsFiles.filter(isNodeImplementationFile);
  const sourceText = jsFiles.map((f) => fs.readFileSync(f, "utf8")).join("\n");
  const sourceCode = stripJsComments(sourceText);
  const implementationText = implementationFiles.map((f) => fs.readFileSync(f, "utf8")).join("\n");
  const implementationCode = stripJsComments(implementationText);

  checkNodeAlipaySdkUsage(pkg, packageFile, sourceCode, errors);
  checkNodeExecAppAuthTokenPlacement(sourceCode, errors);
  checkNodeCoverage(implementationCode, requiredTokens, errors);
  checkNodeInternalExpenseControl(implementationCode, errors);
  checkNodeExpenseFieldRules(implementationCode, errors);
  checkNodeFailOpenBusinessPlaceholders(sourceText, errors);
  checkNodeUnsafeStubs(sourceCode, errors);
  checkNodeSyntax(jsFiles, errors);
  checkNodeModuleLoading(jsFiles, errors);
  checkNodeTests(pkg, path.dirname(packageFile), errors, warnings);
}

function checkNodeAlipaySdkUsage(pkg, packageFile, text, errors) {
  if (!/alipay-sdk/.test(text)) return;
  const deps = Object.assign({}, pkg.dependencies || {}, pkg.devDependencies || {});
  if (!deps["alipay-sdk"]) errors.push("Node.js code uses alipay-sdk but package.json does not declare alipay-sdk");
  if (/require\s*\(\s*["']alipay-sdk["']\s*\)\s*\.default\b/.test(text)) {
    errors.push("Node.js CommonJS code imports alipay-sdk via .default; use `const { AlipaySdk } = require(\"alipay-sdk\")` after verifying the installed SDK export");
  }
  try {
    const sdkPath = require.resolve("alipay-sdk", { paths: [path.dirname(packageFile)] });
    const sdk = require(sdkPath);
    if (typeof sdk.AlipaySdk !== "function") errors.push("installed alipay-sdk does not export AlipaySdk as a constructor");
  } catch (err) {
    if (fs.existsSync(path.join(path.dirname(packageFile), "node_modules"))) {
      errors.push(`failed to load installed alipay-sdk: ${err.message}`);
    }
  }
}

function checkNodeExecAppAuthTokenPlacement(text, errors) {
  if (/\.exec\s*\(\s*[^,]+,\s*\{\s*bizContent[\s\S]{0,300}?\}\s*,\s*\{[\s\S]{0,160}?appAuthToken\s*:/g.test(text)) {
    errors.push("Node.js alipay-sdk exec(...) passes appAuthToken in the third options argument; for OpenAPI 2.0 put it in the second argument with bizContent");
  }
}

function checkNodeCoverage(text, tokens, errors) {
  for (const token of tokens) {
    if (!text.includes(token)) errors.push(`missing required Node.js interface token: ${token}`);
  }
}

function checkNodeInternalExpenseControl(text, errors) {
  const hasInstitutionCreate = /alipay\.ebpp\.invoice\.institution\.create/.test(text);
  if (!hasInstitutionCreate) return;

  const constants = extractStringConstants(text);
  const consultModes = extractCrossLanguageFieldValues(text, ["consult_mode", "consultMode"], constants);
  const ruleFactors = extractCrossLanguageFieldValues(text, ["rule_factor", "ruleFactor"], constants);

  if (!hasExplicitConsultMode(text, consultModes)) {
    errors.push("Node.js institution.create must set consult_mode explicitly for the selected fee-control mode; internal fee-control uses consult_mode='0' and external fee-control uses consult_mode='1'");
  }
  if (hasHardcodedBusinessPolicyValue(text)) {
    errors.push("Node.js internal expense-control code must not silently hardcode business policy values such as quota, amount, threshold, ratio, or time-window limits; require caller input, explicit configuration, confirmed plan values, issue_rule_info_list, or manual issuance");
  }
  if (!hasInternalConsultMode(text, consultModes)) return;

  const quotaLimitFactors = new Set(["QUOTA_DAY", "QUOTA_WEEK", "QUOTA_MONTH", "QUOTA_SEASON", "QUOTA_YEAR", "QUOTA_TOTAL"]);
  const hasQuotaLimitFactor = ruleFactors.some((factor) => quotaLimitFactors.has(factor));
  const hasManualIssueApi = /alipay\.ebpp\.invoice\.expensecontrol\.quota\.create/.test(text);
  const hasIssueRule = /\bissue_rule_info_list\s*:/.test(text);
  const hasIssueRuleGuard = /issueRuleInfoList[\s\S]{0,260}(?:throw\s+new\s+Error|throw\s+Error|throw\b)|(?:throw\s+new\s+Error|throw\s+Error|throw\b)[\s\S]{0,260}issueRuleInfoList|issue_rule_info_list[\s\S]{0,260}(?:throw\s+new\s+Error|throw\s+Error|throw\b)/.test(text);
  if (!hasIssueRule && !hasQuotaLimitFactor && !hasManualIssueApi && !hasIssueRuleGuard) {
    errors.push("internal expense-control institution.create must include a funding or limit source: issue_rule_info_list, a quota limit factor, implemented manual quota issuance, or an explicit guard requiring one; usage restrictions alone are insufficient");
  }
}

function hasExplicitConsultMode(text, consultModes = []) {
  return consultModes.length > 0
    || /(?:consult_mode|consultMode)\s*:\s*(?:["']?[01]["']?|\b[A-Z_]*CONSULT[A-Z_]*MODE[A-Z_]*(?:\s*\.\s*[A-Z_][A-Z0-9_]*)?\b)(?=\s*[,}\]])/.test(text)
    || /["']consult_mode["']\s*:\s*(?:["']?[01]["']?|\b[A-Z_]*CONSULT[A-Z_]*MODE[A-Z_]*\b)(?=\s*[,}\]])/.test(text)
    || /\bCONSULT_MODE_(?:INTERNAL|EXTERNAL)\b\s*=\s*["']?[01]["']?(?=\s*[,;}\]])/.test(text);
}

function hasInternalConsultMode(text, consultModes = []) {
  return consultModes.includes("0")
    || /(?:consult_mode|consultMode)\s*:\s*["']?0["']?(?=\s*[,}\]])/.test(text)
    || /["']consult_mode["']\s*:\s*["']?0["']?(?=\s*[,}\]])/.test(text)
    || /\bCONSULT_MODE_INTERNAL\b\s*=\s*["']?0["']?(?=\s*[,;}\]])/.test(text);
}

function hasHardcodedBusinessPolicyValue(text) {
  return /\b(?:quotaTotal|quotaDay|quotaWeek|quotaMonth|quotaSeason|quotaYear|quota_total|quota_day|quota_week|quota_month|quota_season|quota_year|quotaAmount|quota_amount|limitAmount|limit_amount|limitPercent|limit_percent|amount|threshold|ratio|timeWindow|time_window)\b\s*(?:=|:)\s*["']?\d+(?:\.\d+)?["']?/.test(text);
}

function checkNodeExpenseFieldRules(text, errors) {
  if (/alipay\.ebpp\.invoice\.institution\.create/.test(text) && !/\bstandard_info_list\s*:/.test(text)) {
    errors.push("Node.js institution.create must build documented standard_info_list; do not put usage-rule fields at the top level of bizContent");
  }
  if (/\bexpense_type_sub\s*:/.test(text)) {
    errors.push("Node.js expense subtype field expense_type_sub is fabricated; use standard_info_list.expense_type_sub_category from institution-create docs");
  }
  if (/\bstandard_condition_info_list\s*:/.test(text) && !/\bstandard_info_list\s*:/.test(text)) {
    errors.push("Node.js standard_condition_info_list must be nested under standard_info_list, not top-level bizContent");
  }
  if (/\bemployee_list\s*:/.test(text) && !/\b(?:institution_scope_info|owner_id_list|owner_open_id_list)\s*:/.test(text)) {
    errors.push("Node.js institution scope must use documented institution_scope_info/owner fields; employee_list is not a documented institution.create field");
  }
  if (hasMisdescribedUsageTimeRule(text)) {
    errors.push("Node.js ALARM_CLOCK_TIME semantics must come from the official rule-factor Markdown: it represents usage/available time, not notification, reminder, UI ordering, or display-control semantics");
  }
}

function hasMisdescribedUsageTimeRule(text) {
  if (!/\bALARM_CLOCK_TIME\b/.test(text)) return false;
  return /提醒|通知|排序|置顶|展示控制|展示位置|优先级/.test(text);
}

function checkNodeUnsafeStubs(text, errors) {
  if (/\b(?:verifySign|checkSign|validateSign)\s*\([^)]*\)\s*\{[\s\S]{0,120}?return\s+true\s*;/.test(text)) {
    errors.push("Node.js signature verification contains a return-true stub");
  }
  if (/TODO_STUB|stub implementation|mock success|return\s+["']success["']\s*;[\s\S]{0,160}\/\/\s*TODO/i.test(text)) {
    errors.push("Node.js code contains stub/mock success logic");
  }
}

function checkNodeFailOpenBusinessPlaceholders(text, errors) {
  const marker = /TODO|placeholder|stub|mock|sample|示例|占位|替换为实际|实现实际|需替换为实际/ig;
  for (const match of text.matchAll(marker)) {
    const block = text.slice(Math.max(0, match.index - 500), Math.min(text.length, match.index + 1000));
    if (hasRequestEchoResult(stripJsComments(block))) {
      errors.push("Node.js external expense-control SPI contains a fail-open placeholder that echoes request data as the business result; bind a real service/port, or fail closed until the provider is configured");
      return;
    }
  }
}

function checkNodeSyntax(jsFiles, errors) {
  for (const file of jsFiles) {
    const result = spawnSync(process.execPath, ["--check", file], { cwd: targetDir, encoding: "utf8", maxBuffer: 1024 * 1024 });
    if (result.status !== 0) errors.push(`node --check failed for ${rel(file)}:\n${lastLines(result.stderr || result.stdout)}`);
  }
}

function checkNodeModuleLoading(jsFiles, errors) {
  for (const file of jsFiles) {
    if (!isGeneratedSourceFile(file)) continue;
    if (path.basename(file) === "index.js" && /app\.listen\s*\(/.test(fs.readFileSync(file, "utf8"))) continue;
    const result = spawnSync(process.execPath, ["-e", "require(process.argv[1])", file], { cwd: targetDir, encoding: "utf8", maxBuffer: 1024 * 1024 });
    if (result.status !== 0) errors.push(`Node.js module load failed for ${rel(file)}:\n${lastLines(result.stderr || result.stdout)}`);
  }
}

function checkNodeTests(pkg, cwd, errors, warnings) {
  if (process.env.ALIPAY_VALIDATE_SKIP_NODE_TEST === "1") return;
  if (!pkg.scripts || !pkg.scripts.test) {
    warnings.push("package.json has no test script; skipped npm test");
    return;
  }
  const result = spawnSync("npm", ["test"], { cwd, encoding: "utf8", maxBuffer: 1024 * 1024 * 4 });
  if (result.status !== 0) errors.push(`npm test failed for generated Node.js project:\n${lastLines(`${result.stdout || ""}\n${result.stderr || ""}`, 40)}`);
}

function isGeneratedSourceFile(file) {
  const relPath = rel(file).split(path.sep).join("/");
  return /^(src|lib|app)\//.test(relPath);
}

function isNodeImplementationFile(file) {
  const relPath = rel(file).split(path.sep).join("/");
  if (/\.(?:test|spec)\.(?:js|cjs|mjs)$/i.test(path.basename(file))) return false;
  if (/(^|\/)(?:test|tests|__tests__)\//.test(relPath)) return false;
  return true;
}

function isNodeExpenseFile(file) {
  const relPath = rel(file).split(path.sep).join("/");
  if (/^(config)\//.test(relPath) || /^(src|lib|app)\/common\//.test(relPath)) return true;
  if (/^(src|lib|app)\/expense\//.test(relPath)) return true;
  const text = fs.readFileSync(file, "utf8");
  return /alipay\.ebpp\.invoice|expensecontrol|expense_control|InstitutionCreate|CreateInstitution|BuildInstitution|standard_info_list|issue_rule_info_list|consult_mode|quota\.pay|quota\.refund|quotastatus/i.test(text);
}

function findFile(dir, name) {
  return walk(dir).find((f) => path.basename(f) === name);
}

function checkJavaMavenSdkLatest(errors) {
  const pom = findFile(targetDir, "pom.xml");
  if (!pom) return;
  const sdkVersion = extractPomSdkVersion(fs.readFileSync(pom, "utf8"));
  if (!sdkVersion) {
    errors.push("pom.xml must declare com.alipay.sdk:alipay-sdk-java with an explicit version, alipay-sdk.version property, or alipay.sdk.version property");
    return;
  }
  if (!ALIPAY_SDK_VERSION_PATTERN.test(sdkVersion)) {
    errors.push(`pom.xml uses invalid alipay-sdk-java version ${sdkVersion}; SDK preflight must extract a version matching x.y.z.ALL from pkg:maven/com.alipay.sdk/alipay-sdk-java@<version> or the Maven dependency snippet, not an arbitrary page asset version`);
    return;
  }
  const latest = fetchLatestAlipaySdkVersion();
  if (!latest) {
    errors.push("unable to verify latest alipay-sdk-java version from Central Portal; extract only pkg:maven/com.alipay.sdk/alipay-sdk-java@<version> or the Maven dependency snippet, and require x.y.z.ALL format. Run `curl -sL \"https://central.sonatype.com/artifact/com.alipay.sdk/alipay-sdk-java\"` with approval or provide the Central Portal current version before generating Java/Maven code");
    return;
  }
  if (sdkVersion !== latest) {
    errors.push(`pom.xml uses alipay-sdk-java ${sdkVersion}, but Central Portal current version is ${latest}; upgrade existing and new Java/Maven projects to the current version`);
  }
}

function fetchLatestAlipaySdkVersion() {
  const result = spawnSync("curl", ["-fsSL", "https://central.sonatype.com/artifact/com.alipay.sdk/alipay-sdk-java"], {
    encoding: "utf8",
    maxBuffer: 1024 * 1024 * 2,
  });
  if (result.status !== 0 || !result.stdout) return null;
  const pkg = result.stdout.match(/pkg:maven\/com\.alipay\.sdk\/alipay-sdk-java@([0-9][0-9A-Za-z._-]*\.ALL)/);
  if (pkg) return pkg[1];
  const dep = result.stdout.match(/<artifactId>\s*alipay-sdk-java\s*<\/artifactId>[\s\S]*?<version>\s*([0-9][0-9A-Za-z._-]*\.ALL)\s*<\/version>/);
  return dep ? dep[1] : null;
}

function extractPomSdkVersion(pomText) {
  const properties = extractPomProperties(pomText);
  const dep = pomText.match(/<groupId>\s*com\.alipay\.sdk\s*<\/groupId>[\s\S]*?<artifactId>\s*alipay-sdk-java\s*<\/artifactId>[\s\S]*?<version>\s*([^<\s]+)\s*<\/version>/);
  if (!dep) return properties.get("alipay-sdk.version") || properties.get("alipay.sdk.version") || null;
  const version = dep[1];
  const propertyRef = version.match(/^\$\{([^}]+)\}$/);
  if (propertyRef) return properties.get(propertyRef[1]) || null;
  return version;
}

function extractPomProperties(pomText) {
  const properties = new Map();
  const block = pomText.match(/<properties>([\s\S]*?)<\/properties>/);
  if (!block) return properties;
  for (const m of block[1].matchAll(/<([A-Za-z0-9_.-]+)>\s*([^<\s]+)\s*<\/\1>/g)) {
    properties.set(m[1], m[2]);
  }
  return properties;
}

function lastLines(text, count = 20) {
  return String(text || "").trim().split(/\r?\n/).slice(-count).join("\n");
}

function hasManualWhitelistComment(text) {
  const comments = [];
  for (const m of text.matchAll(/\/\*[\s\S]*?\*\/|^\s*\/\/.*$/gm)) comments.push(m[0]);
  return comments.some((comment) => /字段白名单|白名单字段|白名单\s*[:：]/.test(comment));
}

// -----------------------------------------------------------------------------
// Python / Go / .NET / PHP：制度结构、额度来源、SPI 占位和本地构建检查。
// -----------------------------------------------------------------------------

function checkCrossLanguageExpenseProject(errors, warnings) {
  const files = walk(targetDir).filter((f) => /\.(?:py|go|cs|php)$/i.test(f) && isCrossLanguageExpenseFile(f));
  if (files.length === 0) {
    warnings.push("no Java/Node.js fee-control source files found; skipped expense-control language-specific gates");
    return;
  }

  const rawText = files.map((f) => fs.readFileSync(f, "utf8")).join("\n");
  const sourceText = files.map((f) => stripCrossLanguageComments(fs.readFileSync(f, "utf8"), f)).join("\n");

  checkCrossLanguageExpenseFieldRules(sourceText, errors);
  checkCrossLanguageExpenseTypeSubtypeConsistency(files, errors);
  checkCrossLanguageInternalExpenseControl(sourceText, errors);
  checkCrossLanguageExternalSpiStubs(files, errors);
  checkCrossLanguageSignatureStubs(sourceText, errors);
  checkCrossLanguageBuild(files, warnings, errors);

  if (/字段白名单|白名单字段|白名单\s*[:：]/.test(rawText)) {
    errors.push("code comments must not hand-write field whitelist notes; use 字段来源：接口文档业务请求参数表");
  }
}

function isCrossLanguageExpenseFile(file) {
  const relPath = rel(file).split(path.sep).join("/");
  if (/\/(?:node_modules|vendor|target|dist|build|bin|obj|coverage|__pycache__)\//.test(`/${relPath}/`)) return false;
  if (/\/(?:bill|ec|employee|enterprise|department|accounting|websocket|notify)\//i.test(`/${relPath}/`)) return false;
  const text = fs.readFileSync(file, "utf8");
  return /alipay\.ebpp\.invoice|expensecontrol|expense_control|InstitutionCreate|CreateInstitution|BuildInstitution|standard_info_list|issue_rule_info_list|consult_mode|quota\.pay|quota\.refund|quotastatus/i.test(text);
}

function checkCrossLanguageExpenseFieldRules(text, errors) {
  const hasInstitutionCreate = hasCrossLanguageInstitutionCreate(text);
  if (!hasInstitutionCreate) return;

  if (!fieldNamePattern("standard_info_list").test(text)) {
    errors.push("non-Java institution.create must build documented standard_info_list; do not flatten usage rules into custom fields");
  }

  const forbidden = [
    "expense_type_sub",
    "expense_sub_type",
    "standard_rules",
    "standard_list",
    "condition_list",
    "expense_ctrl_mode",
    "use_rules",
    "issue_rule",
    "effective_time",
    "expire_time",
    "employee_list",
    "department_list",
  ];
  for (const field of forbidden) {
    if (fieldNamePattern(field).test(text)) {
      errors.push(`non-Java institution.create uses forbidden fabricated or misplaced field: ${field}`);
    }
  }

  if (fieldNamePattern("standard_condition_info_list").test(text) && !fieldNamePattern("standard_info_list").test(text)) {
    errors.push("non-Java standard_condition_info_list must be nested under standard_info_list, not top-level bizContent/request body");
  }
}

function hasCrossLanguageInstitutionCreate(text) {
  return /alipay\.ebpp\.invoice\.institution\.create|AlipayEbppInvoiceInstitutionCreateRequest|InstitutionCreate|CreateInstitution|BuildInstitution|createInstitution|buildInstitution|institution_create/i.test(text)
    || (fieldNamePattern("standard_info_list").test(text) && fieldNamePattern("expense_type").test(text));
}

function checkCrossLanguageExpenseTypeSubtypeConsistency(files, errors) {
  const mapping = expenseTypeSubtypeMapping();
  const projectText = files.map((f) => stripCrossLanguageComments(fs.readFileSync(f, "utf8"), f)).join("\n");
  const constants = extractStringConstants(projectText);
  for (const file of files) {
    const text = stripCrossLanguageComments(fs.readFileSync(file, "utf8"), file);
    const expenseTypes = extractCrossLanguageFieldValues(text, ["expense_type", "ExpenseType"], constants);
    const subtypes = extractCrossLanguageFieldValues(text, ["expense_type_sub_category", "ExpenseTypeSubCategory"], constants);
    if (expenseTypes.length === 0 || subtypes.length === 0) continue;

    for (const expenseType of expenseTypes) {
      const allowed = mapping.get(expenseType);
      if (!allowed || allowed.size === 0) continue;
      for (const subtype of subtypes) {
        if (!allowed.has(subtype)) {
          errors.push(`${rel(file)}: expense_type_sub_category ${subtype} is not valid for expense_type ${expenseType}; use the official expense-type Markdown and do not use consume_mode DEFAULT as a subtype`);
        }
      }
    }
  }
}

function extractCrossLanguageFieldValues(text, fields, constants = new Map()) {
  const values = [];
  const expr = valueExpressionPattern();
  for (const field of fields) {
    const jsonKey = new RegExp(`["']${escapeRegExp(field)}["']\\s*(?:=>|:|=)\\s*${expr}`, "g");
    for (const m of text.matchAll(jsonKey)) {
      const value = resolveStringArg(m[1], constants);
      if (value) values.push(value);
    }

    const property = new RegExp(`\\b${escapeRegExp(field)}\\b[\\s\\S]{0,80}?(?:=>|:|=)\\s*${expr}`, "g");
    for (const m of text.matchAll(property)) {
      const value = resolveStringArg(m[1], constants);
      if (value) values.push(value);
    }
  }
  return Array.from(new Set(values));
}

function checkCrossLanguageInternalExpenseControl(text, errors) {
  const constants = extractStringConstants(text);
  const consultModes = extractCrossLanguageFieldValues(text, ["consult_mode", "ConsultMode"], constants);
  const declaresInternalMode = consultModes.includes("0") || /内部费控/.test(text);
  if (!declaresInternalMode || !hasCrossLanguageInstitutionCreate(text)) return;

  const quotaLimitFactors = new Set(["QUOTA_DAY", "QUOTA_WEEK", "QUOTA_MONTH", "QUOTA_SEASON", "QUOTA_YEAR", "QUOTA_TOTAL"]);
  const ruleFactors = extractCrossLanguageFieldValues(text, ["rule_factor", "RuleFactor"], constants);
  const hasQuotaLimitFactor = ruleFactors.some((factor) => quotaLimitFactors.has(factor));
  const hasManualIssueApi = /alipay\.ebpp\.invoice\.expensecontrol\.quota\.create/.test(text);
  const hasIssueRule = fieldNamePattern("issue_rule_info_list").test(text);
  if (!hasQuotaLimitFactor && !hasManualIssueApi && !hasIssueRule) {
    errors.push("non-Java internal expense-control institution.create must include a funding or limit source: issue_rule_info_list, a quota limit factor, implemented manual quota issuance, or an explicit guard requiring one; usage restrictions alone are insufficient");
  }
}

function checkCrossLanguageExternalSpiStubs(files, errors) {
  for (const file of files) {
    const raw = fs.readFileSync(file, "utf8");
    const text = stripCrossLanguageComments(raw, file);
    if (!isCrossLanguageSpiFile(raw, file)) continue;
    checkExternalSpiProtocolFieldNames(raw, file, errors);

    if (/NotImplementedError|NotImplementedException/.test(text)) {
      errors.push(`${rel(file)}: external expense-control SPI contains NotImplemented placeholder logic`);
    }

    if (hasPlaceholderFixedResult(raw, file)) {
      errors.push(`${rel(file)}: external expense-control SPI has placeholder code with fixed allow/success/quota/idempotency result; implement real consult, deduct, refund, status and idempotency logic`);
    }
  }
}

function checkExternalSpiProtocolFieldNames(raw, file, errors) {
  const invalidFields = new Map([
    ["standardId", "standard_id"],
    ["availableAmount", "available_amount"],
    ["consultStatus", "consult_status"],
    ["resultCode", "result_code"],
    ["resultMsg", "result_msg"],
  ]);
  const offenders = [];
  for (const [camel, snake] of invalidFields) {
    const explicitJsonKey = new RegExp(`["'\`]${escapeRegExp(camel)}["'\`]\\s*(?::|=>|,|\\))`);
    const bareObjectKey = new RegExp(`(^|[,{\\s])${escapeRegExp(camel)}\\s*:`, "m");
    const serializerTag = new RegExp(`\\b(?:json|form|url|query)\\s*[:=]\\s*["']${escapeRegExp(camel)}(?:[,\"'])`);
    if (explicitJsonKey.test(raw) || bareObjectKey.test(raw) || serializerTag.test(raw)) {
      offenders.push(`${camel} -> ${snake}`);
    }
  }
  if (offenders.length) {
    errors.push(`${rel(file)}: external expense-control SPI uses camelCase protocol field names (${offenders.join(", ")}); keep HTTP/JSON fields exactly as documented, e.g. consult_status instead of consultStatus`);
  }
}

function checkJavaExternalSpiProtocolFieldNames(files, errors) {
  for (const file of files) {
    const raw = fs.readFileSync(file, "utf8");
    if (!isCrossLanguageSpiFile(raw, file)) continue;
    checkExternalSpiProtocolFieldNames(raw, file, errors);
  }
}

function hasPlaceholderFixedResult(raw, file) {
  const placeholder = /TODO|placeholder|stub|mock|sample|示例|占位|替换为实际|实现实际|需替换为实际/ig;
  for (const match of raw.matchAll(placeholder)) {
    const block = sourceBlockAround(raw, match.index, file);
    const code = stripCrossLanguageComments(block, file);
    if (hasRequestEchoResult(code)) {
      return true;
    }
    // “固定成功返回”本身不等于 stub：真实 SPI 也可能在最终分支返回 success。
    // 只有同时出现占位提示，且函数体没有查询、分支、循环或业务 helper 调用时才报错。
    if (fixedSpiResultPatterns().some((pattern) => pattern.test(code)) && !hasRealSpiLogic(code)) {
      return true;
    }
  }
  return false;
}

function hasRealSpiLogic(code) {
  // Conditional branching: a real consult/deduct must decide based on quota.
  if (/\b(?:if|else|elif|elsif|switch|match|when|case)\b/.test(code)) return true;
  // Loops.
  if (/\b(?:for|foreach|while|range)\b/.test(code)) return true;
  // A call to a helper function/method (real work), excluding language keywords
  // and the response object's own constructor (which is part of the fixed result).
  const ignore = new Set([
    "if", "for", "while", "switch", "return", "func", "function", "def",
    "foreach", "catch", "new", "sizeof", "print", "println", "echo", "throw",
    "await", "go", "defer", "using", "lock",
  ]);
  for (const m of code.matchAll(/\b([A-Za-z_][A-Za-z0-9_.]*)\s*\(/g)) {
    const qualified = m[1];
    const name = qualified.split(".").pop();
    if (ignore.has(name)) continue;
    // Skip constructing the SPI response/record/result object itself.
    if (/(?:Resp|Response|Record|Result|Reply|Dto|DTO|VO)$/.test(qualified)) continue;
    return true;
  }
  return false;
}

function sourceBlockAround(raw, index, file) {
  if (/\.(?:go|cs|java|php)$/i.test(file)) {
    const blocks = [];
    // Block enclosing the placeholder (placeholder sits inside a function body).
    const before = raw.lastIndexOf("{", index);
    if (before >= 0) {
      const close = findMatchingBrace(raw, before);
      if (close > index) blocks.push(raw.slice(before, close + 1));
    }
    // Block that immediately follows the placeholder (placeholder is a comment
    // on the line above the function signature, body comes after).
    const after = raw.indexOf("{", index);
    if (after >= 0 && after - index < 400) {
      const close = findMatchingBrace(raw, after);
      if (close > after) blocks.push(raw.slice(after, close + 1));
    }
    if (blocks.length) return blocks.join("\n");
  }
  return raw.slice(Math.max(0, index - 500), Math.min(raw.length, index + 900));
}

function fixedSpiResultPatterns() {
  return [
    /\bAllowConsume\s*[:=]\s*true\b/i,
    /\ballow_consume["']?\s*(?:=>|:|=)\s*true\b/i,
    /\bSuccess\s*[:=]\s*true\b/i,
    /\bsuccess["']?\s*(?:=>|:|=)\s*true\b/i,
    /\bPass\s*=\s*["']Y["']/i,
    /\bPayResult\s*=\s*["']Y["']/i,
    /\breturn\s+100000\s*;?/i,
    /\breturn\s+new\s+QuotaPayRecord\b/i,
    /\breturn\s+null\s*;?/i,
  ];
}

function hasRequestEchoResult(code) {
  // 占位实现把请求值原样作为业务决策结果返回，本质上仍是固定放行。
  // 这里只识别明显的参数/请求字段回显，避免误伤经过真实业务查询和计算后的返回值。
  if (/\breturn\s+(?:req(?:uest)?|input|params?)\s*(?:\.|->)\s*[A-Za-z_][A-Za-z0-9_]*(?:\s*\(\s*\))?\s*;?/i.test(code)) {
    return true;
  }
  if (/(?:available|quota|allow|result)[A-Za-z0-9_]*["']?\s*(?:=>|:|=)\s*(?:req(?:uest)?|input|params?)\s*(?:\.|->)\s*[A-Za-z_][A-Za-z0-9_]*/i.test(code)) {
    return true;
  }

  const signatures = [
    /\bdef\s+[A-Za-z_][A-Za-z0-9_]*\s*\(([^)]*)\)/g,
    /\bfunction\s+[A-Za-z_][A-Za-z0-9_]*\s*\(([^)]*)\)/g,
    /\bfunc\s+(?:\([^)]*\)\s*)?[A-Za-z_][A-Za-z0-9_]*\s*\(([^)]*)\)/g,
  ];
  for (const signature of signatures) {
    for (const match of code.matchAll(signature)) {
      for (const param of parameterNames(match[1])) {
        if (new RegExp(`\\breturn\\s+${escapeRegExp(param)}\\s*;?`).test(code)) return true;
      }
    }
  }
  return false;
}

function parameterNames(raw) {
  return raw.split(",").map((part) => {
    const cleaned = part.trim().replace(/=.*/, "").trim();
    if (!cleaned) return "";
    const colonName = cleaned.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*:/);
    if (colonName) return colonName[1];
    const pieces = cleaned.replace(/[*&]/g, " ").trim().split(/\s+/);
    return pieces[pieces.length - 1].replace(/^\$/, "");
  }).filter((name) => /^[A-Za-z_][A-Za-z0-9_]*$/.test(name));
}

function isCrossLanguageSpiFile(text, file) {
  return /expensecontrol\.(?:expensecontrol\.consult|quota\.pay|quota\.refund|quotastatus\.query)|HandleConsult|HandleDeduct|HandleRefund|HandleStatus|ExpenseControlConsult|QuotaPay|QuotaRefund|QuotaStatus|_do_consult|_do_quota/i.test(text)
    || /spi/i.test(path.basename(file));
}

function checkCrossLanguageSignatureStubs(text, errors) {
  if (/\b(?:verify|check|validate)[A-Za-z0-9_]*(?:Sign|Signature|Notify)[A-Za-z0-9_]*\s*\([^)]*\)\s*\{[\s\S]{0,180}?\breturn\s+true\b/i.test(text)) {
    errors.push("non-Java signature verification contains a return-true stub");
  }
}

function checkCrossLanguageBuild(files, warnings, errors) {
  const exts = new Set(files.map((f) => path.extname(f).toLowerCase()));
  if (exts.has(".py")) checkPythonSyntax(files.filter((f) => f.endsWith(".py")), warnings, errors);
  if (exts.has(".go")) checkGoBuild(warnings, errors);
  if (exts.has(".cs")) checkDotnetBuild(warnings, errors);
}

function checkPythonSyntax(files, warnings, errors) {
  if (!commandExists("python3")) {
    warnings.push("python3 not found; skipped Python syntax validation");
    return;
  }
  const script = [
    "import ast, pathlib, sys",
    "for name in sys.argv[1:]:",
    "    path = pathlib.Path(name)",
    "    ast.parse(path.read_text(encoding='utf-8'), filename=str(path))",
  ].join("\n");
  const result = spawnSync("python3", ["-c", script, ...files], {
    cwd: targetDir,
    encoding: "utf8",
    env: Object.assign({}, process.env, { PYTHONDONTWRITEBYTECODE: "1" }),
    maxBuffer: 1024 * 1024,
  });
  if (result.status !== 0) errors.push(`Python syntax validation failed:\n${lastLines(result.stderr || result.stdout)}`);
}

function checkGoBuild(warnings, errors) {
  const goMod = findFile(targetDir, "go.mod");
  if (!goMod) {
    warnings.push("Go source detected but go.mod not found; skipped go test");
    return;
  }
  if (!commandExists("go")) {
    warnings.push("go command not found; skipped go test");
    return;
  }
  const result = spawnSync("go", ["test", "./..."], {
    cwd: path.dirname(goMod),
    encoding: "utf8",
    env: Object.assign({}, process.env, { GOCACHE: path.join(os.tmpdir(), "alipay-skill-go-cache") }),
    maxBuffer: 1024 * 1024 * 4,
  });
  if (result.status !== 0) errors.push(`go test ./... failed:\n${lastLines(`${result.stdout || ""}\n${result.stderr || ""}`, 40)}`);
}

function checkDotnetBuild(warnings, errors) {
  const project = walk(targetDir).find((f) => /\.csproj$/i.test(f));
  if (!project) {
    warnings.push(".NET source detected but no .csproj found; skipped dotnet build");
    return;
  }
  if (!commandExists("dotnet")) {
    warnings.push("dotnet command not found; skipped dotnet build");
    return;
  }
  const result = spawnSync("dotnet", ["build", "--nologo"], {
    cwd: path.dirname(project),
    encoding: "utf8",
    maxBuffer: 1024 * 1024 * 8,
  });
  if (result.status !== 0) errors.push(`dotnet build failed:\n${lastLines(`${result.stdout || ""}\n${result.stderr || ""}`, 40)}`);
}

function commandExists(command) {
  const result = spawnSync(command, ["--version"], { encoding: "utf8", maxBuffer: 1024 * 32 });
  return result.status === 0;
}

function fieldNamePattern(field) {
  return new RegExp(`(^|[^A-Za-z0-9_])${escapeRegExp(field)}([^A-Za-z0-9_]|$)`);
}

function stripCrossLanguageComments(text, file) {
  if (file.endsWith(".py")) {
    return text.replace(/^\s*#.*$/gm, "");
  }
  return text
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/^\s*\/\/.*$/gm, "")
    .replace(/^\s*#.*$/gm, "");
}

// -----------------------------------------------------------------------------
// Java/Maven：文档 setter、制度业务约束、SDK 使用和工程结构。
// -----------------------------------------------------------------------------

function checkSetters(javaFiles, errors) {
  const allowed = {};
  for (const [type, doc] of Object.entries(modelDocs)) allowed[type] = allowedSetters(doc, null, true);
  for (const [type, [doc, prefix]] of Object.entries(nestedDocs)) allowed[type] = allowedSetters(doc, prefix, false);

  for (const file of javaFiles) {
    const text = fs.readFileSync(file, "utf8");
    scanSetterBlocks(text, allowed, file, errors);
  }
}

function scanSetterBlocks(text, allowed, file, errors) {
  const vars = {};
  const pattern = /\b([A-Za-z0-9_]+)\s+([A-Za-z0-9_]+)\s*=\s*new\s+\1\s*\(|\b([A-Za-z0-9_]+)\.set([A-Za-z0-9_]+)\s*\(/g;

  function finalize(varName) {
    const state = vars[varName];
    if (!state || !allowed[state.type] || !allowed[state.type].required.size) return;
    for (const setter of allowed[state.type].required) {
      if (!state.called.has(setter)) errors.push(`${rel(file)}: ${state.type} variable ${varName} is missing required documented setter ${setter}`);
    }
  }

  for (const m of text.matchAll(pattern)) {
    if (m[1]) {
      const type = m[1];
      const varName = m[2];
      finalize(varName);
      vars[varName] = { type, called: new Set() };
      continue;
    }

    const varName = m[3];
    const setter = `set${m[4]}`;
    const state = vars[varName];
    if (!state || !allowed[state.type]) continue;
    state.called.add(setter);
    if (!allowed[state.type].all.has(setter) && !isContextualSetterAllowed(text, m.index, state.type, setter, varName)) {
      errors.push(`${rel(file)}: setter ${state.type}.${setter} is not in documentation whitelist`);
    }
  }

  for (const varName of Object.keys(vars)) finalize(varName);
}

function isContextualSetterAllowed(text, index, type, setter, varName) {
  if (type !== "StandardConditionInfo" || setter !== "setRuleId") return false;

  const contextStart = Math.max(0, index - 1200);
  const contextEnd = Math.min(text.length, index + 1200);
  const context = text.slice(contextStart, contextEnd);

  // institution.modify requires rule_id when modifying existing conditions:
  // modify_standard_detail_info.modify_standard_list.modify_condition_list.rule_id
  return new RegExp(
    `modifyConditionList|setModifyConditionList|getModifyConditionList|modify_condition_list|${escapeRegExp(varName)}[\\s\\S]{0,600}setModifyConditionList`
  ).test(context);
}

// SDK setters describe what can be serialized, not what is mutable in every
// operation. When modify_condition_list identifies an existing condition by
// rule_id, rule_factor is immutable according to the interface documentation.
function checkImmutableModifyConditionFields(files, errors) {
  for (const file of files) {
    const text = stripJavaComments(fs.readFileSync(file, "utf8"));
    for (const method of extractMethods(text)) {
      if (!/AlipayEbppInvoiceInstitutionModifyModel|AlipayEbppInvoiceInstitutionModifyRequest/.test(method.body)) continue;
      if (!/setModifyConditionList\s*\(/.test(method.body)) continue;

      for (const match of method.body.matchAll(/\b([A-Za-z_][A-Za-z0-9_]*)\s*\.\s*setRuleId\s*\(/g)) {
        const variable = match[1];
        const setsImmutableFactor = new RegExp(`\\b${escapeRegExp(variable)}\\s*\\.\\s*setRuleFactor\\s*\\(`).test(method.body);
        if (setsImmutableFactor) {
          errors.push(`${rel(file)}: institution.modify updates an existing condition by rule_id but also submits immutable rule_factor on ${variable}; send only documented mutable fields such as rule_value`);
        }
      }
    }
  }
}

function checkExpenseFabricatedFields(text, errors) {
  const code = stripJavaComments(text);
  for (const forbidden of ["use_rules", "issue_rule", "expense_type_sub", "effective_time", "expire_time", "employee_list", "department_list"]) {
    if (hasForbiddenJavaFieldUsage(code, forbidden)) {
      errors.push(`forbidden fabricated field appears: ${forbidden}`);
    }
  }
}

function hasForbiddenJavaFieldUsage(text, field) {
  const camel = snakeToCamel(field);
  const pascal = camel.charAt(0).toUpperCase() + camel.slice(1);
  const quotedField = new RegExp(`["']${escapeRegExp(field)}["']\\s*(?:[:=]|=>)`);
  const bareSnakeField = new RegExp(`(?:^|[\\s{,(])${escapeRegExp(field)}\\s*(?:[:=]|=>)`);
  const mapPutField = new RegExp(`\\.put\\s*\\(\\s*["']${escapeRegExp(field)}["']\\s*,`);
  const setterField = new RegExp(`\\.\\s*set${escapeRegExp(pascal)}\\s*\\(`);
  const memberField = new RegExp(`\\b(?:private|protected|public)\\s+[A-Za-z0-9_<>, ?]+\\s+${escapeRegExp(camel)}\\b`);
  return quotedField.test(text)
    || bareSnakeField.test(text)
    || mapPutField.test(text)
    || setterField.test(text)
    || memberField.test(text);
}

function snakeToCamel(value) {
  return value.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
}

function checkExpenseTypeSubtypeConsistency(text, projectText, errors) {
  const mapping = expenseTypeSubtypeMapping();

  // 常量可能定义在独立 Constants 文件，因此先从全工程建表，
  // 再解析当前制度方法中的 ClassName.CONSTANT 引用。
  const constants = extractStringConstants(`${projectText}\n${text}`);
  const methods = extractJavaMethodBodies(text);

  for (const method of methods) {
    const expenseTypes = Array.from(method.body.matchAll(/\.setExpenseType\s*\(\s*([^)]+?)\s*\)/g))
      .map((m) => resolveStringArg(m[1], constants))
      .filter(Boolean);
    const subtypes = Array.from(method.body.matchAll(/\.setExpenseTypeSubCategory\s*\(\s*([^)]+?)\s*\)/g))
      .map((m) => resolveStringArg(m[1], constants))
      .filter(Boolean);
    if (expenseTypes.length === 0 || subtypes.length === 0) continue;

    for (const expenseType of expenseTypes) {
      const allowed = mapping.get(expenseType);
      if (!allowed || allowed.size === 0) continue;
      for (const subtype of subtypes) {
        if (!allowed.has(subtype)) {
          errors.push(`expense_type_sub_category ${subtype} is not valid for expense_type ${expenseType}; use the mapping in the official expense-type Markdown and do not confuse consume_mode DEFAULT with a subtype`);
        }
      }
    }
  }
}

function expenseTypeSubtypeMapping() {
  const text = interfaceDocs.documentMarkdown("expense-types");
  const mapping = new Map();
  let currentType = null;
  for (const line of text.split(/\r?\n/)) {
    if (!line.startsWith("|") || line.includes("---") || line.includes("费用类型")) continue;
    const cells = line.split("|").map((s) => s.trim());
    const expenseType = cells[1] || "";
    const subtype = cells[3] || "";
    if (expenseType) currentType = expenseType;
    if (!currentType || !subtype) continue;
    if (!mapping.has(currentType)) mapping.set(currentType, new Set());
    mapping.get(currentType).add(subtype);
  }
  return mapping;
}

function extractJavaMethodBodies(text) {
  const methods = [];
  const pattern = /(?:public|private|protected)\s+(?:static\s+)?[A-Za-z0-9_<>, ?\[\]]+\s+([A-Za-z0-9_]+)\s*\([^)]*\)\s*(?:throws\s+[A-Za-z0-9_,\s]+)?\{/g;
  for (const match of text.matchAll(pattern)) {
    const start = match.index + match[0].length - 1;
    const end = findMatchingBrace(text, start);
    if (end > start) methods.push({ name: match[1], body: text.slice(start + 1, end) });
  }
  return methods;
}

function findMatchingBrace(text, openIndex) {
  // rule_value 经常是 JSON 字符串，不能用简单的 indexOf("}")。
  // 这里跳过字符串、转义和注释，只对真正的代码大括号计数。
  let depth = 0;
  let quote = null;
  let escaped = false;
  let lineComment = false;
  let blockComment = false;
  for (let i = openIndex; i < text.length; i++) {
    const ch = text[i];
    const next = text[i + 1];

    if (lineComment) {
      if (ch === "\n") lineComment = false;
      continue;
    }
    if (blockComment) {
      if (ch === "*" && next === "/") {
        blockComment = false;
        i++;
      }
      continue;
    }
    if (quote) {
      if (escaped) {
        escaped = false;
      } else if (ch === "\\") {
        escaped = true;
      } else if (ch === quote) {
        quote = null;
      }
      continue;
    }

    if (ch === "/" && next === "/") {
      lineComment = true;
      i++;
      continue;
    }
    if (ch === "/" && next === "*") {
      blockComment = true;
      i++;
      continue;
    }
    if (ch === "\"" || ch === "'" || ch === "`") {
      quote = ch;
      continue;
    }

    if (ch === "{") depth++;
    if (ch === "}") {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}

function checkInstitutionFundingOrQuotaGuard(text, projectText, errors) {
  if (!text.includes("AlipayEbppInvoiceInstitutionCreateModel")) return;
  if (isExternalExpenseControl(text, projectText)) return;

  const hasIssueRule = /\bIssueRuleInfo\b|\.setIssueRuleInfoList\s*\(/.test(text);
  const hasManualIssue = /\bAlipayEbppInvoiceExpensecontrolQuotaCreateRequest\b|\bAlipayEbppInvoiceExpensecontrolQuotaCreateModel\b/.test(text);
  // 额度因子允许写成 Constants.QUOTA_TOTAL；先还原真实值再分类。
  const constants = extractStringConstants(`${projectText}\n${text}`);
  const quotaLimitFactors = new Set(["QUOTA_DAY", "QUOTA_WEEK", "QUOTA_MONTH", "QUOTA_SEASON", "QUOTA_YEAR", "QUOTA_TOTAL"]);
  const ruleFactors = extractSetRuleFactors(text, constants);
  const hasQuotaLimitCondition = ruleFactors.some((factor) => quotaLimitFactors.has(factor));

  if (hasIssueRule || hasManualIssue || hasQuotaLimitCondition) return;

  const unsupportedFactors = [];
  for (const factor of ["MERCHANT", "ALARM_CLOCK_TIME", "ALLOW_MINIMUM", "OWNER_PAY_MINIMUM", "QUOTA_ONCE", "QUOTA_ONCE_PERCENT", "QUOTA_UNLIMITED"]) {
    if (ruleFactors.includes(factor)) unsupportedFactors.push(factor);
  }
  const suffix = unsupportedFactors.length
    ? ` Present non-qualifying rule factors: ${unsupportedFactors.join(", ")}.`
    : "";
  errors.push(`institution.create for internal expense control must include at least one issue_rule_info_list, one quota limit condition (QUOTA_DAY/WEEK/MONTH/SEASON/YEAR/TOTAL), or the manual issue quota.create interface.${suffix}`);
}

function extractSetRuleFactors(text, constants) {
  return Array.from(text.matchAll(/\.setRuleFactor\s*\(\s*([^)]+?)\s*\)/g))
    .map((m) => resolveStringArg(m[1], constants))
    .filter(Boolean);
}

function isExternalExpenseControl(text, projectText) {
  const combinedText = `${projectText}\n${text}`;
  const constants = extractStringConstants(combinedText);
  const consultModes = extractSetConsultModes(text, constants);
  const explicitExternalMode = consultModes.includes("1")
    || /CONSULT_MODE_EXTERNAL\s*=\s*["']1["']/.test(combinedText)
    || /consult_mode\s*=\s*["']?1["']?|consult_mode=1|外部费控/.test(text);
  if (!explicitExternalMode) return false;

  const requiredSpiTokens = [
    "spi.alipay.commerce.ec.expensecontrol.expensecontrol.consult",
    "spi.alipay.commerce.ec.expensecontrol.quota.pay",
    "spi.alipay.commerce.ec.expensecontrol.quota.refund",
    "spi.alipay.commerce.ec.expensecontrol.quotastatus.query",
  ];
  return requiredSpiTokens.every((token) => projectText.includes(token));
}

function extractSetConsultModes(text, constants) {
  return Array.from(text.matchAll(/\.setConsultMode\s*\(\s*([^)]+?)\s*\)/g))
    .map((m) => resolveStringArg(m[1], constants))
    .filter(Boolean);
}

function checkInstitutionModifyDepth(text, warnings) {
  if (!text.includes("AlipayEbppInvoiceInstitutionModifyRequest")) return;
  const hasModifyStructure = /ModifyScopeInfo|ModifyStandardDetailInfo|ModifyIssueRuleDetailInfo|setModifyScopeInfo|setModifyStandardDetailInfo|setModifyIssueRuleDetailInfo/.test(text);
  if (!hasModifyStructure) {
    warnings.push("institution.modify only appears to cover top-level enable/date fields; if the selected scope includes standard or scope modification, implement modify_standard_detail_info/modify_scope_info instead of deleting that capability");
  }
  if (/AlipayEbppInvoiceInstitutionModifyModel[\s\S]{0,2000}setStandardInfoList\s*\(/.test(text)) {
    warnings.push("institution.modify must not use top-level setStandardInfoList; use modify_standard_detail_info.modify_standard_list/add_standard_list/delete_standard_id_list");
  }
}

function isExpenseFile(file) {
  const relPath = rel(file).split(path.sep).join("/");
  if (/\/expense\//.test(`/${relPath}`)) return true;
  if (/\/(bill|websocket|notify)\//.test(`/${relPath}`)) return false;
  const text = fs.readFileSync(file, "utf8");
  if (/\/controller\//.test(`/${relPath}`) && !/expensecontrol|expense-control|\bSPI\b|Spi/i.test(`${relPath}\n${text}`)) {
    return false;
  }
  return /AlipayEbppInvoiceInstitution|AlipayEbppInvoiceExpensecontrol|StandardInfo|StandardConditionInfo|InstitutionScopeInfo|IssueRuleInfo|setStandardInfoList|setConsultMode|ExpenseControlSpi|SpiConsult|SpiQuota|QuotaStore|expensecontrol\.(?:consult|quota|quotastatus)/i.test(text);
}

function allowedSetters(api, prefix, enforceRequired) {
  const rows = extractRequestRows(api);
  const all = new Set();
  const required = new Set();
  for (const row of rows) {
    const field = row.field;
    let setter = null;
    if (prefix) {
      if (field.startsWith(`${prefix}.`)) setter = toSetter(field.slice(prefix.length + 1).split(".").pop());
    } else if (!field.includes(".")) {
      setter = toSetter(field);
    }
    if (!setter) continue;
    all.add(setter);
    if (enforceRequired && isRequired(row.required)) required.add(setter);
  }
  return { all, required };
}

function extractRequestRows(api) {
  return interfaceDocs.requestRows(api);
}

function checkCoverage(text, tokens, errors) {
  for (const token of tokens) if (!text.includes(token)) errors.push(`missing required interface: ${token}`);
}

function checkSdkModelUsage(text, docs, errors) {
  for (const type of Object.keys(docs)) {
    const declaration = new RegExp(`\\b${escapeRegExp(type)}\\s+([A-Za-z0-9_]+)\\s*=\\s*new\\s+${escapeRegExp(type)}\\s*\\(`);
    const m = text.match(declaration);
    if (!m) {
      errors.push(`missing required SDK model construction: ${type}; generated Java must use official Request + Model classes`);
      continue;
    }
    const varName = m[1];
    const setBizModel = new RegExp(`\\.setBizModel\\s*\\(\\s*${escapeRegExp(varName)}\\s*\\)`);
    if (!setBizModel.test(text)) {
      errors.push(`SDK model ${type} variable ${varName} is not passed to request.setBizModel(...)`);
    }
  }
}

function checkRawBizContent(text, errors) {
  if (usesSdkRequestSetBizContent(text) || /putOtherTextParam\s*\(\s*["']biz_content["']/.test(text)) {
    errors.push("generated Java must not hand-build biz_content with JSON/Map/setBizContent; use official SDK Model setters and request.setBizModel(model)");
  }
}

function usesSdkRequestSetBizContent(text) {
  for (const m of text.matchAll(/\b(Alipay[A-Za-z0-9_]*Request)\s+([A-Za-z0-9_]+)\s*=/g)) {
    const varName = m[2];
    const pattern = new RegExp(`\\b${escapeRegExp(varName)}\\s*\\.\\s*setBizContent\\s*\\(`);
    if (pattern.test(text)) return true;
  }
  return false;
}

function checkUnsafeStubs(files, errors) {
  for (const file of files) {
    const text = fs.readFileSync(file, "utf8");
    for (const method of extractMethods(text)) {
      if (/verifySign|checkSign|validateSign/.test(method.name) && /\breturn\s+true\s*;/.test(method.body)) {
        errors.push(`${rel(file)}: ${method.name}(...) is a security stub returning true; implement SDK signature verification or use the documented SDK message client`);
      }
      if (/Stub implementation for compilation purposes/.test(method.body)
          || /UnsupportedOperationException/.test(method.body) && !isExplicitFailClosedAdapter(text, method)) {
        errors.push(`${rel(file)}: generated code contains a stub implementation in ${method.name}(...)`);
      }
    }
  }
}

function isExplicitFailClosedAdapter(fileText, method) {
  if (!/UnsupportedOperationException/.test(method.body)) return false;
  const body = stripJavaComments(method.body).trim();
  const throwsOnly = /^\{\s*throw\s+new\s+UnsupportedOperationException\s*\([\s\S]*\)\s*;\s*\}$/.test(body);
  const boundary = /fail[- ]closed|not configured|未配置|@ConditionalOnMissingBean|\b(?:Port|Adapter|Gateway)\b/i.test(fileText);
  const sdkOrSecurity = /Alipay[A-Za-z0-9_]*Request|alipayClient\s*\.\s*execute|verifySign|checkSign|validateSign/.test(`${method.name}\n${method.body}`);
  return throwsOnly && boundary && !sdkOrSecurity;
}

function checkJavaExternalSpiStatePersistence(files, projectText, errors) {
  if (!/expensecontrol\.quota\.(?:pay|refund)|expensecontrol\.quotastatus\.query/i.test(projectText)) return;
  for (const file of files) {
    const raw = fs.readFileSync(file, "utf8");
    if (isDemoOrTestSource(file, raw)) continue;
    if (!/@(?:Component|Service|Repository)\b/.test(raw)) continue;
    if (!hasMutableInMemoryStateField(raw)) continue;
    if (!/trade[_A-Za-z]*no|refund|deduct|recover|quota|额度/i.test(raw)) continue;
    if (!/\b(?:put|putIfAbsent|compute|add|remove|mark|save|update)[A-Za-z0-9_]*\s*\(/i.test(raw)) continue;
    if (hasPersistentStateDelegate(raw)) continue;
    errors.push(`${rel(file)}: external expense-control deduct/refund/status state is stored in a default process-local Map/Set; route authoritative state through a persistent transactional Port/Repository, or restrict the in-memory state machine to an explicit demo/test profile`);
  }
}

function hasMutableInMemoryStateField(text) {
  return /(?:^|[;\n])\s*(?:(?:private|protected|public|static|final|volatile)\s+)+(?:Map|ConcurrentMap|ConcurrentHashMap|Set|HashSet)\s*<[^;\n=]+>\s+[A-Za-z_][A-Za-z0-9_]*\s*=\s*new\s+(?:ConcurrentHashMap|HashMap|ConcurrentSkipListMap|HashSet|LinkedHashSet)\b/m.test(text);
}

function hasPersistentStateDelegate(text) {
  return /\b[A-Za-z_][A-Za-z0-9_]*(?:Repository|Port|Dao|Gateway)\s*\.\s*(?:save|insert|update|upsert|delete|persist|store|write|deduct|refund|recover|find|query)\s*\(/i.test(text);
}

function isDemoOrTestSource(file, text) {
  const relPath = rel(file).split(path.sep).join("/");
  return /(^|\/)(?:test|tests|demo|demos|examples)(\/|$)/i.test(relPath)
    || hasExplicitDemoOrTestAnnotation(text);
}

function hasExplicitDemoOrTestAnnotation(text) {
  const annotations = text.match(/@(?:(?:[A-Za-z_$][\w$]*\.)*)?(?:Profile|ConditionalOnProperty)\s*\([^)]*\)/g) || [];
  return annotations.some((annotation) =>
    Array.from(annotation.matchAll(/["']([^"']+)["']/g))
      .some((match) => /(^|[-_.])(?:test|demo)(?:[-_.]|$)/i.test(match[1])));
}

function checkJavaMessageClientStartupFailure(files, errors) {
  for (const file of files) {
    const raw = stripJavaComments(fs.readFileSync(file, "utf8"));
    if (!/AlipayMsgClient/.test(raw) || !/\.connect\s*\(/.test(raw)) continue;
    for (const method of extractMethods(raw)) {
      if (!/\.connect\s*\(/.test(method.body)) continue;
      const catches = catchBodies(method.body);
      if (catches.length && catches.some((body) => !hasSafeConnectFailurePolicy(body))) {
        errors.push(`${rel(file)}: ${method.name}(...) catches initial AlipayMsgClient.connect failure without fail-fast or both retry and health/readiness signaling; do not leave the application running while message intake is unavailable`);
      }
    }
  }
}

function catchBodies(body) {
  const result = [];
  for (const match of body.matchAll(/\bcatch\s*\([^)]*\)\s*\{/g)) {
    const open = match.index + match[0].length - 1;
    const close = findMatchingBrace(body, open);
    if (close > open) result.push(body.slice(open + 1, close));
  }
  return result;
}

function hasSafeConnectFailurePolicy(body) {
  const failsFast = /\bthrow\b|System\s*\.\s*exit\s*\(|SpringApplication\s*\.\s*exit\s*\(|Runtime\s*\.\s*getRuntime\s*\(\s*\)\s*\.\s*halt\s*\(/.test(body);
  const retries = /\b(?:retry|reconnect|backoff|reschedule|schedule|connectAsync)\b|\.connect\s*\(/i.test(body);
  const signalsHealth = /\b(?:health|readiness|availability|liveness)\b|REFUSING_TRAFFIC|\bDOWN\b|setConnected\s*\(\s*false\s*\)|mark[A-Za-z0-9_]*(?:Unavailable|Down)/i.test(body);
  return failsFast || retries && signalsHealth;
}

function checkFailOpenBusinessPlaceholders(files, errors) {
  const placeholder = /TODO|placeholder|stub|mock|sample|示例|占位|替换为实际|实现实际|需替换为实际/i;
  for (const file of files) {
    const text = fs.readFileSync(file, "utf8");
    for (const method of extractMethods(text)) {
      if (!placeholder.test(method.body)) continue;

      const returnsInput = method.params.some((param) => {
        if (!param.name) return false;
        return new RegExp(`\\breturn\\s+${escapeRegExp(param.name)}\\s*;`).test(method.body);
      });
      const echoesRequestField = /\breturn\s+(?:request|req|input|params?)\s*\.\s*(?:get[A-Za-z0-9_]+|[A-Za-z_][A-Za-z0-9_]*)\s*\(\s*\)\s*;/.test(method.body);
      if (returnsInput || echoesRequestField) {
        errors.push(`${rel(file)}: ${method.name}(...) is a fail-open placeholder that echoes request data as the business result; bind a real service/port, or fail closed until the provider is configured`);
      }
    }
  }
}

// Required numeric SPI fields are protocol input, so malformed text must be
// rejected as an invalid parameter. Coercing parse failures to a usable number
// can turn a bad request into a real quota operation.
function checkJavaRequiredNumericParsing(files, errors) {
  for (const file of files) {
    const text = stripJavaComments(fs.readFileSync(file, "utf8"));
    if (!/expensecontrol\.(?:consult|quota)|apply_amount|refund_amount|applyAmount|refundAmount/i.test(text)) continue;
    for (const method of extractMethods(text)) {
      if (!/(?:parse|read|to)[A-Za-z0-9_]*(?:Amount|Number|Long)|(?:Amount|Number|Long)[A-Za-z0-9_]*(?:parse|read|value)/i.test(method.name)) continue;
      const hasNumericParser = /\b(?:Long|Integer|BigDecimal|Double)\s*\.\s*(?:parseLong|parseInt|valueOf|parseDouble)\s*\(/.test(method.body)
        || /\bnew\s+BigDecimal\s*\(/.test(method.body);
      if (!hasNumericParser) continue;
      const returnsDefaultNumber = /\breturn\s+[-+]?(?:0+(?:\.0+)?|1(?:\.0+)?)\s*[LlFfDd]?\s*;/.test(method.body);
      const handlesInvalidInput = /\bcatch\s*\(\s*(?:NumberFormatException|IllegalArgumentException|Exception)\b/.test(method.body)
        || /\b(?:null|isEmpty|isBlank|trim\s*\(\s*\)\s*\.\s*isEmpty)\b/.test(method.body);
      if (returnsDefaultNumber && handlesInvalidInput) {
        errors.push(`${rel(file)}: ${method.name}(...) coerces a missing or malformed required SPI numeric field to a business value; reject invalid input with INVALID_PARAMETER instead of defaulting the amount`);
      }
    }
  }
}

// Whether the platform expects a signed response is a deployment-time contract.
// A signing exception cannot safely switch that contract to unsigned at runtime.
function checkJavaSpiResponseSigningPolicy(files, errors) {
  for (const file of files) {
    const text = stripJavaComments(fs.readFileSync(file, "utf8"));
    if (!/expensecontrol|SPI/i.test(text) || !/\.\s*sign\s*\(/.test(text)) continue;
    for (const method of extractMethods(text)) {
      if (!/\.\s*sign\s*\(/.test(method.body)) continue;
      for (const catchBody of catchBodies(method.body)) {
        const returnsUnsignedEnvelope = /\breturn\b[\s\S]{0,500}(?:response|responseNode|responseJson)/i.test(catchBody)
          && !/\bthrow\b|businessFailure|SYSTEM_ERROR|SIGN(?:ATURE)?_ERROR|setStatus\s*\(\s*5\d\d|HttpStatus\s*\.\s*(?:INTERNAL_SERVER_ERROR|SERVICE_UNAVAILABLE)/i.test(catchBody);
        if (returnsUnsignedEnvelope) {
          errors.push(`${rel(file)}: ${method.name}(...) falls back to an unsigned SPI response after response signing fails; select signed or unsigned mode explicitly in configuration, and fail closed when signing is required`);
        }
      }
    }
  }
}

function checkUnusedSdkMethodParams(files, errors) {
  for (const file of files) {
    const text = fs.readFileSync(file, "utf8");
    for (const method of extractMethods(text)) {
      if (!/Alipay[A-Za-z0-9]+Request|alipayClient\.execute\s*\(/.test(method.body)) continue;
      for (const param of method.params) {
        if (!param.name || param.name === "request" || param.name === "response") continue;
        const bodyWithoutSignature = method.body.slice(method.body.indexOf("{") + 1);
        const uses = new RegExp(`\\b${escapeRegExp(param.name)}\\b`).test(bodyWithoutSignature);
        if (!uses) errors.push(`${rel(file)}: public SDK method ${method.name}(...) declares parameter ${param.name} but never applies it to the request/model`);
      }
    }
  }
}

function extractMethods(text) {
  const methods = [];
  const pattern = /\b(?:public|private|protected)\s+(?:static\s+)?[A-Za-z0-9_<>, ?\[\]]+\s+([A-Za-z0-9_]+)\s*\(([^)]*)\)\s*(?:throws\s+[^{]+)?\{/g;
  for (const m of text.matchAll(pattern)) {
    const open = m.index + m[0].length - 1;
    const close = findMatchingBrace(text, open);
    if (close < 0) continue;
    methods.push({
      name: m[1],
      params: parseParams(m[2]),
      body: text.slice(open, close + 1),
    });
  }
  return methods;
}

function parseParams(params) {
  return params.split(",").map((part) => part.trim()).filter(Boolean).map((part) => {
    const cleaned = part.replace(/@\w+(?:\([^)]*\))?\s*/g, "").trim();
    const pieces = cleaned.split(/\s+/);
    return { name: pieces[pieces.length - 1].replace(/\[\]$/, "") };
  });
}

function findMatchingBrace(text, open) {
  let depth = 0;
  let quote = null;
  let escaped = false;
  let lineComment = false;
  let blockComment = false;
  for (let i = open; i < text.length; i++) {
    const ch = text[i];
    const next = text[i + 1];

    if (lineComment) {
      if (ch === "\n") lineComment = false;
      continue;
    }
    if (blockComment) {
      if (ch === "*" && next === "/") {
        blockComment = false;
        i++;
      }
      continue;
    }
    if (quote) {
      if (escaped) {
        escaped = false;
      } else if (ch === "\\") {
        escaped = true;
      } else if (ch === quote) {
        quote = null;
      }
      continue;
    }

    if (ch === "/" && next === "/") {
      lineComment = true;
      i++;
      continue;
    }
    if (ch === "/" && next === "*") {
      blockComment = true;
      i++;
      continue;
    }
    if (ch === "\"" || ch === "'" || ch === "`") {
      quote = ch;
      continue;
    }

    if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}

function stripJsComments(text) {
  return text.replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");
}

function stripJavaComments(text) {
  return text.replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");
}

function checkSdkStubs(files, errors) {
  const sdkPath = `${path.sep}src${path.sep}main${path.sep}java${path.sep}com${path.sep}alipay${path.sep}api${path.sep}`;
  const offenders = [];
  for (const file of files) {
    const text = fs.readFileSync(file, "utf8");
    if (file.includes(sdkPath) || /^\s*package\s+com\.alipay\.api(\.|;)/m.test(text) || /Stub implementation for compilation purposes/.test(text)) {
      offenders.push(rel(file));
    }
  }
  if (offenders.length) {
    const sample = offenders.slice(0, 8).join(", ");
    const suffix = offenders.length > 8 ? `, ... ${offenders.length - 8} more` : "";
    errors.push(`generated code must not define local Alipay SDK stubs or shadow com.alipay.api classes; remove ${offenders.length} offending files and use the official alipay-sdk-java dependency: ${sample}${suffix}`);
  }
}

function checkSdkReflectionBypass(files, errors) {
  for (const file of files) {
    const text = stripJavaComments(fs.readFileSync(file, "utf8"));
    const sdkRelevant = /com\.alipay\.api|Alipay[A-Za-z0-9_]*(?:Request|Response|Model)|alipayClient\s*\.\s*execute/.test(text);
    const reflectionBypass = /java\.lang\.reflect|Class\s*\.\s*forName\s*\(|\.get(?:Declared)?(?:Method|Field|Constructor)s?\s*\(|\.invoke\s*\(|\.setAccessible\s*\(|BeanUtils|PropertyUtils/.test(text);
    if (sdkRelevant && reflectionBypass) {
      errors.push(`${rel(file)}: generated Java must not use reflection/BeanUtils to bypass official SDK Request/Model/Response compile-time types; inspect the SDK jar with jar tf or javap and use real getters/setters`);
    }
  }
}

function checkPackagePaths(files, errors) {
  const src = `${path.sep}src${path.sep}main${path.sep}java${path.sep}`;
  for (const file of files) {
    const text = fs.readFileSync(file, "utf8");
    const m = text.match(/^\s*package\s+([a-zA-Z0-9_.]+)\s*;/m);
    if (!m || !file.includes(src)) continue;
    const expected = path.dirname(file).slice(file.indexOf(src) + src.length).split(path.sep).join(".");
    if (m[1] !== expected) errors.push(`${rel(file)}: package ${m[1]} does not match path ${expected}`);
  }
}

function walk(dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory() && shouldSkipDir(entry.name)) return [];
    return entry.isDirectory() ? walk(full) : [full];
  });
}

function shouldSkipDir(name) {
  return new Set([".git", ".idea", ".codefuse", "node_modules", "target", "dist", "build", "coverage", "vendor", "bin", "obj", "__pycache__", ".venv", "venv"]).has(name);
}

function toSetter(field) {
  return `set${field.split("_").map((p) => p ? p[0].toUpperCase() + p.slice(1) : "").join("")}`;
}

function isRequired(value) {
  return /^(必须|必选)$/.test(value);
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function rel(file) { return path.relative(targetDir, file); }

function report(name, errors, warnings) {
  for (const w of warnings) console.warn(`[${name}] WARN ${w}`);
  if (errors.length) {
    for (const e of errors) console.error(`[${name}] ERROR ${e}`);
    process.exit(1);
  }
  console.log(`[${name}] OK`);
}

function fail(msg) {
  console.error(`[alipay-enterprise-expense-control] ERROR ${msg}`);
  process.exit(1);
}
