---
name: alipay-enterprise-invoice
description: 支付宝企业码发票集成专用 Skill。当用户提到“企业码发票”“企业票夹”“发票推送”“发票消息”“发票通知”“WebSocket 消息”“企业抬头”“员工抬头”“开票规则”“发票查询”“发票批量查询”“alipay.ebpp.invoice.enterprise”“enterpriseopenrule”“employertitle”或要求生成企业发票接入方案/代码时必须使用。主推并默认采用推模式，基础接入必须完整覆盖企业抬头、开票规则、企业票夹发票变更通知和单笔发票查询；员工抬头以及企业抬头/发票批量查询只在明确选择时接入。
---

# 支付宝企业码发票集成 Skill

## 重要提示

支持两种使用方式：由方案型 Skill 调用时沿用上游已确定的模块、消息入口和技术栈；独立使用时按本文档完成决策。

生成方案或代码时：

1. 默认采用推模式。除非用户只要求解释单个接口，否则基础接入必须包含企业抬头、开票规则、发票消息和单笔发票查询四个必选模块。
2. 员工抬头、企业抬头批量查询和发票批量查询都是选接模块；只有用户主动提出或上下文明确需要时才读取和实现。
3. 接入某个模块时必须覆盖该模块下全部接口和必要通知，不得用批量接口替代必选单笔接口。
4. 生成前读取 [推模式发票流程](references/push-mode/push-mode-flow.md)、[发票通用代码生成规则](references/codegen-general-rules.md) 和 [发票字段与接口规则](references/field-interface-rules.md)，再按消息接入方式读取通用消息文档和技术栈质量门禁，最后按所选模块逐份读取接口文档。
5. 员工抬头接口文档标明“能力待升级、当前仅适用于特定企业、新接客户请勿使用”。选择该模块前必须确认接入方已获准使用；未确认时只列为准入阻塞项，不生成调用代码。
6. 发票消息必须完成真实验签、幂等和失败重试语义。业务处理成功后返回 `success`；验签失败、字段非法、查询失败或业务落库失败时返回 `fail`，让消息按文档策略重试。
7. 接口、字段、枚举、条件必填规则和 SDK 类型只来自已读取文档及真实 SDK。文档或 SDK 中找不到时明确说明，不猜测生成。
8. 生成接口调用代码前必须完成对应语言的 SDK 或 HTTP(S) 接入方式预检。Java/Maven 场景还必须检查真实 `alipay-sdk-java` 中 Request、Model、Response、`AlipayMsgClient` 和 `MsgHandler` 类及关键 setter/getter。
9. 已有项目只做增量改造：第一轮盘点现有 SDK、发票/票夹服务、消息入口、目录结构、发票/抬头/开票规则 Entity、Service、Repository、Controller、已实现接口和业务衔接点，输出拟新增/修改文件清单及 [已有项目衔接契约](references/integration-contract.md)。用户确认前不修改代码。
10. 按模块分段读取、分段生成、分段校验；基础推模式不得预读或实现选接接口。
11. 必选接口的文档字段在当前 SDK Model 中缺失时，先验证更新版本，再验证官方 Request `setBizContent(...)` + `AlipayClient.execute(...)` 路径，最后才考虑文档允许的手工 HTTP(S) 网关；仍无法实现则把模块标为阻塞并停止“完整交付”，不得用 `UnsupportedOperationException`、降级为部分枚举或注释说明后继续宣称 8 项能力齐全。
12. validator 退出码只代表自动门禁结果，不能覆盖交付事实。必选接口能力仍标记“未实现/阻塞/待确认”、fail-closed 默认实现没有通过独立 `@Configuration` 中带 `@ConditionalOnMissingBean(<Port>.class)` 的 `@Bean` 工厂装配、实现类仍被 `@Component/@Repository` 扫描、误标 `@Primary`，或项目已选择生产数据库却缺驱动或迁移时，validator 必须失败。合规的 fail-closed Port 边界表示集成扩展点已交付，不因部署方尚未绑定持久化 Bean 而失败。
13. Java 因 SDK Model 字段缺失时，只要官方 Request 暴露 `setBizContent(...)`，就必须交给 `AlipayClient.execute(...)` 完成请求签名与 RSA2 响应验签；只有 Request/SDK 托管执行确实不可用时才手工调用 HTTP(S) OpenAPI。手工路径必须在读取业务节点前用与 `sign_type` 一致的算法校验响应根节点 `sign`：签名原文是 `alipay_*_response` 对应的 JSON 值对象（从 `{` 到配对的 `}`），不包含响应键名和冒号，语义须与官方 `AlipaySignature.extractSignContent(...)` 一致；RSA2 使用 `rsa256CheckContent(...)`，或使用显式传入 `signType` 的五参 `rsaCheck(...)`/`rsaCertCheck(...)`，四参 `rsaCheckContent(...)` 固定为 RSA/SHA1，不能验证 RSA2。SDK 查询响应缺少 SINGLE 规则字段 getter 时，必须从原始响应体按 `invoice_rule_record_id` 关联补齐 `bill_scope`、`combined_pay_mode`、`default_invoice_kind` 三个专属字段；映射后以 typed record 的 `openMode` 为准逐条验证，SINGLE 缺原始记录、缺 ID、缺字段或字段空白都失败关闭，不能信任 raw body 的 `open_mode` 或对未匹配记录 `continue` 后返回半完整结果。
14. 开票规则修改接口没有 `open_mode` 时，不能把 SINGLE 三字段做成“全不填也继续调用”的可选路径：要么修改前查询并以现有 typed `openMode` 判定，SINGLE 强制补齐并发送三个字段；要么对修改命令始终要求三字段成组并逐值发送。禁止在无法判定模式时静默丢弃三字段。
15. 生产幂等实现必须把处理权绑定到 owner/token、版本号或等价所有权凭证，并以原子条件刷新、完成和释放；不能只按投递 ID 无条件释放或完成。取得处理权、重试重取和条件完成返回的对象、状态、凭证及结果都必须可判定，未知/空值、陈旧所有权和条件未命中统一失败关闭；Handler 只有确认当前处理者完成成功后才能确认消息。仅交付 fail-closed Port 边界时，不要求预置具体 Redis/DB 实现，也不限定接口、方法或状态命名。

由主方案 Skill 调用时，遵守上游阶段闸门；未进入发票阶段前不得读取发票接口文档。

由多 Agent 主方案调用时：

1. 第一轮输出 `已加载 Skill: alipay-enterprise-invoice (<SKILL.md 路径>)`，列出沿用的模式、必选模块、选接模块、消息入口和允许写入范围。
2. 只处理发票域代码和文档，不读取其他子 Skill。
3. 只生成或修改发票域写入范围，例如 `src/main/java/**/invoice/**`。
4. 不修改公共构建文件、公共配置、启动入口或跨域消息路由；需要这些改动时只在回执中提出。
5. 回执列出已读文档、生成文件、接口/通知覆盖和未覆盖边界。

## 步骤 1：确定接入范围

| 层级 | 模块 | 接口范围 | 决策 |
|---|---|---|---|
| 必选 | 企业抬头 | 创建、修改、单笔查询 | 默认接入 |
| 必选 | 开票规则 | 创建、修改、查询 | 默认接入 |
| 必选 | 发票消息 | 企业票夹票据变更通知 | 默认接入 |
| 必选 | 发票查询 | 单笔企业发票查询 | 默认接入 |
| 选接 | 员工抬头 | 新增关系、修改信息、失效关系 | 明确选择且确认准入后接入 |
| 选接 | 批量查询 | 企业抬头分页查询、企业发票分页查询 | 可分别选择 |

消息接入方式：

- 按“上游方案统一入口 > 用户明确指定 > 存量订阅或项目已有入口 > 新建项目默认”的优先级决定，高优先级结果直接沿用且不重复询问。
- 方案型 Skill 调用时沿用上游统一消息入口，不重复创建客户端或网关。
- 存量订阅或现有项目已使用 HTTP(S) / WebSocket 时保持原通道；除非用户明确要求迁移，不因 Java 默认推荐 WebSocket 而改造存量 HTTP 入口。
- 全新、独立且无其他约束的 Java 接入默认推荐官方 WebSocket 长连接 `AlipayMsgClient + MsgHandler`；消息量小或项目已有 HTTP 基础设施时也可明确选择 HTTP(S)。
- Node.js、Python、Go、.NET 等没有对应官方长连接 SDK 的技术栈使用 HTTP(S) 应用网关。
- 两种方式只选择一种作为同一消息订阅的投递通道；不要对 WebSocket 回调再次执行 HTTP 公共参数验签。

决策规则：

- 独立使用且用户没有声明模块时，直接采用四个必选模块，不重复询问是否需要推模式。
- 用户只提“接入发票”时，不默认加入任何选接模块。
- 用户明确要求员工抬头时，先提示准入限制并确认资格。
- 用户明确要求“批量接口”但未说明对象时，确认是企业抬头、发票，还是两者；上下文能够唯一推断时直接沿用。
- “批量查询”是补偿、初始化或运营查询能力，不能代替发票消息驱动的主链路。

## 步骤 2：按推模式接入

读取 [推模式发票流程](references/push-mode/push-mode-flow.md)，按以下顺序实施：

1. 企业抬头创建、修改和查询。
2. 开票规则创建、修改和查询，并把规则关联到真实企业抬头。
3. 企业票夹票据变更通知接收、验签、幂等和失败处理。
4. 根据通知中的 `enterprise_id`、`invoice_no` 和条件必填的 `invoice_code` 调用单笔发票查询。
5. 把发票详情衔接到已有发票、报销、账单或档案业务对象。
6. 仅在已选择时追加员工抬头或批量查询模块。

## 步骤 3：文档路由

| 模块 | 必读文档 |
|---|---|
| 企业抬头 | [创建](https://opendocs.alipay.com/pre-open/56c54fd5_alipay.ebpp.invoice.enterpriseexctrl.employertitle.create.md)、[修改](https://opendocs.alipay.com/pre-open/0885cf72_alipay.ebpp.invoice.enterpriseexctrl.employertitle.modify.md)、[查询](https://opendocs.alipay.com/pre-open/eff810f5_alipay.ebpp.invoice.enterpriseexctrl.employertitle.query.md) |
| 开票规则 | [创建](https://opendocs.alipay.com/pre-open/95f7dc20_alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create.md)、[修改](https://opendocs.alipay.com/pre-open/69d19f43_alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.modify.md)、[查询](https://opendocs.alipay.com/pre-open/bdb5adcb_alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.query.md) |
| 发票消息与查询 | [票据变更通知](https://opendocs.alipay.com/pre-open/6484d2dd_alipay.ebpp.invoice.enterprise.newinvoice.notify.md)、[单笔发票查询](https://opendocs.alipay.com/pre-open/560ca60c_alipay.ebpp.invoice.enterprise.invoiceinfo.query.md) |
| 消息接入 | [通用消息接口集成](https://opendocs.alipay.com/common/02km9j.md)；Java WebSocket 还需读取 [WebSocket 长连接接入](https://opendocs.alipay.com/common/02kiq1.md) |
| Java/Maven 门禁 | [Java/Maven 质量门禁](references/quality-gates/java-maven.md) |
| Node.js 门禁 | [Node.js 质量门禁](references/quality-gates/nodejs.md) |
| Python/Go/.NET 门禁 | [Python/Go/.NET 质量门禁](references/quality-gates/python-go-dotnet.md) |
| 员工抬头（选接） | [新增](https://opendocs.alipay.com/pre-open/c9319ba7_alipay.commerce.ec.employee.title.create.md)、[修改](https://opendocs.alipay.com/pre-open/5c494c5d_alipay.commerce.ec.employee.title.modify.md)、[失效](https://opendocs.alipay.com/pre-open/a71cb747_alipay.commerce.ec.employee.title.delete.md) |
| 企业抬头批量查询（选接） | [企业抬头分页查询](https://opendocs.alipay.com/pre-open/160305b4_alipay.ebpp.invoice.enterpriseexctrl.employertitle.batchquery.md) |
| 发票批量查询（选接） | [企业发票分页查询](https://opendocs.alipay.com/pre-open/35c7a6eb_alipay.ebpp.invoice.enterprise.invoiceinfo.batchquery.md) |

## 完成标准

交付前逐项确认：

- 基础接入完整覆盖 8 个必选接口/通知：企业抬头 3 个、开票规则 3 个、发票通知 1 个、单笔发票查询 1 个。
- HTTP(S) 通知以 `notify_id` 作为投递幂等键并返回 `success/fail`；WebSocket 以回调 `msgId` 作为投递幂等键，成功正常返回、失败抛异常触发重试。
- 两种接入方式都以企业和发票标识做业务去重，只有详情查询和真实业务处理成功后才确认消费完成。
- 投递幂等的处理中租约在首次取得、失败重试重新取得和超时重新取得时都刷新；旧 `FAILED` 记录不得带着过期时间重新进入 `PENDING`，避免同一通知被并发二次取得。
- 业务去重不能只查询或唯一约束 `notify_id`/`msgId`；至少对 `enterprise_id + invoice_no + invoice_code`（数电票允许空代码）形成的业务键做原子查询、唯一约束或等价的外部幂等写入，并覆盖“不同投递 ID、相同业务键”的测试。
- `invoice_code` 按 `invoice_kind` 的条件处理：数电票 `31`/`32` 可空，其他种类不可空。
- 单笔查询不能把网关成功直接视为可落库：调用前拒绝请求种类枚举外值；响应校验文档必填字段、种类及明细枚举和金额格式，并核对企业 ID、号码、种类以及非数电票代码与请求一致；`row_type` 缺失或空白按可选字段接受，非空才校验 `0/1/2`；残缺或错配时必须让通知重试。
- 通知对 `enterprise_id`、`employee_id`、`einv_id`、`invoice_no`、`invoice_kind`、`notify_reason`、`collect_source` 和条件必填的 `invoice_code` 做失败关闭校验，并拒绝文档枚举外的值。
- 响应除网关 `code/sub_code` 外还暴露业务 `success` 时，必须同时检查 typed response 的 `getSuccess()`；不能把 `AlipayResponse.isSuccess()` 当作业务 `success`。
- typed `success` 只有 `Boolean.TRUE` 才算成功；`null` 与 `false` 都失败关闭并有测试覆盖。
- 默认配置不会让生产环境使用 H2、`ddl-auto=update`、空环境变量默认凭据或占位凭据启动；H2 只能位于明确的 local/demo/test profile，空值和占位凭据必须在启动期失败。
- 默认/生产数据源的 JDBC 驱动随构建产物提供，`ddl-auto=validate` 配套 Flyway/Liquibase 或 `schema.sql`；空值、纯空白和占位支付宝凭据都在启动期拒绝。
- 占位凭据先 `trim`/`strip` 再判断；前导或尾随空白不能绕过 `REPLACE_WITH_*`、`CHANGE_ME`、`YOUR_*` 等占位值识别。
- 所有必选请求在 SDK 调用前校验文档必填、二选一、条件必填和枚举；不能只依赖 DTO 注释或支付宝网关报错。
- 必选字符串统一拒绝 `null`、空字符串和纯空白。单笔发票查询必须在发起请求前持有 `invoice_kind`，并据此校验 `invoice_code`；不能在收到响应后才推断请求是否合法。
- Java 生成前已对项目实际解析的 SDK 运行 `jar tf`/`javap` 核验类和关键成员，并通过真实依赖编译；接口证据表作为生成过程输出，不要求生成固定证据文件，也不由 validator 解析自然语言。
- Java SDK Model 缺字段且 Request 有 `setBizContent(...)` 时使用 `AlipayClient.execute(...)` 托管签名与验签；场景接入聚合 validator 不禁止这条官方 SDK 路径。开票规则 create 和 modify 都必须发送各自文档字段，不能让 modify 静默丢弃 SINGLE 三字段。测试捕获实际 Request，解析 `getBizContent()` 为 JSON 后逐项断言企业身份、规则 ID/名称与所有缺口字段的实际值；只用 `contains` 检查键名或只写 `execute(any())` 不算覆盖。开票规则查询按 `invoice_rule_record_id` 关联后，以 typed `openMode` 对每条 SINGLE 记录做非空白全量校验，并覆盖乱序、原始数组/记录缺失、raw `open_mode` 缺失时仍执行 typed 校验，以及空白字段测试。
- 生成 README、SDK 证据表、DTO/Javadoc 或配置注释时，与最终代码、配置及本轮 `javap` 结论一致；不得保留已删除的类/方法名、把 `setBizContent + AlipayClient.execute` 描述成手工 HTTP 网关、宣称所有请求都用 `setBizModel`，或保留已经被配置/实现替换的默认 H2、数据源或适配器描述。不要求创建固定名称的证据文件。
- 通知必须提供可替换的 `NotifyIdempotencyStore` 和 `InvoiceBusinessPort`。生成环境没有数据库依赖时，fail-closed 实现保持普通类，由独立 `@Configuration` 的 `@Bean` 方法创建，并把 `@ConditionalOnMissingBean(<Port>.class)` 标在该方法上；实现类不能再标 `@Component/@Repository`，也不能标 `@Primary`。这样既能在缺少生产实现时提供失败关闭 Bean，又能稳定让位于接入方实现，避免普通组件扫描的条件求值顺序移除唯一默认 Bean。未绑定真实实现时必须让通知失败并触发重试；生产持久化 Bean 的实际绑定属于部署就绪检查，不阻塞代码生成 validator 通过。
- 进程内 `Map`/`Set` 实现只能位于明确的 local/demo/test profile，不能成为无条件生产 Bean。项目选择内置持久化实现时才要求数据库驱动、业务唯一约束和真实数据库并发测试；只交付安全扩展边界时不强制引入数据库。
- Java 测试至少分别覆盖企业抬头、开票规则、单笔发票查询、通知/幂等和 SDK 未暴露字段的原始响应体映射；通知负例逐项覆盖 7 个必填字段与 3 个枚举。手工网关用 RSA2/SHA256 生成合法响应签名并验证正向通过，不能用 RSA/SHA1 向量替代。只有项目选择内置数据库持久化时，业务键测试才要求在真实数据库中覆盖并发唯一键冲突，不能用通知 ID 冲突或 Mockito 查询结果替代。
- 选接模块未被选择时，交付物中不出现对应接口调用。
- 已有项目若已提供业务持久化能力，通知与查询结果应接入真实业务对象；若当前生成环境未提供，则交付 fail-closed Port 边界并明确生产部署需绑定实现，不能用日志或内存旁路后返回成功。
- 已执行目标语言的依赖解析、构建和测试；Java 在删除或替换测试/实现后至少执行一次 `mvn clean test`，避免 `target` 中陈旧 class 和 surefire 报告污染结果；无法运行的检查及原因已明确列出。

最后运行本域官方自检：

```bash
node alipay-enterprise-invoice/scripts/validate_codegen.js <生成项目目录>
```

已有项目使用：

```bash
ALIPAY_PROJECT_MODE=existing node alipay-enterprise-invoice/scripts/validate_codegen.js <项目目录>
```

退出码 `0` 表示通过，`1` 表示生成结果不符合门禁，`2` 表示 validator 自身执行不可信。最终回执必须给出原始命令、退出码和最后几行输出；退出码非 `0` 时不得声明发票代码生成完成。
