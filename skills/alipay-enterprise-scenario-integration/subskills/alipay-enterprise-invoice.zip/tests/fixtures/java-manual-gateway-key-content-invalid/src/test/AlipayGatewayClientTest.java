class AlipayGatewayClientTest {
  void invalidResponseSign_isRejected() {}

  void validResponseSign_isAccepted() {
    String content = "\"alipay_example_response\":{\"code\":\"10000\"}";
    String responseSign = AlipaySignature.sign(content, privateKey, "UTF-8", "RSA2");
    assertDoesNotThrow(() -> gateway.verifyResponseSign(envelope(content, responseSign)));
  }
}
