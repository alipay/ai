class KnownSdkRequestBypass {
  static final String OPEN_RULE_CREATE =
      "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create";
  static final String EMPLOYER_TITLE_QUERY =
      "alipay.ebpp.invoice.enterpriseexctrl.employertitle.query";

  Object createSingle() {
    AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreateRequest request =
        new AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreateRequest();
    return gatewayClient.execute(OPEN_RULE_CREATE, bizContent);
  }

  Object queryByTaxNo() {
    AlipayEbppInvoiceEnterpriseexctrlEmployertitleQueryRequest request =
        new AlipayEbppInvoiceEnterpriseexctrlEmployertitleQueryRequest();
    return gatewayClient.execute(EMPLOYER_TITLE_QUERY, bizContent);
  }
}
