# Stale generated documentation

- SINGLE 经 HTTP(S) 网关实现，调用 `createSingleViaGateway`。
- 请求一律使用 `setBizModel`。
- 通知默认绑定 `FailClosedInvoiceBusinessAdapter`。
- 数据库默认使用嵌入式 H2。

| 接口 | SDK 成员 |
|---|---|
| 新增开票规则 open-rule create | `setBillScope/setCombinedPayMode/setDefaultInvoiceKind` |
