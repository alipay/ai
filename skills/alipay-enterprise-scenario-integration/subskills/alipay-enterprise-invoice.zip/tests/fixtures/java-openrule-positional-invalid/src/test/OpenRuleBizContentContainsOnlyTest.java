class OpenRuleBizContentContainsOnlyTest {
  void createSingle_onlyChecksKeyNames() {
    ArgumentCaptor<AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreateRequest> captor = requestCaptor();
    verify(executor).execute(captor.capture());
    String biz = captor.getValue().getBizContent();
    assertTrue(biz.contains("enterprise_id"));
    assertTrue(biz.contains("invoice_rule_name"));
    assertTrue(biz.contains("open_mode"));
    assertTrue(biz.contains("bill_scope"));
    assertTrue(biz.contains("combined_pay_mode"));
    assertTrue(biz.contains("default_invoice_kind"));
  }
}
