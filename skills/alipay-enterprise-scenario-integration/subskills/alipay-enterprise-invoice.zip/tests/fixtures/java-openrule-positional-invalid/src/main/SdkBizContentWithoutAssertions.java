class SdkBizContentWithoutAssertions {
  static final String METHOD_CREATE =
      "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create";
  void createSingle(String bizContent) {
    AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreateRequest request =
        new AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleCreateRequest();
    request.setBizContent(bizContent);
    executor.execute(request);
  }
}
