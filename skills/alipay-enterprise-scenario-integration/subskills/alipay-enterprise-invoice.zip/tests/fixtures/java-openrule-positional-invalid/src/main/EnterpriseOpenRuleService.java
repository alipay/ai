class EnterpriseOpenRuleService {
  static final String OPEN_MODE_SINGLE = "SINGLE";
  static final String[] SELLER_TYPES = {"MERCHANT", "TP"};
  static final String[] TAGS = {"DEFAULT", "EMPLOYEE_TITLE_FIRST"};

  Object query(EnterpriseIdentity identity, String invoiceRuleId) {
    require(!isBlank(invoiceRuleId), "invoiceRuleId required");
    String body = execute(identity, invoiceRuleId).getBody();
    List<RawRecord> rawRecords = read(body, "enterprise_open_rule_record_info_list");
    for (int i = 0; i < typedRecords.size(); i++) {
      TypedRecord typed = typedRecords.get(i);
      RawRecord raw = rawRecords.get(i);
      typed.setBillScope(raw.get("bill_scope"));
      typed.setCombinedPayMode(raw.get("combined_pay_mode"));
      typed.setDefaultInvoiceKind(raw.get("default_invoice_kind"));
    }
    return typedRecords;
  }
}
