const methods = [
  "alipay.ebpp.invoice.enterpriseexctrl.employertitle.create",
  "alipay.ebpp.invoice.enterpriseexctrl.employertitle.modify",
  "alipay.ebpp.invoice.enterpriseexctrl.employertitle.query",
  "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create",
  "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.modify",
  "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.query",
  "alipay.ebpp.invoice.enterprise.newinvoice.notify",
  "alipay.ebpp.invoice.enterprise.invoiceinfo.query",
];

function notify(params, store) {
  if (!sdk.checkNotifySignV2(params)) return "fail";
  store.tryAcquire(params.notify_id);
  const required = [params.enterprise_id, params.employee_id, params.einv_id, params.invoice_no,
    params.invoice_kind, params.notify_reason, params.collect_source];
  if (required.some((value) => !value)) return "fail";
  if (!["0", "1", "2", "3", "4", "31", "32"].includes(params.invoice_kind)) return "fail";
  if (!["INVOICE_COLLECT", "INVOICE_INFO_CHANGE"].includes(params.notify_reason)) return "fail";
  if (!["INVOICE_EMAIL", "OTHER"].includes(params.collect_source)) return "fail";
  if (!["31", "32"].includes(params.invoice_kind) && !params.invoice_code) return "fail";
  return "success";
}
