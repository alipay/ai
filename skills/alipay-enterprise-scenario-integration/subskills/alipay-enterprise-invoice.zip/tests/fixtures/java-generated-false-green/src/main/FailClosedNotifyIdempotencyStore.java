@Component
@ConditionalOnMissingBean(NotifyIdempotencyStore.class)
class FailClosedNotifyIdempotencyStore implements NotifyIdempotencyStore {
  boolean tryAcquire(String id, long now) { throw new InvoiceBusinessException("store missing"); }
  void markDone(String id) { throw new InvoiceBusinessException("store missing"); }
  void markFailed(String id) { throw new InvoiceBusinessException("store missing"); }
  boolean isDone(String id) { throw new InvoiceBusinessException("store missing"); }
}
