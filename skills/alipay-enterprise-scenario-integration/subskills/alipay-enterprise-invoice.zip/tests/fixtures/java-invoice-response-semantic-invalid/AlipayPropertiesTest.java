class AlipayPropertiesTest {
  void appIdReplaceWithPlaceholder_isRejected() {
    properties.appId = " REPLACE_WITH_APP_ID ";
    assertThrows(IllegalStateException.class, () -> properties.validate());
  }
}
