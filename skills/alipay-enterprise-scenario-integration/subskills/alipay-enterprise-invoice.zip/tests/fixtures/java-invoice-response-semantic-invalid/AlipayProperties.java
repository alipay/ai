class AlipayProperties {
  String appId = "REPLACE_WITH_APP_ID";

  void validate() {
    if (appId == null || appId.trim().isEmpty() || appId.trim().startsWith("REPLACE_WITH_")) {
      throw new IllegalStateException();
    }
  }
}
