class InvoiceNotifyServiceTest {
  protected boolean verifySignature() {
    return true;
  }
}
