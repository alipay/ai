class EnterpriseTitleService {
  void create() {
    AlipayEbppInvoiceEnterpriseexctrlEmployertitleCreateResponse createResponse = execute();
    AlipayEbppInvoiceEnterpriseexctrlEmployertitleModifyResponse modifyResponse = execute();
  }
}

class EnterpriseOpenRuleService {
  void modify() {
    AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyResponse response = execute();
  }

  void validate(String openMode) {
    if ("SINGLE".equals(openMode)) throw new UnsupportedOperationException("only SUMMARY is supported");
  }
}

class EnterpriseInvoiceQueryService {
  void mapFromBody() {
    String body = response.getBody();
    parse("invoice_item_list", body);
  }
}
