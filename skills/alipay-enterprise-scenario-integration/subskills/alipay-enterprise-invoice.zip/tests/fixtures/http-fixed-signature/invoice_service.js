const methods = [
  "alipay.ebpp.invoice.enterpriseexctrl.employertitle.create",
  "alipay.ebpp.invoice.enterpriseexctrl.employertitle.modify",
  "alipay.ebpp.invoice.enterpriseexctrl.employertitle.query",
  "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create",
  "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.modify",
  "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.query",
  "alipay.ebpp.invoice.enterprise.newinvoice.notify",
  "alipay.ebpp.invoice.enterprise.invoiceinfo.query",
];

function verifyNotifySignature() {
  return true;
}

function handleNotification(params, idempotencyStore) {
  if (!verifyNotifySignature(params)) return "fail";
  idempotencyStore.tryAcquire(params.notify_id);
  const invoiceKind = params.invoice_kind;
  const invoiceCode = params.invoice_code;
  return invoiceKind && invoiceCode ? "success" : "fail";
}

module.exports = { handleNotification, methods };
