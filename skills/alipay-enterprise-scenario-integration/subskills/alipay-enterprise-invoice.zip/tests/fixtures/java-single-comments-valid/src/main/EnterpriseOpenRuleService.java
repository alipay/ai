class EnterpriseOpenRuleService {
  // open_mode 仅 SUMMARY / SINGLE；这是一条合法枚举说明。
  // 阻塞分支返回 InvoiceCallException，而非 UnsupportedOperationException。
  private static final String[] MODES = {"SUMMARY", "SINGLE"};
  private static final String[] SELLER_TYPES = {"MERCHANT", "TP"};
  private static final String[] TAGS = {"DEFAULT", "EMPLOYEE_TITLE_FIRST"};

  void validateOpenMode(String mode) {
    if (!"SUMMARY".equals(mode) && !"SINGLE".equals(mode)) {
      throw new IllegalArgumentException("open_mode 非法");
    }
  }

  void validateSingleFields(String mode, String billScope) {
    if ("SINGLE".equals(mode) && billScope == null) {
      throw new IllegalArgumentException("SINGLE 模式 bill_scope 必填");
    }
    if (billScope != null && billScope.length() > 64) {
      throw new IllegalArgumentException("bill_scope 过长");
    }
  }
}

class FailClosedNotifyIdempotencyStore implements NotifyIdempotencyStore {
  boolean tryAcquire(String id, long now) { throw new IllegalStateException("persistent store not configured"); }
  void markDone(String id) { throw new IllegalStateException("persistent store not configured"); }
  void markFailed(String id) { throw new IllegalStateException("persistent store not configured"); }
  boolean isDone(String id) { throw new IllegalStateException("persistent store not configured"); }
}

@Profile({"local", "demo", "test"})
class LocalInvoiceBusinessAdapter implements InvoiceBusinessPort {
  private final Map<String, Object> records = new ConcurrentHashMap<String, Object>();
  boolean persist(Object record) { return records.putIfAbsent(record.toString(), record) == null; }
}
