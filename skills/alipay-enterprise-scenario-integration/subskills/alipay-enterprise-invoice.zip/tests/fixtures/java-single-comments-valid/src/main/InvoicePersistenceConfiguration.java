@Configuration
class InvoicePersistenceConfiguration {
  @Bean
  @ConditionalOnMissingBean(InvoiceBusinessPort.class)
  InvoiceBusinessPort invoiceBusinessPort() {
    return new FailClosedInvoiceBusinessAdapter();
  }

  @Bean
  @ConditionalOnMissingBean(NotifyIdempotencyStore.class)
  NotifyIdempotencyStore notifyIdempotencyStore() {
    return new FailClosedNotifyIdempotencyStore();
  }
}
