const methods = [
  "alipay.ebpp.invoice.enterpriseexctrl.employertitle.create",
  "alipay.ebpp.invoice.enterpriseexctrl.employertitle.modify",
  "alipay.ebpp.invoice.enterpriseexctrl.employertitle.query",
  "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create",
  "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.modify",
  "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.query",
  "alipay.ebpp.invoice.enterprise.newinvoice.notify",
  "alipay.ebpp.invoice.enterprise.invoiceinfo.query",
];

function handleNotification(params, idempotencyStore) {
  idempotencyStore.tryAcquire(params.notifyId);
  const required = [params.enterprise_id, params.employee_id, params.einv_id, params.invoice_no,
    params.invoice_kind, params.notify_reason, params.collect_source];
  if (required.some((value) => !value)) throw new Error("missing field");
  if (!["0", "1", "2", "3", "4", "31", "32"].includes(params.invoice_kind)) throw new Error("invoice kind");
  if (!["INVOICE_COLLECT", "INVOICE_INFO_CHANGE"].includes(params.notify_reason)) throw new Error("notify reason");
  if (!["INVOICE_EMAIL", "OTHER"].includes(params.collect_source)) throw new Error("collect source");
  if (!["31", "32"].includes(params.invoice_kind) && !params.invoice_code) throw new Error("invoice code");
}

module.exports = { handleNotification, methods };
