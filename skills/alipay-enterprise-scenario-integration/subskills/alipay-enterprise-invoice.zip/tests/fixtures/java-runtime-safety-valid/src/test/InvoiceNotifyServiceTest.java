class InvoiceNotifyServiceTest {
  void missingEnterpriseId_returnsFail() {}
  void missingEmployeeId_returnsFail() {}
  void missingEinvId_returnsFail() {}
  void missingInvoiceNo_returnsFail() {}
  void missingInvoiceKind_returnsFail() {}
  void missingNotifyReason_returnsFail() {}
  void missingCollectSource_returnsFail() {}
  void invalidInvoiceKind_returnsFail() {}
  void invalidNotifyReason_returnsFail() {}
  void invalidCollectSource_returnsFail() {}
  void processingConflict_triggersRetry() {}
  void businessPortPersistFailure_retriesAgain() {
    verify(queryService, times(2)).query();
    verify(businessPort, times(2)).persist();
  }
}
