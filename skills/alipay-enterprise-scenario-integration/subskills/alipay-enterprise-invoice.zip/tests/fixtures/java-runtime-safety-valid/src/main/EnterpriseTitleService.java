class EnterpriseTitleService {
  void create(TitleRequest request) {
    require(request.getIdentity() != null, "identity required");
    require(!isBlank(request.getTitleName()), "titleName required");
    require(!isBlank(request.getTaxRegisterNo()), "taxRegisterNo required");
  }

  void modify(TitleRequest request) {
    require(!isBlank(request.getTitleId()), "titleId required");
    require(!isBlank(request.getTitleName()), "titleName required");
    require(!isBlank(request.getTaxRegisterNo()), "taxRegisterNo required");
  }

  Object query(EnterpriseIdentity identity, String titleId) {
    require(!isBlank(titleId), "titleId required");
    return execute(identity, titleId);
  }

  EnterpriseTitleView mapQuery(
      EnterpriseTitleInfo info,
      AlipayEbppInvoiceEnterpriseexctrlEmployertitleQueryResponse response) {
    String titleCode = response.getTitleCode();
    return EnterpriseTitleView.from(info, titleCode);
  }
}

class EnterpriseTitleView {
  private String titleCode;

  static EnterpriseTitleView from(EnterpriseTitleInfo info, String titleCode) {
    EnterpriseTitleView view = new EnterpriseTitleView();
    view.titleCode = titleCode;
    return view;
  }

  String getTitleCode() {
    return titleCode;
  }
}
