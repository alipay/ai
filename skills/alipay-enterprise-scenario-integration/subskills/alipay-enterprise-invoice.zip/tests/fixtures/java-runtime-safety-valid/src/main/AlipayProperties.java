class AlipayProperties {
  String appId = "REPLACE_WITH_APP_ID";
  String privateKey = "CHANGE_ME";
  String alipayPublicKey = "YOUR_ALIPAY_PUBLIC_KEY";

  void validate() {
    validateCredential(appId);
    validateCredential(privateKey);
    validateCredential(alipayPublicKey);
  }

  void validateCredential(String value) {
    if (value == null) throw new IllegalStateException();
    String normalized = value.trim();
    if (normalized.isEmpty() || normalized.startsWith("REPLACE_WITH_")
        || normalized.equals("CHANGE_ME") || normalized.startsWith("YOUR_")) {
      throw new IllegalStateException();
    }
  }
}
