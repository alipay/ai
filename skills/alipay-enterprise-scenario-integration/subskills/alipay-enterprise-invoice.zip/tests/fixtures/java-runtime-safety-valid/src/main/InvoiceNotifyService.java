class InvoiceNotifyService {
  static final String METHOD = "alipay.ebpp.invoice.enterprise.newinvoice.notify";
  static final String[] KINDS = {"0", "1", "2", "3", "4", "31", "32"};
  static final String[] REASONS = {"INVOICE_COLLECT", "INVOICE_INFO_CHANGE"};
  static final String[] SOURCES = {"INVOICE_EMAIL", "OTHER"};

  boolean validate(NotifyBiz biz) {
    return !isBlank(biz.getEnterpriseId()) && !isBlank(biz.getEmployeeId())
        && !isBlank(biz.getEinvId()) && !isBlank(biz.getInvoiceNo())
        && !isBlank(biz.getInvoiceKind()) && !isBlank(biz.getNotifyReason())
        && !isBlank(biz.getCollectSource());
  }
}
