class EnterpriseInvoiceQueryService {
  static final Set<String> VALID_INVOICE_KINDS = setOf("0", "1", "2", "3", "4", "31", "32");
  static final Set<String> DIGITAL_INVOICE_KINDS = setOf("31", "32");
  static final Set<String> VALID_ROW_TYPES = setOf("0", "1", "2");
  static final Set<String> VALID_INVOICE_CHECK_RESULTS = setOf("WAIT_CHECK", "REAL_INVOICE");
  static final Set<String> VALID_SPECIFIC_FACTORS = setOf("RAILWAY", "AIR_TRANSPORTATION");

  Object query(String enterpriseId, String invoiceNo, String invoiceKind, String invoiceCode) {
    require(!isBlank(enterpriseId), "enterpriseId required");
    require(!isBlank(invoiceNo), "invoiceNo required");
    require(VALID_INVOICE_KINDS.contains(invoiceKind), "invoiceKind invalid");
    boolean digital = DIGITAL_INVOICE_KINDS.contains(invoiceKind);
    if (!digital) require(!isBlank(invoiceCode), "invoiceCode required");
    Object model = new InvoiceinfoQueryModel();
    InvoiceResponse response = execute(model, enterpriseId, invoiceNo, invoiceCode);
    requireText(response.getEnterpriseId());
    requireText(response.getInvoiceNo());
    requireText(response.getInvoiceType());
    requireText(response.getInvoiceKind());
    requireText(response.getInvoiceDate());
    requireText(response.getSumAmount());
    requireText(response.getPayerName());
    requireText(response.getPayerRegisterNo());
    requireText(response.getPayeeName());
    requireSame(enterpriseId, response.getEnterpriseId());
    requireSame(invoiceNo, response.getInvoiceNo());
    requireSame(invoiceKind, response.getInvoiceKind());
    boolean responseDigital = DIGITAL_INVOICE_KINDS.contains(response.getInvoiceKind());
    if (!responseDigital) {
      requireText(response.getInvoiceCode());
      requireSame(invoiceCode, response.getInvoiceCode());
    }
    requireEnum(response.getInvoiceType(), "blue", "red");
    requireEnum(response.getInvoiceKind(), "0", "1", "2", "3", "4", "31", "32");
    if (!isBlank(response.getInvoiceCheckResult())) {
      require(VALID_INVOICE_CHECK_RESULTS.contains(response.getInvoiceCheckResult()), "invoiceCheckResult invalid");
    }
    if (!isBlank(response.getSpecificFactor())) {
      require(VALID_SPECIFIC_FACTORS.contains(response.getSpecificFactor()), "specificFactor invalid");
    }
    for (InvoiceItem item : response.getInvoiceItemList()) {
      requireText(item.getItemName());
      requireText(item.getAmount());
      requireText(item.getTax());
      requireText(item.getTaxRate());
      if (!isBlank(item.getRowType())) require(VALID_ROW_TYPES.contains(item.getRowType()), "rowType invalid");
    }
    if (response.getFileDownloadUrl() != null) requireEnum(response.getFileType(), "ofd", "pdf");
    return response.getBody("invoice_item_list");
  }
}
