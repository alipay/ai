class EnterpriseIdentity {
  static EnterpriseIdentity ofV2(String enterpriseId) {
    if (isBlank(enterpriseId)) throw new IllegalArgumentException();
    return new EnterpriseIdentity();
  }

  static EnterpriseIdentity ofV1(String accountId, String agreementNo) {
    if (isBlank(accountId) || isBlank(agreementNo)) throw new IllegalArgumentException();
    return new EnterpriseIdentity();
  }

  static boolean isBlank(String value) {
    return value == null || value.trim().isEmpty();
  }
}
