interface ProcessingLeaseRepository {
  @Query("UPDATE ProcessingRecord r SET r.state = 'PENDING', r.firstSeenAt = :now "
      + "WHERE r.deliveryId = :id AND r.state = 'FAILED'")
  int resumeExpiredProcessing(
      @Param("id") String id,
      @Param("now") long now);

  int reacquireStalePending(String id, long now, long staleBefore);
}
