class AlipayPropertiesTest {
  void appIdReplaceWithPlaceholder_isRejected() {
    properties.appId = " REPLACE_WITH_APP_ID ";
    assertThrows(IllegalStateException.class, () -> properties.validate());
  }

  void privateKeyChangeMePlaceholder_isRejected() {
    properties.privateKey = " CHANGE_ME ";
    assertThrows(IllegalStateException.class, () -> properties.validate());
  }

  void alipayPublicKeyYourPlaceholder_isRejected() {
    properties.alipayPublicKey = " YOUR_ALIPAY_PUBLIC_KEY ";
    assertThrows(IllegalStateException.class, () -> properties.validate());
  }
}
