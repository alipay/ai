class AlipayGatewayClientTest {
  void invalidResponseSign_isRejected() {}
  void missingResponseSign_isRejected() {}
  void tamperedResponseSign_isRejected() {}
  void validResponseSign_isAccepted() {
    String signedContent = "{\"code\":\"10000\"}";
    String responseSign = AlipaySignature.sign(signedContent, privateKey, "UTF-8", "RSA2");
    assertDoesNotThrow(() -> gateway.verifyResponseSign(envelope(signedContent, responseSign)));
  }
}
