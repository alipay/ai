class EnterpriseTitleServiceTest {
  void blankTitleNameTaxRegisterNoAndTitleId_areRejected() {}
  void query_mapsTypedTitleCode() {
    response.setTitleCode("TC-001");
  }
  void query_missingTitleInfo_throws() {}
}
