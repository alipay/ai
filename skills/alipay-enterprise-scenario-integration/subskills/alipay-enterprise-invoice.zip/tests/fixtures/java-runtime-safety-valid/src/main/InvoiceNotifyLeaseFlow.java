interface InvoiceNotifyIdempotencyStore {
  ProcessingClaim claim(String messageId);
  boolean finish(String messageId, String ownerToken);
}

class InvoiceNotifyLeaseFlow {
  private InvoiceNotifyIdempotencyStore store;

  boolean handle(String messageId) {
    ProcessingClaim claim = store.claim(messageId);
    if (claim == null) return false;
    AcquireOutcome outcome = claim.getStatus();
    if (outcome == null) return false;
    if (outcome != AcquireOutcome.ACQUIRED) return false;
    String ownerToken = claim.getToken();
    if (ownerToken == null || ownerToken.trim().isEmpty()) return false;
    return store.finish(messageId, ownerToken);
  }
}
