class AlipayGatewayClient {
  String execute(Map<String, String> params) {
    params.put("sign", AlipaySignature.sign(params, privateKey, charset, signType));
    HttpURLConnection connection = openConnection();
    String body = postForm(connection, params);
    String sign = root(body).get("sign");
    String content = root(body).get("response");
    if (!AlipaySignature.rsa256CheckContent(content, sign, alipayPublicKey, charset)) {
      throw new InvoiceCallException("invalid response sign");
    }
    return body;
  }
}
