@ClientEndpoint
class InvoiceMessageClient {
  static final String METHOD = "alipay.ebpp.invoice.enterprise.newinvoice.notify";
  void onMessage(String message) {
    String invoiceKind = "0";
    String invoiceCode = null;
    processedNotify.putIfAbsent(message, true);
  }
}
