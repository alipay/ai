class EnterpriseInvoiceQueryServiceTest {
  void mapFromBody_invoice_item_list() {}
}
