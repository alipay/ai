class EnterpriseInvoiceQueryService {
  Object query(String enterpriseId, String invoiceNo) {
    return response.getBody("invoice_item_list");
  }
}
