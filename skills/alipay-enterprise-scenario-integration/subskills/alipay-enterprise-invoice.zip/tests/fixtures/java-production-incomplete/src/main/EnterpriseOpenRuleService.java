class EnterpriseOpenRuleService {
  static final String OPEN_MODE_SINGLE = "SINGLE";
  static final String[] SELLER_TYPES = {"MERCHANT", "TP"};
  static final String[] TAGS = {"DEFAULT", "EMPLOYEE_TITLE_FIRST"};

  void create(String openMode) {
    if (OPEN_MODE_SINGLE.equals(openMode)) {
      throw new InvoiceCallException("SINGLE 当前未实现，标记为阻塞");
    }
  }

  void modify() {
    AlipayEbppInvoiceEnterpriseconsumeEnterpriseopenruleModifyResponse resp = execute();
    Boolean businessSuccess = resp.getSuccess();
    if (businessSuccess != null && !businessSuccess) throw new InvoiceCallException();
  }

  Object query(Object identity, String invoiceRuleId) {
    Object model = new Object();
    return execute(model, invoiceRuleId);
  }
}
