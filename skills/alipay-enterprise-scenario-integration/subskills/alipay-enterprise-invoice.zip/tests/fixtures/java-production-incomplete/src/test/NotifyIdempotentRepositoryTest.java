@DataJpaTest
class NotifyIdempotentRepositoryTest {
  void concurrentNotifyId_throwsDataIntegrityViolationException() {
    assertThrows(DataIntegrityViolationException.class, () -> insertDuplicateNotifyId());
  }
}
