class AlipayProperties {
  String appId = "REPLACE_WITH_APP_ID";

  void validate() {
    if (appId.startsWith("REPLACE_WITH_")) throw new IllegalStateException();
  }
}
