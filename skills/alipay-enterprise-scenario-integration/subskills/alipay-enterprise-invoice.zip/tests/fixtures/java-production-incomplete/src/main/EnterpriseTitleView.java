class EnterpriseTitleView {
  private String titleCode;

  static EnterpriseTitleView from(EnterpriseTitleInfo info) {
    return new EnterpriseTitleView();
  }

  String getTitleCode() {
    return titleCode;
  }
}
