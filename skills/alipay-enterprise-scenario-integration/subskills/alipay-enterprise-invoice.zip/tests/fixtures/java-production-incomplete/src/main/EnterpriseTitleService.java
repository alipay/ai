class EnterpriseTitleService {
  void create() {
    AlipayEbppInvoiceEnterpriseexctrlEmployertitleCreateResponse resp = execute();
    Boolean businessSuccess = resp.getSuccess();
    if (businessSuccess != null && !businessSuccess) throw new InvoiceCallException();
  }

  void modify() {
    AlipayEbppInvoiceEnterpriseexctrlEmployertitleModifyResponse resp = execute();
    Boolean businessSuccess = resp.getSuccess();
    if (businessSuccess != null && !businessSuccess) throw new InvoiceCallException();
  }

  EnterpriseTitleView mapQuery(
      EnterpriseTitleInfo info,
      AlipayEbppInvoiceEnterpriseexctrlEmployertitleQueryResponse response) {
    String titleCode = readText(response.getBody(), "title_info", "title_code");
    return EnterpriseTitleView.from(info, titleCode);
  }
}
