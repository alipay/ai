interface InvoiceNotifyIdempotencyStore {
  ProcessingClaim claim(String messageId);
  void finish(String messageId, String ownerToken);
}

class InvoiceNotifyLeaseFlow {
  private InvoiceNotifyIdempotencyStore store;

  boolean handle(String messageId) {
    ProcessingClaim claim = store.claim(messageId);
    AcquireOutcome outcome = claim.getStatus();
    if (outcome != AcquireOutcome.ACQUIRED) return false;
    String ownerToken = claim.getToken();
    store.finish(messageId, ownerToken);
    return true;
  }
}
