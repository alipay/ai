class AlipayGatewayClient {
  String execute(Map<String, String> params) {
    params.put("sign", AlipaySignature.sign(params, privateKey, charset, signType));
    HttpURLConnection connection = openConnection();
    String body = postForm(connection, params);
    return responseNode(body).get("code").equals("10000") ? body : null;
  }
}
