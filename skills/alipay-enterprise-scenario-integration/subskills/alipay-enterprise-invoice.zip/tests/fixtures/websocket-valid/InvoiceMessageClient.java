class InvoiceMessageClient {
  static final String METHOD = "alipay.ebpp.invoice.enterprise.newinvoice.notify";

  void start(InvoiceHandler handler, IdempotencyStore idempotencyStore) {
    AlipayMsgClient client = AlipayMsgClient.getInstance("app-id");
    client.setConnector("openchannel.alipay.com");
    client.setSecurityConfig("RSA2", "private-key", "alipay-public-key");
    client.setMessageHandler(new MsgHandler() {
      public void onMessage(String msgApi, String msgId, String bizContent) {
        if (!METHOD.equals(msgApi)) throw new IllegalArgumentException("unknown msgApi");
        IdempotencyState state = idempotencyStore.tryAcquire(msgId);
        if (state == IdempotencyState.PROCESSING) throw new IllegalStateException("retry later");
        if (state == IdempotencyState.DONE) return;
        InvoiceMessage message = parse(bizContent);
        if (message.enterpriseId == null || message.employeeId == null || message.einvId == null
            || message.invoiceNo == null || message.invoiceKind == null
            || message.notifyReason == null || message.collectSource == null) {
          throw new IllegalArgumentException("required invoice notification field is missing");
        }
        String invoiceKind = message.invoiceKind;
        String invoiceCode = message.invoiceCode;
        if (!Set.of("0", "1", "2", "3", "4", "31", "32").contains(invoiceKind)) {
          throw new IllegalArgumentException("unknown invoice kind");
        }
        if (!Set.of("INVOICE_COLLECT", "INVOICE_INFO_CHANGE").contains(message.notifyReason)) {
          throw new IllegalArgumentException("unknown notify reason");
        }
        if (!Set.of("INVOICE_EMAIL", "OTHER").contains(message.collectSource)) {
          throw new IllegalArgumentException("unknown collect source");
        }
        if (!"31".equals(invoiceKind) && !"32".equals(invoiceKind) && invoiceCode == null) {
          throw new IllegalArgumentException("invoiceCode is required");
        }
        handler.process(message);
        idempotencyStore.markDone(msgId);
      }
    });
    client.connect();
  }
}

class RequiredInvoiceApis {
  String[] methods = {
    "alipay.ebpp.invoice.enterpriseexctrl.employertitle.create",
    "alipay.ebpp.invoice.enterpriseexctrl.employertitle.modify",
    "alipay.ebpp.invoice.enterpriseexctrl.employertitle.query",
    "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.create",
    "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.modify",
    "alipay.ebpp.invoice.enterpriseconsume.enterpriseopenrule.query",
    "alipay.ebpp.invoice.enterprise.invoiceinfo.query"
  };
}

class InvoicePersistenceConfiguration {
  @Bean
  NotifyIdempotencyStore notifyIdempotencyStore() {
    return idempotencyStore;
  }
}
