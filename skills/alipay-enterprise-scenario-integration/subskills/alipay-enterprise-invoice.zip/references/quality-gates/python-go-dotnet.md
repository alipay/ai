# 发票 Python/Go/.NET 质量门禁

本文件约束 Python、Go、.NET 等非 Java/Node.js 技术栈。通用原则见 [发票通用代码生成规则](../codegen-general-rules.md)，字段来源见 [发票字段与接口规则](../field-interface-rules.md)。

1. 当前按 HTTP(S) 应用网关接入发票通知，不生成非官方 WebSocket 协议客户端。
2. 使用目标语言官方 SDK 的验签能力；没有可用 SDK 时按通用消息文档构造待验签原文并使用支付宝公钥验签，不得生成固定 `true` 或空验签。
3. 使用完整原始参数验签后再解析 `biz_content`，使用 `notify_id` 做投递幂等。
4. 成功返回 `success`、失败返回 `fail`；验签、字段校验、详情查询或业务处理失败不得确认成功。
5. OpenAPI 字段严格来自接口文档，金额使用十进制定点类型。
6. 生成后运行本域 validator，并执行 Python 语法/测试、`go test ./...`、`dotnet build/test` 或目标语言等价检查。
