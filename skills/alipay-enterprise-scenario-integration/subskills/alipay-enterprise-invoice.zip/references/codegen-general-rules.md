# 发票通用代码生成规则

本文件适用于所有技术栈。字段和模块边界见 [发票字段与接口生成规则](field-interface-rules.md)。

## 接入与证据

1. 优先使用目标语言的官方支付宝 SDK；只有文档明确支持且目标语言无可用 SDK 时才使用手工 HTTP(S) 网关。Java 正常路径使用官方 `Request + Model + request.setBizModel(model)`；当实际 jar 经 `javap` 确认 Model 缺少文档必填 setter、但官方 Request 暴露 `setBizContent(String)` 时，允许序列化文档字段后继续通过 `AlipayClient.execute(request)` 调用，由 SDK 托管请求签名和响应验签。禁止影子 `com.alipay.api` 类、反射/Map 修改 SDK Model 或绕过官方 Client；Node.js 先核对实际安装包的导出和签名，将 `appAuthToken` 放在 SDK 要求的网关参数位置。
2. 新增接口前核验项目实际解析的依赖。Java 用 `jar tf` 确认类、用 `javap` 核验关键成员并通过真实依赖编译；生成过程记录版本、类名和结论即可，不默认创建固定证据文档，validator 不解析证据自然语言。用户要求保留证据时，内容必须与本轮实际 jar 和 `javap` 一致。
3. SDK 类或字段缺失时不猜测，依次验证可升级版本、官方 Request `setBizContent(...)` + SDK `execute(...)` 路径和文档允许的手工 HTTP(S) 路径。Request 暴露 `setBizContent` 时必须优先使用 SDK 托管执行，不能仅因 Model 缺 setter 就绕开 Client。手工 OpenAPI 必须先按配置的 `sign_type` 验证响应根节点 `sign`，再解析业务节点和判断 `code`；验签原文只包含 `alipay_*_response` 键对应的 JSON 值对象，不包含键名和冒号，与官方 `AlipaySignature.extractSignContent(...)` 语义一致。RSA2 使用 `rsa256CheckContent(...)` 或显式传 `signType` 的五参 `rsaCheck(...)`/`rsaCertCheck(...)`。仍不能实现的必选能力标记阻塞并保持 validator 非零，停止完整交付。

## 实现完整性

4. 不生成 stub、mock、空实现、固定成功或仅打印日志的业务路径。业务扩展可使用 Port/Adapter/回调，但核心 Service/Handler 只依赖接口；通知 Port 未绑定真实落地实现时失败关闭。Spring 默认失败实现保持普通类并由独立配置类的条件 `@Bean` 工厂装配，不能把 `@ConditionalOnMissingBean` 直接贴到被扫描的实现组件上。固定返回 `false` 的 adapter 仅限开发期，完整交付前须通过加载真实启动类的应用上下文验证。
5. 已有项目第一轮只盘点并输出衔接契约草案，用户确认前不修改代码、依赖或配置；实施时复用现有消息网关及发票、报销、账单、档案对象，不新建只写日志或只存幂等状态的旁路模块。
6. 所有必选请求在 SDK/网关调用前校验非空、组合关系、条件必填和枚举。SDK 网关成功不等于业务成功；typed `success` 只接受明确真值，`null`/`false` 均失败，Java `AlipayResponse.isSuccess()` 不能替代业务 `getSuccess()`。查询类成功响应继续校验文档必填字段、枚举、条件字段和请求响应身份一致性，残缺或错配的数据不得进入业务落地。

## 通知可靠性

7. HTTP(S) 通知使用完整原始参数真实验签并等待异步验签 helper；WebSocket 使用官方 `AlipayMsgClient + MsgHandler`，不手写协议、鉴权、心跳、ack，也不重复 HTTP 验签。验签失败、未知 `msg_method`/`msgApi`、未知通知原因或非法发票种类均失败关闭。
8. 投递幂等区分首次获得、已完成和处理中：HTTP(S) 使用 `notify_id`，WebSocket 使用 `msgId`；生产 Store 支持多实例和重启，内存 Map/Set 仅限 demo/test。详情查询和真实业务处理都成功后才完成；失败时释放处理权或记录为可重试，HTTP(S) 返回 `fail`，WebSocket 抛异常。
9. 投递幂等与业务幂等分层：业务层按企业、发票号码和可用发票代码形成稳定键，不同投递 ID 指向同一发票时仍只落地一次；数据库使用唯一约束并处理并发冲突，外部系统传递等价幂等键。处理中时间作为租约，首次、失败重取和超时重取都原子刷新，禁止历史 `FAILED` 记录携带旧租约进入处理中。
10. 生产幂等 Port 的完成、释放和续租必须校验同一 owner/token 或等价版本号；单独使用 `release(msgId)` 无法防止旧处理者释放新实例租约。只有生成真实生产存储实现时执行该门禁，fail-closed 扩展边界不要求预置存储。

## 配置与验证

10. 示例配置不含真实密钥、证书、令牌或业务/生产数据。H2 和自动改表仅限 local/demo/test profile；默认及生产使用外部共享 RDBMS，并随构建交付 JDBC driver、版本化迁移或 schema，完成非嵌入式数据源启动验证。凭据占位值在启动期失败关闭，先 `trim`/`strip` 再匹配，并测试空白、`null`、带前后空格的占位值和正常值。
11. 生成后运行格式化、依赖解析、编译和测试；Java 删除或替换类后至少执行一次 `mvn clean test`，不能让 `target` 中陈旧 class 或 surefire 报告充当测试证据。聚焦测试覆盖企业抬头、开票规则、单笔查询、消息验签/幂等/重试及 SDK 缺字段时的原始响应映射。单笔查询分别覆盖非法请求种类、成功响应必填字段缺失、响应种类与代码条件错配、明细映射、非法金额、非法 `row_type`，以及 `row_type` 缺失/空白仍成功；通知覆盖处理中冲突，并用调用次数或状态断言证明业务落地失败后确实重新执行。Spring 装配测试明确断言共享路由包含发票通知 API，路由数量大于零不能证明发票模块已接入。`setBizContent` workaround 捕获实际 Request，把 `getBizContent()` 解析为 JSON，并对身份、`open_mode` 与缺口字段逐值断言；字符串 `contains` 只证明键名出现，不算结构化测试。SINGLE 原始记录按 ID 补值后，以 typed `openMode` 驱动完整性校验；测试覆盖乱序、原始数组/记录缺失、raw `open_mode` 缺失不能绕过 typed 校验，以及空白字段。业务键并发测试必须触发真实数据库唯一约束。
12. README、接口证据表、DTO/Javadoc 和配置注释不是必选产物；一旦生成，必须在最终代码完成后复核。文档中的类、方法、默认配置和接入路径必须真实存在，并与本轮实际 jar 的 `javap` 结论一致；不能保留旧实现名、把 SDK 托管的 `setBizContent + execute` 写成手工 HTTP、笼统宣称请求一律使用 `setBizModel`，或描述已被替换的默认 H2/固定失败适配器。
13. 接口文档以 `interface-docs.json` 记录的官方 Markdown URL 为准，不在 Skill 内保留字段或枚举快照。运行依赖接口文档的校验时必须从官方 URL 获取当前内容并对临时网络失败重试；仍无法获取时不得使用历史值继续校验。
